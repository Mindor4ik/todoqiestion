package app.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.atan2

/**
 * Электронный уровень (горизонт) по акселерометру — для альбомной ориентации.
 * Линия поворачивается так, чтобы показывать реальный горизонт; зелёная — когда телефон ровный (±1°).
 */
class LevelView(c: Context) : View(c), SensorEventListener {
    private val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    @Suppress("DEPRECATION")
    private val display = (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay

    private val px = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2.5f * px; strokeCap = Paint.Cap.ROUND }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4.5f * px; strokeCap = Paint.Cap.ROUND; color = 0x88000000.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 12f * px; textAlign = Paint.Align.CENTER; color = 0xFFFFFFFF.toInt(); setShadowLayer(3f * px, 0f, 0f, 0xFF000000.toInt())
    }

    private var roll = 0f          // градусы, + = телефон наклонён по часовой
    private var ax = 0f
    private var ay = 0f
    private var have = false
    var active = false
        private set

    val available get() = acc != null

    fun enable(on: Boolean) {
        if (on == active) return
        active = on
        if (on) {
            visibility = VISIBLE
            acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        } else {
            sm.unregisterListener(this)
            visibility = GONE
            have = false
        }
    }

    /** Приложение ушло в фон — сенсор отпускаем; enable(true) снова включит. */
    fun suspend() { if (active) sm.unregisterListener(this) }
    fun resume() { if (active) acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        // Компоненты силы тяжести в осях ЭКРАНА (right/up) — как в официальном примере AxisSwap для поворотов дисплея.
        val x = e.values[0]
        val y = e.values[1]
        val right: Float
        val up: Float
        when (display.rotation) {
            Surface.ROTATION_90 -> { right = -y; up = x }
            Surface.ROTATION_270 -> { right = y; up = -x }
            Surface.ROTATION_180 -> { right = -x; up = -y }
            else -> { right = x; up = y }
        }
        // Сглаживание, чтобы линия не дрожала.
        ax = if (have) ax + 0.2f * (right - ax) else right
        ay = if (have) ay + 0.2f * (up - ay) else up
        have = true
        // Если телефон повернут по часовой на r, «верх мира» на экране смещён влево от «верха экрана»: right = -g·sin r, up = g·cos r.
        roll = Math.toDegrees(atan2(-ax.toDouble(), ay.toDouble())).toFloat()
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        if (!have) return
        val cx = width / 2f
        val cy = height / 2f
        val half = minOf(width, height) * 0.30f
        val gap = 22f * px
        val ok = abs(roll) < 1f
        line.color = if (ok) 0xFF30D158.toInt() else 0xFFFFD60A.toInt()

        // Неподвижные «усики» — где горизонт должен быть.
        for (s in intArrayOf(-1, 1)) {
            val x1 = cx + s * (half + 10f * px)
            cv.drawLine(x1, cy, x1 + s * 12f * px, cy, shadow)
            cv.drawLine(x1, cy, x1 + s * 12f * px, cy, line)
        }
        // Горизонт: поворот против наклона телефона.
        cv.save()
        cv.rotate(-roll, cx, cy)
        for (s in intArrayOf(-1, 1)) {
            cv.drawLine(cx + s * gap, cy, cx + s * half, cy, shadow)
            cv.drawLine(cx + s * gap, cy, cx + s * half, cy, line)
        }
        cv.restore()
        cv.drawText(if (ok) "0°" else "%+.1f°".format(roll), cx, cy - 10f * px, text)
    }
}
