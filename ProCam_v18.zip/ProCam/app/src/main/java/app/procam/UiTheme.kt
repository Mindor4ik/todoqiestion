package app.procam

import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View

enum class UiStyle(val label: String) { MATERIAL("Material"), GLASS("Liquid Glass") }

/**
 * Единый источник визуального языка. Палитра строго монохромная (чёрный / белый / серые):
 * чисто чёрный фон, полупрозрачные «стеклянные» поверхности с бликом и светлой кромкой, белый акцент (активное = белая заливка, чёрный текст).
 * Читается при построении UI; смена стиля = recreate().
 */
object Ui {
    var style: UiStyle = UiStyle.GLASS
    /** Плотность экрана: радиусы и обводки заданы в dp. */
    var density = 1f
    private fun dp(v: Float) = v * density
    private fun hair(): Int = dp(1f).toInt().coerceAtLeast(1)
    val glass get() = style == UiStyle.GLASS

    val accent get() = 0xFFFFFFFF.toInt()
    val onAccent get() = 0xFF000000.toInt()
    val rec get() = 0xFFFFFFFF.toInt()
    val ok get() = 0xFFFFFFFF.toInt()
    val text get() = 0xFFFFFFFF.toInt()
    val dim get() = if (glass) 0xFFB4B4B8.toInt() else 0xFF8E8E93.toInt()
    val root get() = 0xFF000000.toInt()
    val dock get() = 0xFF000000.toInt()
    val menuBg get() = if (glass) 0xD9161618.toInt() else 0xFF1C1C1E.toInt()

    enum class Kind { PANEL, CHIP, BUTTON, HUD, MENU }

    private fun radius(k: Kind): Float = when (k) {
        Kind.PANEL, Kind.MENU -> if (glass) 26f else 18f
        Kind.HUD -> if (glass) 14f else 10f
        else -> if (glass) 20f else 14f
    }

    private fun base(k: Kind, active: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radius(k))
        if (active) { g.setColor(accent); g.setStroke(hair(), accent); return g }
        when (k) {
            Kind.HUD -> { g.setColor(if (glass) 0x59000000 else 0x99000000.toInt()); g.setStroke(hair(), if (glass) 0x40FFFFFF else 0x00000000) }
            Kind.PANEL, Kind.MENU -> {
                g.setColor(if (glass) 0x9E1A1A1C.toInt() else 0xFF1C1C1E.toInt())
                g.setStroke(hair(), if (glass) 0x4DFFFFFF else 0xFF2C2C2E.toInt())
            }
            else -> {
                g.setColor(if (glass) 0x80303032.toInt() else 0xFF2C2C2E.toInt())
                g.setStroke(hair(), if (glass) 0x40FFFFFF else 0xFF3A3A3C.toInt())
            }
        }
        return g
    }

    /** Стеклянный блик сверху + базовая полупрозрачная подложка. */
    fun bg(k: Kind, active: Boolean = false): Drawable {
        val b = base(k, active)
        if (!glass || active) return b
        val sheen = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x40FFFFFF, 0x0DFFFFFF, 0x00000000, 0x12FFFFFF))
        sheen.cornerRadius = dp(radius(k))
        return LayerDrawable(arrayOf(b, sheen))
    }

    /** Капсула поверх превью (зум-«пилюли»). */
    fun pill(): Drawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(40f)
        g.setColor(if (glass) 0x66000000 else 0xB3000000.toInt())
        g.setStroke(hair(), if (glass) 0x40FFFFFF else 0x00000000)
        return g
    }

    /** Круглая подложка: у активной «пилюли» тёмная, у остальных прозрачная. */
    fun disc(on: Boolean): Drawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (on) 0xCC000000.toInt() else 0x00000000)
        return g
    }

    fun ripple(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, null)

    fun skin(v: View, k: Kind, active: Boolean = false) {
        v.background = ripple(bg(k, active))
        v.elevation = dp(if (glass) 4f else if (k == Kind.PANEL || k == Kind.MENU) 2f else 0.5f)
    }
}
