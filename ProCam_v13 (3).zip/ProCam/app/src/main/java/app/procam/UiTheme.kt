package app.procam

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View

enum class UiStyle(val label: String) { MATERIAL("Material"), GLASS("Liquid Glass") }

/** Единый источник визуального языка. Читается при построении UI; смена стиля = recreate(). */
object Ui {
    var style: UiStyle = UiStyle.MATERIAL
    /** Плотность экрана: радиусы и обводки заданы в dp. */
    var density = 1f
    private fun dp(v: Float) = v * density
    val glass get() = style == UiStyle.GLASS

    val accent get() = 0xFFFFB300.toInt()
    val onAccent get() = 0xFF1A1200.toInt()
    val text get() = if (glass) 0xFFF2F7FC.toInt() else 0xFFECEFF2.toInt()
    val dim get() = if (glass) 0xFFA8B6C6.toInt() else 0xFF9AA7B2.toInt()
    val root get() = if (glass) 0xFF05070C.toInt() else 0xFF0B0E11.toInt()
    val dock get() = if (glass) 0xB30A1018.toInt() else 0xFF101010.toInt()
    val menuBg get() = if (glass) 0xE60A1018.toInt() else 0xF2101418.toInt()

    enum class Kind { PANEL, CHIP, BUTTON, HUD, MENU }

    private fun radius(k: Kind): Float = when (k) {
        Kind.PANEL, Kind.MENU -> if (glass) 24f else 16f
        Kind.HUD -> if (glass) 16f else 10f
        else -> if (glass) 20f else 12f
    }

    private fun base(k: Kind, active: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radius(k))
        if (active) { g.setColor(accent); g.setStroke(dp(1f).toInt().coerceAtLeast(1), accent); return g }
        when (k) {
            Kind.HUD -> { g.setColor(if (glass) 0x660A1018.toInt() else 0x88000000.toInt()); g.setStroke(dp(1f).toInt().coerceAtLeast(1), if (glass) 0x2AFFFFFF else 0x00000000) }
            Kind.PANEL, Kind.MENU -> {
                g.setColor(if (glass) 0x8C141C28.toInt() else 0xFF151A20.toInt())
                g.setStroke(dp(1f).toInt().coerceAtLeast(1), if (glass) 0x2EFFFFFF else 0xFF2A333D.toInt())
            }
            else -> {
                g.setColor(if (glass) 0x731E2A3A.toInt() else 0xFF1D242C.toInt())
                g.setStroke(dp(1f).toInt().coerceAtLeast(1), if (glass) 0x24FFFFFF else 0xFF3C454D.toInt())
            }
        }
        return g
    }

    /** Стеклянный блик сверху + базовая полупрозрачная подложка. */
    fun bg(k: Kind, active: Boolean = false): Drawable {
        val b = base(k, active)
        if (!glass || active) return b
        val sheen = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x30FFFFFF, 0x0CFFFFFF, 0x00000000))
        sheen.cornerRadius = dp(radius(k))
        return LayerDrawable(arrayOf(b, sheen))
    }

    fun ripple(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(if (glass) 0x33FFFFFF else 0x33FFB300.toInt()), content, null)

    fun skin(v: View, k: Kind, active: Boolean = false) {
        v.background = ripple(bg(k, active))
        v.elevation = dp(if (glass) 4f else if (k == Kind.PANEL || k == Kind.MENU) 2f else 0.5f)
    }
}
