package app.procam

import java.io.BufferedReader

/**
 * 3D LUT из .cube. [data] — плоский массив RGB (size³ × 3), порядок как в файле:
 * R меняется быстрее всего, затем G, затем B (это же порядок x/y/z для glTexImage3D).
 * [domainMin]/[domainMax] — DOMAIN_MIN/DOMAIN_MAX (по умолчанию 0..1).
 */
class CubeLut(
    val title: String,
    val size: Int,
    val data: FloatArray,
    val domainMin: FloatArray = floatArrayOf(0f, 0f, 0f),
    val domainMax: FloatArray = floatArrayOf(1f, 1f, 1f)
)

object CubeLutReader {
    const val MAX_SIZE = 65
    private val WS = Regex("\\s+")

    fun read(reader: BufferedReader): CubeLut {
        var title = "Custom LUT"
        var size = 0
        var dMin = floatArrayOf(0f, 0f, 0f)
        var dMax = floatArrayOf(1f, 1f, 1f)
        var data = FloatArray(0)
        var count = 0
        var lineNo = 0

        fun triple(parts: List<String>, no: Int): FloatArray {
            if (parts.size != 4) error("Строка $no: ожидалось 3 числа после ${parts[0]}")
            return FloatArray(3) { k ->
                val f = parts[k + 1].toFloatOrNull()
                if (f == null || !f.isFinite()) error("Строка $no: «${parts[k + 1]}» — не число")
                f
            }
        }

        reader.forEachLine { raw ->
            lineNo++
            val line = raw.trimStart('﻿').substringBefore('#').trim()
            if (line.isEmpty()) return@forEachLine
            val parts = line.split(WS)
            val key = parts[0]

            if (key[0].isLetter()) {
                // Ключевое слово. Неизвестные расширения (LUT_3D_INPUT_RANGE и т.п.) спецификация разрешает пропускать.
                when (key.uppercase()) {
                    "TITLE" -> title = line.substring(key.length).trim().trim('"').ifBlank { title }
                    "LUT_3D_SIZE" -> {
                        val n = parts.getOrNull(1)?.toIntOrNull() ?: error("Строка $lineNo: некорректный LUT_3D_SIZE")
                        if (n !in 2..MAX_SIZE) error("Поддерживается LUT_3D_SIZE от 2 до $MAX_SIZE (в файле $n)")
                        size = n
                        data = FloatArray(n * n * n * 3)
                        count = 0
                    }
                    "LUT_1D_SIZE" -> error("Это 1D LUT — поддерживаются только 3D LUT (LUT_3D_SIZE)")
                    "DOMAIN_MIN" -> dMin = triple(parts, lineNo)
                    "DOMAIN_MAX" -> dMax = triple(parts, lineNo)
                    else -> Unit
                }
                return@forEachLine
            }

            if (size == 0) error("Строка $lineNo: данные раньше LUT_3D_SIZE")
            if (parts.size != 3) error("Строка $lineNo: ожидалось 3 числа, найдено ${parts.size}")
            if (count + 3 > data.size) error("Слишком много значений: ожидалось ${size * size * size} RGB-троек")
            for (k in 0..2) {
                val f = parts[k].toFloatOrNull()
                if (f == null || !f.isFinite()) error("Строка $lineNo: «${parts[k]}» — не число")
                data[count++] = f
            }
        }

        if (size == 0) error("В файле нет LUT_3D_SIZE — это не 3D .cube")
        if (count != data.size) error("Число RGB-значений ${count / 3}, ожидалось ${size * size * size}")
        for (k in 0..2) {
            if (dMax[k] <= dMin[k]) error("DOMAIN_MAX должен быть больше DOMAIN_MIN")
        }
        return CubeLut(title, size, data, dMin, dMax)
    }
}
