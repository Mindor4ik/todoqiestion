package app.procam

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow

/**
 * Лента выбора LUT над нижней полосой. Первая карточка — исходная сцена без LUT,
 * дальше — та же сцена с каждым импортированным LUT. Перелистывание применяет
 * центрированную карточку (во время записи — только просмотр), тап — тоже применяет.
 * Превью генерируются в фоне на процедурной сцене (небо, вода, зелень, кожа, серая шкала),
 * вход LUT считается так же, как в шейдере: LOG-кривая или Rec.709.
 */
class LutRibbon(
    ctx: Context,
    private val entries: () -> List<LutEntry>,
    private val activeUri: () -> String?,
    private val bakeOn: () -> Boolean,
    private val isRecording: () -> Boolean,
    private val inLog: () -> Boolean,
    private val curve: () -> Curve,
    private val parse: (String) -> CubeLut?,      // вызывается в фоне
    private val onPick: (LutEntry?) -> Unit,
    private val onBake: (Boolean) -> Unit,
    private val onAdd: () -> Unit,
    private val onClose: () -> Unit
) : FrameLayout(ctx) {

    private val px = resources.displayMetrics.density
    private fun dp(v: Int) = (v * px).toInt()
    private val main = Handler(Looper.getMainLooper())
    private val amber = 0xFFFFFFFF.toInt()

    private val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(0xE61C1C1E.toInt())
            setStroke(dp(1), 0xFF3A3A3C.toInt())
        }
    }
    private val bakeBtn = TextView(ctx)
    private val scroll = object : HorizontalScrollView(ctx) {
        override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
            super.onScrollChanged(l, t, oldl, oldt)
            if (suppress) return
            highlightCenter()
            scheduleSettle()
        }
    }.apply {
        isHorizontalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                main.removeCallbacks(settleRun)
                suppress = false
            }
            false
        }
    }
    private val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

    private val cards = ArrayList<View>()
    private val cardEntries = ArrayList<LutEntry?>()
    private val thumbs = LinkedHashMap<String, Bitmap>()
    private var base: Bitmap? = null
    private var gen = 0
    private var suppress = false
    private var thumbThread: HandlerThread? = null
    private var thumbHandler: Handler? = null
    private val settleRun = Runnable { settle() }

    val opened get() = visibility == VISIBLE

    init {
        visibility = GONE
        addView(root, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(ctx).apply {
            text = "LUT"
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        head.addView(title, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        styleChip(bakeBtn, false)
        bakeBtn.setOnClickListener { onBake(!bakeOn()); refresh() }
        head.addView(bakeBtn, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, dp(32)).apply { setMargins(dp(3), 0, dp(3), 0) })
        val add = TextView(ctx).apply { text = "+ .cube"; textSize = 12f }
        styleChip(add, false)
        add.setOnClickListener { onAdd() }
        head.addView(add, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, dp(32)).apply { setMargins(dp(3), 0, dp(3), 0) })
        val close = TextView(ctx).apply { text = "✕"; textSize = 14f; gravity = Gravity.CENTER }
        styleChip(close, false)
        close.setOnClickListener { onClose() }
        head.addView(close, LinearLayout.LayoutParams(dp(36), dp(32)).apply { setMargins(dp(3), 0, 0, 0) })
        root.addView(head, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        scroll.addView(row)
        root.addView(scroll, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(104)).apply { topMargin = dp(6) })
    }

    private fun styleChip(v: TextView, on: Boolean) {
        v.gravity = Gravity.CENTER
        v.setPadding(dp(10), 0, dp(10), 0)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (on) amber else 0xFF2C2C2E.toInt())
            setStroke(dp(1), if (on) amber else 0xFF3A3A3C.toInt())
        }
        v.setTextColor(if (on) Color.BLACK else 0xFFFFFFFF.toInt())
    }

    // ------------------------------------------------------------ открытие / закрытие

    fun open() {
        visibility = VISIBLE
        rebuild()
    }

    fun close() {
        visibility = GONE
        gen++
        main.removeCallbacks(settleRun)
    }

    fun release() {
        close()
        thumbThread?.quitSafely()
        thumbThread = null
        thumbHandler = null
    }

    fun rebuild() {
        gen++
        main.removeCallbacks(settleRun)
        cards.clear(); cardEntries.clear(); row.removeAllViews()
        val list = entries()
        addCard(null)
        for (e in list) addCard(e)
        refresh()
        ensureThumbThread()
        val g = gen
        val log = inLog(); val cv = curve()
        for (e in list) {
            val key = "${e.uri}|$log|$cv"
            val cached = thumbs[key]
            if (cached != null) continue
            thumbHandler?.post {
                if (g != gen) return@post
                val lut = try { parse(e.uri) } catch (x: Exception) { null }
                val bmp = if (lut != null) applyLut(scene(), lut, log, cv) else null
                if (bmp != null) {
                    thumbs[key] = bmp
                    while (thumbs.size > 32) thumbs.remove(thumbs.keys.first())
                }
                main.post {
                    if (g != gen) return@post
                    val i = cardEntries.indexOfFirst { it?.uri == e.uri }
                    if (i >= 0 && bmp != null) (cards[i].findViewWithTag<ImageView>("img")).setImageBitmap(bmp)
                }
            }
        }
        scroll.post {
            val cw = cards.firstOrNull()?.width ?: dp(128)
            val pad = ((scroll.width - cw) / 2).coerceAtLeast(0)
            row.setPadding(pad, 0, pad, 0)
            centerOn(activeIndex(), false)
        }
    }

    fun refresh() {
        if (!opened) return
        bakeBtn.text = if (bakeOn()) "→ видео: вкл" else "→ видео: выкл"
        styleChip(bakeBtn, bakeOn())
        highlightCenter()
    }

    private fun ensureThumbThread() {
        if (thumbThread == null) {
            val t = HandlerThread("lut-thumbs"); t.start()
            thumbThread = t
            thumbHandler = Handler(t.looper)
        }
    }

    // ------------------------------------------------------------ карточки

    private fun addCard(e: LutEntry?) {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(3))
            background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(0xFF1C1C1E.toInt()); setStroke(dp(2), Color.TRANSPARENT) }
        }
        val img = ImageView(context).apply {
            tag = "img"
            scaleType = ImageView.ScaleType.FIT_XY
            setImageBitmap(scene())
            setBackgroundColor(0xFF000000.toInt())
        }
        card.addView(img, LinearLayout.LayoutParams(dp(120), dp(66)))
        val name = TextView(context).apply {
            tag = "name"
            textSize = 10f
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(0xFFEBEBF5.toInt())
            text = shortName(e)
        }
        card.addView(name, LinearLayout.LayoutParams(dp(120), LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
        card.setOnClickListener {
            onPick(e)
            centerOn(cards.indexOf(card), true)
        }
        val key = if (e == null) "base" else "${e.uri}|${inLog()}|${curve()}"
        thumbs[key]?.let { img.setImageBitmap(it) }
        row.addView(card, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { setMargins(dp(3), 0, dp(3), 0) })
        cards.add(card); cardEntries.add(e)
    }

    private fun shortName(e: LutEntry?): String {
        if (e == null) return "Без LUT"
        val n = e.name
        return if (n.length <= 14) n else n.take(13) + "…"
    }

    private fun activeIndex(): Int {
        val a = activeUri()
        val i = cardEntries.indexOfFirst { it?.uri == a }
        return if (i >= 0) i else 0
    }

    private fun centerIndex(): Int {
        if (cards.isEmpty()) return 0
        val cx = scroll.scrollX + scroll.width / 2
        var best = 0; var bd = Float.MAX_VALUE
        for (i in cards.indices) {
            val c = cards[i]
            val d = abs(c.left + c.width / 2f - cx)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private fun highlightCenter() {
        val ci = centerIndex()
        val a = activeUri()
        for (i in cards.indices) {
            val active = cardEntries[i]?.uri == a && (a != null || i == 0)
            val center = i == ci
            val stroke = if (active) amber else if (center) 0xFF8E8E93.toInt() else Color.TRANSPARENT
            (cards[i].background as GradientDrawable).setStroke(dp(2), stroke)
            val nm = cards[i].findViewWithTag<TextView>("name")
            nm.setTextColor(if (active) amber else if (center) Color.WHITE else 0xFFEBEBF5.toInt())
        }
    }

    private fun centerOn(i: Int, smooth: Boolean) {
        if (i !in cards.indices) return
        val c = cards[i]
        val target = (c.left + c.width / 2 - scroll.width / 2).coerceAtLeast(0)
        suppress = true
        if (smooth) scroll.smoothScrollTo(target, 0) else scroll.scrollTo(target, 0)
        main.postDelayed({ suppress = false; highlightCenter() }, if (smooth) 260 else 90)
    }

    private fun scheduleSettle() {
        main.removeCallbacks(settleRun)
        main.postDelayed(settleRun, 150)
    }

    private fun settle() {
        val i = centerIndex()
        centerOn(i, true)
        main.postDelayed({
            val e = cardEntries.getOrNull(i) ?: return@postDelayed
            val a = activeUri()
            val same = e.uri == a
            if (!isRecording() && !same) onPick(e)
            highlightCenter()
        }, 280)
    }

    // ------------------------------------------------------------ сцена и применение LUT

    private fun scene(): Bitmap {
        base?.let { return it }
        val w = 192; val h = 108
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h * 0.74f,
            intArrayOf(0xFF16213E.toInt(), 0xFF3A6EA5.toInt(), 0xFFF2A65A.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h * 0.74f, p)
        p.shader = RadialGradient(w * 0.72f, h * 0.60f, h * 0.20f,
            intArrayOf(0xFFFFF3C4.toInt(), 0xFFFFB347.toInt(), 0x00FFB347), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(w * 0.72f, h * 0.60f, h * 0.20f, p)
        p.shader = null
        p.color = 0xFF2B2D5E.toInt()
        val far = Path().apply {
            moveTo(0f, h * 0.62f); lineTo(w * 0.18f, h * 0.50f); lineTo(w * 0.34f, h * 0.60f)
            lineTo(w * 0.52f, h * 0.47f); lineTo(w * 0.70f, h * 0.59f); lineTo(w * 0.86f, h * 0.52f)
            lineTo(w.toFloat(), h * 0.61f); lineTo(w.toFloat(), h * 0.74f); lineTo(0f, h * 0.74f); close()
        }
        cv.drawPath(far, p)
        p.color = 0xFF1B1D3A.toInt()
        val near = Path().apply {
            moveTo(0f, h * 0.70f); lineTo(w * 0.22f, h * 0.62f); lineTo(w * 0.45f, h * 0.70f)
            lineTo(w * 0.66f, h * 0.64f); lineTo(w * 0.9f, h * 0.71f); lineTo(w.toFloat(), h * 0.67f)
            lineTo(w.toFloat(), h * 0.78f); lineTo(0f, h * 0.78f); close()
        }
        cv.drawPath(near, p)
        p.shader = LinearGradient(0f, h * 0.74f, 0f, h.toFloat(), 0xFF2A6F7F.toInt(), 0xFF0E2233.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, h * 0.74f, w.toFloat(), h.toFloat(), p)
        p.shader = null
        p.color = 0x66FFD9A0
        cv.drawRect(w * 0.68f, h * 0.74f, w * 0.76f, h * 0.95f, p)
        p.color = 0xFF1E4D2B.toInt()
        for (i in 0..5) cv.drawCircle(w * (0.04f + i * 0.035f), h * (0.80f + (i % 2) * 0.04f), h * 0.05f, p)
        // серая шкала + цветовые патчи + кожа — объективная опора для оценки LUT
        val cy = h * 0.86f; val ch = h * 0.12f
        for (i in 0..7) {
            val g = (i * 255 / 7)
            p.color = Color.rgb(g, g, g)
            cv.drawRect(w * (0.30f + i * 0.045f), cy, w * (0.30f + (i + 1) * 0.045f), cy + ch, p)
        }
        val cols = intArrayOf(0xFFD94040.toInt(), 0xFF40B060.toInt(), 0xFF4070D9.toInt(), 0xFFE0C040.toInt(), 0xFFC050C0.toInt(), 0xFF40C0C0.toInt(), 0xFFC68642.toInt())
        for (i in cols.indices) {
            p.color = cols[i]
            cv.drawRect(w * (0.68f + i * 0.045f), cy, w * (0.68f + (i + 1) * 0.045f), cy + ch, p)
        }
        base = b
        return b
    }

    private fun srgbToLin(u: Float): Float = if (u <= 0.04045f) u / 12.92f else ((u + 0.055f) / 1.055f).pow(2.4f)
    private fun linToSrgb(l: Float): Float = if (l <= 0.0031308f) l * 12.92f else 1.055f * l.pow(1f / 2.4f) - 0.055f

    private fun applyLut(src: Bitmap, lut: CubeLut, log: Boolean, cv: Curve): Bitmap {
        val w = src.width; val h = src.height
        val n = lut.size
        val d = lut.data
        val srcPx = IntArray(w * h); src.getPixels(srcPx, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        val inv = FloatArray(3) { 1f / (lut.domainMax[it] - lut.domainMin[it]) }
        for (i in srcPx.indices) {
            val c = srcPx[i]
            val r = srgbToLin(((c shr 16) and 255) / 255f)
            val g = srgbToLin(((c shr 8) and 255) / 255f)
            val b = srgbToLin((c and 255) / 255f)
            val ir = if (log) LogMath.encode(cv, r) else linToSrgb(r)
            val ig = if (log) LogMath.encode(cv, g) else linToSrgb(g)
            val ib = if (log) LogMath.encode(cv, b) else linToSrgb(b)
            val fx = ((ir - lut.domainMin[0]) * inv[0]).coerceIn(0f, 1f) * (n - 1)
            val fy = ((ig - lut.domainMin[1]) * inv[1]).coerceIn(0f, 1f) * (n - 1)
            val fz = ((ib - lut.domainMin[2]) * inv[2]).coerceIn(0f, 1f) * (n - 1)
            val x0 = floor(fx.toDouble()).toInt().coerceIn(0, n - 1); val x1 = (x0 + 1).coerceAtMost(n - 1)
            val y0 = floor(fy.toDouble()).toInt().coerceIn(0, n - 1); val y1 = (y0 + 1).coerceAtMost(n - 1)
            val z0 = floor(fz.toDouble()).toInt().coerceIn(0, n - 1); val z1 = (z0 + 1).coerceAtMost(n - 1)
            val tx = fx - x0; val ty = fy - y0; val tz = fz - z0
            for (k in 0..2) {
                val c000 = d[((x0 + y0 * n + z0 * n * n) * 3) + k]
                val c100 = d[((x1 + y0 * n + z0 * n * n) * 3) + k]
                val c010 = d[((x0 + y1 * n + z0 * n * n) * 3) + k]
                val c110 = d[((x1 + y1 * n + z0 * n * n) * 3) + k]
                val c001 = d[((x0 + y0 * n + z1 * n * n) * 3) + k]
                val c101 = d[((x1 + y0 * n + z1 * n * n) * 3) + k]
                val c011 = d[((x0 + y1 * n + z1 * n * n) * 3) + k]
                val c111 = d[((x1 + y1 * n + z1 * n * n) * 3) + k]
                val c00 = c000 + (c100 - c000) * tx
                val c10 = c010 + (c110 - c010) * tx
                val c01 = c001 + (c101 - c001) * tx
                val c11 = c011 + (c111 - c011) * tx
                val c0 = c00 + (c10 - c00) * ty
                val c1 = c01 + (c11 - c01) * ty
                val v = (c0 + (c1 - c0) * tz).coerceIn(0f, 1f)
                val byte = (v * 255f + 0.5f).toInt()
                out[i] = out[i] or (byte shl (16 - 8 * k))
            }
            out[i] = out[i] or 0xFF000000.toInt()
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}
