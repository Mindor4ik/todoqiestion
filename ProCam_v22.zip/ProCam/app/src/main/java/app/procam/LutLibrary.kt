package app.procam

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Запись в библиотеке LUT: сам файл остаётся там, где он лежит (доступ сохраняется через SAF). */
data class LutEntry(val name: String, val uri: String, val size: Int)

/** Список импортированных .cube и выбранный LUT; хранится в SharedPreferences. */
class LutLibrary(private val prefs: SharedPreferences) {
    val items = ArrayList<LutEntry>()
    var activeUri: String? = null
        private set

    init { load() }

    private fun load() {
        items.clear()
        try {
            val arr = JSONArray(prefs.getString("lut_lib", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(LutEntry(o.getString("name"), o.getString("uri"), o.optInt("size", 0)))
            }
        } catch (e: Exception) {
            items.clear()
        }
        // Миграция: раньше хранился один LUT (lut_uri / lut_label).
        val old = prefs.getString("lut_uri", null)
        if (old != null) {
            if (items.none { it.uri == old }) {
                val label = prefs.getString("lut_label", null)?.substringBefore(" · ")?.trim().orEmpty()
                items.add(LutEntry(label.ifBlank { "LUT" }, old, 0))
            }
            val e = prefs.edit()
            if (prefs.getString("lut_active", null) == null) e.putString("lut_active", old)
            e.remove("lut_uri").remove("lut_label").apply()
            save()
        }
        activeUri = prefs.getString("lut_active", null)?.takeIf { u -> items.any { it.uri == u } }
    }

    fun save() {
        val arr = JSONArray()
        for (e in items) arr.put(JSONObject().put("name", e.name).put("uri", e.uri).put("size", e.size))
        prefs.edit().putString("lut_lib", arr.toString()).apply()
    }

    fun add(e: LutEntry) {
        val i = items.indexOfFirst { it.uri == e.uri }
        if (i >= 0) items[i] = e else items.add(e)
        save()
    }

    fun remove(uri: String) {
        items.removeAll { it.uri == uri }
        if (activeUri == uri) setActive(null)
        save()
    }

    fun setActive(uri: String?) {
        activeUri = uri
        val e = prefs.edit()
        if (uri == null) e.remove("lut_active") else e.putString("lut_active", uri)
        e.apply()
    }

    fun active(): LutEntry? = items.firstOrNull { it.uri == activeUri }

    /** Следующий по кругу: без LUT → 1-й → 2-й → … → без LUT. */
    fun next(): LutEntry? {
        if (items.isEmpty()) return null
        val i = items.indexOfFirst { it.uri == activeUri }
        return if (activeUri == null) items.first() else items.getOrNull(i + 1)
    }
}
