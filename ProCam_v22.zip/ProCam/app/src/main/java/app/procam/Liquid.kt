package app.procam

import android.animation.TimeInterpolator

/**
 * Затухающая пружина 0 → 1 с перелётом: движение «оседает», как капля воды.
 * damping — как быстро гаснут колебания, freq — как быстро они идут. Значения по умолчанию дают ~18% перелёта.
 */
class Spring(private val damping: Float = 6.5f, private val freq: Float = 11f) : TimeInterpolator {
    override fun getInterpolation(t: Float): Float {
        if (t >= 1f) return 1f
        return (1.0 - Math.exp((-damping * t).toDouble()) * Math.cos((freq * t).toDouble())).toFloat()
    }
}
