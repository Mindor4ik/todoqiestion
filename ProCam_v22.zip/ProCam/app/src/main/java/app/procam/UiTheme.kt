package app.procam

import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.view.View

enum class UiStyle(val label: String) { MATERIAL("Material"), GLASS("Liquid Glass") }

/**
 * Единый источник визуального языка. Палитра строго монохромная (чёрный / белый / серые):
 * чисто чёрный фон, полупрозрачные «стеклянные» поверхности с бликом и светлой кромкой, белый акцент (активное = белая заливка, чёрный текст).
 * Читается при построении UI; смена стиля = recreate().
 */
object Ui {
    var style: UiStyle = UiStyle.GLASS
    /** Плотность экрана: радиусы и обводки заданы в dp. */
    var density = 1f
    private fun dp(v: Float) = v * density
    private fun hair(): Int = dp(1f).toInt().coerceAtLeast(1)
    val glass get() = style == UiStyle.GLASS

    val accent get() = 0xFFFFFFFF.toInt()
    val onAccent get() = 0xFF000000.toInt()
    val rec get() = 0xFFFF3B30.toInt()
    val ok get() = 0xFFFFFFFF.toInt()
    val text get() = 0xFFFFFFFF.toInt()
    val dim get() = if (glass) 0xFFB4B4B8.toInt() else 0xFF8E8E93.toInt()
    val root get() = 0xFF000000.toInt()
    val dock get() = 0xFF000000.toInt()
    val menuBg get() = if (glass) 0xD9161618.toInt() else 0xFF1C1C1E.toInt()

    enum class Kind { PANEL, CHIP, BUTTON, HUD, MENU }

    private fun radius(k: Kind): Float = when (k) {
        Kind.PANEL, Kind.MENU -> if (glass) 26f else 18f
        Kind.HUD -> if (glass) 14f else 10f
        else -> if (glass) 20f else 14f
    }

    private fun base(k: Kind, active: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radius(k))
        if (active) { g.setColor(accent); g.setStroke(hair(), accent); return g }
        when (k) {
            Kind.HUD -> { g.setColor(if (glass) 0x59000000 else 0x99000000.toInt()); g.setStroke(hair(), if (glass) 0x40FFFFFF else 0x00000000) }
            Kind.PANEL, Kind.MENU -> {
                g.setColor(if (glass) 0x9E1A1A1C.toInt() else 0xFF1C1C1E.toInt())
                g.setStroke(hair(), if (glass) 0x4DFFFFFF else 0xFF2C2C2E.toInt())
            }
            else -> {
                g.setColor(if (glass) 0x80303032.toInt() else 0xFF2C2C2E.toInt())
                g.setStroke(hair(), if (glass) 0x40FFFFFF else 0xFF3A3A3C.toInt())
            }
        }
        return g
    }

    /** Стеклянный блик сверху + базовая полупрозрачная подложка. */
    fun bg(k: Kind, active: Boolean = false): Drawable {
        val b = base(k, active)
        if (!glass || active) return b
        val sheen = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x40FFFFFF, 0x0DFFFFFF, 0x00000000, 0x12FFFFFF))
        sheen.cornerRadius = dp(radius(k))
        return LayerDrawable(arrayOf(b, sheen))
    }

    /** Капсула поверх превью (зум-«пилюли»). */
    fun pill(): Drawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(40f)
        g.setColor(if (glass) 0x66000000 else 0xB3000000.toInt())
        g.setStroke(hair(), if (glass) 0x40FFFFFF else 0x00000000)
        return g
    }

    /** Круглая подложка: у активной «пилюли» тёмная, у остальных прозрачная. */
    fun disc(on: Boolean): Drawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (on) 0xCC000000.toInt() else 0x00000000)
        return g
    }

    fun ripple(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, null)

    fun skin(v: View, k: Kind, active: Boolean = false) {
        v.background = ripple(bg(k, active))
        v.elevation = dp(if (glass) 4f else if (k == Kind.PANEL || k == Kind.MENU) 2f else 0.5f)
    }
}

/** Кнопка записи: кольцо + внутренняя фигура, которая перетекает из круга в скруглённый квадрат (t = 0…1). Рисуется сама, без LayerDrawable. */
class RecDrawable(private val density: Float) : Drawable() {
    var t = 0f
        set(v) { field = v; invalidateSelf() }
    var color = 0xFFFF3B30.toInt()
    private val ringFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40000000 }
    private val ringStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f * density }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun draw(c: Canvas) {
        val b = bounds
        val full = minOf(b.width(), b.height()).toFloat()
        val cx = b.exactCenterX(); val cy = b.exactCenterY()
        val sw = ringStroke.strokeWidth
        c.drawCircle(cx, cy, full / 2f - sw / 2f, ringFill)
        c.drawCircle(cx, cy, full / 2f - sw / 2f, ringStroke)
        // круг почти во всё кольцо; квадрат — 36% стороны кнопки, целиком внутри кольца
        val side = full * (0.70f + (0.36f - 0.70f) * t.coerceIn(0f, 1.2f).coerceAtLeast(0f))
        val half = side / 2f
        val rad = half * (1f - t.coerceIn(0f, 1f)) + side * 0.22f * t.coerceIn(0f, 1f)
        inner.color = color
        r.set(cx - half, cy - half, cx + half, cy + half)
        c.drawRoundRect(r, rad.coerceAtMost(half), rad.coerceAtMost(half), inner)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * Кнопка паузы в стиле кнопки записи: то же кольцо (белая обводка, тёмная подложка) и белая фигура внутри.
 * Две планки плавно перетекают в треугольник «продолжить» и обратно (t = 0…1). Кольцо при паузе подкрашивается красным.
 */
class PauseIcon(private val density: Float) : Drawable() {
    private var t = 0f
    private var anim: android.animation.ValueAnimator? = null
    var play = false
        set(v) {
            if (field == v) return
            field = v
            glide(if (v) 1f else 0f)
        }

    private fun glide(to: Float) {
        anim?.cancel()
        val from = t
        val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
        a.duration = 420
        a.interpolator = Spring(6.5f, 10f)
        a.addUpdateListener { t = from + (to - from) * (it.animatedValue as Float); invalidateSelf() }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(an: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(an: android.animation.Animator) { if (!cancelled) { t = to; invalidateSelf() } }
        })
        anim = a
        a.start()
    }

    /** Без анимации (сброс при старте/остановке записи). */
    fun reset() { anim?.cancel(); play = false; t = 0f; invalidateSelf() }

    private val ringFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40000000 }
    private val ringStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * density }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); strokeJoin = Paint.Join.ROUND }
    private val path = Path()

    private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f
    private fun mixColor(a: Int, b: Int, f: Float): Int {
        val ff = f.coerceIn(0f, 1f)
        val al = ((a ushr 24) + ((b ushr 24) - (a ushr 24)) * ff).toInt()
        val r = (((a shr 16) and 255) + (((b shr 16) and 255) - ((a shr 16) and 255)) * ff).toInt()
        val g = (((a shr 8) and 255) + (((b shr 8) and 255) - ((a shr 8) and 255)) * ff).toInt()
        val bl = ((a and 255) + ((b and 255) - (a and 255)) * ff).toInt()
        return (al shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** Четырёхугольник (верх-лево, верх-право, низ-право, низ-лево) между формой «планка» и «часть треугольника». */
    private fun quad(c: Canvas, a: FloatArray, b: FloatArray, f: Float, cx: Float, cy: Float) {
        path.reset()
        for (k in 0 until 4) {
            val x = cx + lerp(a[k * 2], b[k * 2], f)
            val y = cy + lerp(a[k * 2 + 1], b[k * 2 + 1], f)
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, p)
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val full = minOf(b.width(), b.height()).toFloat()
        val cx = b.exactCenterX(); val cy = b.exactCenterY()
        val sw = ringStroke.strokeWidth
        c.drawCircle(cx, cy, full / 2f - sw / 2f, ringFill)
        ringStroke.color = mixColor(0xFFFFFFFF.toInt(), 0xFFFF3B30.toInt(), t * 0.85f)
        c.drawCircle(cx, cy, full / 2f - sw / 2f, ringStroke)

        val f = t.coerceIn(0f, 1f)
        val s = full * 0.20f                    // половина высоты фигуры
        val w = s * 0.62f; val gap = s * 0.42f   // планка паузы
        val x0 = -s * 0.55f; val x1 = s * 0.95f  // треугольник «play»: от x0 до x1, середина разреза xm
        val xm = lerp(x0, x1, 0.45f)
        val yTop = -s + s * (xm - x0) / (x1 - x0)
        val pl = floatArrayOf(-gap - w, -s, -gap, -s, -gap, s, -gap - w, s)
        val pr = floatArrayOf(gap, -s, gap + w, -s, gap + w, s, gap, s)
        val tl = floatArrayOf(x0, -s, xm, yTop, xm, -yTop, x0, s)
        val tr = floatArrayOf(xm, yTop, x1, 0f, x1, 0f, xm, -yTop)
        // небольшое скругление углов обводкой того же цвета
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeWidth = s * 0.28f
        quad(c, pl, tl, f, cx, cy)
        quad(c, pr, tr, f, cx, cy)
        p.style = Paint.Style.FILL
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
