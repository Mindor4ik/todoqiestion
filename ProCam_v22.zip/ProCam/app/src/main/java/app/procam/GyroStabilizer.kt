package app.procam

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * EIS по гироскопу, версия 2.
 *
 * Отличия от v1:
 *  - ROLLING SHUTTER: на кадр выдаётся BANDS+1 матриц (по строкам сенсора), а не одна.
 *    Реальная камера Ra берётся в момент экспозиции данной строки, виртуальная Rv — один раз
 *    в центре кадра. Это и есть построчная коррекция RS.
 *  - СГЛАЖИВАНИЕ С НУЛЕВОЙ ФАЗОЙ: вместо причинного EMA — гауссово взвешенное усреднение
 *    кватернионов в окне [t-past, t+future]. «Будущее» берётся бесплатно: гироскоп опережает
 *    видеотракт на 30–60 мс. Недостающая часть компенсируется экстраполяцией сглаженной пути.
 *  - ТОЧНЫЙ КРОП: масштаб коррекции подбирается бинарным поиском так, чтобы ВСЕ 4 угла
 *    выходного кадра во ВСЕХ полосах лежали внутри исходного. Смазанных краёв не бывает.
 *  - МЯГКИЙ ПРЕДЕЛ (tanh-колено) перед точным ограничением — нет «удара в стену».
 *  - Оценка покоя-смещения гироскопа (bias) и мягкая фузия гравитации вместо жёсткого отсечения.
 *  - Горячий путь без аллокаций (v1 создавала ~10 массивов на каждый из 400 сэмплов/с).
 *  - СИНХРОНИЗАЦИЯ: результат калибровки — абсолютный сдвиг, полуэкспозиция больше не
 *    прибавляется повторно. Смена выдержки AE больше не рассинхронизирует стабилизацию.
 *
 * Не компенсируется: дисторсия объектива, параллакс, смаз от движения.
 */
class GyroStabilizer(ctx: Context) : SensorEventListener {

    companion object {
        private const val TAG = "ProCamGyro"
        private const val CAP = 4096
        private const val ASSUMED_LATENCY_NS = 35_000_000L
        /** Полос rolling shutter. 16 = шаг ~2 мс при skew 32 мс. */
        const val BANDS = 16
        private const val WORK = 1280

        fun available(ctx: Context): Boolean = try {
            (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager)
                .getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        } catch (e: Exception) { false }

        fun horizonAvailable(ctx: Context): Boolean = try {
            (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager)
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        } catch (e: Exception) { false }
    }

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var thread: HandlerThread? = null

    // ---------------- кольцевой буфер ориентаций реальной камеры
    private val lock = Any()
    private val ts = LongArray(CAP)
    private val qa = DoubleArray(CAP * 4)
    private var head = 0
    private var count = 0
    private val qA = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var tPrev = -1L
    private val wPrev = DoubleArray(3)

    // сырой гироскоп в осях устройства (нужен автокалибровке для перебора осей)
    private val rawT = LongArray(CAP)
    private val rawC = DoubleArray(CAP * 3)
    private var rawHead = 0
    private var rawCount = 0
    private val rawPrevW = DoubleArray(3)

    // bias (оси устройства)
    private val bias = DoubleArray(3)
    private var bN = 0
    private val bSum = DoubleArray(3)
    private val bSq = DoubleArray(3)

    // гравитация в мировой системе интегратора
    private val upW = DoubleArray(3)
    private var haveUp = false
    private var tAcc = 0L
    private var accVar = 0.0

    // ---------------- настройки
    @Volatile private var sensorRot = 90
    @Volatile private var tau = 0.2
    @Volatile private var geomX = 0.74   // (W/2)/f
    @Volatile private var geomY = 0.42   // (H/2)/f
    @Volatile private var boxX = 0.64    // geomX / crop
    @Volatile private var boxY = 0.36
    @Volatile private var kneeX = 0.06   // допуск pitch, нормализованные единицы
    @Volatile private var kneeY = 0.10   // допуск yaw
    @Volatile private var kneeZ = 0.07   // допуск roll
    @Volatile private var exposureNs = 0L
    @Volatile private var skewNs = 0L
    @Volatile private var useArrival = false

    /** Коррекция rolling shutter. Если камера не отдаёт skew — автоматически не работает. */
    @Volatile var rsEnable = true

    // ---------------- Frame Lock: замкнутая доводка по изображению
    @Volatile var lockEnable = false
    private val lockLock = Any()
    private val cG = DoubleArray(2); private val mG = DoubleArray(2)
    private val cB = Array(3) { DoubleArray(2) }; private val mB = Array(3) { DoubleArray(2) }
    private val outT = DoubleArray(6)
    private var lockTs = 0L

    /** Остаточный сдвиг в пикселях проб-кадра (A->B). Высокочастотный контур: намеренные панорамы не трогает. */
    fun addResidual(ts: Long, gx: Double, gy: Double, b: DoubleArray, conf: Double, pW: Int, pH: Int) {
        if (!lockEnable || conf < 0.35) return
        synchronized(lockLock) {
            val dt = if (lockTs > 0) ((ts - lockTs) * 1e-9).coerceIn(0.001, 0.1) else 0.033
            lockTs = ts
            val aLow = 1 - exp(-dt / 0.5); val leak = exp(-dt / 1.2); val gain = 0.8
            val bx = boxX; val by = boxY
            val limX = geomX - bx; val limY = geomY - by
            val mx = gx * 2 / pW * bx; val my = gy * 2 / pH * by
            mG[0] += (mx - mG[0]) * aLow; mG[1] += (my - mG[1]) * aLow
            cG[0] = (cG[0] * leak + (mx - mG[0]) * gain).coerceIn(-0.30 * limX, 0.30 * limX)
            cG[1] = (cG[1] * leak + (my - mG[1]) * gain).coerceIn(-0.30 * limY, 0.30 * limY)
            for (k in 0..2) {
                val px = (b[3 + k * 2] - gx) * 2 / pW * bx; val py = (b[4 + k * 2] - gy) * 2 / pH * by
                mB[k][0] += (px - mB[k][0]) * aLow; mB[k][1] += (py - mB[k][1]) * aLow
                cB[k][0] = (cB[k][0] * leak + (px - mB[k][0]) * gain).coerceIn(-0.12 * limX, 0.12 * limX)
                cB[k][1] = (cB[k][1] * leak + (py - mB[k][1]) * gain).coerceIn(-0.12 * limY, 0.12 * limY)
            }
            for (k in 0..2) { outT[k * 2] = cG[0] + cB[k][0]; outT[k * 2 + 1] = cG[1] + cB[k][1] }
        }
    }

    /** Сдвиги окна (верх/середина/низ) для шейдера; нули, если контур выключен. */
    fun lockT(out: FloatArray) {
        synchronized(lockLock) { for (i in 0..5) out[i] = if (lockEnable) outT[i].toFloat() else 0f }
    }
    /** Ручная подстройка величины skew (0.5…1.5), если картинка «плывёт» по вертикали. */
    @Volatile var rsScale = 1.0
    @Volatile var horizonLock = false
    /** Сила блокировки горизонта 0..1. 1 — жёстко, 0.6 — «живой» горизонт, меньше кропа. */
    @Volatile var horizonStrength = 1f
    @Volatile var manualOffsetNs = 0L
    /** Экстраполяция сглаженного пути для компенсации лага окна. */
    @Volatile var lagCompensation = true

    // ---------------- автокалибровка
    class CalResult(val sensorRot: Int, val shiftNs: Long, val score: Double, val margin: Long, val marginScore: Double)

    @Volatile var calibrating = false
    @Volatile var calStartMs = 0L
    /** Абсолютная добавка к метке кадра (без полуэкспозиции!). Действует только если calibrated. */
    @Volatile var calShiftNs = 0L
    @Volatile var calibrated = false
    var onResult: ((CalResult?) -> Unit)? = null

    private val MAXP = 200
    private val pairLock = Any()
    private val pairA = LongArray(MAXP)
    private val pairB = LongArray(MAXP)
    private val pairDx = DoubleArray(MAXP)
    private val pairDy = DoubleArray(MAXP)
    private var pairN = 0
    @Volatile private var calRunning = false

    // ---------------- часы камеры без REALTIME
    private var minDelta = Long.MAX_VALUE
    private var winCount = 0
    private var clockOffset = 0L
    private var haveClock = false

    // ---------------- переиспользуемый скретч (сенсорный поток, под lock)
    private val sW = DoubleArray(3)
    private val sRv = DoubleArray(3)
    private val sDq = DoubleArray(4)
    private val sTmp = DoubleArray(4)
    private val sM = DoubleArray(9)

    // ---------------- скретч рендера (только GL-поток)
    private val wTs = LongArray(WORK)
    private val wQa = DoubleArray(WORK * 4)
    private var wN = 0
    private val rUp = DoubleArray(3)
    private val rQv = DoubleArray(4)
    private val rQv2 = DoubleArray(4)
    private val rQa = DoubleArray(4)
    private val rRel = DoubleArray(4)
    private val rTmp = DoubleArray(4)
    private val rV = DoubleArray(3)
    private val rW = DoubleArray(3)
    private val bandV = DoubleArray((BANDS + 1) * 3)
    private val rMat = DoubleArray(9)
    private val cornersX = doubleArrayOf(-1.0, 1.0, 1.0, -1.0)
    private val cornersY = doubleArrayOf(-1.0, -1.0, 1.0, 1.0)

    // ================================================================ жизненный цикл

    fun start(sensorOrientation: Int, arrivalSync: Boolean): Boolean {
        val g = gyroSensor ?: return false
        sensorRot = sensorOrientation
        useArrival = arrivalSync
        synchronized(lock) {
            head = 0; count = 0; tPrev = -1L; haveUp = false
            rawHead = 0; rawCount = 0
            qA[0] = 1.0; qA[1] = 0.0; qA[2] = 0.0; qA[3] = 0.0
            bias[0] = 0.0; bias[1] = 0.0; bias[2] = 0.0
            bN = 0; bSum.fill(0.0); bSq.fill(0.0)
        }
        val t = HandlerThread("procam-gyro"); t.start(); thread = t
        val h = Handler(t.looper)
        var ok = false
        // 800 Гц -> 400 -> 200. Выше 200 Гц нужно HIGH_SAMPLING_RATE_SENSORS (в манифесте есть).
        for (period in intArrayOf(1250, 2500, 5000)) {
            try { if (sm.registerListener(this, g, period, h)) { ok = true; break } }
            catch (e: Exception) { Log.w(TAG, "gyro ${period}us refused: ${e.message}") }
        }
        if (ok) accSensor?.let { a ->
            try { sm.registerListener(this, a, 10000, h) } catch (e: Exception) { }
        }
        if (!ok) stop()
        return ok
    }

    fun stop() {
        try { sm.unregisterListener(this) } catch (e: Exception) { }
        thread?.quitSafely(); thread = null
    }

    fun configure(tauSec: Double, focalPx: Double, w: Int, h: Int, crop: Double) {
        tau = tauSec.coerceIn(0.02, 2.0)
        val f = max(focalPx, 100.0)
        val c = max(crop, 1.01)
        val gx = (w / 2.0) / f
        val gy = (h / 2.0) / f
        geomX = gx; geomY = gy
        boxX = gx / c; boxY = gy / c
        kneeX = max(gy - boxY, 1e-4)
        kneeY = max(gx - boxX, 1e-4)
        val ratio = max(w, h).toDouble() / min(w, h)
        var a = 0.0
        while (a < 0.6 && ratio * sin(a + 0.002) + cos(a + 0.002) <= c) a += 0.002
        kneeZ = max(0.9 * a, 1e-4)
    }

    fun setFrameTiming(exposure: Long, skew: Long) { exposureNs = exposure; skewNs = skew }

    fun onFrameArrival(frameTs: Long, arrivalNs: Long) {
        if (!useArrival) return
        val d = arrivalNs - frameTs
        if (d < minDelta) minDelta = d
        if (++winCount >= 60) {
            // сглаживаем оценку, иначе скачок minDelta дёргает весь кадр
            clockOffset = if (!haveClock) minDelta else (clockOffset * 3 + minDelta) / 4
            haveClock = true; minDelta = Long.MAX_VALUE; winCount = 0
        }
    }

    // ================================================================ сенсор

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val v = e.values
        when (e.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> synchronized(lock) {
                val x = v[0].toDouble() - bias[0]
                val y = v[1].toDouble() - bias[1]
                val z = v[2].toDouble() - bias[2]
                updateBias(v[0].toDouble(), v[1].toDouble(), v[2].toDouble())
                recordRaw(e.timestamp, x, y, z)
                mapToCam(sensorRot, x, y, z, sW)
                integrate(e.timestamp, sW)
            }
            Sensor.TYPE_ACCELEROMETER -> synchronized(lock) {
                mapToCam(sensorRot, v[0].toDouble(), v[1].toDouble(), v[2].toDouble(), sW)
                accel(e.timestamp, sW)
            }
        }
    }

    /** Покой: скользящие 200 сэмплов, если СКО мало — медленно уточняем bias. */
    private fun updateBias(x: Double, y: Double, z: Double) {
        bSum[0] += x; bSum[1] += y; bSum[2] += z
        bSq[0] += x * x; bSq[1] += y * y; bSq[2] += z * z
        if (++bN < 200) return
        val n = bN.toDouble()
        var still = true
        for (k in 0..2) {
            val m = bSum[k] / n
            val varr = bSq[k] / n - m * m
            if (varr > 4e-6) still = false     // СКО > 0.002 рад/с
        }
        if (still) for (k in 0..2) {
            val m = bSum[k] / n
            bias[k] = bias[k] * 0.9 + m * 0.1
        }
        bN = 0; bSum.fill(0.0); bSq.fill(0.0)
    }

    private fun recordRaw(t: Long, x: Double, y: Double, z: Double) {
        var cx = 0.0; var cy = 0.0; var cz = 0.0
        if (rawCount > 0) {
            val last = (rawHead - 1 + CAP) % CAP
            if (t <= rawT[last]) return
            val dt = min((t - rawT[last]) * 1e-9, 0.1)
            cx = rawC[last * 3] + 0.5 * (x + rawPrevW[0]) * dt
            cy = rawC[last * 3 + 1] + 0.5 * (y + rawPrevW[1]) * dt
            cz = rawC[last * 3 + 2] + 0.5 * (z + rawPrevW[2]) * dt
        }
        rawT[rawHead] = t
        rawC[rawHead * 3] = cx; rawC[rawHead * 3 + 1] = cy; rawC[rawHead * 3 + 2] = cz
        rawHead = (rawHead + 1) % CAP
        if (rawCount < CAP) rawCount++
        rawPrevW[0] = x; rawPrevW[1] = y; rawPrevW[2] = z
    }

    /**
     * Мягкая фузия гравитации: вес коррекции падает с отклонением |a| от g, но не обнуляется.
     * Жёсткое отсечение 8.3..11.3 (v1) при ходьбе отбрасывало почти всё — горизонт «уплывал».
     */
    private fun accel(t: Long, a: DoubleArray) {
        val n = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
        if (n < 1.0) return
        val dev = abs(n - 9.81)
        accVar = accVar * 0.95 + dev * 0.05
        val trust = exp(-(dev * dev) / (2.0 * 1.6 * 1.6))
        if (trust < 0.02) return
        matFrom(sM, qA, 0)
        val ux = a[0] / n; val uy = a[1] / n; val uz = a[2] / n
        val wx = sM[0] * ux + sM[1] * uy + sM[2] * uz
        val wy = sM[3] * ux + sM[4] * uy + sM[5] * uz
        val wz = sM[6] * ux + sM[7] * uy + sM[8] * uz
        if (!haveUp) {
            upW[0] = wx; upW[1] = wy; upW[2] = wz; haveUp = true; tAcc = t; return
        }
        val dt = max((t - tAcc) * 1e-9, 0.0); tAcc = t
        val k = (1.0 - exp(-dt / 1.5)) * trust
        val nx = upW[0] + k * (wx - upW[0])
        val ny = upW[1] + k * (wy - upW[1])
        val nz = upW[2] + k * (wz - upW[2])
        val nn = sqrt(nx * nx + ny * ny + nz * nz)
        if (nn > 1e-9) { upW[0] = nx / nn; upW[1] = ny / nn; upW[2] = nz / nn }
    }

    private fun integrate(t: Long, w: DoubleArray) {
        if (tPrev < 0) {
            tPrev = t; wPrev[0] = w[0]; wPrev[1] = w[1]; wPrev[2] = w[2]
            push(t); return
        }
        val dt = (t - tPrev) * 1e-9
        if (dt <= 0.0 || dt > 0.1) {
            tPrev = t; wPrev[0] = w[0]; wPrev[1] = w[1]; wPrev[2] = w[2]; return
        }
        sRv[0] = (w[0] + wPrev[0]) * 0.5 * dt
        sRv[1] = (w[1] + wPrev[1]) * 0.5 * dt
        sRv[2] = (w[2] + wPrev[2]) * 0.5 * dt
        quatFromRotvec(sDq, sRv, 0)
        qmul(sTmp, qA, 0, sDq, 0)
        qnorm(sTmp)
        qA[0] = sTmp[0]; qA[1] = sTmp[1]; qA[2] = sTmp[2]; qA[3] = sTmp[3]
        tPrev = t; wPrev[0] = w[0]; wPrev[1] = w[1]; wPrev[2] = w[2]
        push(t)
    }

    private fun push(t: Long) {
        ts[head] = t
        qa[head * 4] = qA[0]; qa[head * 4 + 1] = qA[1]
        qa[head * 4 + 2] = qA[2]; qa[head * 4 + 3] = qA[3]
        head = (head + 1) % CAP
        if (count < CAP) count++
    }

    private fun idx(i: Int) = (head - count + i + CAP) % CAP

    /** Смена осей по результату калибровки: не сбрасываем историю, а переигрываем её. */
    private fun setSensorRot(r: Int) {
        synchronized(lock) {
            if (r == sensorRot) return
            sensorRot = r
            head = 0; count = 0; haveUp = false
            qA[0] = 1.0; qA[1] = 0.0; qA[2] = 0.0; qA[3] = 0.0
            if (rawCount < 2) { tPrev = -1L; return }
            var prevPhys = (rawHead - rawCount + CAP) % CAP
            for (i in 1 until rawCount) {
                val cur = (rawHead - rawCount + i + CAP) % CAP
                sRv[0] = rawC[cur * 3] - rawC[prevPhys * 3]
                sRv[1] = rawC[cur * 3 + 1] - rawC[prevPhys * 3 + 1]
                sRv[2] = rawC[cur * 3 + 2] - rawC[prevPhys * 3 + 2]
                mapToCam(r, sRv[0], sRv[1], sRv[2], sW)
                quatFromRotvec(sDq, sW, 0)
                qmul(sTmp, qA, 0, sDq, 0); qnorm(sTmp)
                qA[0] = sTmp[0]; qA[1] = sTmp[1]; qA[2] = sTmp[2]; qA[3] = sTmp[3]
                push(rawT[cur])
                prevPhys = cur
            }
            tPrev = rawT[prevPhys]
            mapToCam(r, rawPrevW[0], rawPrevW[1], rawPrevW[2], wPrev)
        }
    }

    // ================================================================ выдача варпа

    private fun baseOffset(): Long =
        (if (calibrated) calShiftNs else exposureNs / 2) +
        manualOffsetNs + (if (useArrival) clockOffset - ASSUMED_LATENCY_NS else 0L)

    /**
     * Заполняет out: (BANDS+1) матриц 3x3 «по столбцам» (как ждёт GLSL mat3),
     * R_j = Ra(t_row_j)^T · Rv(t_center) — из виртуальной камеры в реальную для данной строки.
     * false — данных нет, оставляйте единичные матрицы (кроп всё равно применится).
     */
    fun warpAt(frameTs: Long, out: FloatArray): Boolean {
        if (out.size < (BANDS + 1) * 9) return false
        if (useArrival && !haveClock) return false

        val sk = if (rsEnable) skewNs.toDouble() * rsScale else 0.0
        val t0 = frameTs + baseOffset()
        val tc = t0 + (sk * 0.5).toLong()

        val sigma = max(tau * 0.5, 0.01)
        val want = 3.0 * sigma
        val past = min(want, 1.2)
        val futureWant = min(want, 0.30)
        val spanNs = ((past + futureWant) * 1e9).toLong() + 120_000_000L + sk.toLong()

        var up0 = 0.0; var up1 = 0.0; var up2 = 0.0
        val upOk: Boolean
        synchronized(lock) {
            if (count < 8) return false
            val lastT = ts[idx(count - 1)]
            if (tc - lastT > 300_000_000L) return false
            upOk = haveUp
            up0 = upW[0]; up1 = upW[1]; up2 = upW[2]
            val lo = lowerBound(tc - spanNs)
            val hi = min(count - 1, lowerBound(tc + spanNs) + 1)
            var n = hi - lo + 1
            if (n > WORK) n = WORK
            val start = idx(lo)
            val first = min(n, CAP - start)
            System.arraycopy(ts, start, wTs, 0, first)
            System.arraycopy(qa, start * 4, wQa, 0, first * 4)
            if (first < n) {
                System.arraycopy(ts, 0, wTs, first, n - first)
                System.arraycopy(qa, 0, wQa, first * 4, (n - first) * 4)
            }
            wN = n
        }
        if (wN < 4) return false
        rUp[0] = up0; rUp[1] = up1; rUp[2] = up2

        val future = min(futureWant, max(0.0, (wTs[wN - 1] - tc) * 1e-9 - 0.002))

        // сглаженная виртуальная камера в центре кадра
        val tBar = smooth(tc, sigma, past, future, rQv)
        if (lagCompensation) {
            val lag = (tc - tBar) * 1e-9
            if (lag > 0.004) {
                val d = 0.06
                smooth(tc - (d * 1e9).toLong(), sigma, past, future, rQv2)
                qconj(rTmp, rQv2, 0)
                qmul(rRel, rTmp, 0, rQv, 0)
                rotvecFrom(rW, rRel, 0)
                var g = lag / d
                if (g > 1.0) g = 1.0
                // не разгоняем экстраполяцию: резкая смена направления не должна «выстреливать»
                val wn = sqrt(rW[0] * rW[0] + rW[1] * rW[1] + rW[2] * rW[2])
                val maxAdv = 0.10
                if (wn * g > maxAdv) g = maxAdv / max(wn, 1e-9)
                rW[0] *= g; rW[1] *= g; rW[2] *= g
                quatFromRotvec(rTmp, rW, 0)
                qmul(rRel, rQv, 0, rTmp, 0); qnorm(rRel)
                rQv[0] = rRel[0]; rQv[1] = rRel[1]; rQv[2] = rRel[2]; rQv[3] = rRel[3]
            }
        }

        if (horizonLock && upOk && horizonStrength > 0.01f) {
            matFrom(rMat, rQv, 0)
            val ux = rMat[0] * rUp[0] + rMat[3] * rUp[1] + rMat[6] * rUp[2]
            val uy = rMat[1] * rUp[0] + rMat[4] * rUp[1] + rMat[7] * rUp[2]
            val phi = atan2(ux, -uy) * horizonStrength.toDouble()
            rW[0] = 0.0; rW[1] = 0.0; rW[2] = phi
            quatFromRotvec(rTmp, rW, 0)
            qmul(rRel, rQv, 0, rTmp, 0); qnorm(rRel)
            rQv[0] = rRel[0]; rQv[1] = rRel[1]; rQv[2] = rRel[2]; rQv[3] = rRel[3]
        }

        // построчные отклонения
        for (j in 0..BANDS) {
            val tr = t0 + (sk * j / BANDS).toLong()
            nlerpWork(tr, rQa)
            qconj(rTmp, rQa, 0)
            qmul(rRel, rTmp, 0, rQv, 0)
            rotvecFrom(rV, rRel, 0)
            // мягкое колено: до 60% запаса — без изменений, дальше плавное насыщение
            val u = max(max(abs(rV[0]) / kneeX, abs(rV[1]) / kneeY), abs(rV[2]) / kneeZ)
            if (u > 0.6) {
                val s = (0.6 + 0.4 * tanh((u - 0.6) / 0.4)) / u
                rV[0] *= s; rV[1] *= s; rV[2] *= s
            }
            bandV[j * 3] = rV[0]; bandV[j * 3 + 1] = rV[1]; bandV[j * 3 + 2] = rV[2]
        }

        // точное ограничение: все углы во всех полосах внутри исходного кадра
        var alpha = 1.0
        if (!fitsAll(1.0)) {
            var lo = 0.0; var hi = 1.0
            repeat(12) {
                val mid = (lo + hi) * 0.5
                if (fitsAll(mid)) lo = mid else hi = mid
            }
            alpha = lo
        }

        for (j in 0..BANDS) {
            rV[0] = bandV[j * 3] * alpha
            rV[1] = bandV[j * 3 + 1] * alpha
            rV[2] = bandV[j * 3 + 2] * alpha
            quatFromRotvec(rRel, rV, 0)
            matFrom(rMat, rRel, 0)
            val o = j * 9
            for (c in 0..2) for (r in 0..2) out[o + c * 3 + r] = rMat[r * 3 + c].toFloat()
        }
        return true
    }

    private fun fitsAll(alpha: Double): Boolean {
        val bx = boxX; val by = boxY; val gx = geomX; val gy = geomY
        val tx: Double; val ty: Double
        synchronized(lockLock) { tx = (outT[0] + outT[2] + outT[4]) / 3; ty = (outT[1] + outT[3] + outT[5]) / 3 }
        for (j in 0..BANDS) {
            rV[0] = bandV[j * 3] * alpha
            rV[1] = bandV[j * 3 + 1] * alpha
            rV[2] = bandV[j * 3 + 2] * alpha
            quatFromRotvec(rRel, rV, 0)
            matFrom(rMat, rRel, 0)
            for (k in 0..3) {
                val dx = cornersX[k] * bx; val dy = cornersY[k] * by
                val sz = rMat[6] * dx + rMat[7] * dy + rMat[8]
                val sx = rMat[0] * dx + rMat[1] * dy + rMat[2] + tx * sz
                val sy = rMat[3] * dx + rMat[4] * dy + rMat[5] + ty * sz
                if (sz <= 0.05) return false
                if (abs(sx) > gx * sz || abs(sy) > gy * sz) return false
            }
        }
        return true
    }

    /** Гауссово взвешенное усреднение кватернионов. Возвращает средневзвешенное время (нс). */
    private fun smooth(t: Long, sigma: Double, past: Double, future: Double, out: DoubleArray): Long {
        nlerpWork(t, rQa)
        val lo = lowerBoundW(t - (past * 1e9).toLong())
        val hi = min(wN - 1, lowerBoundW(t + (future * 1e9).toLong()))
        var sw = 0.0; var st = 0.0
        var a0 = 0.0; var a1 = 0.0; var a2 = 0.0; var a3 = 0.0
        val inv2 = 1.0 / (2.0 * sigma * sigma)
        for (i in lo..hi) {
            val dt = (wTs[i] - t) * 1e-9
            val w = exp(-dt * dt * inv2)
            if (w < 1e-4) continue
            val o = i * 4
            val s = if (wQa[o] * rQa[0] + wQa[o + 1] * rQa[1] +
                        wQa[o + 2] * rQa[2] + wQa[o + 3] * rQa[3] >= 0) 1.0 else -1.0
            a0 += w * s * wQa[o]; a1 += w * s * wQa[o + 1]
            a2 += w * s * wQa[o + 2]; a3 += w * s * wQa[o + 3]
            sw += w; st += w * wTs[i].toDouble()
        }
        if (sw < 1e-9) {
            out[0] = rQa[0]; out[1] = rQa[1]; out[2] = rQa[2]; out[3] = rQa[3]; return t
        }
        out[0] = a0; out[1] = a1; out[2] = a2; out[3] = a3
        qnorm(out)
        return (st / sw).toLong()
    }

    private fun lowerBound(t: Long): Int {
        var lo = 0; var hi = count - 1
        if (t <= ts[idx(0)]) return 0
        if (t >= ts[idx(hi)]) return hi
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (ts[idx(mid)] <= t) lo = mid else hi = mid
        }
        return lo
    }

    private fun lowerBoundW(t: Long): Int {
        if (wN == 0) return 0
        if (t <= wTs[0]) return 0
        if (t >= wTs[wN - 1]) return wN - 1
        var lo = 0; var hi = wN - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (wTs[mid] <= t) lo = mid else hi = mid
        }
        return lo
    }

    private fun nlerpWork(t: Long, out: DoubleArray) {
        val i0 = lowerBoundW(t)
        val i1 = min(i0 + 1, wN - 1)
        val t0 = wTs[i0]; val t1 = wTs[i1]
        val a = if (t1 > t0) ((t - t0).toDouble() / (t1 - t0)).coerceIn(0.0, 1.0) else 0.0
        val o0 = i0 * 4; val o1 = i1 * 4
        val s = if (wQa[o0] * wQa[o1] + wQa[o0 + 1] * wQa[o1 + 1] +
                    wQa[o0 + 2] * wQa[o1 + 2] + wQa[o0 + 3] * wQa[o1 + 3] >= 0) 1.0 else -1.0
        for (k in 0..3) out[k] = (1 - a) * wQa[o0 + k] + a * s * wQa[o1 + k]
        qnorm(out)
    }

    // ================================================================ автокалибровка

    fun startCalibration() {
        synchronized(pairLock) { pairN = 0 }
        calStartMs = SystemClock.elapsedRealtime()
        calibrating = true
    }

    fun failCalibration() {
        if (!calibrating) return
        calibrating = false
        onResult?.invoke(null)
    }

    fun addMotion(ta: Long, tb: Long, dx: Double, dy: Double) {
        synchronized(pairLock) {
            if (pairN == MAXP) {
                System.arraycopy(pairA, 1, pairA, 0, MAXP - 1)
                System.arraycopy(pairB, 1, pairB, 0, MAXP - 1)
                System.arraycopy(pairDx, 1, pairDx, 0, MAXP - 1)
                System.arraycopy(pairDy, 1, pairDy, 0, MAXP - 1)
                pairN--
            }
            pairA[pairN] = ta; pairB[pairN] = tb
            pairDx[pairN] = dx; pairDy[pairN] = dy
            pairN++
        }
    }

    fun requestCalibrate(fs: Double) {
        if (!calibrating || calRunning) return
        if (useArrival && !haveClock) return
        val baseNs = if (useArrival) clockOffset - ASSUMED_LATENCY_NS else 0L
        val pa: LongArray; val pb: LongArray; val dx: DoubleArray; val dy: DoubleArray
        synchronized(pairLock) {
            pa = pairA.copyOf(pairN); pb = pairB.copyOf(pairN)
            dx = pairDx.copyOf(pairN); dy = pairDy.copyOf(pairN)
        }
        if (pa.size < 20) return
        val rt: LongArray; val rc: DoubleArray
        synchronized(lock) {
            rt = LongArray(rawCount); rc = DoubleArray(rawCount * 3)
            for (i in 0 until rawCount) {
                val q = (rawHead - rawCount + i + CAP) % CAP
                rt[i] = rawT[q]
                rc[i * 3] = rawC[q * 3]; rc[i * 3 + 1] = rawC[q * 3 + 1]; rc[i * 3 + 2] = rawC[q * 3 + 2]
            }
        }
        calRunning = true
        Thread({
            var res: CalResult? = null
            try { res = solveSync(rt, rc, pa, pb, dx, dy, fs, baseNs) }
            catch (e: Exception) { Log.w(TAG, "solveSync: ${e.message}") }
            if (res != null && calibrating) {
                calShiftNs = res.shiftNs
                calibrated = true
                if (res.sensorRot != sensorRot) setSensorRot(res.sensorRot)
                calibrating = false
                onResult?.invoke(res)
            }
            calRunning = false
        }, "procam-sync").start()
    }

    private fun cumAt(rt: LongArray, rc: DoubleArray, t: Long): DoubleArray? {
        val n = rt.size
        if (n < 2 || t < rt[0] || t > rt[n - 1]) return null
        var lo = 0; var hi = n - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (rt[mid] <= t) lo = mid else hi = mid
        }
        val a = (t - rt[lo]).toDouble() / (rt[hi] - rt[lo]).toDouble()
        return doubleArrayOf(
            rc[lo * 3] * (1 - a) + rc[hi * 3] * a,
            rc[lo * 3 + 1] * (1 - a) + rc[hi * 3 + 1] * a,
            rc[lo * 3 + 2] * (1 - a) + rc[hi * 3 + 2] * a
        )
    }

    private fun syncScore(
        rt: LongArray, rc: DoubleArray, pa: LongArray, pb: LongArray,
        dx: DoubleArray, dy: DoubleArray, fs: Double, rot: Int, shiftNs: Long
    ): Double {
        var num = 0.0; var pp = 0.0; var mm = 0.0
        val c = DoubleArray(3)
        for (k in pa.indices) {
            val ca = cumAt(rt, rc, pa[k] + shiftNs) ?: return -2.0
            val cb = cumAt(rt, rc, pb[k] + shiftNs) ?: return -2.0
            mapToCam(rot, cb[0] - ca[0], cb[1] - ca[1], cb[2] - ca[2], c)
            val px = -fs * c[1]; val py = fs * c[0]
            num += px * dx[k] + py * dy[k]
            pp += px * px + py * py
            mm += dx[k] * dx[k] + dy[k] * dy[k]
        }
        return num / (sqrt(pp * mm) + 1e-12)
    }

    private fun solveSync(
        rt: LongArray, rc: DoubleArray, pa: LongArray, pb: LongArray,
        dx: DoubleArray, dy: DoubleArray, fs: Double, baseNs: Long
    ): CalResult? {
        val n = pa.size
        var e2 = 0.0
        for (k in 0 until n) e2 += dx[k] * dx[k] + dy[k] * dy[k]
        if (sqrt(e2 / n) < 0.25) return null
        val rots = intArrayOf(0, 90, 180, 270)
        val bestScore = DoubleArray(4); val bestMs = IntArray(4)
        for (ri in 0..3) {
            var bs = -2.0; var bm = 0
            var m = -100
            while (m <= 100) {
                val sc = syncScore(rt, rc, pa, pb, dx, dy, fs, rots[ri], baseNs + m * 1_000_000L)
                if (sc > bs) { bs = sc; bm = m }
                m += 4
            }
            for (mm in (bm - 3)..(bm + 3)) {
                val sc = syncScore(rt, rc, pa, pb, dx, dy, fs, rots[ri], baseNs + mm * 1_000_000L)
                if (sc > bs) { bs = sc; bm = mm }
            }
            bestScore[ri] = bs; bestMs[ri] = bm
        }
        var b1 = 0
        for (i in 1..3) if (bestScore[i] > bestScore[b1]) b1 = i
        var b2 = -1
        for (i in 0..3) if (i != b1 && (b2 < 0 || bestScore[i] > bestScore[b2])) b2 = i
        val margin = bestScore[b1] - bestScore[b2]
        if (bestScore[b1] < 0.5 || margin < 0.12) return null
        // ВАЖНО: результат — абсолютный сдвиг. Полуэкспозиция НЕ вычитается и НЕ прибавляется
        // потом: калибровка уже поглотила её. Иначе смена выдержки AE ломает синхронизацию.
        return CalResult(rots[b1], bestMs[b1] * 1_000_000L, bestScore[b1], bestMs[b1].toLong(), margin)
    }
}

// ---------------------------------------------------------------- кватернионы (без аллокаций)

private fun qmul(o: DoubleArray, a: DoubleArray, ao: Int, b: DoubleArray, bo: Int) {
    val aw = a[ao]; val ax = a[ao + 1]; val ay = a[ao + 2]; val az = a[ao + 3]
    val bw = b[bo]; val bx = b[bo + 1]; val by = b[bo + 2]; val bz = b[bo + 3]
    o[0] = aw * bw - ax * bx - ay * by - az * bz
    o[1] = aw * bx + ax * bw + ay * bz - az * by
    o[2] = aw * by - ax * bz + ay * bw + az * bx
    o[3] = aw * bz + ax * by - ay * bx + az * bw
}

private fun qconj(o: DoubleArray, a: DoubleArray, ao: Int) {
    o[0] = a[ao]; o[1] = -a[ao + 1]; o[2] = -a[ao + 2]; o[3] = -a[ao + 3]
}

private fun qnorm(q: DoubleArray) {
    val n = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    if (n < 1e-12) { q[0] = 1.0; q[1] = 0.0; q[2] = 0.0; q[3] = 0.0; return }
    q[0] /= n; q[1] /= n; q[2] /= n; q[3] /= n
}

private fun quatFromRotvec(o: DoubleArray, r: DoubleArray, ro: Int) {
    val x = r[ro]; val y = r[ro + 1]; val z = r[ro + 2]
    val a = sqrt(x * x + y * y + z * z)
    if (a < 1e-12) {
        o[0] = 1.0; o[1] = x * 0.5; o[2] = y * 0.5; o[3] = z * 0.5; qnorm(o); return
    }
    val s = sin(a / 2) / a
    o[0] = cos(a / 2); o[1] = x * s; o[2] = y * s; o[3] = z * s
}

private fun rotvecFrom(o: DoubleArray, q: DoubleArray, qo: Int) {
    val s = if (q[qo] < 0) -1.0 else 1.0
    val w = q[qo] * s; val x = q[qo + 1] * s; val y = q[qo + 2] * s; val z = q[qo + 3] * s
    val n = sqrt(x * x + y * y + z * z)
    if (n < 1e-12) { o[0] = 2 * x; o[1] = 2 * y; o[2] = 2 * z; return }
    val k = 2 * atan2(n, w) / n
    o[0] = x * k; o[1] = y * k; o[2] = z * k
}

/** Матрица 3x3 по строкам. */
private fun matFrom(o: DoubleArray, q: DoubleArray, qo: Int) {
    val w = q[qo]; val x = q[qo + 1]; val y = q[qo + 2]; val z = q[qo + 3]
    o[0] = 1 - 2 * (y * y + z * z); o[1] = 2 * (x * y - z * w); o[2] = 2 * (x * z + y * w)
    o[3] = 2 * (x * y + z * w); o[4] = 1 - 2 * (x * x + z * z); o[5] = 2 * (y * z - x * w)
    o[6] = 2 * (x * z - y * w); o[7] = 2 * (y * z + x * w); o[8] = 1 - 2 * (x * x + y * y)
}

private fun mapToCam(rot: Int, x: Double, y: Double, z: Double, o: DoubleArray) {
    when (rot) {
        90 -> { o[0] = -y; o[1] = -x; o[2] = -z }
        270 -> { o[0] = y; o[1] = x; o[2] = -z }
        180 -> { o[0] = -x; o[1] = y; o[2] = -z }
        else -> { o[0] = x; o[1] = -y; o[2] = -z }
    }
}
