package app.procam

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Rect
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.DynamicRangeProfiles
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.hardware.camera2.params.TonemapCurve
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.util.Size
import android.view.Surface
import java.util.concurrent.Executor
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

enum class Mode { SDR, LOG, HLG }
enum class Codec(val mime: String, val label: String) { HEVC(MIME_HEVC, "HEVC"), AVC(MIME_AVC, "H.264") }

val AWB_PRESETS = listOf(
    "AUTO" to CameraMetadata.CONTROL_AWB_MODE_AUTO,
    "3200K" to CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
    "4000K" to CameraMetadata.CONTROL_AWB_MODE_WARM_FLUORESCENT,
    "5500K" to CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT,
    "6500K" to CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
    "7500K" to CameraMetadata.CONTROL_AWB_MODE_SHADE
)

class Cfg {
    var cameraId = ""
    var size = Size(3840, 2160)
    var fps = 30
    var codec = Codec.HEVC
    var mode = Mode.SDR
    var curve = Curve.SLOG3
    var hwLog = false
    var emuHlg = false
    var tenBitEmu = false
    var bppIdx = 1
    var qualityPreset = 1
    var bitrateMode = 0      // 0 VBR, 1 CBR, 2 CQ
    var bitrateKbps = 0      // 0 = авто; иначе значение в кбит/с
    var gopSec = 1f
    var bFrames = false
    var audioKbps = 192
    var eisLock = true
    /** Ручная поправка: повернуть превью на 180° (если картинка на экране вверх ногами). */
    var previewTurn = false
    var smoothRec = false   // запись через GL: старт без пересоздания сессии камеры (нет подфриза)
    var audio = true
    // ручные параметры
    var aeManual = false
    var iso = 400
    var expNs = 20_833_333L
    var ev = 0
    var afManual = false
    var focus = 0f
    var awbIdx = 0
    var zoom = 1f
    /** Встроенная стабилизация: 0 выкл, 1 только OIS (оптика), 2 OIS + EIS камеры. */
    var stabMode = 2
    var stab: Boolean
        get() = stabMode > 0
        set(v) { stabMode = if (v) 2 else 0 }
    var torch = false
    // ассисты
    var zebra = false
    var zebraLevel = 0.95f
    var peaking = false
    var falseColor = false
    var hist = true
    var viewLog = false
    // Open Gate: писать весь сенсор (обычно 4:3), а не обрезанный 16:9
    var openGate = false
    // Яркость LOG в стопах (предусиление сцены перед кривой). 0 = «чистая» кривая, +1 по умолчанию — заметно ярче
    var logEv = 1
    // LUT: 0 = выкл, 1 = только превью, 2 = превью + запекание в запись (только GL-маршрут)
    var lutMode = 1
    var lutInLog = true
    // Шумоподавление. nrIsp — ISP камеры: 0 авто, 1 выкл, 2 быстрое, 3 высокое, 4 минимальное.
    // nrSoft — программное (GL: пространственный + временной фильтр): 0 выкл, 1..3 сила.
    var nrIsp = 0
    var nrSoft = 0
    // Электронная стабилизация по гироскопу (GL): 0 выкл, 1 слабая, 2 средняя, 3 сильная. eisSyncMs — ручная синхронизация.
    var eis = 0
    var eisSyncMs = 0
    // Вид стабилизации: false — сглаживание, true — блокировка горизонта (+ сглаживание). Рамка активной области: 0 выкл, 1 статичная, 2 живая.
    var eisHorizon = false
    var eisFrame = 2
    // Результаты автосинхронизации по камерам: id -> (оси SENSOR_ORIENTATION, добавка времени, мс). Хранится UI.
    val eisCal = HashMap<String, Pair<Int, Int>>()
}

/** direct: камера пишет прямо в кодек; иначе камера -> GL (эмуляция) -> кодек. */
data class Route(
    val direct: Boolean = true,
    val hlgNative: Boolean = false,
    val hwLog: Boolean = false,
    val tenBitGl: Boolean = false,
    val lutBaked: Boolean = false,  // LUT реально запекается в файл (нужен GL-маршрут)
    val glProc: Boolean = false     // включена программная обработка кадра (EIS / шумоподавление): только GL-маршрут
)

class CameraEngine(private val ctx: Context, private val ui: Listener) {

    /** Все вызовы приходят в главном потоке. */
    interface Listener {
        fun onInfo(text: String)
        fun onExposure(text: String)
        fun onHist(bins: IntArray)
        fun onError(msg: String)
        fun onRecording(on: Boolean)
        fun onPaused(on: Boolean)
        fun onSaved(path: String)
        fun onReady()
        fun onEisFrame(c: FloatArray?)
        /** Статус автосинхронизации гироскопа; saved = результат нужно сохранить (cfg.eisCal обновлён). */
        fun onSync(msg: String, saved: Boolean)
    }

    companion object { private const val TAG = "ProCamEngine" }

    val cfg = Cfg()
    @Volatile var caps: CamCaps? = null; private set

    private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("procam-cam").also { it.start() }
    private val handler = Handler(thread.looper)
    private val exec = Executor { handler.post(it) }
    private val main = Handler(Looper.getMainLooper())

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var gl: GlPipeline? = null
    fun debugInfo(): String = gl?.dbg?.ifEmpty { null } ?: "обработка кадра ещё не запущена"
    @Volatile private var selectedLut: CubeLut? = null

    /** Задать/убрать LUT. Если от наличия LUT зависит маршрут записи (режим «запись»), перезапускает превью. */
    fun setLut(lut: CubeLut?) {
        handler.post {
            val had = selectedLut != null
            selectedLut = lut
            if (running && recorder == null && cfg.lutMode == 2 && had != (lut != null)) {
                stopInternal()
                handler.postDelayed({ startInternal() }, 300)
            } else {
                gl?.setLut(lut)
                pushGlParams()
            }
        }
    }

    /** Применить изменение lutMode/lutInLog: перезапуск только если меняется маршрут записи. */
    fun lutConfigChanged() {
        handler.post {
            val c = caps
            if (running && c != null && recorder == null && decideRoute(c).lutBaked != route.lutBaked) {
                stopInternal()
                handler.postDelayed({ startInternal() }, 300)
            } else {
                pushGlParams()
            }
        }
    }
    /** Изменились EIS / программное шумоподавление: перезапуск, только если меняется маршрут (камера -> GL), иначе — «на лету». */
    fun procConfigChanged() {
        handler.post {
            val c = caps
            if (running && c != null && recorder == null && routeKey(decideRoute(c)) != routeKey(route)) {
                stopInternal()
                handler.postDelayed({ startInternal() }, 300)
            } else {
                pushGlParams()
                applyRepeating()
            }
        }
    }

    private fun routeKey(r: Route) = listOf(r.direct, r.hlgNative, r.hwLog, r.lutBaked, r.glProc)

    fun gyroAvailable(): Boolean = GyroStabilizer.available(ctx)

    fun horizonAvailable(): Boolean = GyroStabilizer.horizonAvailable(ctx)

    /** Повторить автосинхронизацию гироскопа с видео. */
    fun recalibrate() {
        handler.post {
            val gs = gyro
            if (gs == null) {
                main.post { ui.onSync("Сначала включите стабилизацию по гироскопу", false) }
            } else {
                gs.startCalibration()
                main.post { ui.onSync("Калибровка гироскопа: подвигайте телефоном 2–3 секунды, снимая что-нибудь с текстурой", false) }
            }
        }
    }

    private fun onCalResult(res: GyroStabilizer.CalResult?) {
        if (res == null) {
            main.post { ui.onSync("Автосинхронизация не удалась: мало движения или в кадре нет текстуры. Подвигайте телефон при хорошем свете и нажмите «Откалибровать заново».", false) }
            return
        }
        val ms = Math.round(res.shiftNs / 1e6).toInt()
        cfg.eisCal[cfg.cameraId] = Pair(res.sensorRot, ms)
        val txt = "Гироскоп синхронизирован: добавка ${if (ms >= 0) "+" else ""}$ms мс, оси для SENSOR_ORIENTATION ${res.sensorRot}° (совпадение ${(res.score * 100).toInt()} %)"
        main.post { ui.onSync(txt, true) }
    }

    /** Грубая модель шума: СКО ∝ sqrt(усиления). Это ОЦЕНКА, не измерение; при выключенном ISP-NR шум выше. */
    private fun nrSigma(): Float {
        val iso = if (lastIso > 0) lastIso else 400
        val ispK = when (cfg.nrIsp) { 1 -> 1.8f; 4 -> 1.3f; else -> 1f }
        return (0.012f * kotlin.math.sqrt(iso / 100f) * ispK).coerceIn(0.010f, 0.14f)
    }

    /** Режим шумоподавления ISP (1..4 из Cfg.nrIsp) поддерживается выбранной камерой. */
    fun nrIspAvailable(opt: Int): Boolean {
        val c = caps ?: return opt == 0
        return when (opt) {
            0 -> true
            1 -> c.nrModes.contains(CameraMetadata.NOISE_REDUCTION_MODE_OFF)
            2 -> c.nrModes.contains(CameraMetadata.NOISE_REDUCTION_MODE_FAST)
            3 -> c.nrModes.contains(CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY)
            4 -> c.nrModes.contains(CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL)
            else -> false
        }
    }

    private var camSurface: Surface? = null
    private var recSurface: Surface? = null
    private var previewSurface: Surface? = null
    private var recorder: Recorder? = null
    private var route = Route()
    private var running = false
    private var rotationDeg = 90
    private var focusRect: MeteringRectangle? = null
    private var frameCount = 0
    @Volatile private var lastIso = 0
    private var gyro: GyroStabilizer? = null
    @Volatile private var lastFocalMm = 0f
    @Volatile private var latestFrame: FloatArray? = null
    private val framePending = java.util.concurrent.atomic.AtomicBoolean(false)

    // ---------------------------------------------------------------- публичное API

    fun lenses(): List<Lens> = cm.cameraIdList.mapNotNull { id ->
        val ch = cm.getCameraCharacteristics(id)
        if (ch.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) return@mapNotNull null
        val cs = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toSet() ?: emptySet()
        if (!cs.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) return@mapNotNull null
        val fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
        val ss = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        val eq = if (fl != null && ss != null) (fl * 43.27 / hypot(ss.width.toDouble(), ss.height.toDouble())).roundToInt() else 0
        Lens(id, if (eq > 0) "${eq}mm" else "cam $id", eq)
    }.sortedBy { it.eq }

    /** Размеры для текущего режима (16:9 или Open Gate), которые реально может записать кодек телефона. */
    private fun sizesFor(c: CamCaps): List<Size> {
        val all = if (cfg.openGate && c.gateSizes.isNotEmpty()) c.gateSizes else c.videoSizes
        val ok = all.filter { Enc.supports(MIME_HEVC, it.width, it.height, 24) || Enc.supports(MIME_AVC, it.width, it.height, 24) }
        return ok.ifEmpty { all }
    }

    fun sizeOptions(): List<Size> = caps?.let { sizesFor(it) } ?: emptyList()

    /** Есть ли у выбранной камеры Open Gate. */
    fun gateAvailable(): Boolean = caps?.gateSizes?.isNotEmpty() == true

    fun fpsOptions(): List<Int> {
        val c = caps ?: return listOf(30)
        return fpsOptionsFor(c, cfg.size)
    }

    fun start(surface: Surface, displayRotationDeg: Int) {
        previewSurface = surface
        handler.post {
            rotationDeg = displayRotationDeg
            startInternal()
        }
    }

    /** Поворот дисплея изменился (landscape <-> reverse landscape). Превью и тап-фокус следуют сразу; метка поворота файла берётся в начале записи. */
    fun setRotation(displayRotationDeg: Int) {
        handler.post {
            if (rotationDeg == displayRotationDeg) return@post
            rotationDeg = displayRotationDeg
            pushGlParams()
        }
    }

    /** Буфер камеры нужно перевернуть на 180° относительно экрана (reverse landscape на «90°-сенсоре» и т.п.). */
    private fun needs180(c: CamCaps) = (c.sensorOrientation - rotationDeg + 360) % 360 == 180

    fun stop() {
        previewSurface = null
        handler.post { stopInternal() }
    }

    fun restart() {
        handler.post {
            stopInternal()
            handler.postDelayed({ startInternal() }, 300)
        }
    }

    /** Применить «живые» параметры (экспозиция, фокус, зум, ассисты) без перезапуска. */
    fun update() {
        handler.post {
            if (digitalRouteCheck()) return@post
            pushGlParams()
            applyRepeating()
        }
    }

    // ---- цифровой зум сверх аппаратного максимума камеры ----
    @Volatile private var digSticky = false
    private var digWarned = false

    /** Во сколько раз кадр надо дополнительно увеличить программно: запрошенный зум / то, что камера отдаёт аппаратно. */
    private fun digitalZoomWanted(c: CamCaps): Float {
        val hw = cfg.zoom.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
        return if (hw > 0.01f) maxOf(1f, cfg.zoom / hw) else 1f
    }

    /** Нужен ли GL-маршрут из-за цифрового зума (с гистерезисом, чтобы на границе камера не перезапускалась туда-сюда). */
    private fun wantsDigital(c: CamCaps): Boolean =
        digitalZoomWanted(c) > 1.001f || (digSticky && cfg.zoom >= c.zoomRange.upper * 0.6f)

    /** Реально применяемый цифровой зум: только на GL-маршруте (в прямой записи кадр до кодека не дотянуться). */
    private fun dzNow(): Float {
        val c = caps ?: return 1f
        return if (route.direct) 1f else digitalZoomWanted(c)
    }

    /** Переход между прямой записью и GL-маршрутом при выходе за аппаратный зум. true — запущен перезапуск камеры. */
    private fun digitalRouteCheck(): Boolean {
        val c = caps ?: return false
        val dz = digitalZoomWanted(c)
        if (dz > 1.001f) digSticky = true else {
            digWarned = false
            if (cfg.zoom < c.zoomRange.upper * 0.6f) digSticky = false
        }
        if (!running) return false
        if (recorder != null) {
            if (dz > 1.001f && route.direct && !digWarned) {
                digWarned = true
                main.post { ui.onError("Цифровой зум выше аппаратного не включить во время записи в прямом режиме. Остановите запись или включите «Плавный старт записи» (запись через GL).") }
            }
            return false
        }
        if (routeKey(decideRoute(c)) != routeKey(route)) {
            stopInternal()
            handler.postDelayed({ startInternal() }, 300)
            return true
        }
        return false
    }

    fun togglePause() {
        handler.post {
            val r = recorder ?: return@post
            r.setPaused(!r.paused)
            val p = r.paused
            main.post { ui.onPaused(p) }
        }
    }

    fun toggleRecord() {
        handler.post { if (recorder == null) startRecording() else stopRecording() }
    }

    fun tapFocus(u: Float, v: Float) {
        handler.post {
            val c = caps ?: return@post
            val a = c.activeArray
            // Тот же поворот, что у превью (needs180), иначе при перевёрнутом экране фокус уходит в противоположную точку.
            val flip = needs180(c)
            val uu = if (flip) 1f - u else u
            val vv = if (flip) 1f - v else v
            // Видимая область — центральный кроп по текущему зуму; регионы AF/AE заданы в координатах всего массива.
            val z = cfg.zoom.coerceIn(c.zoomRange.lower, c.zoomRange.upper).coerceAtLeast(1f) * dzNow()
            val cw = a.width() / z
            val ch = a.height() / z
            val cx = (a.centerX() + (uu - 0.5f) * cw).toInt()
            val cy = (a.centerY() + (vv - 0.5f) * ch).toInt()
            val half = (cw * 0.06f).toInt().coerceAtLeast(8)
            val r = Rect(
                (cx - half).coerceAtLeast(a.left), (cy - half).coerceAtLeast(a.top),
                (cx + half).coerceAtMost(a.right - 1), (cy + half).coerceAtMost(a.bottom - 1)
            )
            focusRect = MeteringRectangle(r, MeteringRectangle.METERING_WEIGHT_MAX)
            applyRepeating()
        }
    }

    fun clearFocus() {
        handler.post { focusRect = null; applyRepeating() }
    }

    fun release() {
        handler.post {
            stopInternal()
            thread.quitSafely()
        }
    }

    // ---------------------------------------------------------------- запуск

    private fun fpsOptionsFor(c: CamCaps, size: Size): List<Int> {
        val mx = c.maxFps(size)
        return listOf(24, 25, 30, 50, 60)
            .filter { it <= mx && Enc.supports(cfg.codec.mime, size.width, size.height, it) }
            .ifEmpty { listOf(mx.coerceIn(15, 30)) }
    }

    private fun normalize(c: CamCaps) {
        if (cfg.openGate && c.gateSizes.isEmpty()) {
            cfg.openGate = false
            main.post { ui.onError("Open Gate недоступен: эта камера не отдаёт для видео кадр шире 16:9 (весь сенсор). Включён обычный 16:9.") }
        }
        val sizes = sizesFor(c)
        if (sizes.isEmpty()) throw IllegalStateException("у камеры нет подходящих размеров видео")
        if (sizes.none { it == cfg.size }) {
            // Для 16:9 предпочитаем стандартный 4K UHD, а не самый широкий размер из списка (например, 4096×2304).
            cfg.size = sizes.firstOrNull { it.width == 3840 && it.height == 2160 } ?: sizes.first()
        }
        val opts = fpsOptionsFor(c, cfg.size)
        if (cfg.fps !in opts) cfg.fps = opts.lastOrNull { it <= 30 } ?: opts.first()
        if (cfg.codec == Codec.HEVC && !Enc.supports(MIME_HEVC, cfg.size.width, cfg.size.height, cfg.fps)) cfg.codec = Codec.AVC
    }

    private fun decideRoute(c: CamCaps): Route {
        val s = cfg.size
        val ten = cfg.tenBitEmu && cfg.codec == Codec.HEVC && Enc.hevcMain10(s.width, s.height, cfg.fps)
        // Запекание LUT возможно только когда кадр проходит через наш шейдер. HLG (LUT даёт SDR-картинку) и аппаратный LOG (прямая запись) — только превью.
        val bake = cfg.lutMode == 2 && selectedLut != null
        // Программные EIS и шумоподавление тоже требуют GL-маршрута: кадр должен пройти через наш шейдер, прежде чем попасть в кодер.
        val proc = (cfg.eis > 0 && GyroStabilizer.available(ctx)) || cfg.nrSoft > 0
        // Цифровой зум выше аппаратного тоже требует GL: кроп делает наш шейдер
        val dig = wantsDigital(c)
        return when (cfg.mode) {
            Mode.SDR -> if (bake || proc || cfg.smoothRec || dig) Route(direct = false, tenBitGl = ten, lutBaked = bake, glProc = proc) else Route()
            Mode.LOG ->
                if (cfg.hwLog && c.hwLog) {
                    if (proc || cfg.smoothRec || dig) Route(direct = false, hwLog = true, glProc = true) else Route(hwLog = true)
                } else Route(direct = false, tenBitGl = ten, lutBaked = bake, glProc = proc)
            Mode.HLG ->
                if (!proc && !dig && !cfg.emuHlg && c.hlg10Native && cfg.codec == Codec.HEVC && Enc.hevcMain10(s.width, s.height, cfg.fps))
                    Route(hlgNative = true) else Route(direct = false, tenBitGl = ten, glProc = proc)
        }
    }

    private fun describe(): String {
        val s = cfg.size
        val res = (if (cfg.openGate && s.width * 9 != s.height * 16) "OPEN GATE ${aspectLabel(s)} " else "") + sizeLabel(s)
        val mode = when (cfg.mode) {
            Mode.SDR -> "SDR Rec.709"
            Mode.LOG -> "LOG ${cfg.curve.label}"
            Mode.HLG -> "HLG"
        }
        val bits = if (route.tenBitGl) "10" else "8"
        val pipe = when {
            route.hlgNative -> "нативный HLG10 · 10-bit"
            route.hwLog -> "аппаратная tone-кривая · 8-bit"
            !route.direct -> "GL-эмуляция · $bits-bit"
            else -> "прямая запись · 8-bit"
        }
        val lut = when {
            selectedLut == null || cfg.lutMode == 0 -> ""
            route.lutBaked -> " · LUT: в видео и на экране"
            else -> " · LUT: только на экране"
        }
        val eisTxt = if (route.glProc && gyro != null && cfg.eis > 0) " · EIS ${listOf("", "слабая", "средняя", "сильная", "максимальная")[cfg.eis.coerceIn(0, 4)]}${if (cfg.eisHorizon) " + горизонт" else ""}" else ""
        val nrTxt = if (route.glProc && cfg.nrSoft > 0) " · NR ${cfg.nrSoft}" else ""
        return "${res}${cfg.fps} · ${cfg.codec.label} · $mode · $pipe$lut$eisTxt$nrTxt"
    }

    private fun startInternal() {
        if (running) return
        val sf = previewSurface ?: return
        try {
            if (cfg.cameraId.isEmpty() || !cm.cameraIdList.contains(cfg.cameraId)) {
                cfg.cameraId = lenses().firstOrNull { it.id == "0" }?.id ?: lenses().first().id
            }
            val c = CamCaps(cfg.cameraId, cm.getCameraCharacteristics(cfg.cameraId))
            caps = c
            normalize(c)
            route = decideRoute(c)
            running = true
            val stream = if (route.direct) c.previewStreamSizeFor(cfg.size) else cfg.size
            val g = GlPipeline { bins -> main.post { ui.onHist(bins) } }
            gl = g
            g.onEncoderError = {
                handler.post {
                    if (recorder != null) {
                        main.post { ui.onError("Поверхность кодека перестала принимать кадры — запись остановлена, файл сохранён до этого момента") }
                        stopRecording()
                    }
                }
            }
            g.onNotice = { msg -> main.post { ui.onError(msg) } }
            g.onEisFrame = { arr ->
                latestFrame = arr
                if (!framePending.getAndSet(true)) main.post { framePending.set(false); ui.onEisFrame(latestFrame) }
            }
            selectedLut?.let { g.setLut(it) }
            if (route.glProc && cfg.eis > 0 && GyroStabilizer.available(ctx)) {
                val gs = GyroStabilizer(ctx)
                val saved = cfg.eisCal[cfg.cameraId]
                if (gs.start(saved?.first ?: c.sensorOrientation, !c.timestampRealtime)) {
                    gs.calShiftNs = (saved?.second ?: 0) * 1_000_000L
                    gs.calibrated = saved != null
                    gs.rsEnable = true
                    gs.horizonStrength = 1f
                    gs.onResult = { res -> handler.post { onCalResult(res) } }
                    gs.startCalibration()
                    gyro = gs
                    g.stabilizer = gs
                    main.post { ui.onSync("Калибровка гироскопа: подвигайте телефоном 2–3 секунды, снимая что-нибудь с текстурой", false) }
                } else {
                    main.post { ui.onError("Гироскоп не отдаёт данные — стабилизация отключена") }
                }
            }
            pushGlParams()
            g.start(sf, stream.width, stream.height, route.tenBitGl) { surf, tenActive, err ->
                handler.post {
                    if (surf == null) { fail("GL: $err"); return@post }
                    camSurface = surf
                    route = route.copy(tenBitGl = tenActive)
                    val info = describe()
                    main.post { ui.onInfo(info); ui.onReady() }
                    openCamera()
                }
            }
        } catch (e: Exception) {
            fail("Старт: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        try {
            cm.openCamera(cfg.cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { camera = d; createSession(null) }
                override fun onDisconnected(d: CameraDevice) { d.close(); camera = null; fail("Камера отключена") }
                override fun onError(d: CameraDevice, error: Int) { d.close(); camera = null; fail("Ошибка камеры $error") }
            }, handler)
        } catch (e: CameraAccessException) {
            fail("openCamera: ${e.message}")
        } catch (e: SecurityException) {
            fail("Нет разрешения на камеру")
        }
    }

    private fun createSession(rec: Surface?) {
        val cam = camera ?: return
        val prev = camSurface ?: return
        recSurface = rec
        pushGlParams()
        val cb = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                if (rec != null) {
                    try {
                        recorder?.start()
                        main.post { ui.onRecording(true) }
                    } catch (e: Exception) {
                        Log.e(TAG, "recorder.start", e)
                        configureFailed(true)
                        return
                    }
                }
                applyRepeating()
            }

            override fun onConfigureFailed(s: CameraCaptureSession) { configureFailed(rec != null) }
        }
        try {
            val c = caps
            if (rec != null && route.hlgNative && c != null && Build.VERSION.SDK_INT >= 33) {
                val o1 = OutputConfiguration(prev)
                val o2 = OutputConfiguration(rec)
                o1.setDynamicRangeProfile(c.previewProfileForHlg())
                o2.setDynamicRangeProfile(DynamicRangeProfiles.HLG10)
                cam.createCaptureSession(SessionConfiguration(SessionConfiguration.SESSION_REGULAR, listOf(o1, o2), exec, cb))
            } else {
                @Suppress("DEPRECATION")
                cam.createCaptureSession(listOfNotNull(prev, rec), cb, handler)
            }
        } catch (e: Exception) {
            fail("Сессия: ${e.message}")
        }
    }

    private fun configureFailed(withRec: Boolean) {
        if (withRec) {
            val r = recorder
            recorder = null
            try { r?.abort() } catch (e: Exception) { }
            main.post {
                ui.onRecording(false)
                ui.onError("Телефон не принял конфигурацию записи (${cfg.mode}, ${cfg.size.width}p${cfg.fps}). Попробуйте эмуляцию, другой fps или кодек.")
            }
            createSession(null)
        } else {
            fail("Не удалось создать сессию камеры")
        }
    }

    // ---------------------------------------------------------------- запись

    private fun recConfig(c: CamCaps): RecConfig {
        val s = cfg.size
        val bpp = doubleArrayOf(0.10, 0.15, 0.22)[cfg.bppIdx.coerceIn(0, 2)] * (if (cfg.codec == Codec.AVC) 1.5 else 1.0)
        val auto = (s.width.toLong() * s.height * cfg.fps * bpp).toLong()
        val br = (if (cfg.bitrateKbps > 0) cfg.bitrateKbps * 1000L else auto)
            .coerceIn(8_000_000L, Enc.maxBitrate(cfg.codec.mime).toLong()).toInt()
        val tag = when (cfg.mode) { Mode.SDR -> ColorTag.BT709; Mode.LOG -> ColorTag.LOG; Mode.HLG -> ColorTag.HLG }
        val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        return RecConfig(
            s.width, s.height, cfg.fps, cfg.codec.mime, br,
            route.hlgNative || route.tenBitGl, tag, cfg.audio && mic,
            (c.sensorOrientation - rotationDeg + 360) % 360, c.timestampRealtime,
            cfg.bitrateMode, cfg.gopSec, cfg.bFrames, cfg.audioKbps
        )
    }

    private fun startRecording() {
        val c = caps ?: return
        if (!running || session == null) return
        val r = Recorder(ctx, recConfig(c))
        r.onVideoIssue = { msg, fatal ->
            main.post { ui.onError("Видео: $msg") }
            if (fatal) handler.post { if (recorder === r) stopRecording() }
        }
        try {
            r.prepare()
        } catch (e: Exception) {
            try { r.abort() } catch (x: Exception) { }
            main.post { ui.onError("Кодек не создан: ${e.message}") }
            return
        }
        recorder = r
        if (route.direct) {
            createSession(r.inputSurface)          // запись стартует в onConfigured
        } else {
            try {
                r.start()
                gl?.startEncoding(r.inputSurface!!, cfg.size.width, cfg.size.height)
                main.post { ui.onRecording(true) }
            } catch (e: Exception) {
                recorder = null
                try { r.abort() } catch (x: Exception) { }
                main.post { ui.onError("Старт записи: ${e.message}") }
            }
        }
    }

    private fun stopRecording() {
        val r = recorder ?: return
        recorder = null
        main.post { ui.onRecording(false) }
        if (route.direct) {
            createSession(null)                    // превью без выхода в кодек
            finishAsync(r)
            // запись была в прямом режиме: если зум успел уйти выше аппаратного, переключаемся на GL
            handler.postDelayed({ digitalRouteCheck() }, 900)
        } else {
            gl?.stopEncoding { finishAsync(r) }
        }
    }

    private fun finishAsync(r: Recorder) {
        Thread {
            val p = r.finish()
            main.post { if (p != null) ui.onSaved(p) else ui.onError("Файл не сохранён (нет данных)") }
        }.start()
    }

    // ---------------------------------------------------------------- запрос камеры

    private val captureCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            gyro?.let { gs ->
                val e = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                val k = res.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW)
                if (e != null && k != null) gs.setFrameTiming(e, k)
                res.get(CaptureResult.LENS_FOCAL_LENGTH)?.let { lastFocalMm = it }
            }
            res.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
            if (frameCount % 15 == 0) gl?.nrSigma = nrSigma()
            if (++frameCount % 15 != 0) return
            val iso = res.get(CaptureResult.SENSOR_SENSITIVITY)
            val et = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            if (iso != null && et != null && et > 0) {
                val t = "ISO $iso · 1/${(1e9 / et).roundToInt()}"
                main.post { ui.onExposure(t) }
            }
        }
    }

    private fun applyRepeating() {
        val s = session ?: return
        val cam = camera ?: return
        val c = caps ?: return
        val prev = camSurface ?: return
        try {
            val b = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            // Пока работает стабилизация по гироскопу, встроенные EIS и OIS камеры выключены: иначе они «двоят» коррекцию.
            val swEis = route.glProc && gyro != null && cfg.eis > 0
            b.addTarget(prev)
            recSurface?.let { b.addTarget(it) }
            b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, c.fpsRangeFor(cfg.fps))

            val iso = c.isoRange
            val exp = c.expRange
            if (cfg.aeManual && c.manualSensor && iso != null && exp != null) {
                b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
                b.set(CaptureRequest.SENSOR_SENSITIVITY, cfg.iso.coerceIn(iso.lower, iso.upper))
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, cfg.expNs.coerceIn(exp.lower, exp.upper))
                b.set(CaptureRequest.SENSOR_FRAME_DURATION, 1_000_000_000L / cfg.fps)
            } else {
                b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, cfg.ev)
            }

            val awb = AWB_PRESETS[cfg.awbIdx.coerceIn(0, AWB_PRESETS.size - 1)].second
            b.set(CaptureRequest.CONTROL_AWB_MODE, if (c.awbModes.contains(awb)) awb else CameraMetadata.CONTROL_AWB_MODE_AUTO)

            if (cfg.afManual && c.minFocus > 0f) {
                b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
                b.set(CaptureRequest.LENS_FOCUS_DISTANCE, cfg.focus.coerceIn(0f, c.minFocus))
            } else {
                if (c.afModes.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO))
                    b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                focusRect?.let { r ->
                    if (c.maxAfRegions > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(r))
                    if (c.maxAeRegions > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(r))
                }
            }

            val z = cfg.zoom.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
            if (Build.VERSION.SDK_INT >= 30) {
                b.set(CaptureRequest.CONTROL_ZOOM_RATIO, z)
            } else {
                val a = c.activeArray
                val w = (a.width() / z).toInt()
                val h = (a.height() / z).toInt()
                b.set(CaptureRequest.SCALER_CROP_REGION, Rect(a.centerX() - w / 2, a.centerY() - h / 2, a.centerX() + w / 2, a.centerY() + h / 2))
            }

            if (c.stabModes.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)) {
                b.set(
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    if (cfg.stabMode >= 2 && !swEis) CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON else CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
                )
            }
            if (c.oisModes.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)) {
                b.set(
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    if (cfg.stabMode >= 1 && !swEis) CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
                )
            }
            b.set(CaptureRequest.FLASH_MODE, if (cfg.torch) CameraMetadata.FLASH_MODE_TORCH else CameraMetadata.FLASH_MODE_OFF)

            val nrMode = when (cfg.nrIsp) {
                1 -> CameraMetadata.NOISE_REDUCTION_MODE_OFF
                2 -> CameraMetadata.NOISE_REDUCTION_MODE_FAST
                3 -> CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY
                4 -> CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL
                else -> -1
            }
            if (nrMode >= 0 && c.nrModes.contains(nrMode)) b.set(CaptureRequest.NOISE_REDUCTION_MODE, nrMode)

            if (route.hwLog && c.hwLog) {
                val pts = LogMath.tonemapPoints(cfg.curve, min(c.maxCurvePoints, 64), Math.pow(2.0, cfg.logEv.toDouble()).toFloat())
                b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE)
                b.set(CaptureRequest.TONEMAP_CURVE, TonemapCurve(pts, pts, pts))
            }
            s.setRepeatingRequest(b.build(), captureCb, handler)
        } catch (e: Exception) {
            Log.w(TAG, "applyRepeating: ${e.message}")
            main.post { ui.onError("Запрос камеры: ${e.message}") }
        }
    }

    private fun pushGlParams() {
        val c = caps
        val hlgPrev = recorder != null && route.hlgNative && c != null && c.previewProfileForHlg() != 1L
        val lutOn = selectedLut != null && cfg.lutMode != 0
        val eisOn = route.glProc && gyro != null && cfg.eis > 0
        val focal = if (c != null) focalPx(c) else 0f
        if (eisOn) {
            gyro?.manualOffsetNs = cfg.eisSyncMs * 1_000_000L
            gyro?.horizonLock = cfg.eisHorizon
            gyro?.lockEnable = cfg.eisLock && cfg.eis > 0
            if (c != null) gyro?.configure(eisTau(), focal.toDouble(), cfg.size.width, cfg.size.height, eisCrop().toDouble())
        }
        gl?.frameNs = 1_000_000_000L / cfg.fps.coerceAtLeast(1)
        gl?.params = GlParams(
            out = if (route.direct || route.hwLog) 0 else when (cfg.mode) { Mode.LOG -> 1; Mode.HLG -> 2; else -> 0 },
            curve = cfg.curve.ordinal,
            logGain = Math.pow(2.0, cfg.logEv.toDouble()).toFloat(),
            inLog = route.hwLog,
            inHlg = hlgPrev,
            viewLog = cfg.viewLog,
            zebra = cfg.zebra,
            zebraLevel = cfg.zebraLevel,
            peaking = cfg.peaking,
            falseColor = cfg.falseColor,
            hist = cfg.hist,
            previewTurn180 = cfg.previewTurn,
            sensorRot = c?.sensorOrientation ?: 90,
            dispRot = rotationDeg,
            lutView = lutOn,
            lutRec = lutOn && route.lutBaked,
            lutInLog = cfg.lutInLog,
            eis = eisOn,
            eisCrop = eisCrop(),
            dzoom = dzNow(),
            eisFocal = focal,
            nr = if (route.glProc) cfg.nrSoft.coerceIn(0, 3) else 0,
            eisFrame = if (eisOn) cfg.eisFrame.coerceIn(0, 2) else 0
        )
    }

    /** Постоянная времени сглаживания (с) и кроп-запас для уровней стабилизации 1..3. */
    private fun eisTau(): Double = doubleArrayOf(0.0, 0.10, 0.20, 0.35, 0.60)[cfg.eis.coerceIn(0, 4)]
    private fun eisCrop(): Float = (floatArrayOf(1f, 1.07f, 1.15f, 1.25f, 1.30f)[cfg.eis.coerceIn(0, 4)] + (if (cfg.eisHorizon && cfg.eis > 0) 0.10f else 0f)) * dzNow()

    /**
     * Фокусное расстояние в пикселях кадра записи: f_мм / ширина_датчика_мм * ширина_массива * (ширина_кадра / ширина_кропа) * зум.
     * Если характеристики неизвестны — берём горизонтальный угол обзора ~70°.
     */
    private fun focalPx(c: CamCaps): Float {
        val s = cfg.size
        val fl = if (lastFocalMm > 0f) lastFocalMm else c.focalMm
        val a = c.activeArray
        val ratio = s.width.toDouble() / s.height
        val arr = a.width().toDouble() / a.height()
        val cropW0 = if (ratio >= arr) a.width().toDouble() else a.height() * ratio
        val z = cfg.zoom.coerceIn(c.zoomRange.lower, c.zoomRange.upper).coerceAtLeast(0.1f)
        if (fl > 0f && c.physWidthMm > 0f) {
            return (fl / c.physWidthMm * a.width() * s.width / cropW0 * z).toFloat()
        }
        return ((s.width / 2.0) / Math.tan(Math.toRadians(35.0)) * z).toFloat()
    }

    // ---------------------------------------------------------------- остановка

    private fun stopInternal() {
        val r = recorder
        if (r != null) {
            recorder = null
            gl?.stopEncoding { }
            main.post { ui.onRecording(false) }
            finishAsync(r)
        }
        running = false
        try { session?.close() } catch (e: Exception) { }
        session = null
        recSurface = null
        try { camera?.close() } catch (e: Exception) { }
        camera = null
        try { gyro?.stop() } catch (e: Exception) { }
        gyro = null
        latestFrame = null
        main.post { ui.onEisFrame(null) }
        gl?.stop()
        gl = null
        camSurface = null
    }

    private fun fail(msg: String) {
        Log.e(TAG, msg)
        main.post { ui.onError(msg) }
        stopInternal()
    }
}
