import numpy as np, math
from eis_ref import *
W, H, f, crop = 3840, 2160, 2594.0, 1.25
def run(horizon, sign, roll_amp_deg=4.0, S=90, secs=8.0, seed=2):
    rng = np.random.default_rng(seed); M = dev_to_cam(S)
    fr = rng.uniform(2.0, 8.0, size=(3, 3)); am = rng.uniform(0.002, 0.006, size=(3, 3)); ph = rng.uniform(0, 6.28, size=(3, 3))
    axis = np.array([1.0, 0, 0]); U = np.array([1.0, 0, 0])     # «вверх» мира = ось x устройства в альбомной позе при t=0
    def R_dev(t):
        shake = np.array([np.sum(am[i]*np.sin(2*np.pi*fr[i]*t + ph[i])) for i in range(3)])
        roll = math.radians(roll_amp_deg)*math.sin(2*math.pi*0.25*t)
        return to_mat(from_rotvec(0.15*t*axis)) @ to_mat(from_rotvec(shake)) @ to_mat(from_rotvec(np.array([0, 0, roll])))
    st = Stab(S, cap=8192); st.configure(0.2, f, W, H, crop); st.horizon = horizon; st.sign = sign
    for t in np.arange(0, secs, 1/400):
        w = to_rotvec(mat_to_q(R_dev(t-1e-4).T @ R_dev(t+1e-4)))/2e-4
        st.gyro(t, w)
        if int(round(t*400)) % 4 == 0:   # акселерометр 100 Гц
            st.accel(t, 9.81 * (R_dev(t).T @ U))
    F = np.array([0.0, 0.0, -1.0]); Rr = np.array([0.0, -1.0, 0.0])      # вперёд и вправо в мировых осях (S=90)
    a_src, a_out = [], []
    for t in np.arange(1.5, secs-0.5, 1/30.0):
        Rc = R_dev(t) @ M.T; Rv = st.rot_at(t)
        def px(p, use_v):
            da = Rc.T @ p
            if use_v: da = Rv.T @ da; return f*crop*da[:2]/da[2]
            return f*da[:2]/da[2]
        for use_v, lst in ((False, a_src), (True, a_out)):
            A = px(F - 0.35*Rr, use_v); B = px(F + 0.35*Rr, use_v)
            lst.append(math.degrees(math.atan2(B[1]-A[1], B[0]-A[0])))
    return float(np.sqrt(np.mean(np.square(a_src)))), float(np.sqrt(np.mean(np.square(a_out))))
print("наклон горизонта (RMS, градусы), крен устройства ±4°:")
print("без блокировки           :", "%.2f -> %.2f" % run(False, 1))
print("блокировка, знак +1      :", "%.2f -> %.2f" % run(True, 1))
print("блокировка, знак -1      :", "%.2f -> %.2f" % run(True, -1))
for amp in (2.0, 6.0, 10.0, 16.0):
    print(f"крен ±{amp:4.1f}°, знак +1   : %.2f -> %.2f" % run(True, 1, roll_amp_deg=amp))
