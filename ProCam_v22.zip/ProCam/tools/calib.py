"""Прототип автосинхронизации гироскоп <-> видео: глобальный сдвиг между кадрами (проекции) + поиск смещения времени и осей."""
import numpy as np, math
from eis_ref import to_mat, from_rotvec, to_rotvec, mat_to_q, dev_to_cam

OUT_W, OUT_H = 128, 72

def make_texture(seed=5, n=1024):
    rng = np.random.default_rng(seed)
    spec = (rng.normal(size=(n, n//2+1)) + 1j*rng.normal(size=(n, n//2+1)))
    fy = np.fft.fftfreq(n)[:, None]; fx = np.fft.rfftfreq(n)[None, :]
    amp = 1.0/np.maximum(np.sqrt(fx**2 + fy**2), 1/n)**1.3
    t = np.fft.irfft2(spec*amp, s=(n, n)); t = (t - t.min())/(t.max() - t.min())
    return t

def bilinear(img, u, v):         # u, v — в пикселях текстуры
    h, w = img.shape
    u = np.clip(u, 0, w-1.001); v = np.clip(v, 0, h-1.001)
    u0 = np.floor(u).astype(int); v0 = np.floor(v).astype(int); du = u-u0; dv = v-v0
    return (img[v0, u0]*(1-du)*(1-dv) + img[v0, u0+1]*du*(1-dv) + img[v0+1, u0]*(1-du)*dv + img[v0+1, u0+1]*du*dv)

def render_probe(tex, R_cam, f_s, noise=0.02, rng=None):
    ys, xs = np.mgrid[0:OUT_H, 0:OUT_W]
    d = np.stack([(xs-OUT_W/2+0.5)/f_s, (ys-OUT_H/2+0.5)/f_s, np.ones_like(xs, float)], -1)
    w = d @ R_cam.T                                           # мировые лучи
    az = np.arctan2(w[..., 0], -w[..., 2]); el = np.arctan2(w[..., 1], np.hypot(w[..., 0], w[..., 2]))
    n = tex.shape[0]; u = (az/ (math.pi) * 0.5 + 0.5)*n*3 % n; v = (el/(math.pi)*0.5 + 0.5)*n*3 % n
    img = bilinear(tex, u, v)
    if noise and rng is not None: img = img + rng.normal(0, noise, img.shape)
    return img

def _profile_shift(a, b, R=10):
    def prep(x):
        x = x - x.mean(); k = 9; sm = np.convolve(x, np.ones(k)/k, mode='same'); x = x - sm
        win = np.hanning(len(x)); return x*win
    a = prep(a); b = prep(b); n = len(a)
    best = None; cs = []
    for s in range(-R, R+1):
        if s >= 0: c = np.dot(a[:n-s], b[s:])
        else: c = np.dot(a[-s:], b[:n+s])
        cs.append(c)
    cs = np.array(cs); i = int(np.argmax(cs))
    if i == 0 or i == len(cs)-1: return None
    den = cs[i-1] - 2*cs[i] + cs[i+1]
    sub = 0.5*(cs[i-1] - cs[i+1])/den if den != 0 else 0.0
    return (i - R) + sub, float(cs[i]/(np.linalg.norm(a)*np.linalg.norm(b) + 1e-9))

def global_shift(A, B, R=10):
    cx = _profile_shift(A.sum(0), B.sum(0), R); cy = _profile_shift(A.sum(1), B.sum(1), R)
    if cx is None or cy is None: return None
    return cx[0], cy[0], min(cx[1], cy[1])

class Gyro:
    """Сырой гироскоп в осях устройства + накопленный интеграл (для предсказания поворота между моментами)."""
    def __init__(self): self.t = []; self.c = [np.zeros(3)]
    def add(self, t, w):
        if self.t:
            dt = min(t - self.t[-1], 0.1); self.c.append(self.c[-1] + 0.5*(w + self.w)*dt)
        else: self.c = [np.zeros(3)]
        self.t.append(t); self.w = w
    def cum(self, tq):
        ts = np.array(self.t); i = int(np.clip(np.searchsorted(ts, tq) - 1, 0, len(ts)-2)); a = (tq - ts[i])/(ts[i+1]-ts[i])
        return (1-a)*self.c[i] + a*self.c[i+1]

def calibrate(gyro, pairs, f_s, search_ms=100, step_ms=1, min_corr=0.5, min_margin=0.12, min_rms=0.0):
    """pairs: список (ta, tb, dx, dy). Возвращает (S, delta_s, score, margin) или None."""
    P = np.array([[p[2], p[3]] for p in pairs]); rms = math.sqrt(float(np.mean(np.sum(P**2, 1))))
    if len(pairs) < 20 or rms < min_rms: return None
    ts = np.array(gyro.t); C = np.array(gyro.c)
    ta = np.array([p[0] for p in pairs]); tb = np.array([p[1] for p in pairs])
    results = {}
    for S in (0, 90, 180, 270):
        M = dev_to_cam(S); best = (-2, 0)
        for dms in range(-search_ms, search_ms+1, step_ms):
            d = dms/1000.0
            if ta.min() + d < ts[0] or tb.max() + d > ts[-1]: continue
            ca = np.stack([np.interp(ta + d, ts, C[:, k]) for k in range(3)], 1)
            cb = np.stack([np.interp(tb + d, ts, C[:, k]) for k in range(3)], 1)
            dphi = (cb - ca) @ M.T
            pred = np.stack([-f_s*dphi[:, 1], f_s*dphi[:, 0]], 1)
            sc = float(np.sum(pred*P))/(math.sqrt(float(np.sum(pred**2))*float(np.sum(P**2))) + 1e-12)
            if sc > best[0]: best = (sc, d)
        results[S] = best
    order = sorted(results.items(), key=lambda kv: -kv[1][0])
    (S1, (sc1, d1)), (S2, (sc2, d2)) = order[0], order[1]
    if sc1 < min_corr or sc1 - sc2 < min_margin: return None
    return S1, d1, sc1, sc1 - sc2

def simulate(S_true=90, delta_true=0.023, secs=8.0, seed=1, fps=30, probe_step=2, shake=1.0, pan=0.1, img_noise=0.02, f=2594.0, W=3840):
    rng = np.random.default_rng(seed); M = dev_to_cam(S_true); tex = make_texture(7)
    fr = rng.uniform(1.5, 7.0, size=(3, 4)); am = shake*rng.uniform(0.002, 0.008, size=(3, 4)); ph = rng.uniform(0, 2*np.pi, size=(3, 4))
    axis = np.array([1.0, 0, 0])
    def R_dev(t):
        sh = np.array([np.sum(am[i]*np.sin(2*np.pi*fr[i]*t + ph[i])) for i in range(3)])
        return to_mat(from_rotvec(pan*np.sin(0.5*t)*axis)) @ to_mat(from_rotvec(sh))
    g = Gyro(); bias = np.array([0.003, -0.002, 0.004])
    for t in np.arange(0, secs, 1/400):
        w = to_rotvec(mat_to_q(R_dev(t-1e-4).T @ R_dev(t+1e-4)))/2e-4 + bias + rng.normal(0, 0.002, 3)
        g.add(t, w)
    f_s = f*OUT_W/W; pairs = []; prev = None
    for k, ts in enumerate(np.arange(0.3, secs-0.4, 1/fps)):
        if k % probe_step: continue
        Rc = R_dev(ts + delta_true) @ M.T                    # содержимое кадра соответствует ориентации в момент ts + delta
        img = render_probe(tex, Rc, f_s, img_noise, rng)
        if prev is not None:
            r = global_shift(prev[1], img)
            if r is not None and r[2] > 0.3: pairs.append((prev[0], ts, r[0], r[1]))
        prev = (ts, img)
    return g, pairs, f_s

if __name__ == "__main__":
    for S_true, dt_true, shake in ((90, 0.023, 1.0), (90, -0.031, 1.0), (90, 0.060, 1.0), (270, 0.015, 1.0), (0, 0.040, 1.0), (90, 0.023, 0.3), (90, 0.023, 0.05)):
        g, pairs, f_s = simulate(S_true, dt_true, shake=shake)
        res = calibrate(g, pairs, f_s)
        txt = "нет уверенного результата" if res is None else f"S={res[0]} δ={res[1]*1000:+.0f} мс  корр.={res[2]:.2f}  запас над 2-м кандидатом={res[3]:.2f}"
        print(f"истина S={S_true:3d} δ={dt_true*1000:+4.0f} мс, тряска x{shake}: пар {len(pairs):3d} -> {txt}")
