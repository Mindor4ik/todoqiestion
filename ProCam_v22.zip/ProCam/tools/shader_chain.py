import numpy as np, math
from eis_ref import *

W, H, f, crop = 3840, 2160, 2594.0, 1.15
A = np.array([(W/2)/(f*crop), (H/2)/(f*crop)]); B = np.array([f/(W/2), f/(H/2)])

def rot_inv(q, rot):
    if rot == 1: return np.array([-q[1], q[0]])
    if rot == 2: return -q
    if rot == 3: return np.array([q[1], -q[0]])
    return q
def rot_fwd(p, rot):
    if rot == 1: return np.array([p[1], -p[0]])
    if rot == 2: return -p
    if rot == 3: return np.array([-p[1], p[0]])
    return p

def chain(q, R, tm, rot):      # зеркало GLSL: клип выхода -> клип источника -> uv текстуры OES
    d = np.array([q[0]*A[0], -q[1]*A[1], 1.0])
    s = R @ d
    q2 = np.array([s[0]/s[2]*B[0], -(s[1]/s[2])*B[1]])
    p = rot_inv(q2, rot)
    uv = tm @ np.array([p[0]*0.5+0.5, p[1]*0.5+0.5, 0, 1])
    return q2, uv[:2]

# 1) тождественная гомография и кроп=1: q' == q; uv == как в обычном (без прохода) шейдере
A1 = np.array([(W/2)/f, (H/2)/f])
for rot in range(4):
    tm = np.eye(4); tm[1,1] = -1; tm[1,3] = 1      # типичный флип по вертикали
    for q in (np.array([0.3, -0.4]), np.array([-0.9, 0.7])):
        d = np.array([q[0]*A1[0], -q[1]*A1[1], 1.0]); s = d
        q2 = np.array([s[0]/s[2]*B[0], -(s[1]/s[2])*B[1]])
        assert np.allclose(q2, q), (rot, q, q2)
        p = rot_inv(q, rot)
        assert np.allclose(rot_fwd(p, rot), q)       # rotInv — обратная к вершинному повороту
print("OK: единичная гомография даёт исходные координаты, rotInv обратна повороту для rot=0..3")

# 2) геометрия: мировая точка, видимая в «выходе» по эталону, при прогоне через шейдерную цепочку попадает в её пиксель источника
st = Stab(90, cap=4096); st.configure(0.2, f, W, H, crop)
M = dev_to_cam(90)
rng = np.random.default_rng(3)
R_dev = lambda t: to_mat(from_rotvec(0.2*t*np.array([1.0,0,0]))) @ to_mat(from_rotvec(np.array([0.01*math.sin(9*t), 0.012*math.sin(7*t+1), 0.008*math.sin(5*t+2)])))
for t in np.arange(0, 3, 1/400):
    w = to_rotvec(mat_to_q(R_dev(t-1e-4).T @ R_dev(t+1e-4)))/2e-4
    st.gyro(t, w)
worst = 0.0
for t in (1.0, 1.7, 2.3):
    Rc = R_dev(t) @ M.T
    Rv = st.rot_at(t)
    for p in ([0.0,0.0,1.0], [0.25,0.1,1.0], [-0.2,-0.12,1.0]):
        da = Rc.T @ np.array(p)                       # луч в реальной камере
        src_px = f*da[:2]/da[2]                       # пиксель источника (центр, y вниз)
        dv = Rv.T @ da
        out_px = f*crop*dv[:2]/dv[2]                  # где точка в выходном кадре по эталону
        q = np.array([out_px[0]/(W/2), -out_px[1]/(H/2)])      # в клип-координаты выхода
        q2, _ = chain(q, Rv, np.eye(4), 0)
        src_from_chain = np.array([q2[0]*(W/2), -q2[1]*(H/2)])
        worst = max(worst, float(np.max(np.abs(src_from_chain - src_px))))
print(f"OK: шейдерная цепочка совпадает с эталоном по геометрии, макс. расхождение {worst:.2e} px")
