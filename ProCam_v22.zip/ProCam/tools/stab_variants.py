"""Прототип v2: каскад фильтров + мягкий ограничитель + адаптивная скорость у края запаса + сдвиг вперёд по времени (используем «будущее» буфера гироскопа)."""
import numpy as np, math
from eis_ref import qmul, qconj, qnorm, from_rotvec, to_rotvec, to_mat, dev_to_cam, mat_to_q, roll_limit

class Stab2:
    def __init__(self, S=90, soft=True, shift=True, adaptive=True):
        self.M = dev_to_cam(S); self.t = []; self.qa = []; self.qv = []
        self.qA = np.array([1.0, 0, 0, 0]); self.q1 = self.qA.copy(); self.q2 = self.qA.copy()
        self.tp = None; self.wp = None; self.tau = 0.2; self.lim = np.array([0.05, 0.08, 0.07])
        self.soft, self.shift, self.adaptive = soft, shift, adaptive
    def configure(self, tau, f, W, H, crop):
        self.tau = tau
        sx = (W/2)*(1-1/crop); sy = (H/2)*(1-1/crop)
        self.lim = np.array([0.85*math.atan(sy/f), 0.85*math.atan(sx/f), 0.85*roll_limit(crop, W, H)])
    def gyro(self, t, wd):
        wc = self.M @ wd
        if self.tp is not None:
            dt = t - self.tp
            if 0 < dt <= 0.1:
                self.qA = qnorm(qmul(self.qA, from_rotvec(0.5*(wc+self.wp)*dt)))
                al = 1 - math.exp(-dt/(self.tau*0.5))
                if self.adaptive:
                    u = float(np.max(np.abs(to_rotvec(qmul(qconj(self.qA), self.q2)))/self.lim))
                    al = min(1.0, al*(1 + 8*min(max(u-0.6, 0), 1.0)**2))
                self.q1 = qnorm(qmul(self.q1, from_rotvec(al*to_rotvec(qmul(qconj(self.q1), self.qA)))))
                self.q2 = qnorm(qmul(self.q2, from_rotvec(al*to_rotvec(qmul(qconj(self.q2), self.q1)))))
                r = to_rotvec(qmul(qconj(self.qA), self.q2))
                hard = self.lim*(1.6 if self.soft else 1.0)          # защита от «наматывания» состояния
                rc = np.clip(r, -hard, hard)
                if np.any(rc != r): self.q2 = qnorm(qmul(self.qA, from_rotvec(rc)))
        self.tp = t; self.wp = wc
        self.t.append(t); self.qa.append(self.qA.copy()); self.qv.append(self.q2.copy())
    def _interp(self, arr, ts, tq):
        k = min(max(np.searchsorted(ts, tq) - 1, 0), len(ts)-2); a = min(max((tq - ts[k])/(ts[k+1]-ts[k]), 0), 1)
        s = 1 if np.dot(arr[k], arr[k+1]) >= 0 else -1
        return qnorm((1-a)*arr[k] + a*s*arr[k+1])
    def rot_at(self, tq):
        ts = np.array(self.t); qa = np.array(self.qa); qv = np.array(self.qv)
        look = max(0.0, ts[-1] - tq)
        L = min(0.9*look, 0.6*self.tau, 0.12) if self.shift else 0.0
        qA = self._interp(qa, ts, tq); qV = self._interp(qv, ts, tq + L)
        r = to_rotvec(qmul(qconj(qA), qV))
        if self.soft: r = self.lim*np.tanh(r/self.lim)
        else: r = np.clip(r, -self.lim, self.lim)
        return to_mat(from_rotvec(r))

def run(S=90, pan=0.1, tau=0.2, amp=1.0, crop=1.15, f=2594.0, W=3840, H=2160, t0=0.8, t1=5.0, look=0.06, sync=0.0, seed=1, **flags):
    rng = np.random.default_rng(seed); M = dev_to_cam(S)
    fr = rng.uniform(2.0, 8.0, size=(3, 4)); am = amp*rng.uniform(0.002, 0.008, size=(3, 4)); ph = rng.uniform(0, 2*np.pi, size=(3, 4))
    axis = np.array([1.0, 0, 0])
    def R_dev(t):
        sh = np.array([np.sum(am[i]*np.sin(2*np.pi*fr[i]*t + ph[i])) for i in range(3)])
        return to_mat(from_rotvec(pan*t*axis)) @ to_mat(from_rotvec(sh))
    st = Stab2(S, **flags); st.configure(tau, f, W, H, crop)
    tf = np.arange(t0, t1, 1/30.0); tg = np.arange(0, t1+0.5, 1/400); gi = 0
    pts = np.array([[0.0, 0, 1], [0.25, 0.1, 1], [-0.2, -0.12, 1], [0.3, -0.15, 1]])
    src, out = [], []
    for t in tf:
        while gi < len(tg) and tg[gi] <= t + look:
            wv = to_rotvec(mat_to_q(R_dev(tg[gi]-1e-4).T @ R_dev(tg[gi]+1e-4)))/2e-4; st.gyro(tg[gi], wv); gi += 1
        Rc = R_dev(t) @ M.T; Rv = st.rot_at(t + sync)
        s_row, o_row = [], []
        for p in pts:
            da = Rc.T @ p; s_row.append(f*da[:2]/da[2]); dv = Rv.T @ da; o_row.append(f*crop*dv[:2]/dv[2])
        src.append(s_row); out.append(o_row)
    src, out = np.array(src), np.array(out)
    acc = lambda x: float(np.sqrt(np.mean((x[2:] - 2*x[1:-1] + x[:-2])**2)))
    disp = float(np.max(np.abs(out - crop*src)))      # смещение кадра относительно «без стабилизации, только кроп»
    return acc(src), acc(out), disp

if __name__ == "__main__":
    variants = {"v1 (как сейчас)": dict(soft=False, shift=False, adaptive=False),
                "+мягкий предел": dict(soft=True, shift=False, adaptive=True),
                "+сдвиг вперёд": dict(soft=True, shift=True, adaptive=True)}
    for title, kw in (("только тряска", dict(pan=0.0, amp=1.0)), ("тряска + панорама 0.15 рад/с", dict(pan=0.15, amp=1.0)),
                      ("панорама 0.3 рад/с без тряски", dict(pan=0.3, amp=0.0, t1=3.0)), ("сильная тряска x4 + панорама 0.15", dict(pan=0.15, amp=4.0))):
        print("---", title)
        for name, fl in variants.items():
            a, b, d = run(**kw, **fl)
            print(f"  {name:16s}: подавление {100*(1-b/a):5.1f} %   макс. смещение кадра {d:6.1f} px")
