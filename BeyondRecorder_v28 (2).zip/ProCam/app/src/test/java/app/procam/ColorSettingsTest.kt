package app.procam

import org.junit.Assert.*
import org.junit.Test

class ColorSettingsTest {
    @Test fun v2ConfigMigratesAndKeepsValues() {
        val st = MemStore(mapOf(SettingsSchema.KEY_VERSION to 2, "fps" to 60, "lut_mode" to 2))
        SettingsManager(st).migrate()
        assertEquals(SettingsSchema.VERSION, st.all()[SettingsSchema.KEY_VERSION]); assertEquals(60, st.all()["fps"]); assertEquals(2, st.all()["lut_mode"])
    }
    @Test fun lutModeRecordOnlyAccepted() {
        val st = MemStore(mapOf("lut_mode" to 3)); SettingsManager(st).migrate()
        assertEquals(3, st.all()["lut_mode"])
    }
    @Test fun defaultsAreNeutral() {
        val cs = ColorSettings(MemStore())
        assertEquals(0, cs.i("c26_scope_mask")); assertEquals(1f, cs.f("c26_lut_mix")); assertFalse(cs.b("c26_custom_log")); assertEquals(0, cs.i("c26_dither"))
        val cu = ColorUniforms.build(cs, 0, 0, 0, false, false, 0.95f)
        assertFalse(cu.gradeOn); assertEquals(0, cu.tone)
    }
    @Test fun setClampsAndResetRestores() {
        val cs = ColorSettings(MemStore())
        cs.set("c26_sat", 99f); assertEquals(4f, cs.f("c26_sat"))
        cs.set("c26_ev", 1f); cs.reset(listOf("c26_ev", "c26_sat")); assertEquals(0f, cs.f("c26_ev")); assertEquals(1f, cs.f("c26_sat"))
    }
    @Test fun invalidStoredColorValuesSanitized() {
        val st = MemStore(mapOf("c26_sat" to 1000f, "c26_work" to 9))
        SettingsManager(st).migrate()
        assertEquals(1f, st.all()["c26_sat"]); assertEquals(0, st.all()["c26_work"])
    }
    @Test fun bypassIsNotPersisted() {
        val st = MemStore(); val cs = ColorSettings(st); cs.bypass = true
        assertTrue(st.all().keys.none { it.contains("bypass") })
    }
}
