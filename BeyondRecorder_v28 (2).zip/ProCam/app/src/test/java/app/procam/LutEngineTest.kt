package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

class LutEngineTest {
    private fun cube(n: Int, f: (DoubleArray) -> DoubleArray, title: String = "t"): CubeLut {
        val d = FloatArray(n * n * n * 3)
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val o = f(doubleArrayOf(r.toDouble() / (n - 1), g.toDouble() / (n - 1), b.toDouble() / (n - 1)))
            val i = ((b * n + g) * n + r) * 3
            for (c in 0..2) d[i + c] = o[c].toFloat()
        }
        return CubeLut(title, n, d)
    }
    private fun text3(l: CubeLut): String {
        val sb = StringBuilder("TITLE \"${l.title}\"\nLUT_3D_SIZE ${l.size}\n")
        for (i in 0 until l.size * l.size * l.size) sb.append("${l.data[i * 3]} ${l.data[i * 3 + 1]} ${l.data[i * 3 + 2]}\n")
        return sb.toString()
    }

    @Test fun identityLutsGiveInputBothInterpolations() {
        val rnd = Random(2)
        for (n in intArrayOf(2, 3, 17, 33)) {
            val l = cube(n, { it })
            repeat(300) {
                val p = DoubleArray(3) { rnd.nextDouble() }
                for (m in LutInterp.values()) { val o = LutEngine.sample3D(l, p, m); for (c in 0..2) assertEquals("n=$n $m", p[c], o[c], 1e-6) }
            }
        }
    }
    @Test fun affineLutIsExactForBoth() {
        val l = cube(9, { doubleArrayOf(0.8 * it[0] + 0.1 * it[1] + 0.05, 0.2 * it[0] + 0.7 * it[1] + 0.1 * it[2], 0.3 * it[2] + 0.1) })
        val rnd = Random(3)
        repeat(300) {
            val p = DoubleArray(3) { rnd.nextDouble() }
            val e = doubleArrayOf(0.8 * p[0] + 0.1 * p[1] + 0.05, 0.2 * p[0] + 0.7 * p[1] + 0.1 * p[2], 0.3 * p[2] + 0.1)
            for (m in LutInterp.values()) { val o = LutEngine.sample3D(l, p, m); for (c in 0..2) assertEquals(e[c], o[c], 1e-6) }
        }
    }
    @Test fun nodesAreReproducedExactly() {
        val l = cube(5, { doubleArrayOf(it[0] * it[0], it[1] * it[2], 1 - it[0]) })
        for (m in LutInterp.values()) for (b in 0 until 5) for (g in 0 until 5) for (r in 0 until 5) {
            val p = doubleArrayOf(r / 4.0, g / 4.0, b / 4.0)
            val o = LutEngine.sample3D(l, p, m); val i = ((b * 5 + g) * 5 + r) * 3
            for (c in 0..2) assertEquals(l.data[i + c].toDouble(), o[c], 1e-6)
        }
    }
    @Test fun trilinearAndTetrahedralDifferOnNonlinearButBoundedAndConverge() {
        val f = { v: DoubleArray -> doubleArrayOf(v[0] * v[1], v[1] * v[2], v[0] * v[2]) }   // мультилинейная: trilinear точна
        val l = cube(17, f)
        val rnd = Random(4); var maxDiff = 0.0
        repeat(500) {
            val p = DoubleArray(3) { rnd.nextDouble() }
            val e = f(p); val tri = LutEngine.sample3D(l, p, LutInterp.TRILINEAR); val tet = LutEngine.sample3D(l, p, LutInterp.TETRAHEDRAL)
            for (c in 0..2) { assertEquals(e[c], tri[c], 1e-6); maxDiff = maxOf(maxDiff, Math.abs(e[c] - tet[c])) }
        }
        assertTrue("tetra max error $maxDiff", maxDiff > 1e-5 && maxDiff < 0.01)
        // гладкая нелинейность: обе сходятся к аналитике при росте размера
        val g = { v: DoubleArray -> DoubleArray(3) { Math.pow(v[it], 2.2) } }
        fun err(n: Int, m: LutInterp): Double { val lut = cube(n, g); var e = 0.0; val r = Random(5); repeat(300) { val p = DoubleArray(3) { r.nextDouble() }; val o = LutEngine.sample3D(lut, p, m); e = maxOf(e, Math.abs(o[0] - Math.pow(p[0], 2.2))) }; return e }
        for (m in LutInterp.values()) assertTrue(err(33, m) < err(9, m))
    }
    @Test fun outOfDomainInputsAreClamped() {
        val l = cube(5, { it })
        val o = LutEngine.sample3D(l, doubleArrayOf(-1.0, 2.0, 0.5), LutInterp.TETRAHEDRAL)
        assertEquals(0.0, o[0], 1e-9); assertEquals(1.0, o[1], 1e-9)
    }
    @Test fun domainRangeRespected() {
        val l = CubeLut("d", 2, FloatArray(24) { i -> val c = (i / 3); val r = c and 1; val g = (c shr 1) and 1; val b = (c shr 2) and 1; floatArrayOf(r.toFloat(), g.toFloat(), b.toFloat())[i % 3] },
            floatArrayOf(-1f, -1f, -1f), floatArrayOf(3f, 3f, 3f))
        val o = LutEngine.sample3D(l, doubleArrayOf(1.0, 1.0, 1.0), LutInterp.TRILINEAR)   // середина домена −1…3
        for (c in 0..2) assertEquals(0.5, o[c], 1e-6)
    }

    @Test fun parse3DRoundTripAndInfo() {
        val l = cube(5, { doubleArrayOf(it[0] * 0.5, it[1], 1 - it[2]) }, "Test Look")
        val p = LutEngine.parse(text3(l)) as AnyLut.D3
        assertEquals(5, p.lut.size); assertEquals("Test Look", p.lut.title)
        val i = LutEngine.info(p); assertEquals("3D", i.kind); assertFalse(i.identity); assertEquals(125L * 3, i.entries)
        assertTrue(LutEngine.info(AnyLut.D3(cube(5, { it }))).identity)
    }
    @Test fun parse1D() {
        val txt = "# c\nTITLE \"curve\"\nLUT_1D_SIZE 3\n0 0 0\n0.7 0.5 0.3\n1 1 1\n"
        val l = LutEngine.parse(txt) as AnyLut.D1
        assertEquals(3, l.lut.size)
        val o = LutEngine.sample1D(l.lut, doubleArrayOf(0.25, 0.5, 1.0))
        assertEquals(0.35, o[0], 1e-6); assertEquals(0.5, o[1], 1e-6); assertEquals(1.0, o[2], 1e-6)
        val i = LutEngine.info(l); assertEquals("1D", i.kind); assertFalse(i.identity)
        assertTrue(LutEngine.info(LutEngine.parse("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n")).identity)
    }
    @Test fun parseErrorsAreExplicit() {
        fun fails(t: String, part: String) { try { LutEngine.parse(t); fail("ожидалась ошибка: $part") } catch (e: IllegalStateException) { assertTrue("${e.message}", e.message!!.contains(part)) } }
        fails("hello", "нет ни LUT_1D_SIZE")
        fails("LUT_1D_SIZE 2\nLUT_3D_SIZE 2\n", "одновременно")
        fails("LUT_1D_SIZE 3\n0 0 0\n1 1 1\n", "ожидалось 3")
        fails("LUT_1D_SIZE 2\n0 0 x\n1 1 1\n", "не число")
        fails("LUT_1D_SIZE 2\n0 0 NaN\n1 1 1\n", "не число")
        fails("LUT_1D_SIZE 1\n", "от 2")
        fails("LUT_3D_SIZE 2\n0 0 0\n", "ожидалось 8")
        fails("LUT_3D_SIZE 999\n", "от 2 до")
        fails("LUT_1D_SIZE 2\nDOMAIN_MIN 1 1 1\nDOMAIN_MAX 0 0 0\n0 0 0\n1 1 1\n", "DOMAIN_MAX")
    }
    @Test fun noSmallSizeCapAnymore() {
        assertTrue(CubeLutReader.MAX_SIZE >= 129)                 // v0.25: 65
        assertEquals(256L * 256 * 256 * 8, LutEngine.gpuBytes3D(256))
    }
    @Test fun warningsAboutDoubleOrWrongApplication() {
        val info = LutInfo("3D", 33, "x", 1, floatArrayOf(0f), floatArrayOf(1f), 0f, 1f, false, 1)
        val w = LutEngine.warnings(LutIo.REC709_G24_LOOK, LutScope.RECORD, Tf.SLOG3, true, info)
        assertTrue(w.any { it.contains("перестанет быть LOG") })
        assertTrue(LutEngine.warnings(LutIo.REC709_G24_LOOK, LutScope.MONITOR, Tf.SLOG3, true, info).isEmpty())
        assertTrue(LutEngine.warnings(LutIo.LOG_LOOK, LutScope.RECORD, Tf.SLOG3, true, info).isEmpty())   // v0.25: LUT как итоговый код
        val over = info.copy(outMax = 1.5f)
        assertTrue(LutEngine.warnings(LutIo.LOG_LOOK, LutScope.MONITOR, null, false, over).any { it.contains("обрезана") })
    }
    @Test fun scopeSemantics() {
        assertTrue(LutScope.MONITOR.onMonitor && !LutScope.MONITOR.onRecord)
        assertTrue(!LutScope.RECORD.onMonitor && LutScope.RECORD.onRecord)
        assertTrue(LutScope.BOTH.onMonitor && LutScope.BOTH.onRecord)
    }
}
