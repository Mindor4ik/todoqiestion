package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

class ColorMathTest {
    private fun near(exp: Double, act: Double, eps: Double, msg: String = "") = assertEquals(msg, exp, act, eps)

    @Test fun matrix709to2020MatchesShaderConstants() {
        val m = Spaces.convert(Spaces.REC709, Spaces.REC2020)
        val shader = doubleArrayOf(0.6274039, 0.3292830, 0.0433131, 0.0690973, 0.9195404, 0.0113623, 0.0163914, 0.0880133, 0.8955953)
        for (i in 0 until 9) near(shader[i], m[i], 2e-4, "m[$i]")
        val back = Spaces.convert(Spaces.REC2020, Spaces.REC709)
        val shader709 = doubleArrayOf(1.6604910, -0.5876411, -0.0728499, -0.1245505, 1.1328999, -0.0083494, -0.0181508, -0.1005789, 1.1187297)
        for (i in 0 until 9) near(shader709[i], back[i], 2e-4, "back[$i]")
    }
    @Test fun whiteMapsToWhiteInEverySpace() {
        for (a in Spaces.builtIn) for (b in Spaces.builtIn) {
            val w = M3.mulV(Spaces.convert(a, b), doubleArrayOf(1.0, 1.0, 1.0))
            for (c in 0..2) near(1.0, w[c], 1e-6, "${a.name}→${b.name}")
        }
    }
    @Test fun roundTripBetweenSpaces() {
        val m = M3.mul(Spaces.convert(Spaces.DISPLAY_P3, Spaces.REC709), Spaces.convert(Spaces.REC709, Spaces.DISPLAY_P3))
        assertTrue(M3.isIdentity(m, 1e-9))
    }
    @Test fun lumaWeights() {
        val w = Spaces.REC709.lumaWeights(); near(0.2126, w[0], 2e-4); near(0.7152, w[1], 2e-4); near(0.0722, w[2], 2e-4)
        val w2 = Spaces.REC2020.lumaWeights(); near(0.2627, w2[0], 2e-4); near(0.6780, w2[1], 2e-4); near(0.0593, w2[2], 2e-4)
    }
    @Test fun p3IsWiderThan709() {
        // чистый зелёный P3 в Rec.709 даёт отрицательные компоненты
        val g = M3.mulV(Spaces.convert(Spaces.DISPLAY_P3, Spaces.REC709), doubleArrayOf(0.0, 1.0, 0.0))
        assertTrue(g[0] < 0 && g[2] < 0)
    }

    @Test fun knownTransferValues() {
        near(0.7354, Tf.SRGB.encode(0.5), 1e-4)
        near(0.5, Tf.HLG.encode(1.0 / 12), 1e-9); near(1.0, Tf.HLG.encode(1.0), 1e-4)
        near(0.5081, Tf.PQ.encode(0.01), 2e-4); near(1.0, Tf.PQ.encode(1.0), 1e-9)
        near(420.0 / 1023.0, Tf.SLOG3.encode(0.18), 1e-9)            // 18 % серый = 420/1023
        near(0.4233, Tf.VLOG.encode(0.18), 2e-4)
        near(0.3910, Tf.LOGC.encode(0.18), 2e-4)
        near(Math.log(1 + 31 * 0.18) / Math.log(2.0) / 5, Tf.FLAT.encode(0.18), 1e-12)
        near(0.4090, Tf.BT709.encode(0.18), 2e-4)
    }
    @Test fun transferRoundTrips() {
        for (t in Tf.values()) {
            var x = 0.0
            while (x <= 1.0) {
                val y = t.encode(x)
                near(x, t.decode(y), 1e-6, "${t.label} x=$x")
                x += 0.01
            }
        }
    }
    @Test fun transfersMonotonic() {
        for (t in Tf.values()) { var prev = -1.0; var x = 0.0; while (x <= 1.0) { val y = t.encode(x); assertTrue("${t.label} $x", y >= prev - 1e-12); prev = y; x += 0.005 } }
    }
    @Test fun logCurvesNotConfusedWithGamma() {
        // LOG-кривая «поднимает» тени сильнее любой гаммы: 1 % света
        assertTrue(Tf.SLOG3.encode(0.01) > Tf.SRGB.encode(0.01) * 0.9)
        assertTrue(Tf.FLAT.encode(0.18) < Tf.SLOG3.encode(0.18) + 0.2)
    }
    @Test fun customLog() {
        val c = CustomLog("t")
        assertTrue(c.valid())
        for (x in doubleArrayOf(0.02, 0.1, 0.18, 0.5, 0.9)) near(x, c.decode(c.encode(x)), 1e-9)
        assertFalse(CustomLog("bad", a = -1.0).valid())
        assertFalse(CustomLog("nan", c = Double.NaN).valid())
        assertTrue(c.encode(5.0) <= 1.0 && c.encode(-1.0) >= 0.0)
    }

    @Test fun toneMapProperties() {
        for (t in ToneMap.values()) {
            near(0.0, t.apply(0.0), 1e-9, t.label)
            var prev = -1.0; var x = 0.0
            while (x < 20.0) { val y = t.apply(x); assertTrue(y in 0.0..1.0); assertTrue(y >= prev - 1e-12); prev = y; x += 0.05 }
        }
        near(1.0, ToneMap.REINHARD.apply(4.0, 4.0), 1e-9)       // белая точка уходит ровно в 1
        near(1.0, ToneMap.HABLE.apply(4.0, 4.0), 1e-9)
        assertEquals(0.5, ToneMap.NONE.apply(0.5), 0.0); assertEquals(1.0, ToneMap.NONE.apply(3.0), 0.0)   // NONE = обрезка как в v0.25
        assertTrue(ToneMap.FILMIC.apply(3.0) > ToneMap.NONE.apply(0.9) - 0.1)
    }
    @Test fun gamutDesatKeepsLumaAndRemovesNegatives() {
        val lw = Spaces.REC709.lumaWeights()
        val c = doubleArrayOf(-0.2, 0.9, 0.1)
        val y0 = lw[0] * c[0] + lw[1] * c[1] + lw[2] * c[2]
        val o = GamutMap.DESAT.apply(c, lw)
        assertTrue(o.all { it >= -1e-12 && it <= 1.0 })
        near(y0, lw[0] * o[0] + lw[1] * o[1] + lw[2] * o[2], 1e-9)
        val clip = GamutMap.CLIP.apply(c, lw); assertEquals(0.0, clip[0], 0.0)
        // внутри охвата ничего не меняется
        val ins = doubleArrayOf(0.2, 0.4, 0.6); val o2 = GamutMap.DESAT.apply(ins, lw); for (k in 0..2) near(ins[k], o2[k], 1e-12)
    }

    @Test fun whiteBalanceNeutralizesSceneWhite() {
        near(0.0, M3.mul(WhiteBalance.matrix(6500.0, 0.0, Spaces.REC709), M3.I).let { m -> (0 until 9).sumOf { abs(m[it] - M3.I[it]) } }, 1e-9)
        for (k in doubleArrayOf(2800.0, 3200.0, 5000.0, 8000.0, 12000.0)) {
            val xy = WhiteBalance.sceneWhite(k, 0.0)
            val xyz = doubleArrayOf(xy[0] / xy[1], 1.0, (1 - xy[0] - xy[1]) / xy[1])
            val rgb = M3.mulV(M3.inv(Spaces.REC709.toXyz()), xyz)
            val o = M3.mulV(WhiteBalance.matrix(k, 0.0, Spaces.REC709), rgb)
            near(o[0], o[1], 1e-6, "k=$k r/g"); near(o[2], o[1], 1e-6, "k=$k b/g")
        }
    }
    @Test fun whiteBalanceDirectionAndTint() {
        val tungsten = WhiteBalance.matrix(3200.0, 0.0, Spaces.REC709)      // источник тёплый → картинку надо охладить
        assertTrue(tungsten[8] > tungsten[0])
        val cool = WhiteBalance.matrix(9000.0, 0.0, Spaces.REC709)
        assertTrue(cool[0] > cool[8])
        val t0 = WhiteBalance.matrix(6500.0, 0.0, Spaces.REC709); val t1 = WhiteBalance.matrix(6500.0, 60.0, Spaces.REC709); val t2 = WhiteBalance.matrix(6500.0, -60.0, Spaces.REC709)
        assertFalse(M3.isIdentity(t1, 1e-4)); assertFalse(M3.isIdentity(t2, 1e-4))
        assertTrue((t1[4] - t0[4]) * (t2[4] - t0[4]) < 0)                    // знаки тинта дают противоположные сдвиги зелёного
    }
}
