package app.procam

import org.junit.Assert.*
import org.junit.Test

class ScopesTest {
    private fun frame(w: Int, h: Int, f: (Int, Int) -> IntArray): ByteArray {
        val b = ByteArray(w * h * 4)
        for (y in 0 until h) for (x in 0 until w) { val c = f(x, y); val i = (y * w + x) * 4; b[i] = c[0].toByte(); b[i + 1] = c[1].toByte(); b[i + 2] = c[2].toByte(); b[i + 3] = 255.toByte() }
        return b
    }

    @Test fun histogramOfSolidAndRamp() {
        val gray = Scopes.histogram(frame(16, 9) { _, _ -> intArrayOf(128, 128, 128) }, 144)
        assertEquals(144, gray.luma[128]); assertEquals(144, gray.r[128]); assertEquals(0, gray.luma[0])
        val ramp = Scopes.histogram(frame(256, 4) { x, _ -> intArrayOf(x, x, x) }, 1024)
        for (v in 0..255) assertEquals(4, ramp.luma[v])
        assertEquals(1f / 256, ramp.clippedHigh(), 1e-6f); assertEquals(1f / 256, ramp.clippedLow(), 1e-6f)
    }
    @Test fun histogramSeparatesChannels() {
        val h = Scopes.histogram(frame(8, 8) { _, _ -> intArrayOf(255, 10, 0) }, 64)
        assertEquals(64, h.r[255]); assertEquals(64, h.g[10]); assertEquals(64, h.b[0]); assertEquals(64, h.luma[Scopes.luma709(255, 10, 0)])
    }
    @Test fun waveformShowsLevelPerColumn() {
        val w = 64; val h = 8
        val px = frame(w, h) { x, _ -> val v = x * 255 / (w - 1); intArrayOf(v, v, v) }
        val wf = Scopes.waveform(px, w, h, 64)
        for (col in 0 until 64) {
            val v = col * 255 / 63
            assertEquals("col $col", h, wf[col * 256 + v])              // все h пикселей столбца на своём уровне
        }
        val half = Scopes.waveform(frame(32, 4) { x, _ -> if (x < 16) intArrayOf(0, 0, 0) else intArrayOf(255, 255, 255) }, 32, 4, 2)
        assertEquals(64, half[0 * 256 + 0]); assertEquals(64, half[1 * 256 + 255])
    }
    @Test fun rgbParadeSeparatesChannels() {
        val p = Scopes.parade(frame(8, 8) { _, _ -> intArrayOf(255, 0, 128) }, 8, 8, 8)
        assertEquals(8, p[0][3 * 256 + 255]); assertEquals(8, p[1][3 * 256 + 0]); assertEquals(8, p[2][3 * 256 + 128])
    }
    @Test fun vectorscopeGrayCentredColoursOffCentre() {
        val size = 128
        val g = Scopes.vectorscope(frame(4, 4) { _, _ -> intArrayOf(100, 100, 100) }, 16, size)
        val c = Scopes.vectorPos(100, 100, 100, size)
        assertEquals(16, g[c.second * size + c.first]); assertTrue(Math.abs(c.first - 63.5) <= 1 && Math.abs(c.second - 63.5) <= 1)
        val (rx, ry) = Scopes.vectorPos(255, 0, 0, size); assertTrue(ry > 120 && rx < 64)             // красный: Cr максимален
        val (bx, by) = Scopes.vectorPos(0, 0, 255, size); assertTrue(bx > 120 && by < 64)             // синий: Cb максимален
        val (yx, yy) = Scopes.vectorPos(255, 255, 0, size); assertTrue(yx < 40 && yy > 64 - 5)
    }
    @Test fun vectorscopeRadiusGrowsWithSaturation() {
        val size = 128; fun r(s: Int): Double { val (x, y) = Scopes.vectorPos(128 + s, 128, 128 - s, size); return Math.hypot(x - 63.5, y - 63.5) }
        assertTrue(r(10) < r(30) && r(30) < r(80))
    }
    @Test fun vectorTargetsAreInsideAndDistinct() {
        val t = Scopes.vectorTargets(128); assertEquals(6, t.size)
        assertEquals(6, t.map { it.second }.toSet().size)
    }
    @Test fun falseColorRanges() {
        val m = FalseColorMap.BEYOND
        assertNotNull(m.colorFor(0.01)); assertEquals(0x00BF33, m.colorFor(0.43)); assertNull(m.colorFor(0.5)); assertEquals(0xFF0000, m.colorFor(0.99)); assertEquals(0xFFE600, m.colorFor(0.93))
        assertEquals(10, FalseColorMap.SPECTRUM.ranges.size)
        for (i in 0..99) assertNotNull(FalseColorMap.SPECTRUM.colorFor(i / 100.0))
        val c = FalseColorMap.custom(0f, 0.1f, 0.4f, 0.5f, 0.9f, 1.01f); assertEquals(0x4040F2, c.colorFor(0.05)); assertNull(c.colorFor(0.2))
    }
    @Test fun zebraIndependentThresholds() {
        val z = ZebraConfig(hiOn = true, hiLevel = 0.9f, loOn = true, loLevel = 0.1f)
        assertEquals(1, z.hit(0.95)); assertEquals(2, z.hit(0.05)); assertEquals(0, z.hit(0.5))
        assertEquals(0, ZebraConfig(hiOn = false, loOn = true).hit(0.99)); assertEquals(1, ZebraConfig(hiOn = true, hiLevel = 0.5f).hit(0.6))
        assertEquals(0, ZebraConfig(loOn = false, hiOn = false).hit(0.0))
    }
    @Test fun colorBarsLandOnTheirTargets() {
        val bars = arrayOf(intArrayOf(191, 191, 191), intArrayOf(191, 191, 0), intArrayOf(0, 191, 191), intArrayOf(0, 191, 0), intArrayOf(191, 0, 191), intArrayOf(191, 0, 0), intArrayOf(0, 0, 191))
        val px = frame(7, 1) { x, _ -> bars[x] }
        val v = Scopes.vectorscope(px, 7, 128)
        for (b in bars.drop(1)) { val (x, y) = Scopes.vectorPos(b[0], b[1], b[2], 128); assertEquals(1, v[y * 128 + x]) }
        val targets = Scopes.vectorTargets(128).map { it.second }
        assertTrue(targets.all { t -> v[t.second * 128 + t.first] > 0 })
    }
}
