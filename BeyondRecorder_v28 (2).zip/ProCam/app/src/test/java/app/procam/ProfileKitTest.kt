package app.procam

import org.junit.Assert.*
import org.junit.Test

class ProfileKitTest {
    @Test fun defaultLayoutMatchesV027() {
        assertEquals(listOf(RailItem.ZEBRA, RailItem.PEAKING, RailItem.GRID, RailItem.LEVEL, RailItem.LOG, RailItem.LUT, RailItem.EIS, RailItem.NR), HomeLayouts.DEFAULT.visible())
    }
    @Test fun layoutRoundTripAndValidation() {
        val l = HomeLayouts.move(HomeLayouts.PROFESSIONAL, RailItem.NR, -3).copy(name = "A\tB", railOpacity = 70)
        val d = HomeLayouts.decode(HomeLayouts.encode(l)); assertEquals(l.entries, d.layout!!.entries); assertEquals(70, d.layout!!.railOpacity)
        assertNull(HomeLayouts.decode("garbage").layout)
        val bad = HomeLayouts.decode("BRL1\tX\t5\t0\tZEBRA:1,ZEBRA:0,FOO:1")
        assertEquals(30, bad.layout!!.railOpacity); assertEquals(RailItem.values().size, bad.layout!!.entries.size); assertTrue(bad.problems.size >= 3)
    }
    @Test fun lockedLayoutRejectsChanges() {
        val l = HomeLayouts.setLocked(HomeLayouts.DEFAULT, true)
        assertSame(l, HomeLayouts.move(l, RailItem.NR, -1)); assertEquals(l, HomeLayouts.setEnabled(l, RailItem.NR, false))
    }
    @Test fun corruptedActiveLayoutFallsBackToDefault() {
        assertEquals(HomeLayouts.DEFAULT, HomeLayoutStore(MemStore(mapOf(HomeLayouts.ACTIVE to "xx"))).active())
    }
    @Test fun uiProfileChangesOnlyUiKeys() {
        val st = MemStore(mapOf("fps" to 60, "rec_w" to 3840, "eis" to 3, "mode" to "LOG"))
        val written = UiProfiles.apply(st, UiProfiles.BUILT_IN.first { it.name == "Cinema" })
        assertTrue(UiProfiles.KEYS.containsAll(written))
        assertEquals(60, st.all()["fps"]); assertEquals(3, st.all()["eis"]); assertEquals("LOG", st.all()["mode"])
    }
    @Test fun customProfileRoundTripAndImportChecks() {
        val st = MemStore(mapOf("th28_variant" to 4, "ui_style" to 2)); UiProfiles.saveCurrent(st, "Мой")
        val text = UiProfiles.export(st, "Мой")!!
        val st2 = MemStore(); assertEquals("Мой" to null, UiProfiles.importProfile(st2, text))
        assertTrue(UiProfiles.applyCustom(st2, "Мой")); assertEquals(4, st2.all()["th28_variant"])
        assertNotNull(UiProfiles.importProfile(MemStore(), text.replace("Мой", "Чужой")).second)   // сумма не совпала
    }
    @Test fun settingsImportRejectsTamperingAndBadValues() {
        val st = MemStore(mapOf("fps" to 60)); val txt = SettingsPorter.exportAll(st)
        val st2 = MemStore(); assertEquals(1, SettingsPorter.importAll(st2, txt).applied)
        assertNotNull(SettingsPorter.importAll(MemStore(), txt.replace("60", "61")).fatal)
        val bad = Codec28.pack(SettingsPorter.KIND_ALL, mapOf("eis" to 99, "evil" to 1, "fps" to 24))
        val rep = SettingsPorter.importAll(MemStore(), bad); assertEquals(1, rep.applied); assertEquals(2, rep.rejected.size)
        assertNotNull(SettingsPorter.importAll(MemStore(), txt, SettingsPorter.KIND_UI).fatal)
    }
    @Test fun migrationCreatesRestorableBackup() {
        val st = MemStore(mapOf(SettingsSchema.KEY_VERSION to 4, "fps" to 60)); SettingsManager(st).migrate()
        assertTrue(SettingsPorter.hasBackup(st)); st.commit(mapOf("fps" to 24)); assertEquals(24, st.all()["fps"])
        assertTrue(SettingsPorter.restoreBackup(st).applied >= 1); assertEquals(60, st.all()["fps"])
    }
    @Test fun resetKeepsHistoryProfilesAndBackup() {
        val st = MemStore(mapOf("fps" to 60, AlertKeys.HISTORY to "x", "p28.ui.A" to "y", "b28.backup" to "z", "s28.fav" to "fps"))
        SettingsManager(st).resetToDefaults()
        assertFalse(st.all().containsKey("fps")); assertTrue(st.all().containsKey(AlertKeys.HISTORY) && st.all().containsKey("p28.ui.A") && st.all().containsKey("b28.backup"))
    }
    @Test fun cameraPresetExcludesInterface() {
        val st = MemStore(mapOf("fps" to 60, "ui_style" to 2, "th28_variant" to 3, "n28.OVERHEAT.mode" to "OFF")); val m = SettingsManager(st)
        m.savePreset("P"); st.commit(mapOf("fps" to 24, "ui_style" to 0)); m.applyPreset("P")
        assertEquals(60, st.all()["fps"]); assertEquals(0, st.all()["ui_style"])
    }
    @Test fun searchFindsAndRanks() {
        assertTrue(SettingsCatalog.search("шум").any { it.key == "nr_soft" }); assertTrue(SettingsCatalog.search("fps").first().key == "fps")
        assertTrue(SettingsCatalog.search("").isEmpty()); assertTrue(SettingsCatalog.search("zzzzqq").isEmpty())
        assertEquals(13, SettingCategory.values().size)
    }
    @Test fun favoritesAndHistory() {
        val st = MemStore(); val f = SettingFavorites(st)
        assertTrue(f.toggle("fps")); assertFalse(f.toggle("fps")); assertFalse(f.toggle("no_such"))
        val h = SettingHistory(st); h.record("fps", 30, 60, 5); h.record("s28.fav", null, "x", 6); h.record("fps", 60, 60, 7)
        assertEquals(1, h.rows().size); assertEquals("30", h.rows()[0].old)
    }
    @Test fun tradeoffFlag() {
        assertTrue(Suggestion("a", "b", mapOf("fps" to 30)).tradeoff)
        assertFalse(Suggestion("w", "warn").tradeoff); assertFalse(Suggestion("auto", "b", mapOf("q_kbps" to 0)).tradeoff)
    }
}
