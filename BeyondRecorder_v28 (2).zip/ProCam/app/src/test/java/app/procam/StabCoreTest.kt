package app.procam

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

class StabCoreTest {
    @Test fun adaptiveSigmaShrinksWithSpeedAndIsBounded() {
        val b = 0.2
        assertEquals(b, AdaptiveSmoothing.sigma(b, 0.0, 1.0), 1e-12)
        assertTrue(AdaptiveSmoothing.sigma(b, 0.35, 1.0) < b * 0.51)
        assertTrue(AdaptiveSmoothing.sigma(b, 0.1, 1.0) > AdaptiveSmoothing.sigma(b, 1.0, 1.0))
        assertEquals(b * 0.15, AdaptiveSmoothing.sigma(b, 100.0, 1.0), 1e-12)
        assertEquals(b, AdaptiveSmoothing.sigma(b, 5.0, 0.0), 1e-12)   // adapt=0 — окно постоянно
    }
    @Test fun characterTradesNaturalForStable() {
        assertTrue(AdaptiveSmoothing.adaptFor(0.0) > AdaptiveSmoothing.adaptFor(1.0))
        assertTrue(AdaptiveSmoothing.baseScaleFor(1.0) > AdaptiveSmoothing.baseScaleFor(0.0))
    }
    @Test fun slewLimiterSuppressesJump() {
        val s = SlewLimiter(0.01)
        assertEquals(0.0, s.step(0.0), 0.0)
        assertEquals(0.01, s.step(0.5), 1e-12)          // скачок на 0.5 → шаг только 0.01
        assertEquals(0.02, s.step(0.5), 1e-12)
        assertEquals(0.015, s.step(0.0, 0.5), 1e-12)    // масштаб шага
    }
    @Test fun cropControllerFastAttackSlowRelease() {
        val c = CropController(1.0, 1.5, attackPerSec = 3.0, releasePerSec = 0.3)
        val up = c.step(1.4, 0.033)
        assertTrue(up > 1.0 && up < 1.4)                  // не прыжок: ограничено скоростью
        repeat(60) { c.step(1.4, 0.033) }
        assertEquals(1.4, c.c, 1e-6)
        val rel = c.step(1.0, 0.033)
        assertTrue(rel < 1.4 && rel > 1.38)               // спад медленный
        assertEquals(1.5, CropController(1.0, 1.5).also { repeat(100) { _ -> it.step(9.0, 0.033) } }.c, 1e-9)  // не выше maxC
    }
    @Test fun requiredZoomGeometry() {
        assertEquals(1.0, CropMath.requiredZoom(1920.0, 1080.0, 0.0, 0.0, 0.0), 1e-12)
        // сдвиг 5% ширины: z = hw/(hw - tx)
        assertEquals(960.0 / (960 - 96), CropMath.requiredZoom(1920.0, 1080.0, 96.0, 0.0, 0.0), 1e-9)
        // поворот 5° без сдвига: проверяем напрямую — углы окна 1/z внутри кадра
        val z = CropMath.requiredZoom(1920.0, 1080.0, 0.0, 0.0, Math.toRadians(5.0))
        val r = Math.toRadians(5.0)
        val cx = 960.0 / z; val cy = 540.0 / z
        val ex = abs(cx * cos(r)) + abs(cy * sin(r)); val ey = abs(cx * sin(r)) + abs(cy * cos(r))
        assertTrue(ex <= 960.0 + 1e-6 && ey <= 540.0 + 1e-6)
        assertTrue(ey > 540.0 - 1e-6 || ex > 960.0 - 1e-6)    // минимальность: упираемся в границу
        assertTrue(CropMath.requiredZoom(100.0, 100.0, 60.0, 0.0, 0.0).isInfinite())
    }
    @Test fun cropLossNumbers() {
        assertEquals(0.0, CropMath.lossLinearPct(1.0), 1e-12)
        assertEquals(20.0, CropMath.lossLinearPct(1.25), 1e-9)
        assertEquals(36.0, CropMath.lossAreaPct(1.25), 1e-9)
        assertEquals(1.25, CropMath.cFromPct(20.0), 1e-9)
    }
    private fun grid(w: Int, h: Int, ang: Double): Gray {
        val d = FloatArray(w * h); val cx = w / 2.0; val cy = h / 2.0
        for (y in 0 until h) for (x in 0 until w) {
            val u = (x - cx) * cos(ang) + (y - cy) * sin(ang); val v = -(x - cx) * sin(ang) + (y - cy) * cos(ang)
            d[y * w + x] = (0.5 + 0.4 * tanh(4 * sin(u * 0.5)) * tanh(4 * sin(v * 0.5))).toFloat()
        }
        return Gray(w, h, d)
    }
    @Test fun imageTiltFindsGridRotationWithConfidence() {
        val t0 = HorizonEstimator.imageTilt(grid(160, 90, 0.0))!!
        assertEquals(0.0, t0.rad, 0.01); assertTrue("conf0=${t0.confidence}", t0.confidence > 0.6)
        val t = HorizonEstimator.imageTilt(grid(160, 90, Math.toRadians(7.0)))!!
        assertEquals(Math.toRadians(7.0), t.rad, Math.toRadians(2.5)); assertTrue("conf7=${t.confidence}", t.confidence > 0.6)
    }
    @Test fun imageTiltLowConfidenceOnNoise() {
        val rng = java.util.Random(1); val g = Gray(160, 90, FloatArray(160 * 90) { rng.nextFloat() })
        val t = HorizonEstimator.imageTilt(g)!!
        assertTrue("шум не должен выдаваться за горизонт: ${t.confidence}", t.confidence < 0.2)
    }
    /** Камера дрожит по x(t); строка r экспонируется на r·skew позже. Из сдвигов полос восстанавливаем skew. */
    @Test fun rsEstimatorRecoversSkew() {
        val skew = 0.020; val dt = 1.0 / 30
        fun x(t: Double) = 14.0 * sin(2 * PI * 2.0 * t) + 6.0 * sin(2 * PI * 3.3 * t + 1.0)
        fun band(k: Int, r: Double) = x(k * dt + r * skew) - x((k - 1) * dt + r * skew)
        val e = RsEstimator()
        for (k in 1..400) e.add(band(k, 1.0 / 6), band(k, 5.0 / 6), band(k, 0.5), dt)
        val s = e.skewSec()!!
        assertEquals(skew, s, skew * 0.12)
        assertTrue(e.reliability() > 0.9)
    }
    @Test fun rsEstimatorRefusesWhenNoData() {
        val e = RsEstimator()
        for (k in 0 until 100) e.add(1.0, 1.0, 1.0, 1.0 / 30)       // постоянная скорость: ускорения нет
        assertNull(e.skewSec()); assertEquals(0.0, e.reliability(), 0.0)
    }
    @Test fun temporalManagerTracksDropsAndGaps() {
        val m = TemporalManager(); m.setNominalFps(30)
        val dt = 33_333_333L; var t = 1_000_000_000L
        m.onFrame(t)
        repeat(10) { t += dt; assertFalse(m.onFrame(t).gap) }
        t += dt * 3                                      // потеряно 2 кадра
        val f = m.onFrame(t); assertEquals(2, f.dropped); assertFalse(f.gap)
        t += dt * 6                                      // большой разрыв → сброс истории
        val g = m.onFrame(t); assertTrue(g.gap); assertEquals(5, g.dropped)
        assertEquals(7L, m.droppedTotal); assertEquals(1L, m.gapResets)
        assertEquals(0L, m.onFrame(t).dtNs)              // метка не растёт → недействителен
    }
    @Test fun temporalFpsEstimateIsActualNotNominal() {
        val m = TemporalManager(); m.setNominalFps(60)
        var t = 0L; var fps = 0.0
        for (i in 0 until 40) { t += 40_000_000L; fps = m.onFrame(t + 1).fps }
        assertEquals(25.0, fps, 0.5)
    }
    @Test fun modesChangeAlgorithmsNotRecordingParams() {
        val m = TemporalManager()
        m.mode = TemporalManager.Mode.LOW_LATENCY; val a = m.profile()
        m.mode = TemporalManager.Mode.MAX_QUALITY; val b = m.profile()
        assertTrue(a.analysisW < b.analysisW && a.maxFeatures < b.maxFeatures && a.flowLevels < b.flowLevels)
        assertTrue(a.futureWindowSec < b.futureWindowSec && a.nrTemporalScale < b.nrTemporalScale)
    }
    @Test fun bandShiftsSplitsTopBottom() {
        val n = 30
        val x0 = FloatArray(n) { (it % 5 - 2) * 24f }; val y0 = FloatArray(n) { (it / 5 - 3) * 10f }
        val x1 = FloatArray(n) { x0[it] + (if (y0[it] <= -10) 1f else if (y0[it] >= 20) 3f else 2f) }; val y1 = FloatArray(n) { y0[it] + (if (x0[it] < 0) -1f else if (x0[it] > 0) 1f else 0f) }
        val g = GlobalMotion(2.0, 0.0, 0.0, 1.0, n, n, 1.0, FlowMethod.LK_PYRAMID, 0.0, x0, y0, x1, y1, BooleanArray(n) { true })
        val r = BandShifts.of(g, 120, 60)!!
        assertEquals(1.0, r.rowsFirstX, 1e-6); assertEquals(3.0, r.rowsLastX, 1e-6); assertEquals(2.0, r.rowsMidX, 1e-6)
        assertEquals(-1.0, r.colsFirstY, 1e-6); assertEquals(1.0, r.colsLastY, 1e-6)
    }
}
