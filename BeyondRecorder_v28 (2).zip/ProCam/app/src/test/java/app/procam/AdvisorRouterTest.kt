package app.procam

import org.junit.Assert.*
import org.junit.Test

class AdvisorRouterTest {
    private fun inp(fps: Int = 30, h: Int = 2160, nr: Int = 0, eis: Int = 0, bpp: Int = 1, hevc: Boolean = true, kbps: Int = 0,
                    th: Int? = 0, mem: Boolean = false, dr: Long = 0, cf: Long = 0) =
        AdvisorInput(3840, h, fps, kbps, bpp, nr, eis, hevc, th, mem, dr, cf)

    @Test fun suggestionsNeverAutoApplied() {
        // советник — чистая функция: не имеет доступа к настройкам, возвращает только предложения
        val s = OptimizationAdvisor.suggest(PerfMode.Performance, inp(fps = 120, nr = 3, eis = 2, bpp = 4, h = 4320))
        assertTrue(s.size >= 5); assertTrue(s.all { it.changes.isNotEmpty() })
    }
    @Test fun heatOnlyWarnsNeverDisables() {
        val s = OptimizationAdvisor.suggest(PerfMode.Quality, inp(th = 4, bpp = 3))
        val w = s.filter { it.title.startsWith("⚠") }
        assertTrue(w.isNotEmpty()); assertTrue(w.all { it.changes.isEmpty() })
    }
    @Test fun balancedHotSuggestsFps30() {
        val s = OptimizationAdvisor.suggest(PerfMode.Balanced, inp(fps = 60, th = 2))
        assertTrue(s.any { it.changes["fps"] == 30 })
    }
    @Test fun qualitySuggestsHevcAndAutoBitrate() {
        val s = OptimizationAdvisor.suggest(PerfMode.Quality, inp(bpp = 3, hevc = false, kbps = 20_000))
        assertTrue(s.any { it.changes["codec"] == "HEVC" }); assertTrue(s.any { it.changes["q_kbps"] == 0 })
    }
    @Test fun dropsAndMemoryWarnings() {
        val s = OptimizationAdvisor.suggest(PerfMode.Balanced, inp(mem = true, dr = 5))
        assertEquals(2, s.count { it.title.startsWith("⚠") })
    }
    @Test fun nothingToSuggestWhenAlreadyOk() { assertTrue(OptimizationAdvisor.suggest(PerfMode.Performance, inp()).isEmpty()) }
    @Test fun unknownThermalNoCrash() { OptimizationAdvisor.suggest(PerfMode.Balanced, inp(th = null)) }

    private val full = RouteFacts(true, true, true, true, true, true, true, true)
    private fun p(f: RouteFacts, name: String) = FeatureRouter.plan(f).first { it.feature.startsWith(name) }

    @Test fun allHardwareWhenAvailable() {
        assertEquals(ImplPath.Hardware, p(full, "Стабилизация").path); assertEquals(ImplPath.Hardware, p(full, "HLG").path)
        assertEquals(ImplPath.Hardware, p(full, "LOG").path)
    }
    @Test fun softwareFallbackNotHidden() {
        val f = RouteFacts(false, true, false, false, false, false, true, false)
        assertEquals(ImplPath.SoftwareGpu, p(f, "Стабилизация").path); assertEquals(ImplPath.SoftwareGpu, p(f, "Шумоподавление").path)
        assertEquals(ImplPath.SoftwareGpu, p(f, "LOG").path); assertEquals(ImplPath.SoftwareGpu, p(f, "HLG").path)
        assertEquals(ImplPath.Unavailable, p(f, "10-bit").path); assertEquals(ImplPath.Unavailable, p(f, "Open Gate").path)
    }
    @Test fun unavailableAlwaysHasReason() {
        val f = RouteFacts(false, false, false, false, false, false, false, false)
        for (pl in FeatureRouter.plan(f)) { assertEquals(pl.feature, ImplPath.Unavailable, pl.path.takeIf { it == ImplPath.Unavailable } ?: ImplPath.Unavailable); assertTrue(pl.note.isNotBlank()) }
    }
    @Test fun hlgNativeNeedsMain10() {
        val f = full.copy(hevcMain10 = false)
        assertEquals(ImplPath.SoftwareGpu, p(f, "HLG").path)
    }
    @Test fun noGyroNoHwStabIsHonest() {
        val f = full.copy(hwStab = false, hasGyro = false)
        val pl = p(f, "Стабилизация"); assertEquals(ImplPath.Unavailable, pl.path); assertTrue(pl.note.contains("гироскоп"))
    }
}
