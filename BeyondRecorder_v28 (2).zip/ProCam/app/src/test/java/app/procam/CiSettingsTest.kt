package app.procam

import org.junit.Assert.*
import org.junit.Test

class CiSettingsTest {
    @Test fun v3ConfigMigratesToV4KeepingValuesAndColorKeys() {
        val st = MemStore(mapOf(SettingsSchema.KEY_VERSION to 3, "eis" to 3, "nr_soft" to 2, "c26_sat" to 1.3f))
        SettingsManager(st).migrate()
        assertEquals(SettingsSchema.VERSION, st.all()[SettingsSchema.KEY_VERSION]); assertEquals(3, st.all()["eis"]); assertEquals(2, st.all()["nr_soft"]); assertEquals(1.3f, st.all()["c26_sat"])
        assertEquals(1f, CiSettings(st).f("ci_strength"))
    }
    @Test fun defaultsReproduceV26Behaviour() {
        val c = CiSettings(MemStore())
        assertEquals(0, c.i("ci_src")); assertFalse(c.b("ci_adapt")); assertFalse(c.b("ci_dyncrop")); assertEquals(0, c.i("ci_border"))
        assertEquals(-1f, c.f("ci_maxcrop")); assertEquals(2, c.i("ci_lock_flow")); assertFalse(c.b("ci_nr_adv")); assertFalse(c.b("ci_ll")); assertFalse(c.b("ci_nr_mc"))
        assertNull(NrMap.map(c.nr(0, TemporalManager.profileOf(c.temporal()))))                 // NR не включается сам
        val p = NrMap.map(c.nr(3, TemporalManager.profileOf(TemporalManager.Mode.BALANCED)))!!
        assertEquals(0.08f, p.aY, 1e-6f)                                                          // быстрые уровни = v0.25
    }
    @Test fun valuesAreClampedAndInvalidSanitized() {
        val st = MemStore(mapOf("ci_strength" to 99f, "ci_border" to 7, "ci_hz_trim" to -50f))
        SettingsManager(st).migrate()
        assertEquals(1f, st.all()["ci_strength"]); assertEquals(0, st.all()["ci_border"]); assertEquals(0f, st.all()["ci_hz_trim"])
        val c = CiSettings(MemStore()); c.set("ci_strength", 99); assertEquals(4f, c.f("ci_strength"))
    }
    @Test fun compareIsNotPersisted() {
        val st = MemStore(); val c = CiSettings(st); c.compare = true
        assertTrue(st.all().keys.none { it.contains("compare") })
    }
    @Test fun analysisFollowsModeUnlessOverridden() {
        val c = CiSettings(MemStore())
        c.set("ci_proc", 0); val a = c.analysis(TemporalManager.profileOf(c.temporal()))
        assertEquals(96, a.w); assertEquals(2, a.every)
        c.set("ci_an_w", 3); c.set("ci_an_div", 1)
        val b = c.analysis(TemporalManager.profileOf(c.temporal()))
        assertEquals(160, b.w); assertEquals(1, b.every)
    }
    @Test fun resetRestoresDefaults() {
        val c = CiSettings(MemStore()); c.set("ci_maxcrop", 25f); c.set("ci_dyncrop", true)
        c.reset(listOf("ci_maxcrop", "ci_dyncrop")); assertEquals(-1f, c.f("ci_maxcrop")); assertFalse(c.b("ci_dyncrop"))
    }
    @Test fun presetsCarryCiKeys() {
        assertTrue(CiKeys.rules.keys.all { SettingsSchema.rules.containsKey(it) })
    }
}
