package app.procam

import org.junit.Assert.*
import org.junit.Test

class StateTest {
    @Test fun normalLifecycle() {
        val s = AppState()
        assertTrue(s.camera.go(CameraState.Opening)); assertTrue(s.camera.go(CameraState.Configuring)); assertTrue(s.camera.go(CameraState.Preview))
        assertTrue(s.recording.go(RecordingState.Preparing)); assertTrue(s.recording.go(RecordingState.Recording))
        assertTrue(s.recording.go(RecordingState.Paused)); assertTrue(s.recording.go(RecordingState.Recording))
        assertTrue(s.recording.go(RecordingState.Finalizing)); assertTrue(s.recording.go(RecordingState.Completed))
        assertTrue(s.recording.go(RecordingState.Idle))
        assertTrue(s.invariantViolations().isEmpty())
    }
    @Test fun forbiddenTransitionIsRejectedAndLogged() {
        val s = AppState()
        assertFalse(s.recording.go(RecordingState.Recording, "без подготовки"))
        assertEquals(RecordingState.Idle, s.recording.state)
        assertEquals(1, s.recording.violations().size)
        assertFalse(s.camera.go(CameraState.Preview))
        assertEquals(CameraState.Closed, s.camera.state)
    }
    @Test fun sameStateIsNoop() {
        val s = AppState()
        assertTrue(s.camera.go(CameraState.Closed))
        assertTrue(s.camera.recent().isEmpty())
    }
    @Test fun forceWorksFromAnywhereAndIsLogged() {
        val s = AppState()
        s.camera.go(CameraState.Opening); s.camera.go(CameraState.Configuring); s.camera.go(CameraState.Preview)
        s.camera.force(CameraState.Closed, "disconnect")
        assertEquals(CameraState.Closed, s.camera.state)
        assertTrue(s.camera.recent().last().reason.startsWith("force"))
    }
    @Test fun invariantRecordingWithClosedCamera() {
        val s = AppState()
        s.recording.go(RecordingState.Preparing)
        assertTrue(s.invariantViolations().any { it.contains("закрытой") })
    }
    @Test fun everyStateReachableAndTablesComplete() {
        for (c in CameraState.values()) assertTrue("camera $c", AppState.cameraTable.containsKey(c))
        for (r in RecordingState.values()) assertTrue("rec $r", AppState.recordingTable.containsKey(r))
        // из Error всегда есть выход
        assertTrue(AppState.cameraTable[CameraState.Error]!!.isNotEmpty())
        assertTrue(AppState.recordingTable[RecordingState.Error]!!.isNotEmpty())
    }
    @Test fun errorDuringRecordingThenRecover() {
        val s = AppState()
        s.recording.go(RecordingState.Preparing); s.recording.go(RecordingState.Recording)
        assertTrue(s.recording.go(RecordingState.Error, "encoder died"))
        assertTrue(s.recording.go(RecordingState.Idle))
        assertTrue(s.recording.go(RecordingState.Preparing))
    }
    @Test fun listenersCalledOnChange() {
        val s = AppState(); var n = 0
        s.camera.listen { n++ }
        s.camera.go(CameraState.Opening); s.camera.go(CameraState.Opening); s.camera.force(CameraState.Closed, "x")
        assertEquals(2, n)
    }
    @Test fun lensSwitchWhileRecordingKeepsRecording() {
        val s = AppState()
        s.camera.go(CameraState.Opening); s.camera.go(CameraState.Configuring); s.camera.go(CameraState.Preview)
        s.recording.go(RecordingState.Preparing); s.recording.go(RecordingState.Recording)
        s.processing.go(ProcessingState.SwitchingLens); s.camera.go(CameraState.Configuring); s.camera.go(CameraState.Preview)
        s.processing.go(ProcessingState.GlPipeline)
        assertEquals(RecordingState.Recording, s.recording.state)
        assertTrue(s.invariantViolations().isEmpty())
    }
    @Test fun historyBounded() {
        val s = AppState()
        repeat(300) { s.camera.force(if (it % 2 == 0) CameraState.Preview else CameraState.Closed, "t") }
        assertTrue(s.camera.recent(1000).size <= 100)
    }
    @Test fun concurrentTransitionsStayConsistent() {
        val s = AppState()
        val ts = (1..8).map { Thread { repeat(2000) { s.processing.go(ProcessingState.values()[it % 4]) } } }
        ts.forEach { it.start() }; ts.forEach { it.join() }
        assertTrue(s.processing.state in ProcessingState.values())
    }
}
