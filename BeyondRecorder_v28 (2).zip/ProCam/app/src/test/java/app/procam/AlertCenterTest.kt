package app.procam

import org.junit.Assert.*
import org.junit.Test

class AlertCenterTest {
    private fun hot() = MonitorInput(3, 1.1f, 44f, 500f, null, 300L, false, 800L, true, 2f)

    @Test fun defaultsShowWarning() {
        val c = AlertCenter(MemStore())
        val d = c.post(AlertType.OVERHEAT, "hot", nowMs = 1000)!!
        assertTrue(d.banner); assertEquals(1, c.list().size)
    }
    @Test fun offHidesAndRecordsNothing() {
        val st = MemStore(); val c = AlertCenter(st)
        c.setMode(AlertType.OVERHEAT, AlertMode.OFF)
        assertNull(c.post(AlertType.OVERHEAT, "hot", nowMs = 1)); assertEquals(0, c.list().size)
    }
    @Test fun monitoringIndependentOfNotificationSettings() {
        val st = MemStore(); val c = AlertCenter(st)
        val before = AlertRules.evaluate(hot()) { c.threshold(it) }.map { it.type }
        AlertType.values().filter { !it.dataLoss }.forEach { c.setMode(it, AlertMode.OFF) }
        val after = AlertRules.evaluate(hot()) { c.threshold(it) }.map { it.type }
        assertEquals(before, after); assertTrue(AlertType.OVERHEAT in after)
    }
    @Test fun alertsNeverTouchShootingSettings() {
        val st = MemStore(mapOf("fps" to 60, "rec_w" to 3840))
        val c = AlertCenter(st)
        c.post(AlertType.OVERHEAT, "x", nowMs = 1); c.setMode(AlertType.TEMP_HIGH, AlertMode.OFF)
        assertEquals(60, st.all()["fps"]); assertEquals(3840, st.all()["rec_w"])
        assertTrue(st.all().keys.all { it == "fps" || it == "rec_w" || it.startsWith("n28.") })
    }
    @Test fun dataLossNeedsConfirmation() {
        val c = AlertCenter(MemStore())
        assertTrue(c.setMode(AlertType.STORAGE_FULL, AlertMode.OFF) is AlertCenter.SetResult.NeedsConfirm)
        assertNotNull(c.post(AlertType.STORAGE_FULL, "x", nowMs = 1))
        assertTrue(c.setMode(AlertType.STORAGE_FULL, AlertMode.OFF, true) is AlertCenter.SetResult.Ok)
        assertNull(c.post(AlertType.STORAGE_FULL, "x", nowMs = 2))
    }
    @Test fun cooldownSuppressesBannerAndCoalesces() {
        val c = AlertCenter(MemStore())
        assertTrue(c.post(AlertType.OVERHEAT, "a", nowMs = 0)!!.banner)
        val d = c.post(AlertType.OVERHEAT, "b", nowMs = 10_000)!!
        assertFalse(d.banner); assertEquals(1, c.list().size); assertEquals(2, c.list()[0].count)
        assertTrue(c.post(AlertType.OVERHEAT, "c", nowMs = 130_000)!!.banner)
    }
    @Test fun onceShowsOnlyOnce() {
        val c = AlertCenter(MemStore()); c.setMode(AlertType.OVERHEAT, AlertMode.ONCE); c.setRepeat(AlertType.OVERHEAT, 0)
        assertTrue(c.post(AlertType.OVERHEAT, "a", nowMs = 1)!!.banner); assertFalse(c.post(AlertType.OVERHEAT, "b", nowMs = 5)!!.banner)
    }
    @Test fun criticalOnlyHidesWarnings() {
        val c = AlertCenter(MemStore()); c.setMode(AlertType.OVERHEAT, AlertMode.CRITICAL_ONLY)
        assertFalse(c.post(AlertType.OVERHEAT, "w", nowMs = 1)!!.banner); assertEquals(1, c.list().size)
        assertTrue(c.post(AlertType.OVERHEAT, "c", Severity.CRITICAL, nowMs = 500_000, key = "k2")!!.banner)
    }
    @Test fun silentHasNoSound() {
        val c = AlertCenter(MemStore()); c.setMode(AlertType.CAMERA_ERROR, AlertMode.SILENT)
        val d = c.post(AlertType.CAMERA_ERROR, "e", nowMs = 1)!!
        assertTrue(d.banner); assertFalse(d.sound); assertFalse(d.vibrate)
    }
    @Test fun historySurvivesRestartAndFilters() {
        val st = MemStore(); val c = AlertCenter(st)
        c.post(AlertType.OVERHEAT, "hot\tline", nowMs = 1); c.post(AlertType.STORAGE_LOW, "low", nowMs = 2)
        val c2 = AlertCenter(st)
        assertEquals(2, c2.list().size); assertEquals("hot\tline", c2.list(AlertGroup.THERMAL)[0].text)
        assertEquals(1, c2.list(query = "low").size); assertEquals(2, c2.unread())
        c2.markAllRead(); assertEquals(0, c2.unread())
    }
    @Test fun retentionPrunes() {
        val c = AlertCenter(MemStore()); c.setRetentionDays(1)
        c.post(AlertType.OVERHEAT, "old", nowMs = 0)
        c.prune(3 * 86_400_000L); assertEquals(0, c.list().size)
    }
    @Test fun thresholdValidated() {
        val c = AlertCenter(MemStore())
        assertTrue(c.setThreshold(AlertType.TEMP_HIGH, 5f) is AlertCenter.SetResult.Invalid)
        assertTrue(c.setThreshold(AlertType.TEMP_HIGH, 45f) is AlertCenter.SetResult.Ok); assertEquals(45f, c.threshold(AlertType.TEMP_HIGH))
    }
    @Test fun unavailableMetricsMakeNoFindings() {
        val none = MonitorInput(null, null, null, null, null, null, false, null, false, null)
        assertTrue(AlertRules.evaluate(none) { null }.isEmpty())
    }
    @Test fun classifier() {
        assertEquals(AlertType.AUDIO_LOSS, AlertClassifier.classify("Звук потерян: x. Запись продолжается без звука"))
        assertEquals(AlertType.ENCODE_PROBLEM, AlertClassifier.classify("Поверхность кодека перестала принимать кадры"))
        assertEquals(AlertType.CAMERA_ERROR, AlertClassifier.classify("Ошибка камеры 3"))
    }
    @Test fun schemaKeepsAlertValuesAndFixesInvalid() {
        val st = MemStore(mapOf("n28.OVERHEAT.mode" to "WAT", "n28.TEMP_HIGH.thr" to 45f))
        SettingsManager(st).migrate()
        assertEquals("ALWAYS", st.all()["n28.OVERHEAT.mode"]); assertEquals(45f, st.all()["n28.TEMP_HIGH.thr"])
    }
}
