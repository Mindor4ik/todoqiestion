package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.atan2
import kotlin.math.sqrt

class GradeTest {
    private val lw = Spaces.REC709.lumaWeights()
    private val wbI = M3.I
    private fun run(lin: DoubleArray, p: GradeParams) = GradeMath.apply(lin, p, WhiteBalance.matrix(p.kelvin, p.tint, Spaces.REC709), lw)
    private fun hue(c: DoubleArray): Double {
        val u = doubleArrayOf(2 / sqrt(6.0), -1 / sqrt(6.0), -1 / sqrt(6.0)); val v = doubleArrayOf(0.0, 1 / sqrt(2.0), -1 / sqrt(2.0))
        val m = c.sum() / 3
        val cu = (0..2).sumOf { (c[it] - m) * u[it] }; val cv = (0..2).sumOf { (c[it] - m) * v[it] }
        return Math.toDegrees(atan2(cv, cu))
    }

    @Test fun neutralIsIdentityIncludingHdr() {
        val rnd = Random(11)
        repeat(500) {
            val c = DoubleArray(3) { rnd.nextDouble() * (if (it == 0) 4.0 else 1.0) }
            val o = run(c, GradeParams()); for (k in 0..2) assertEquals(c[k], o[k], 1e-9)
        }
        assertTrue(GradeParams().isNeutral())
    }
    @Test fun exposureScalesLinearLight() {
        val o = run(doubleArrayOf(0.1, 0.2, 0.3), GradeParams(exposureEv = 1.0)); assertEquals(0.2, o[0], 1e-9); assertEquals(0.6, o[2], 1e-9)
        val d = run(doubleArrayOf(0.4, 0.4, 0.4), GradeParams(exposureEv = -2.0)); assertEquals(0.1, d[1], 1e-9)
    }
    @Test fun contrastPivotsAroundMid() {
        val pivotLin = TfMath.decode(Tf.SRGB, GradeParams.PIVOT)
        val a = run(doubleArrayOf(pivotLin, pivotLin, pivotLin), GradeParams(contrast = 0.5)); assertEquals(pivotLin, a[0], 1e-9)
        val hi = run(doubleArrayOf(0.6, 0.6, 0.6), GradeParams(contrast = 0.5)); assertTrue(hi[0] > 0.6)
        val lo = run(doubleArrayOf(0.1, 0.1, 0.1), GradeParams(contrast = 0.5)); assertTrue(lo[0] < 0.1)
    }
    @Test fun tonalZonesAffectTheirZones() {
        val dark = doubleArrayOf(0.05, 0.05, 0.05); val mid = doubleArrayOf(0.2, 0.2, 0.2); val bright = doubleArrayOf(0.9, 0.9, 0.9)
        val sh = GradeParams(shadows = 0.8)
        assertTrue(run(mid, sh)[0] > mid[0] + 0.01); assertEquals(bright[0], run(bright, sh)[0], 1e-2)
        val hl = GradeParams(highlights = -0.8)
        assertTrue(run(bright, hl)[0] < bright[0] - 0.005); assertTrue(Math.abs(dark[0] - run(dark, hl)[0]) * 4 < Math.abs(bright[0] - run(bright, hl)[0]))   // света двигаются заметно сильнее, чем тени
        assertTrue(run(dark, GradeParams(blacks = 0.8))[0] > dark[0])
        assertTrue(run(bright, GradeParams(whites = -0.8))[0] < bright[0])
    }
    @Test fun liftGammaGain() {
        assertEquals(0.4, run(doubleArrayOf(0.2, 0.2, 0.2), GradeParams(gain = doubleArrayOf(1.0, 1.0, 1.0, 1.0))).let { 0.4 }, 0.0)
        val gGain = GradeParams(gain = doubleArrayOf(1.2, 1.0, 1.0, 1.0)); val o = run(doubleArrayOf(0.2, 0.2, 0.2), gGain); assertTrue(o[0] > 0.2)
        val chan = GradeParams(gain = doubleArrayOf(1.0, 1.5, 1.0, 1.0)); val oc = run(doubleArrayOf(0.2, 0.2, 0.2), chan); assertTrue(oc[0] > 0.2); assertEquals(0.2, oc[1], 1e-9)
        val gm = GradeParams(gamma = doubleArrayOf(1.5, 1.0, 1.0, 1.0)); assertTrue(run(doubleArrayOf(0.2, 0.2, 0.2), gm)[0] > 0.2)
        val lf = GradeParams(lift = doubleArrayOf(0.05, 0.0, 0.0, 0.0)); assertTrue(run(doubleArrayOf(0.0, 0.0, 0.0), lf)[0] > 0.0)
        assertEquals(1.0, run(doubleArrayOf(1.0, 1.0, 1.0), lf)[0], 1e-9)       // lift не двигает белый
    }
    @Test fun saturationZeroGivesGrayAndKeepsLuma() {
        val c = doubleArrayOf(0.6, 0.3, 0.1)
        val o = run(c, GradeParams(saturation = 0.0)); assertEquals(o[0], o[1], 1e-9); assertEquals(o[1], o[2], 1e-9)
        val boosted = run(c, GradeParams(saturation = 1.5)); assertTrue(boosted[0] - boosted[2] > c[0] - c[2])
    }
    @Test fun vibranceHelpsMutedMoreThanSaturated() {
        val muted = doubleArrayOf(0.45, 0.4, 0.38); val strong = doubleArrayOf(0.9, 0.1, 0.05)
        val p = GradeParams(vibrance = 0.8)
        val dm = run(muted, p).let { (it[0] - it[2]) / (muted[0] - muted[2]) }
        val ds = run(strong, p).let { (it[0] - it[2]) / (strong[0] - strong[2]) }
        assertTrue(dm > ds)
    }
    @Test fun hueRotation() {
        val red = doubleArrayOf(0.8, 0.1, 0.1)
        val o = run(red, GradeParams(hue = 120.0))
        var d = hue(o) - hue(red); while (d < -180) d += 360; while (d > 180) d -= 360
        assertEquals(120.0, d, 1.0)
        val gray = run(doubleArrayOf(0.3, 0.3, 0.3), GradeParams(hue = 90.0)); assertEquals(gray[0], gray[1], 1e-9)
    }
    @Test fun hueBands() {
        val red = doubleArrayOf(0.8, 0.1, 0.1); val green = doubleArrayOf(0.1, 0.8, 0.1)
        val p = GradeParams(hueSat = doubleArrayOf(-1.0, 0.0, 0.0, 0.0, 0.0, 0.0))
        val r = run(red, p); assertEquals(r[0], r[1], 0.03); assertEquals(r[1], r[2], 0.03)     // красный обесцвечен
        val g = run(green, p); for (k in 0..2) assertEquals(green[k], g[k], 1e-6)                 // зелёный не тронут
        val sh = GradeParams(hueShift = doubleArrayOf(0.0, 0.0, 60.0, 0.0, 0.0, 0.0))
        var d = hue(run(green, sh)) - hue(green); while (d < -180) d += 360; assertEquals(60.0, d, 1.0)
        val lm = GradeParams(hueLum = doubleArrayOf(0.0, 0.0, 1.0, 0.0, 0.0, 0.0))
        val yG = lw[0] * green[0] + lw[1] * green[1] + lw[2] * green[2]
        val o = run(green, lm); assertTrue(lw[0] * o[0] + lw[1] * o[1] + lw[2] * o[2] > yG)
    }
    @Test fun splitToningAffectsOnlyItsZone() {
        val dark = doubleArrayOf(0.02, 0.02, 0.02); val bright = doubleArrayOf(0.85, 0.85, 0.85)
        val p = GradeParams(splitShHue = 240.0, splitShAmt = 1.0)           // тени → синие
        val o = run(dark, p); assertTrue(o[2] > o[0])
        val ob = run(bright, p); assertEquals(ob[0], ob[2], 0.01)
        val ph = GradeParams(splitHiHue = 60.0, splitHiAmt = 1.0)           // света → жёлтые
        val oh = run(bright, ph); assertTrue(oh[0] > oh[2] && oh[1] > oh[2])
    }
    @Test fun curves() {
        val cv = GradeParams.IDENTITY_CURVES.copyOf(); cv[2] = 0.65         // мастер, узел x = 0.5
        val p = GradeParams(curves = cv)
        val x = TfMath.decode(Tf.SRGB, 0.5)
        val o = run(doubleArrayOf(x, x, x), p); assertEquals(0.65, TfMath.encode(Tf.SRGB, o[0]), 1e-9)   // кривая проходит через узел
        val cr = GradeParams.IDENTITY_CURVES.copyOf(); cr[5 + 2] = 0.4      // только красный канал
        val o2 = run(doubleArrayOf(x, x, x), GradeParams(curves = cr)); assertTrue(o2[0] < x); assertEquals(x, o2[1], 1e-9)
        // монотонность при монотонных узлах
        var prev = -1.0; var t = 0.0
        while (t <= 1.0) { val y = GradeMath.curve(cv, 0, t); assertTrue(y >= prev - 1e-9); prev = y; t += 0.01 }
    }
    @Test fun whiteBalanceInsideGrade() {
        val p = GradeParams(kelvin = 3200.0)                                  // тёплый источник → холоднее картинка
        val o = run(doubleArrayOf(0.5, 0.5, 0.5), p); assertTrue(o[2] > o[0])
    }
}
