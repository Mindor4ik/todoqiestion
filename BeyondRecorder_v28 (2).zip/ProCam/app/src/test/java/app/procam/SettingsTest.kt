package app.procam

import org.junit.Assert.*
import org.junit.Test

class SettingsTest {
    @Test fun freshStoreMigratesToCurrent() {
        val st = MemStore(); val m = SettingsManager(st)
        assertEquals(0, m.storedVersion())
        m.migrate()
        assertEquals(SettingsSchema.VERSION, m.storedVersion())
    }
    @Test fun migrationKeepsUserValues() {
        val st = MemStore(mapOf("fps" to 60, "eis" to 3, "q_kbps" to 123456, "grid" to 2))
        SettingsManager(st).migrate()
        val a = st.all(); assertEquals(60, a["fps"]); assertEquals(3, a["eis"]); assertEquals(123456, a["q_kbps"]); assertEquals(2, a["grid"])
    }
    @Test fun invalidValuesReplacedAndReported() {
        val st = MemStore(mapOf("eis" to 99, "fps" to "abc", "codec" to "VP9", "zebra_level" to Float.NaN))
        val log = SettingsManager(st).migrate()
        val a = st.all()
        assertEquals(0, a["eis"]); assertEquals(30, a["fps"]); assertEquals("HEVC", a["codec"]); assertEquals(0.95f, a["zebra_level"])
        assertTrue(log.size >= 4)
    }
    @Test fun migrationIdempotent() {
        val st = MemStore(mapOf("eis" to 99)); val m = SettingsManager(st)
        m.migrate(); val second = m.migrate()
        assertTrue(second.none { it.contains("невозможно") })
    }
    @Test fun newerSchemaLeftUntouched() {
        val st = MemStore(mapOf(SettingsSchema.KEY_VERSION to 99, "eis" to 99))
        val log = SettingsManager(st).migrate()
        assertEquals(99, st.all()["eis"]); assertEquals(99, st.all()[SettingsSchema.KEY_VERSION]); assertEquals(1, log.size)
    }
    @Test fun unknownKeysPreserved() {
        val st = MemStore(mapOf("future_key" to 5, "eis_cal_v2" to "1,2,3"))
        SettingsManager(st).migrate()
        assertEquals(5, st.all()["future_key"]); assertEquals("1,2,3", st.all()["eis_cal_v2"])
    }
    @Test fun resetKeepsPresetsAndCalibrationAndVersion() {
        val st = MemStore(mapOf("fps" to 60, "eis_cal_v2" to "x")); val m = SettingsManager(st)
        m.migrate(); m.savePreset("A"); m.resetToDefaults()
        val a = st.all()
        assertFalse(a.containsKey("fps")); assertTrue(a.containsKey("eis_cal_v2")); assertTrue(a.containsKey("preset.A")); assertEquals(SettingsSchema.VERSION, a[SettingsSchema.KEY_VERSION])
    }
    @Test fun presetRoundTrip() {
        val st = MemStore(mapOf("fps" to 60, "codec" to "AVC", "zebra" to true, "zebra_level" to 0.8f, "camera_id" to "3"))
        val m = SettingsManager(st)
        assertEquals("Мой", m.savePreset("  Мой  "))
        st.commit(mapOf("fps" to 24, "codec" to "HEVC", "zebra" to false, "camera_id" to "0"))
        assertTrue(m.applyPreset("Мой") >= 4)
        val a = st.all()
        assertEquals(60, a["fps"]); assertEquals("AVC", a["codec"]); assertEquals(true, a["zebra"]); assertEquals(0.8f, a["zebra_level"])
        assertEquals("0", a["camera_id"])    // привязано к телефону — не входит в пресет
    }
    @Test fun presetNameSanitized() {
        val m = SettingsManager(MemStore())
        assertNull(m.savePreset("   "))
        assertEquals(40, m.savePreset("x".repeat(100))!!.length)
        assertEquals("a b", m.savePreset("a\tb"))
    }
    @Test fun presetWithSpecialCharsInValues() {
        val st = MemStore(mapOf("codec" to "A\tB\nC\\D")); val m = SettingsManager(st)
        m.savePreset("p"); st.commit(mapOf("codec" to "HEVC"))
        m.applyPreset("p")
        // значение невозможно по правилу → после sanitize стало значением по умолчанию, но разбор не сломался
        assertEquals("HEVC", st.all()["codec"])
    }
    @Test fun missingPresetReturnsMinusOne() { assertEquals(-1, SettingsManager(MemStore()).applyPreset("нет")) }
    @Test fun corruptedPresetIgnoredPerLine() {
        val st = MemStore(mapOf("preset.bad" to "fps\ti\tNaN\ngarbage\neis\ti\t2\n"))
        val m = SettingsManager(st)
        assertEquals(1, m.applyPreset("bad")); assertEquals(2, st.all()["eis"])
    }
    @Test fun presetCannotOverwritePresetsOrVersion() {
        val st = MemStore(mapOf("preset.evil" to "schema\ti\t0\npreset.x\ts\tboom\n")); val m = SettingsManager(st)
        m.migrate(); m.applyPreset("evil")
        assertEquals(SettingsSchema.VERSION, m.storedVersion()); assertFalse(st.all().containsKey("preset.x"))
    }
    @Test fun deletePresetAndList() {
        val m = SettingsManager(MemStore()); m.savePreset("b"); m.savePreset("a")
        assertEquals(listOf("a", "b"), m.presetNames()); m.deletePreset("a"); assertEquals(listOf("b"), m.presetNames())
    }
    @Test fun applyChangesValidates() {
        val st = MemStore(); SettingsManager(st).applyChanges(mapOf("fps" to 60, "eis" to 77))
        assertEquals(60, st.all()["fps"]); assertEquals(0, st.all()["eis"])
    }
    @Test fun noArtificialLimitsInRules() {
        val r = SettingsSchema.rules
        assertTrue((r["fps"] as Rule.IntR).ok(240)); assertTrue((r["fps"] as Rule.IntR).ok(1))
        assertTrue((r["rec_w"] as Rule.IntR).ok(7680)); assertTrue((r["q_kbps"] as Rule.IntR).ok(1_000_000))
        assertTrue((r["q_gop"] as Rule.FloatR).ok(0.04f))
    }
    @Test fun defaultsAreValidAgainstOwnRules() {
        for ((k, rule) in SettingsSchema.rules) assertTrue("default $k", rule.ok(rule.default))
    }
}
