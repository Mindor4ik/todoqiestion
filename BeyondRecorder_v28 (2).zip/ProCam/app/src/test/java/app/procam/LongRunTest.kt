package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

/** Модельные длительные прогоны логики (время симулируется, реальная запись не выполняется). */
class LongRunTest {
    @Test fun eightHoursWithPausesJitterAndDrops() {
        val n = PtsNormalizer(true); n.setMonotonic(0, true); n.setMonotonic(1, true); n.setNominalFrameUs(0, 1_000_000L / 60)
        val rnd = Random(7)
        val vStep = 1_000_000L / 60; val aStep = 1024 * 1_000_000L / 48000
        var tv = 0L; var ta = 0L; var expectedDrops = 0L
        var lastV = -1L; var lastA = -1L
        val end = 8 * 3600 * 1_000_000L
        var nextPause = 600_000_000L
        while (tv < end) {
            if (tv >= nextPause) { tv += 3_000_000L + rnd.nextInt(5_000_000); ta = tv; n.markResume(); nextPause += 600_000_000L }
            if (rnd.nextInt(5000) == 0) { tv += vStep * 2; expectedDrops += 2 }      // потеря двух кадров
            val pv = n.normalize(0, tv + rnd.nextInt(400) - 200); if (lastV >= 0) assertTrue(pv > lastV); lastV = pv
            tv += vStep
            while (ta <= tv) { val pa = n.normalize(1, ta); if (lastA >= 0) assertTrue(pa > lastA); lastA = pa; ta += aStep }
        }
        val st = n.stats(0, 1)
        assertEquals(st.videoSeconds, st.audioSeconds, 1.0)
        assertTrue("drops ${st.droppedVideo} vs $expectedDrops", Math.abs(st.droppedVideo - expectedDrops) <= expectedDrops / 10 + 5)
        assertTrue("fps ${st.actualFps}", Math.abs(st.actualFps - 60f) < 0.5f)
        assertTrue(Math.abs(st.avStartOffsetMs!!) < 50f)
    }

    @Test fun thousandsOfRecordingCyclesKeepStateConsistent() {
        val s = AppState()
        s.camera.go(CameraState.Opening); s.camera.go(CameraState.Configuring); s.camera.go(CameraState.Preview)
        val rnd = Random(3)
        repeat(5000) {
            assertTrue(s.recording.go(RecordingState.Preparing)); assertTrue(s.recording.go(RecordingState.Recording))
            repeat(rnd.nextInt(4)) { s.recording.go(RecordingState.Paused); s.recording.go(RecordingState.Recording) }
            if (rnd.nextInt(10) == 0) { s.recording.go(RecordingState.Error, "x"); s.recording.go(RecordingState.Idle) }
            else { s.recording.go(RecordingState.Finalizing); s.recording.go(RecordingState.Completed); s.recording.go(RecordingState.Idle) }
        }
        assertTrue(s.invariantViolations().isEmpty())
        assertTrue(s.recording.recent(1000).size <= 100)
    }

    @Test fun backgroundDuringRecordingFinalizes() {
        // onPause → engine.stopInternal: из Recording/Paused запись переходит в Finalizing, камера закрывается принудительно
        for (start in listOf(RecordingState.Recording, RecordingState.Paused)) {
            val s = AppState()
            s.camera.go(CameraState.Opening); s.camera.go(CameraState.Configuring); s.camera.go(CameraState.Preview)
            s.recording.go(RecordingState.Preparing); s.recording.go(RecordingState.Recording)
            if (start == RecordingState.Paused) s.recording.go(RecordingState.Paused)
            assertTrue(s.recording.go(RecordingState.Finalizing, "камера остановлена"))
            s.camera.force(CameraState.Closed, "stopInternal")
            assertTrue(s.recording.go(RecordingState.Completed)); assertTrue(s.recording.go(RecordingState.Idle))
            assertTrue(s.invariantViolations().isEmpty())
        }
    }

    @Test fun cameraLostDuringRecordingNoContradiction() {
        val s = AppState()
        s.camera.go(CameraState.Opening); s.camera.go(CameraState.Configuring); s.camera.go(CameraState.Preview)
        s.recording.go(RecordingState.Preparing); s.recording.go(RecordingState.Recording)
        s.camera.force(CameraState.Error, "Камера отключена")
        assertTrue(s.recording.go(RecordingState.Finalizing)); s.camera.force(CameraState.Closed, "stopInternal")
        s.recording.go(RecordingState.Completed)
        assertTrue(s.invariantViolations().isEmpty())
    }

    @Test fun settingsChurn() {
        val st = MemStore(); val m = SettingsManager(st); m.migrate()
        val rnd = Random(5)
        repeat(2000) {
            m.applyChanges(mapOf("fps" to rnd.nextInt(2000), "eis" to rnd.nextInt(10)))
            if (it % 100 == 0) { m.savePreset("p${it % 7}"); m.applyPreset("p${it % 7}") }
            if (it % 500 == 0) m.resetToDefaults()
        }
        for ((k, r) in SettingsSchema.rules) { val v = st.all()[k]; if (v != null) assertTrue("$k=$v", r.ok(v)) }
        assertEquals(SettingsSchema.VERSION, m.storedVersion())
    }
}
