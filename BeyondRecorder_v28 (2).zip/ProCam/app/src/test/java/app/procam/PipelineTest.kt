package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.pow

class PipelineTest {
    private val rnd = Random(21)
    private fun rgb() = DoubleArray(3) { rnd.nextDouble() }

    @Test fun defaultConfigIsIdentityForSdr() {
        val c = ColorConfig()
        repeat(500) { val s = rgb(); val o = ColorPipeline.process(c, s); for (k in 0..2) assertEquals(s[k], o[k], 1e-9) }
    }
    @Test fun matchesV025SdrAndLogOutput() {
        val gain = 2.0.pow(1.0)
        val c = ColorConfig(out = OutSpec(tf = Tf.SLOG3, gain = gain))
        repeat(200) {
            val s = rgb(); val lin = DoubleArray(3) { TfMath.decode(Tf.SRGB, s[it]) }
            val o = ColorPipeline.process(c, s)
            for (k in 0..2) assertEquals(Tf.SLOG3.encode(lin[k] * gain), o[k], 1e-9)
        }
    }
    @Test fun hlgInputMatchesV025Shader() {
        // v0.25: lin = clamp(TO709 * (hlgInv(src) / 0.265)); v = srgbEnc(lin)
        val c = ColorConfig(input = InKind.HLG, inPrim = Spaces.REC2020)
        val to709 = Spaces.convert(Spaces.REC2020, Spaces.REC709)
        repeat(300) {
            val s = DoubleArray(3) { 0.3 + 0.2 * rnd.nextDouble() }            // тёплая/нейтральная середина, внутри охвата
            val e = DoubleArray(3) { Tf.HLG.decode(s[it]) / 0.265 }
            val l = M3.mulV(to709, e)
            if (l.any { it < 0.0 || it > 1.0 }) return@repeat
            val o = ColorPipeline.process(c, s)
            for (k in 0..2) assertEquals(Tf.SRGB.encode(l[k]), o[k], 1e-6)
        }
    }
    @Test fun noPrematureClippingInWorkingSpace() {
        // HLG-блик выше SDR-белого: в рабочем линейном пространстве значение > 1 сохраняется, и тон-мэппинг его «сворачивает», а не обрезает
        val hdr = ColorConfig(input = InKind.HLG, inPrim = Spaces.REC2020, toneMap = ToneMap.FILMIC)
        val src = doubleArrayOf(0.9, 0.9, 0.9)
        assertTrue(ColorPipeline.workingLinear(ColorConfig(input = InKind.HLG, inPrim = Spaces.REC2020), src)[0] > 2.0)
        val a = ColorPipeline.process(hdr, doubleArrayOf(0.8, 0.8, 0.8)); val b = ColorPipeline.process(hdr, doubleArrayOf(0.95, 0.95, 0.95))
        assertTrue("различимы после тон-мэппинга", b[0] > a[0] + 0.005)
        val clip = ColorConfig(input = InKind.HLG, inPrim = Spaces.REC2020)
        assertEquals(ColorPipeline.process(clip, doubleArrayOf(0.8, 0.8, 0.8))[0], ColorPipeline.process(clip, doubleArrayOf(0.95, 0.95, 0.95))[0], 1e-9)   // без тон-мэппинга — обрезка (как раньше)
    }
    @Test fun previewAndRecordShareOneChain() {
        // запись в LOG и монитор в Rec.709 при одной градации/тон-мэппинге: после обратного преобразования выхода записи линейный свет совпадает с мониторным
        val grade = GradeParams(exposureEv = 0.3, contrast = 0.2, saturation = 1.2, kelvin = 5200.0, shadows = 0.3)
        for (curve in listOf(Tf.SLOG3, Tf.VLOG, Tf.LOGC, Tf.FLAT)) {
            val rec = ColorConfig(grade = grade, toneMap = ToneMap.FILMIC, out = OutSpec(tf = curve, gain = 1.5))
            val mon = ColorConfig(grade = grade, toneMap = ToneMap.FILMIC, out = OutSpec(tf = Tf.SRGB))
            repeat(200) {
                val s = rgb()
                val code = ColorPipeline.process(rec, s)
                val back = ColorPipeline.decodeOut(rec, code)
                val m = ColorPipeline.outputLinear(mon, s)
                if (code.any { it >= 0.999 }) return@repeat          // код упёрся в максимум файла: яркости выше диапазона кривой обрезаются физически
                for (k in 0..2) assertEquals("${curve.label}", m[k], back[k], 2e-4)
            }
        }
    }
    @Test fun previewAndRecordShareLutOrder() {
        val id = LutEngine.parse(identity3D(17))
        val rec = ColorConfig(lut = id, lutIo = LutIo.REC709_LOOK, out = OutSpec(tf = Tf.SRGB), grade = GradeParams(exposureEv = 0.2))
        val none = ColorConfig(out = OutSpec(tf = Tf.SRGB), grade = GradeParams(exposureEv = 0.2))
        repeat(200) { val s = rgb(); val a = ColorPipeline.process(rec, s); val b = ColorPipeline.process(none, s); for (k in 0..2) assertEquals(b[k], a[k], 2e-3) }   // тождественный LUT не меняет картинку
    }
    @Test fun lutAppliedExactlyOnce() {
        // «инверсный» LUT out = 1 − in: двойное применение вернуло бы исходное, одно — инвертирует
        val inv = LutEngine.parse(buildLut(9) { doubleArrayOf(1 - it[0], 1 - it[1], 1 - it[2]) })
        val c = ColorConfig(lut = inv, lutIo = LutIo.REC709_LOOK)
        val s = doubleArrayOf(0.2, 0.5, 0.9); val o = ColorPipeline.process(c, s)
        for (k in 0..2) assertEquals(1 - s[k], o[k], 2e-3)
    }
    @Test fun lutMixBlendsInOutputCode() {
        val inv = LutEngine.parse(buildLut(9) { doubleArrayOf(1 - it[0], 1 - it[1], 1 - it[2]) })
        val s = doubleArrayOf(0.2, 0.5, 0.9)
        val half = ColorPipeline.process(ColorConfig(lut = inv, lutIo = LutIo.REC709_LOOK, lutMix = 0.5), s)
        for (k in 0..2) assertEquals(0.5, half[k], 2e-3)
        val zero = ColorPipeline.process(ColorConfig(lut = inv, lutIo = LutIo.REC709_LOOK, lutMix = 0.0), s)
        for (k in 0..2) assertEquals(s[k], zero[k], 1e-9)
    }
    @Test fun lutInputFollowsLogCurve() {
        // вход LUT — «как LOG-кривая съёмки»: LUT-тождество в LOG-пространстве + выход как raw даёт LOG-кодированную картинку
        val id = LutEngine.parse(identity3D(33))
        val c = ColorConfig(logCurve = Tf.SLOG3, lut = id, lutIo = LutIo.LOG_LOOK)
        val s = doubleArrayOf(0.3, 0.5, 0.7)
        val o = ColorPipeline.process(c, s)
        for (k in 0..2) assertEquals(Tf.SLOG3.encode(Tf.SRGB.decode(s[k])), o[k], 3e-3)
    }
    @Test fun lut1DWorksInPipeline() {
        val l = LutEngine.parse("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n")
        val c = ColorConfig(lut = l, lutIo = LutIo.REC709_LOOK)
        val s = rgb(); val o = ColorPipeline.process(c, s); for (k in 0..2) assertEquals(s[k], o[k], 1e-6)
    }
    @Test fun gamutMappingEffectInPipeline() {
        // насыщенный зелёный P3 → экран Rec.709: без mapping канал обрезается, с DESAT — яркость сохраняется
        val p3 = ColorConfig(inPrim = Spaces.DISPLAY_P3, work = Spaces.DISPLAY_P3, out = OutSpec(prim = Spaces.REC709, tf = Tf.LINEAR))
        val s = doubleArrayOf(0.1, 0.9, 0.1)
        val clip = ColorPipeline.process(p3, s)
        val desat = ColorPipeline.process(ColorConfig(inPrim = Spaces.DISPLAY_P3, work = Spaces.DISPLAY_P3, gamutMap = GamutMap.DESAT, out = OutSpec(prim = Spaces.REC709, tf = Tf.LINEAR)), s)
        assertTrue(clip.all { it in 0.0..1.0 } && desat.all { it in 0.0..1.0 })
        val lw = Spaces.REC709.lumaWeights()
        val v = M3.mulV(Spaces.convert(Spaces.DISPLAY_P3, Spaces.REC709), DoubleArray(3) { TfMath.decode(Tf.SRGB, s[it]) })
        val yTrue = lw[0] * v[0] + lw[1] * v[1] + lw[2] * v[2]
        val yClip = lw[0] * clip[0] + lw[1] * clip[1] + lw[2] * clip[2]; val yDes = lw[0] * desat[0] + lw[1] * desat[1] + lw[2] * desat[2]
        assertEquals(yTrue, yDes, 1e-9)                              // DESAT сохраняет яркость
        assertTrue(Math.abs(yClip - yTrue) > 1e-4)                   // обрезка её искажает
    }
    @Test fun workingSpaceChoiceDoesNotChangeNeutralResult() {
        // нейтральная цепочка: результат не зависит от выбранного рабочего охвата (преобразования туда-обратно взаимно обратны)
        val s = DoubleArray(3) { 0.25 + 0.4 * rnd.nextDouble() }
        val ref = ColorPipeline.process(ColorConfig(), s)
        for (w in Spaces.builtIn) { val o = ColorPipeline.process(ColorConfig(work = w), s); for (k in 0..2) assertEquals(w.name, ref[k], o[k], 1e-6) }
    }
    @Test fun customProfileFromPrimaries() {
        val custom = Primaries("моя", 0.66, 0.33, 0.29, 0.62, 0.15, 0.05, 0.3127, 0.3290)
        val m = M3.mul(Spaces.convert(custom, Spaces.REC709), Spaces.convert(Spaces.REC709, custom))
        assertTrue(M3.isIdentity(m, 1e-9))
        val o = ColorPipeline.process(ColorConfig(inPrim = custom, work = custom, out = OutSpec(prim = custom)), doubleArrayOf(0.2, 0.4, 0.6))
        assertEquals(0.4, o[1], 1e-9)
    }

    private fun buildLut(n: Int, f: (DoubleArray) -> DoubleArray): String {
        val sb = StringBuilder("LUT_3D_SIZE $n\n")
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) { val o = f(doubleArrayOf(r.toDouble() / (n - 1), g.toDouble() / (n - 1), b.toDouble() / (n - 1))); sb.append("${o[0]} ${o[1]} ${o[2]}\n") }
        return sb.toString()
    }
    private fun identity3D(n: Int) = buildLut(n) { it }
}
