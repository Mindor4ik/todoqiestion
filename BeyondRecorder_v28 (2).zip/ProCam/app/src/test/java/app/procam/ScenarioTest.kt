package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.*

/**
 * Воспроизводимые сценарии для источника «оптический поток»: синтетические кадры с ИЗВЕСТНЫМ движением камеры (тряска рук, ходьба, пан, неподвижная сцена,
 * движущийся объект, слабый свет, мелкие детали). Проверяется точность оценки и остаточная тряска после сглаживания. Это программные тесты, не испытания на телефонах.
 */
class ScenarioTest {
    private val W = 128; private val H = 72
    private fun tex(x: Double, y: Double, fs: Double): Double {
        val u = x * fs; val v = y * fs
        var r = 0.5 + 0.18 * sin(u * 0.31 + 0.7) * cos(v * 0.23 + 0.2) + 0.12 * sin(u * 0.57 - v * 0.41 + 1.3) + 0.10 * cos(u * 0.13 + v * 0.77) + 0.08 * sin((u + 2 * v) * 0.9)
        return r.coerceIn(0.0, 1.0)
    }
    private fun frame(sx: Double, sy: Double, fs: Double, noise: Double, rng: Random, obj: Boolean = false, frameNo: Int = 0): Gray {
        val d = FloatArray(W * H)
        for (y in 0 until H) for (x in 0 until W) {
            var v = tex(x - sx, y - sy, fs)
            if (obj && abs(x - (30 + frameNo * 2)) < 12 && abs(y - 36) < 9) v = 0.15 + 0.7 * (((x + frameNo * 2) / 3 + y / 3) % 2)   // объект едет по кадру
            d[y * W + x] = (v + rng.nextGaussian() * noise).toFloat().coerceIn(0f, 1f)
        }
        return Gray(W, H, d)
    }
    private class Out(val trueS: DoubleArray, val estS: DoubleArray, val stabilized: DoubleArray, val ideal: DoubleArray)

    /** Путь содержимого S(t) (px). Оцениваем по кадрам, копим, сглаживаем причинным гауссовым окном (как в режиме без гироскопа). */
    private fun run(n: Int, path: (Int) -> Pair<Double, Double>, fs: Double = 1.0, noise: Double = 0.0, obj: Boolean = false, sigmaFrames: Double = 3.0): Out {
        val rng = Random(5)
        val ts = DoubleArray(n); val es = DoubleArray(n)
        var prev = frame(0.0, 0.0, fs, noise, rng, obj, 0); var cx = 0.0
        val prm = FlowEngine.Params(maxFeatures = 100, levels = 3, ransacIters = 60)
        for (k in 1 until n) {
            val (sx, sy) = path(k); ts[k] = sx
            val cur = frame(sx, sy, fs, noise, rng, obj, k)
            val g = FlowEngine.estimate(prev, cur, FlowMethod.LK_PYRAMID, prm)
            cx += if (g != null && g.conf >= 0.25) g.tx else 0.0
            es[k] = cx; prev = cur
        }
        fun smooth(a: DoubleArray, causal: Boolean): DoubleArray = DoubleArray(n) { i ->
            var sw = 0.0; var s = 0.0
            for (j in max(0, i - (4 * sigmaFrames).toInt())..(if (causal) i else min(n - 1, i + (4 * sigmaFrames).toInt()))) { val w = exp(-((i - j) / sigmaFrames).pow(2) / 2); sw += w; s += w * a[j] }
            s / sw
        }
        return Out(ts, es, smooth(es, true), smooth(ts, false))
    }
    private fun rms(a: DoubleArray, from: Int = 10): Double { var s = 0.0; var c = 0; for (i in from until a.size) { s += a[i] * a[i]; c++ }; return sqrt(s / c) }
    private fun hp(a: DoubleArray, sigma: Double = 10.0): DoubleArray { val n = a.size; return DoubleArray(n) { i -> var sw = 0.0; var s = 0.0; for (j in max(0, i - 40)..min(n - 1, i + 40)) { val w = exp(-((i - j) / sigma).pow(2) / 2); sw += w; s += w * a[j] }; a[i] - s / sw } }

    @Test fun handShakeIsReducedSeveralTimes() {
        val o = run(90, { k -> 3.0 * sin(2 * PI * 7 * k / 30.0) + 1.5 * sin(2 * PI * 11 * k / 30.0 + 1) to 0.0 })
        val before = rms(hp(o.trueS)); val after = rms(hp(o.stabilized))
        assertTrue("тряска $before → $after", after < before / 2.5)
        assertEquals(0.0, rms(DoubleArray(90) { o.estS[it] - o.trueS[it] }) , 0.5)        // оценка пути близка к истинной
    }
    @Test fun walkingBounceWithSlowPan() {
        val o = run(90, { k: Int -> (0.15 * k + 1.2 * sin(2 * PI * 2 * k / 30.0)) to 0.0 })
        assertTrue("hp ${rms(hp(o.stabilized))} vs ${rms(hp(o.trueS))}", rms(hp(o.stabilized)) < rms(hp(o.trueS)) * 0.85)
        // медленный пан не «выглаживается» в ноль: стабилизированный путь следует за истинным
        assertEquals("ideal ${o.ideal[85]} stab ${o.stabilized[85]}", o.ideal[85], o.stabilized[85], 1.2)
    }
    @Test fun fastPanIsTrackedWithoutDrift() {
        val o = run(40, { k -> 4.0 * k to 0.0 }, fs = 0.5)          // 4 px/кадр
        assertEquals(o.trueS[39], o.estS[39], 6.0)                   // накопленная ошибка на 156 px пути — единицы px
    }
    @Test fun staticSceneProducesNoFalseMotion() {
        val o = run(90, { _ -> 0.0 to 0.0 }, noise = 0.01)
        assertTrue("дрейф ${o.estS.last()}", abs(o.estS.last()) < 1.0)
    }
    @Test fun movingObjectDoesNotPullTheCamera() {
        val o = run(60, { k -> (0.5 * sin(k * 0.3)) to 0.0 }, obj = true)
        assertEquals(o.trueS[59], o.estS[59], 2.5)
    }
    @Test fun lowLightNoiseKeepsEstimateUsable() {
        val o = run(60, { k -> 2.0 * sin(2 * PI * 5 * k / 30.0) to 0.0 }, noise = 0.06)
        assertTrue("шум: ошибка пути ${rms(DoubleArray(60) { o.estS[it] - o.trueS[it] })}", rms(DoubleArray(60) { o.estS[it] - o.trueS[it] }) < 1.5)
    }
    @Test fun fineDetailSceneStillTracks() {
        val o = run(60, { k -> 2.5 * sin(2 * PI * 4 * k / 30.0) to 0.0 }, fs = 1.6)
        assertTrue(rms(DoubleArray(60) { o.estS[it] - o.trueS[it] }) < 1.5)
    }
}
