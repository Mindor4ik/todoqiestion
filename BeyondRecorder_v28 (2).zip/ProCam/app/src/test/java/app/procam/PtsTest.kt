package app.procam

import org.junit.Assert.*
import org.junit.Test

class PtsTest {
    private val V = 0; private val A = 1
    private fun fpsUs(fps: Int) = 1_000_000L / fps

    @Test fun commonBaseStartsAtZeroForEarliest() {
        val n = PtsNormalizer(true)
        assertEquals(0L, n.normalize(A, 5_000_000))
        assertEquals(40_000L, n.normalize(V, 5_040_000))
    }
    @Test fun pauseGapRemoved() {
        val n = PtsNormalizer(true); n.setNominalFrameUs(V, fpsUs(25))
        var last = 0L
        for (i in 0 until 10) last = n.normalize(V, 1_000_000L + i * 40_000)
        n.markResume()
        val after = n.normalize(V, 1_000_000L + 10 * 40_000 + 5_000_000)   // пауза 5 с
        assertEquals(40_000L, after - last)
        assertEquals(0L, n.stats(V, A).droppedVideo)
    }
    @Test fun audioStrictlyIncreasing() {
        val n = PtsNormalizer(true); n.setMonotonic(A, true)
        var prev = -1L
        for (raw in longArrayOf(100, 100, 100, 90, 200, 200)) { val p = n.normalize(A, raw); assertTrue(p > prev); prev = p }
        assertTrue(n.stats(V, A).ptsCorrections >= 4)
    }
    @Test fun nonMonotonicVideoWithBFramesNotTouched() {
        val n = PtsNormalizer(true)    // monotonic выключен (B-кадры)
        n.normalize(V, 1000); n.normalize(V, 1080); val p = n.normalize(V, 1040)
        assertEquals(40L, p); assertEquals(0L, n.stats(V, A).ptsCorrections)
    }
    @Test fun droppedFramesCountedFromGaps() {
        val n = PtsNormalizer(true); n.setNominalFrameUs(V, fpsUs(30)); n.setMonotonic(V, true)
        val step = fpsUs(30)
        var t = 0L
        for (i in 0 until 30) { n.normalize(V, t); t += step }
        t += step * 3     // потеряно 3 кадра
        n.normalize(V, t)
        val st = n.stats(V, A)
        assertEquals(3L, st.droppedVideo)
        assertTrue(st.maxVideoGapMs > 100f)
    }
    @Test fun noFalseDropsOnJitter() {
        val n = PtsNormalizer(true); n.setNominalFrameUs(V, fpsUs(60)); n.setMonotonic(V, true)
        var t = 0L; val rnd = java.util.Random(1)
        for (i in 0 until 600) { n.normalize(V, t); t += fpsUs(60) + rnd.nextInt(2000) - 1000 }
        assertEquals(0L, n.stats(V, A).droppedVideo)
        assertEquals(60f, n.stats(V, A).actualFps, 1f)
    }
    @Test fun actualFpsMatches() {
        for (fps in intArrayOf(24, 30, 50, 60, 120)) {
            val n = PtsNormalizer(true); n.setNominalFrameUs(V, fpsUs(fps))
            for (i in 0 until fps * 5) n.normalize(V, i * (1_000_000.0 / fps).toLong())
            assertEquals(fps.toFloat(), n.stats(V, A).actualFps, fps * 0.02f)
        }
    }
    @Test fun avSyncOffsetReported() {
        val n = PtsNormalizer(true)
        n.setCommonBase(1_000_000)
        n.normalize(A, 1_000_000); n.normalize(V, 1_060_000)
        val off = n.stats(V, A).avStartOffsetMs!!
        assertEquals(60f, off, 0.5f)
    }
    @Test fun avDriftOverLongRunStaysSmall() {
        val n = PtsNormalizer(true); n.setMonotonic(A, true); n.setMonotonic(V, true); n.setNominalFrameUs(V, fpsUs(30))
        var tv = 0L; var ta = 0L
        // 1 час: видео 30 fps, аудио кадр AAC 1024/48000 с
        val aStep = (1024 * 1_000_000L) / 48000
        while (tv < 3_600_000_000L) {
            n.normalize(V, tv); tv += fpsUs(30)
            while (ta <= tv) { n.normalize(A, ta); ta += aStep }
        }
        val st = n.stats(V, A)
        assertEquals(st.videoSeconds, st.audioSeconds, 0.1)
        assertEquals(0L, st.droppedVideo)
    }
    @Test fun statsEmptySafe() {
        val st = PtsNormalizer(true).stats(V, A)
        assertEquals(0L, st.videoFrames); assertNull(st.avStartOffsetMs); assertEquals(0f, st.actualFps, 0f)
    }
    @Test fun invalidTrackIgnored() {
        val n = PtsNormalizer(false)
        assertEquals(0L, n.normalize(9, 100)); assertEquals(0L, n.count(9)); assertEquals(-1.0, n.endSeconds(9), 0.0)
    }
    @Test fun separateBasesWhenNotCommon() {
        val n = PtsNormalizer(false)
        assertEquals(0L, n.normalize(V, 500)); assertEquals(0L, n.normalize(A, 900))
    }
    @Test fun multiplePausesAccumulate() {
        val n = PtsNormalizer(true); n.setMonotonic(V, true)
        var raw = 0L; var last = 0L
        repeat(5) { r -> repeat(10) { last = n.normalize(V, raw); raw += 33_333 }; raw += 2_000_000; n.markResume() }
        assertTrue("pts=$last", last < 2_000_000L)   // 50 кадров ≈ 1.67 с, паузы вырезаны
    }
}
