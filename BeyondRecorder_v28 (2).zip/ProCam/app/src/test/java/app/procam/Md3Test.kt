package app.procam

import org.junit.Assert.*
import org.junit.Test

class Md3Test {
    @Test fun staticPalettesMeetTextContrast() {
        for ((n, p) in Md3.ALL) {
            for ((pair, fg, bg) in Md3.textPairs(p)) assertTrue("$n $pair ${Md3.contrast(fg, bg)}", Md3.contrast(fg, bg) >= Md3.TEXT_CONTRAST)
            assertTrue("$n outline", Md3.contrast(p.outline, p.surface) >= Md3.UI_CONTRAST)
        }
    }
    @Test fun customPaletteContrastForAllHues() {
        for (dark in listOf(true, false)) for (h in 0 until 360 step 7) for (s in listOf(0f, 0.3f, 0.7f, 1f)) {
            val p = Md3.custom(Md3.fromHsl(h.toFloat(), s, 0.5f), dark)
            for ((pair, fg, bg) in Md3.textPairs(p)) assertTrue("h=$h s=$s dark=$dark $pair", Md3.contrast(fg, bg) >= Md3.TEXT_CONTRAST)
        }
    }
    @Test fun contrastExtremes() { assertEquals(21.0, Md3.contrast(0xFFFFFFFF.toInt(), 0xFF000000.toInt()), 0.01); assertEquals(1.0, Md3.contrast(-1, -1), 0.001) }
    @Test fun fitReachesTarget() { assertTrue(Md3.contrast(Md3.fit(0xFF888888.toInt(), 0xFF777777.toInt()), 0xFF777777.toInt()) >= 4.8) }
    @Test fun typographyNotBelow11() { assertTrue(Md3.Type.LABEL_SMALL >= 11f) }
    @Test fun uiStyleOrderMatchesPreference() { assertEquals(UiStyle.GLASS, UiStyle.fromPref(1)); assertEquals(UiStyle.M3, UiStyle.fromPref(2)) }
    @Test fun freshInstallGetsM3_existingKeepsOldStyle() {
        assertEquals(2, SettingsManager(MemStore()).resolveUiStyle())
        val old = MemStore(mapOf("fps" to 30)); assertEquals(1, SettingsManager(old).resolveUiStyle()); assertEquals(1, old.all()["ui_style"])
        val kept = MemStore(mapOf("ui_style" to 0)); assertEquals(0, SettingsManager(kept).resolveUiStyle())
    }
}
