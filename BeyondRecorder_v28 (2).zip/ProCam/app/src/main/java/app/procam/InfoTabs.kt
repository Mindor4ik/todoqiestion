package app.procam

import android.graphics.Typeface
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Вкладки меню «Диагностика» и «Настройки»: вынесены из MainActivity. Построение интерфейса как и раньше, в коде. */
internal class InfoTabs(private val a: MainActivity) {
    private val main get() = a.main
    private val MATCH get() = a.MATCH
    private val WRAP get() = a.WRAP
    private fun dp(v: Int) = a.dp(v)
    fun stopTick() { a.main.removeCallbacks(diagTick); diagViews.clear() }
    fun loadPerfMode() { perfMode = PerfMode.values().getOrElse(a.prefs.getInt("perf_mode", PerfMode.Balanced.ordinal)) { PerfMode.Balanced } }

    // ------------------------------------------------------------ Диагностика (реальные данные)

    private val diagViews = LinkedHashMap<String, TextView>()
    private val resMon by lazy { ResourceMonitor(a) }
    @Volatile private var devProfile: DeviceProfile? = null
    private var lastRes: ResourceSnapshot? = null
    private var perfMode = PerfMode.Balanced
    private var sugBox: LinearLayout? = null
    private var sugSig = ""

    private val diagTick = object : Runnable {
        override fun run() {
            if (a.menuTab != 9 || !a.menuVisible()) return
            refreshDiagnostics()
            main.postDelayed(this, 1000)
        }
    }

    private fun diagCard(key: String, title: String, desc: String = ""): TextView {
        val box = a.card(title, desc)
        val tv = TextView(a)
        tv.textSize = 11.5f
        tv.setTextColor(Ui.text)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextIsSelectable(true)
        tv.setPadding(0, dp(4), 0, 0)
        box.addView(tv)
        diagViews[key] = tv
        return tv
    }

    fun buildDiagnosticsTab() {
        a.card("О разделе", "Только реальные показатели устройства и записи. Если телефон не отдаёт значение, так и написано: «недоступно». " +
            "Режимы оптимизации ничего не меняют сами: они только предлагают изменения, и вы решаете, применять ли.")
        diagCard("engine", "Состояние и запись")
        diagCard("states", "Состояния и переходы")
        diagCard("rec", "Запись: факты по таймстампам файла")
        diagCard("res", "Ресурсы")
        // режимы оптимизации: только предложения
        val box = a.card("Режим оптимизации", "Performance / Balanced / Quality подбирают предложения под вашу цель. Применяются только по кнопке «Применить»; во время записи недоступно.")
        val modes = PerfMode.values()
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        for (pm in modes) {
            val b = a.flatButton(pm.label, 13f)
            a.segStyle(b, pm == perfMode)
            b.setOnClickListener {
                perfMode = pm; a.prefs.edit().putInt("perf_mode", pm.ordinal).apply()
                sugSig = ""; a.showTab(9, true)
            }
            row.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(6), dp(2), 0) })
        }
        box.addView(row)
        val hint = TextView(a)
        hint.text = perfMode.hint
        hint.textSize = 11f
        hint.setTextColor(Ui.dim)
        hint.setPadding(0, dp(4), 0, 0)
        box.addView(hint)
        sugBox = LinearLayout(a).also { it.orientation = LinearLayout.VERTICAL; box.addView(it) }
        diagCard("device", "Устройство")
        diagCard("cams", "Камеры")
        diagCard("codecs", "Видеокодеры")
        diagCard("plans", "Способ реализации функций на активной камере",
            "Для каждой функции выбирается аппаратный или программный путь. «Недоступно» только если нет ни того ни другого, с причиной.")
        diagCard("errors", "Журнал ошибок")
        if (devProfile == null) Thread {
            devProfile = try { DeviceProfiler.collect(a) } catch (e: Exception) { null }
            main.post { if (a.menuTab == 9) refreshDiagnostics() }
        }.start()
        refreshDiagnostics()
        main.postDelayed(diagTick, 1000)
    }

    private fun refreshDiagnostics() {
        if (!a.engineReady) return
        val label = a.lenses.firstOrNull { it.id == a.engine.cfg.cameraId }?.label ?: "—"
        val f = a.engine.diagFacts(label)
        val r = resMon.sample().also { lastRes = it }
        val dev = devProfile
        diagViews["engine"]?.text = DiagnosticsReport.engine(f) + "\n" + a.engine.colorShaderStatus()
        diagViews["states"]?.text = DiagnosticsReport.states(f)
        diagViews["rec"]?.text = DiagnosticsReport.recording(f.rec, f.lastRec, f.selectedFps)
        diagViews["res"]?.text = DiagnosticsReport.resources(r)
        diagViews["device"]?.text = DiagnosticsReport.device(dev)
        diagViews["cams"]?.text = DiagnosticsReport.cameras(dev, f.activeCameraId)
        diagViews["codecs"]?.text = DiagnosticsReport.codecs(dev)
        diagViews["errors"]?.text = DiagnosticsReport.errors(f)
        diagViews["plans"]?.text = a.engine.routeFacts(dev)?.let { DiagnosticsReport.plans(FeatureRouter.plan(it)) } ?: "камера ещё не открыта"
        val st = f.rec ?: f.lastRec
        val list = OptimizationAdvisor.suggest(perfMode, AdvisorInput(
            a.engine.cfg.size.width, a.engine.cfg.size.height, a.engine.cfg.fps, a.engine.cfg.bitrateKbps, a.engine.cfg.bppIdx,
            a.engine.cfg.nrSoft, a.engine.cfg.eis, a.engine.cfg.codec == Codec.HEVC,
            r.thermalStatus, r.lowMemory, st?.droppedVideo ?: 0, f.captureFailed))
        val sig = list.joinToString("|") { it.title }
        if (sig != sugSig) { sugSig = sig; rebuildSuggestions(list) }
    }

    private fun rebuildSuggestions(list: List<Suggestion>) {
        val box = sugBox ?: return
        box.removeAllViews()
        if (list.isEmpty()) {
            val t = TextView(a); t.text = "Для этого режима предложений нет — текущие настройки уже подходят."
            t.textSize = 11.5f; t.setTextColor(Ui.dim); t.setPadding(0, dp(6), 0, 0); box.addView(t)
            return
        }
        for (s in list) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(8), 0, 0)
            val t = TextView(a); t.text = s.title; t.textSize = 13f; t.setTypeface(null, Typeface.BOLD); t.setTextColor(Ui.text)
            val w = TextView(a); w.text = s.why; w.textSize = 11f; w.setTextColor(Ui.dim)
            row.addView(t); row.addView(w)
            if (s.changes.isNotEmpty()) {
                val b = a.flatButton("Применить", 12.5f)
                a.segStyle(b, false)
                b.setOnClickListener {
                    a.idle {
                        a.settings.saveShooting(a.engine.cfg)
                        a.settings.applyChanges(s.changes)
                        a.appLog("Применено по вашему согласию: ${s.title}")
                        a.recreate()
                    }
                }
                row.addView(b, LinearLayout.LayoutParams(WRAP, dp(38)).apply { topMargin = dp(4) })
            }
            box.addView(row)
        }
    }

    // ------------------------------------------------------------ Настройки: версия схемы, пресеты, сброс

    fun buildSettingsTab() {
        a.settings.saveShooting(a.engine.cfg)
        a.card("Хранилище настроек", "Схема v${a.settings.storedVersion()} (текущая v${SettingsSchema.VERSION}). Обновление приложения не стирает ваши настройки: " +
            "при необходимости они переносятся в новую схему, а значения, которые невозможно применить, заменяются стандартными с записью в журнал.")
        val box = a.card("Пользовательские пресеты", "Пресет — снимок всех текущих настроек (кроме калибровки гироскопа и выбранной камеры). Можно хранить любое число.")
        val add = a.flatButton("Сохранить текущие настройки как пресет…", 13f)
        a.segStyle(add, false)
        add.setOnClickListener {
            val et = EditText(a)
            et.hint = "Название пресета"
            et.setSingleLine(true)
            android.app.AlertDialog.Builder(a).setTitle("Новый пресет").setView(et)
                .setPositiveButton("Сохранить") { _, _ ->
                    a.settings.saveShooting(a.engine.cfg)
                    val n = a.settings.savePreset(et.text.toString())
                    if (n == null) a.toast("Введите название") else { a.toast("Пресет «$n» сохранён"); a.showTab(10, true) }
                }.setNegativeButton("Отмена", null).show()
        }
        box.addView(add, LinearLayout.LayoutParams(MATCH, dp(44)).apply { topMargin = dp(8) })
        for (name in a.settings.presetNames()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val t = TextView(a); t.text = name; t.textSize = 14f; t.setTextColor(Ui.text)
            row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            val ap = a.flatButton("Применить", 12.5f); a.segStyle(ap, false)
            ap.setOnClickListener {
                a.idle {
                    val n = a.settings.applyPreset(name)
                    if (n >= 0) { a.appLog("Пресет «$name» применён ($n параметров)"); a.recreateApplyingPrefs() }
                }
            }
            val del = a.flatButton("Удалить", 12.5f); a.segStyle(del, false)
            del.setOnClickListener { a.settings.deletePreset(name); a.showTab(10, true) }
            row.addView(ap, LinearLayout.LayoutParams(WRAP, dp(38)).apply { setMargins(dp(4), 0, dp(4), 0) })
            row.addView(del, LinearLayout.LayoutParams(WRAP, dp(38)))
            box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        val rbox = a.card("Стандартные настройки", "Вернёт все параметры к значениям по умолчанию. Пресеты и калибровка гироскопа сохранятся.")
        val reset = a.flatButton("Сбросить настройки…", 13f)
        a.segStyle(reset, false)
        reset.setOnClickListener {
            a.idle {
                android.app.AlertDialog.Builder(a).setTitle("Сбросить настройки?")
                    .setMessage("Все параметры вернутся к стандартным. Пресеты не удаляются.")
                    .setPositiveButton("Сбросить") { _, _ -> a.settings.resetToDefaults(); a.recreate() }
                    .setNegativeButton("Отмена", null).show()
            }
        }
        rbox.addView(reset, LinearLayout.LayoutParams(MATCH, dp(44)).apply { topMargin = dp(8) })
    }
}
