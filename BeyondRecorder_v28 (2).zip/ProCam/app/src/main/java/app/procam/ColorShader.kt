package app.procam

/**
 * Фрагментный шейдер цветовой цепочки v0.26. Повторяет эталон ColorPipeline/GradeMath (Kotlin) шаг в шаг;
 * проверка численных эквивалентов — в тестах эталона. GLSL на устройстве проверяется компиляцией при запуске:
 * если шейдер не собрался, GlPipeline автоматически откатывается на шейдер v0.25 и сообщает причину в Диагностике.
 */
object ColorShader {
    const val FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp int;
precision highp sampler3D;
precision highp sampler2D;
uniform samplerExternalOES uTex;
uniform sampler3D uLut;
uniform sampler2D uLut1;
uniform int uLutEnabled;
uniform int uLutKind;        // 0: 3D, 1: 1D
uniform int uLutInterp;      // 0: trilinear (аппаратно), 1: tetrahedral
uniform float uLutMix;
uniform float uLutSize;
uniform float uLut1Size;
uniform vec3 uLutMin;
uniform vec3 uLutScale;
uniform int uLutInTf;
uniform int uLutOutTf;
uniform int uLutOutRaw;
uniform mat3 uLutInMat;
uniform mat3 uLutOutMat;
uniform float uLogGain;
uniform vec4 uCl;            // пользовательская LOG: a, b, c, d
uniform int uPass;           // 0 запись, 1 превью, 2 скоуп
uniform int uOut;            // 0 sdr, 1 log, 2 hlg
uniform int uCurve;          // 0 flat, 1 slog3, 2 vlog, 3 logc, 4 пользовательская
uniform int uInKind;         // 0 sdr, 1 hlg, 2 log с камеры
uniform int uInTf;
uniform float uHlgWhite;
uniform int uPassthru;       // всё нейтрально: пиксель идёт как есть
uniform int uBypass;         // монитор: показать без градации, тон-мэппинга и LUT
uniform float uDither;
uniform mat3 uToWork;
uniform mat3 uWb;
uniform mat3 uWorkToOut;
uniform vec3 uLumaW;
uniform vec3 uLumaOut;
uniform int uGradeOn;
uniform float uEx;
uniform float uContrast;
uniform float uHi;
uniform float uSh;
uniform float uWh;
uniform float uBl;
uniform float uSat;
uniform float uVib;
uniform float uHueRot;
uniform vec3 uLift;
uniform vec3 uGammaV;
uniform vec3 uGain;
uniform float uCurves[20];
uniform vec3 uHue[6];
uniform int uBands;
uniform int uSplitOn;
uniform vec3 uSplitSh;
uniform vec3 uSplitHi;
uniform float uSplitBal;
uniform int uTone;
uniform float uToneWhite;
uniform int uGamut;
uniform int uSdrTf;
uniform int uViewLog;
uniform int uZebraHi;
uniform float uZebraHiLv;
uniform int uZebraLo;
uniform float uZebraLoLv;
uniform float uZebraAlpha;
uniform int uPeak;
uniform int uFalse;
uniform int uFcN;
uniform float uFcLo[8];
uniform float uFcHi[8];
uniform vec3 uFcCol[8];
uniform vec2 uTexel;
in vec2 vUv;
out vec4 oColor;

const float L10 = 0.30103;
const float SHW = 9.4814815;

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

float hlgOetf(float e) {
  e = clamp(e, 0.0, 1.0);
  return e <= 1.0 / 12.0 ? sqrt(3.0 * e) : 0.17883277 * log(max(12.0 * e - 0.28466892, 1e-6)) + 0.55991073;
}
float hlgInv(float v) {
  v = clamp(v, 0.0, 1.0);
  return v <= 0.5 ? v * v / 3.0 : (exp((v - 0.55991073) / 0.17883277) + 0.28466892) / 12.0;
}

float logEncC(int c, float x) {
  x = max(x, 0.0);
  if (c == 1) return x >= 0.01125 ? (420.0 + log2((x + 0.01) / 0.19) * L10 * 261.5) / 1023.0
                                  : (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0;
  if (c == 2) return x < 0.01 ? 5.6 * x + 0.125 : 0.241514 * log2(x + 0.00873) * L10 + 0.598206;
  if (c == 3) return x > 0.010591 ? 0.247190 * log2(5.555556 * x + 0.052272) * L10 + 0.385537
                                  : 5.367655 * x + 0.092809;
  if (c == 4) return clamp(uCl.z * log2(uCl.x * x + uCl.y) + uCl.w, 0.0, 1.0);
  return log2(1.0 + 31.0 * x) / 5.0;
}
float logDecC(int c, float y) {
  y = clamp(y, 0.0, 1.0);
  if (c == 1) { float v = y * 1023.0; return v >= 171.2102946929 ? pow(10.0, (v - 420.0) / 261.5) * 0.19 - 0.01
                                                                 : (v - 95.0) * 0.01125 / (171.2102946929 - 95.0); }
  if (c == 2) return y < 0.181 ? (y - 0.125) / 5.6 : pow(10.0, (y - 0.598206) / 0.241514) - 0.00873;
  if (c == 3) return y > 0.149658 ? (pow(10.0, (y - 0.385537) / 0.247190) - 0.052272) / 5.555556
                                  : (y - 0.092809) / 5.367655;
  if (c == 4) return (exp2((y - uCl.w) / uCl.z) - uCl.y) / uCl.x;
  return (exp2(5.0 * y) - 1.0) / 31.0;
}
vec3 logEnc0(vec3 l) { return vec3(logEncC(uCurve, l.r), logEncC(uCurve, l.g), logEncC(uCurve, l.b)); }
vec3 logEnc(vec3 l) { return logEnc0(l * uLogGain); }
vec3 logDec(vec3 v) { return vec3(logDecC(uCurve, v.r), logDecC(uCurve, v.g), logDecC(uCurve, v.b)) / uLogGain; }

// Передаточные функции по номерам: 0 linear, 1 sRGB, 2 Rec.709, 3 gamma 2.2, 4 gamma 2.4, 5 HLG, 6 PQ, 7 S-Log3, 8 V-Log, 9 LogC, 10 Flat, 11 пользовательская LOG
float tfEncS(int id, float x) {
  if (id == 0) return x;
  x = max(x, 0.0);
  if (id == 1) return x <= 0.0031308 ? 12.92 * x : 1.055 * pow(x, 1.0 / 2.4) - 0.055;
  if (id == 2) return x < 0.018 ? 4.5 * x : 1.099 * pow(x, 0.45) - 0.099;
  if (id == 3) return pow(x, 1.0 / 2.2);
  if (id == 4) return pow(x, 1.0 / 2.4);
  if (id == 5) return hlgOetf(x);
  if (id == 6) { float p = pow(min(x, 1.0), 0.1593017578125); return pow((0.8359375 + 18.8515625 * p) / (1.0 + 18.6875 * p), 78.84375); }
  if (id == 7) return logEncC(1, x);
  if (id == 8) return logEncC(2, x);
  if (id == 9) return logEncC(3, x);
  if (id == 11) return logEncC(4, x);
  return logEncC(0, x);
}
float tfDecS(int id, float y) {
  if (id == 0) return y;
  y = clamp(y, 0.0, 1.0);
  if (id == 1) return y <= 0.04045 ? y / 12.92 : pow((y + 0.055) / 1.055, 2.4);
  if (id == 2) return y < 0.081 ? y / 4.5 : pow((y + 0.099) / 1.099, 1.0 / 0.45);
  if (id == 3) return pow(y, 2.2);
  if (id == 4) return pow(y, 2.4);
  if (id == 5) return hlgInv(y);
  if (id == 6) { float p = pow(y, 1.0 / 78.84375); return pow(max(p - 0.8359375, 0.0) / (18.8515625 - 18.6875 * p), 1.0 / 0.1593017578125); }
  if (id == 7) return logDecC(1, y);
  if (id == 8) return logDecC(2, y);
  if (id == 9) return logDecC(3, y);
  if (id == 11) return logDecC(4, y);
  return logDecC(0, y);
}
vec3 tfEnc3(int id, vec3 v) { return vec3(tfEncS(id, v.r), tfEncS(id, v.g), tfEncS(id, v.b)); }
vec3 tfDec3(int id, vec3 v) { return vec3(tfDecS(id, v.r), tfDecS(id, v.g), tfDecS(id, v.b)); }

vec3 srgbEncX(vec3 l) { l = max(l, vec3(0.0)); return mix(l * 12.92, 1.055 * pow(l, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), l)); }
vec3 srgbDecX(vec3 v) { v = max(v, vec3(0.0)); return mix(v / 12.92, pow((v + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), v)); }

// ---------------------------------------------------------------- градация
float curveEval(int off, float x) {
  if (x <= 0.0) return x + uCurves[off];
  if (x >= 1.0) return x + (uCurves[off + 4] - 1.0);
  float t = x * 4.0;
  int i = min(int(t), 3);
  float f = t - float(i);
  float p0 = uCurves[off + i];
  float p1 = uCurves[off + i + 1];
  int im1 = max(i - 1, 0);
  int ip2 = min(i + 2, 4);
  float m0 = (i == 0) ? (p1 - p0) : (uCurves[off + i + 1] - uCurves[off + im1]) * 0.5;
  float m1 = (i == 3) ? (p1 - p0) : (uCurves[off + ip2] - uCurves[off + i]) * 0.5;
  float f2 = f * f;
  float f3 = f2 * f;
  return (2.0 * f3 - 3.0 * f2 + 1.0) * p0 + (f3 - 2.0 * f2 + f) * m0 + (-2.0 * f3 + 3.0 * f2) * p1 + (f3 - f2) * m1;
}

float tonalF(float g) {
  float c = clamp(g, 0.0, 1.0);
  float o = 1.0 - c;
  g += uBl * 0.10 * pow(o, 6.0);
  g += uSh * 0.25 * SHW * c * o * o * o;
  g += uHi * 0.25 * SHW * c * c * c * o;
  g += uWh * 0.10 * pow(c, 6.0);
  return 0.46 + (g - 0.46) * (1.0 + uContrast);
}

vec3 hueAnchor(float hd) {
  float h = mod(hd, 360.0);
  float t = h / 60.0;
  int i = min(int(t), 5);
  float f = t - float(i);
  float w = (1.0 - cos(3.14159265 * f)) * 0.5;
  return uHue[i] * (1.0 - w) + uHue[(i + 1) % 6] * w;
}

vec3 chromaOps(vec3 g) {
  float y0 = dot(g, uLumaW);
  vec3 r = g;
  if (uSat != 1.0) r = vec3(y0) + (r - vec3(y0)) * uSat;
  if (uVib != 0.0) {
    float mx = max(r.r, max(r.g, r.b));
    float mn = min(r.r, min(r.g, r.b));
    float s = mx > 1e-6 ? clamp((mx - mn) / mx, 0.0, 1.0) : 0.0;
    r = vec3(y0) + (r - vec3(y0)) * (1.0 + uVib * (1.0 - s));
  }
  if (uBands == 1) {
    const vec3 U = vec3(0.8164966, -0.4082483, -0.4082483);
    const vec3 V = vec3(0.0, 0.7071068, -0.7071068);
    float m = (r.r + r.g + r.b) / 3.0;
    vec3 d = r - vec3(m);
    float cu = dot(d, U);
    float cv = dot(d, V);
    float ch = sqrt(cu * cu + cv * cv);
    float hd = ch > 1e-5 ? degrees(atan(cv, cu)) : 0.0;
    float wgt = clamp(ch * 6.0, 0.0, 1.0);
    vec3 a = hueAnchor(hd);
    float ang = radians(uHueRot + a.x * wgt);
    float sm = 1.0 + a.y * wgt;
    float nu = (cu * cos(ang) - cv * sin(ang)) * sm;
    float nv = (cu * sin(ang) + cv * cos(ang)) * sm;
    float lumAdd = a.z * wgt * 0.25;
    r = vec3(m) + nu * U + nv * V + vec3(lumAdd);
    float y1 = dot(r, uLumaW);
    r += vec3(y0 + lumAdd - y1);
  }
  if (uSplitOn == 1) {
    float y = clamp(dot(r, uLumaW), 0.0, 1.0);
    float yb = clamp(y + uSplitBal, 0.0, 1.0);
    float ws = (1.0 - yb) * (1.0 - yb);
    float wh = yb * yb;
    r += uSplitSh * ws + uSplitHi * wh;
  }
  return r;
}

vec3 gradeAll(vec3 lin) {
  vec3 x = max(uWb * lin, vec3(0.0)) * uEx;
  vec3 g = srgbEncX(x);
  g = vec3(tonalF(g.r), tonalF(g.g), tonalF(g.b));
  vec3 vv = uGain * (g + uLift * (vec3(1.0) - clamp(g, 0.0, 1.0)));
  vec3 pw = pow(max(vv, vec3(0.0)), vec3(1.0) / uGammaV);
  g = mix(vv, pw, step(vec3(0.0), vv));
  g = vec3(curveEval(5, curveEval(0, g.r)), curveEval(10, curveEval(0, g.g)), curveEval(15, curveEval(0, g.b)));
  g = chromaOps(g);
  return srgbDecX(g);
}

float toneOne(float x) {
  if (uTone == 1) { x = max(x, 0.0); return clamp(x * (1.0 + x / (uToneWhite * uToneWhite)) / (1.0 + x), 0.0, 1.0); }
  if (uTone == 2) { x = max(x, 0.0); return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
  if (uTone == 3) {
    float a = max(x, 0.0) * 2.0;
    float w = uToneWhite * 2.0;
    float ha = ((a * (0.15 * a + 0.05) + 0.004) / (a * (0.15 * a + 0.5) + 0.06)) - 0.02 / 0.3;
    float hw = ((w * (0.15 * w + 0.05) + 0.004) / (w * (0.15 * w + 0.5) + 0.06)) - 0.02 / 0.3;
    return clamp(ha / hw, 0.0, 1.0);
  }
  return x;
}

vec3 gamutMap(vec3 c) {
  if (uGamut == 1) {
    float y = clamp(dot(c, uLumaOut), 0.0, 1.0);
    float t = 1.0;
    if (c.r < 0.0) t = min(t, y / (y - c.r));
    if (c.g < 0.0) t = min(t, y / (y - c.g));
    if (c.b < 0.0) t = min(t, y / (y - c.b));
    return clamp(vec3(y) + (c - vec3(y)) * t, 0.0, 1.0);
  }
  return clamp(c, 0.0, 1.0);
}

// ---------------------------------------------------------------- LUT
vec3 lutTrilinear(vec3 c) {
  vec3 n = clamp((c - uLutMin) * uLutScale, 0.0, 1.0);
  vec3 uv = n * ((uLutSize - 1.0) / uLutSize) + vec3(0.5 / uLutSize);
  return texture(uLut, uv).rgb;
}
vec3 lutTetra(vec3 c) {
  vec3 n = clamp((c - uLutMin) * uLutScale, 0.0, 1.0) * (uLutSize - 1.0);
  vec3 b0 = min(floor(n), vec3(uLutSize - 2.0));
  vec3 f = n - b0;
  ivec3 i0 = ivec3(b0);
  vec3 c000 = texelFetch(uLut, i0, 0).rgb;
  vec3 c111 = texelFetch(uLut, i0 + ivec3(1, 1, 1), 0).rgb;
  if (f.r > f.g) {
    vec3 c100 = texelFetch(uLut, i0 + ivec3(1, 0, 0), 0).rgb;
    if (f.g > f.b) {
      vec3 c110 = texelFetch(uLut, i0 + ivec3(1, 1, 0), 0).rgb;
      return c000 + f.r * (c100 - c000) + f.g * (c110 - c100) + f.b * (c111 - c110);
    }
    vec3 c101 = texelFetch(uLut, i0 + ivec3(1, 0, 1), 0).rgb;
    if (f.r > f.b) return c000 + f.r * (c100 - c000) + f.b * (c101 - c100) + f.g * (c111 - c101);
    vec3 c001 = texelFetch(uLut, i0 + ivec3(0, 0, 1), 0).rgb;
    return c000 + f.b * (c001 - c000) + f.r * (c101 - c001) + f.g * (c111 - c101);
  }
  vec3 c010 = texelFetch(uLut, i0 + ivec3(0, 1, 0), 0).rgb;
  if (f.b > f.g) {
    vec3 c001 = texelFetch(uLut, i0 + ivec3(0, 0, 1), 0).rgb;
    vec3 c011 = texelFetch(uLut, i0 + ivec3(0, 1, 1), 0).rgb;
    return c000 + f.b * (c001 - c000) + f.g * (c011 - c001) + f.r * (c111 - c011);
  }
  if (f.b > f.r) {
    vec3 c011 = texelFetch(uLut, i0 + ivec3(0, 1, 1), 0).rgb;
    return c000 + f.g * (c010 - c000) + f.b * (c011 - c010) + f.r * (c111 - c011);
  }
  vec3 c110 = texelFetch(uLut, i0 + ivec3(1, 1, 0), 0).rgb;
  return c000 + f.g * (c010 - c000) + f.r * (c110 - c010) + f.b * (c111 - c110);
}
vec3 lut1D(vec3 c) {
  vec3 n = clamp((c - uLutMin) * uLutScale, 0.0, 1.0);
  float k = (uLut1Size - 1.0) / uLut1Size;
  float h = 0.5 / uLut1Size;
  return vec3(texture(uLut1, vec2(n.r * k + h, 0.5)).r, texture(uLut1, vec2(n.g * k + h, 0.5)).g, texture(uLut1, vec2(n.b * k + h, 0.5)).b);
}
vec3 lutSample(vec3 c) {
  if (uLutKind == 1) return lut1D(c);
  if (uLutInterp == 1 && uLutSize > 2.5) return lutTetra(c);
  return lutTrilinear(c);
}

// ---------------------------------------------------------------- цепочка
vec3 inputLinear(vec3 src) {
  if (uInKind == 2) return logDec(src);
  if (uInKind == 1) return vec3(hlgInv(src.r), hlgInv(src.g), hlgInv(src.b)) / uHlgWhite;
  return tfDec3(uInTf, src);
}

vec3 encodeOut(vec3 lin) {
  if (uPass == 0) {
    if (uOut == 1) return logEnc(lin);
    if (uOut == 2) { vec3 e = lin * uHlgWhite; return vec3(hlgOetf(e.r), hlgOetf(e.g), hlgOetf(e.b)); }
    return tfEnc3(uSdrTf, lin);
  }
  if (uViewLog == 1) return logEnc(lin);
  return tfEnc3(uSdrTf, lin);
}

vec3 colorChain(vec3 src) {
  bool act = !(uPass != 0 && uBypass == 1);
  vec3 w = uToWork * inputLinear(src);
  if (uGradeOn == 1 && act) w = gradeAll(w);
  if (uTone != 0 && act) w = vec3(toneOne(w.r), toneOne(w.g), toneOne(w.b));
  vec3 lin = gamutMap(uWorkToOut * w);
  vec3 plain = (uPass != 0 && uViewLog == 1 && uInKind == 2) ? src : encodeOut(lin);
  if (uLutEnabled == 1 && act) {
    vec3 li = clamp(tfEnc3(uLutInTf, uLutInMat * lin), 0.0, 1.0);
    vec3 lo = lutSample(li);
    vec3 withLut = (uLutOutRaw == 1) ? clamp(lo, 0.0, 1.0) : encodeOut(clamp(uLutOutMat * tfDec3(uLutOutTf, lo), 0.0, 1.0));
    return mix(plain, withLut, clamp(uLutMix, 0.0, 1.0));
  }
  return plain;
}

vec3 falseColorMap(float y, vec3 v) {
  for (int i = 0; i < 8; i++) {
    if (i >= uFcN) break;
    if (y >= uFcLo[i] && y < uFcHi[i]) return uFcCol[i];
  }
  return v;
}

void main() {
  vec3 src = clamp(texture(uTex, vUv).rgb, 0.0, 1.0);
  if (uPassthru == 1) { oColor = vec4(src, 1.0); return; }
  vec3 v = colorChain(src);
  if (uPass == 1) {
    float y = lum(v);
    if (uFalse == 1) v = falseColorMap(y, v);
    if (uPeak == 1) {
      float gx = lum(texture(uTex, vUv + vec2(uTexel.x, 0.0)).rgb) - lum(texture(uTex, vUv - vec2(uTexel.x, 0.0)).rgb);
      float gy = lum(texture(uTex, vUv + vec2(0.0, uTexel.y)).rgb) - lum(texture(uTex, vUv - vec2(0.0, uTexel.y)).rgb);
      if (abs(gx) + abs(gy) > 0.18) v = vec3(1.0, 0.15, 0.15);
    }
    if (uZebraHi == 1 && y >= uZebraHiLv) {
      if (fract((gl_FragCoord.x + gl_FragCoord.y) / 14.0) > 0.5) v = mix(v, vec3(0.0), uZebraAlpha);
    } else if (uZebraLo == 1 && y <= uZebraLoLv) {
      if (fract((gl_FragCoord.x - gl_FragCoord.y) / 14.0) > 0.5) v = mix(v, vec3(0.15, 0.45, 1.0), uZebraAlpha);
    }
  }
  if (uDither > 0.0) {
    float n = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
    float m = fract(sin(dot(gl_FragCoord.xy + vec2(7.1, 3.7), vec2(12.9898, 78.233))) * 43758.5453);
    v += vec3((n + m - 1.0) * uDither / 255.0);
  }
  oColor = vec4(v, 1.0);
}
"""
}
