package app.procam

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Адаптивная ширина окна сглаживания: в покое — длинное окно (устойчиво), при намеренном движении — короткое (камера «едет» без лага и лишнего кропа). */
object AdaptiveSmoothing {
    /** @param adapt 0 — окно постоянно; больше — сильнее реагирует на скорость. speedRef — скорость (рад/с), при которой окно уменьшается вдвое при adapt=1. */
    fun sigma(base: Double, speed: Double, adapt: Double, speedRef: Double = 0.35, minFrac: Double = 0.15): Double =
        base * max(minFrac, 1.0 / (1.0 + adapt * abs(speed) / speedRef))

    /** Характер: 0 — максимально естественное движение (сильная адаптация), 1 — максимально устойчивое изображение (слабая адаптация, длинное окно). */
    fun adaptFor(character: Double): Double = 3.0 - 2.6 * character.coerceIn(0.0, 1.0)
    fun baseScaleFor(character: Double): Double = 0.6 + 0.9 * character.coerceIn(0.0, 1.0)
}

/** Ограничитель скорости изменения коррекции (рад или нормированные единицы за кадр): подавляет рывки при скачках оценки. */
class SlewLimiter(var maxStep: Double) {
    private var last = 0.0
    private var have = false
    fun reset() { have = false }
    fun step(v: Double, scale: Double = 1.0): Double {
        if (!have) { last = v; have = true; return v }
        val m = maxStep * scale
        last += (v - last).coerceIn(-m, m)
        return last
    }
}

/**
 * Управление динамическим кропом: масштаб кадра растёт быстро (чтобы закрыть границы) и спадает медленно (нет «дыхания»).
 * Работает в логарифмических единицах, поэтому изменение масштаба плавное. Границы жёстко соблюдаются точной проверкой в стабилизаторе.
 */
class CropController(val minC: Double = 1.0, var maxC: Double = 1.3, val attackPerSec: Double = 2.5, val releasePerSec: Double = 0.3) {
    var c = minC; private set
    fun reset(v: Double = minC) { c = v.coerceIn(minC, maxC) }
    fun step(required: Double, dtSec: Double): Double {
        val target = required.coerceIn(minC, maxC)
        val d = ln(target) - ln(c)
        val rate = (if (d > 0) attackPerSec else releasePerSec) * dtSec
        c = exp(ln(c) + d.coerceIn(-rate, rate)).coerceIn(minC, maxC)
        return c
    }
}

/** Потеря области кадра для пользователя: crop = 1/c по линейным размерам. */
object CropMath {
    fun lossLinearPct(c: Double) = (1.0 - 1.0 / max(c, 1.0)) * 100.0
    fun lossAreaPct(c: Double) = (1.0 - 1.0 / (max(c, 1.0) * max(c, 1.0))) * 100.0
    /** Максимальный кроп в процентах (линейно) → коэффициент c. */
    fun cFromPct(pct: Double) = 1.0 / (1.0 - pct.coerceIn(0.0, 95.0) / 100.0)
    /** Минимальный масштаб, при котором окно 1/z кадра после поворота rot и сдвига (tx,ty) (в пикселях) целиком лежит внутри кадра w×h. */
    fun requiredZoom(w: Double, h: Double, tx: Double, ty: Double, rot: Double): Double {
        val hw = w / 2; val hh = h / 2
        val c = abs(cos(rot)); val s = abs(sin(rot))
        if (abs(tx) >= hw || abs(ty) >= hh) return Double.POSITIVE_INFINITY
        return max(1.0, max((hw * c + hh * s) / (hw - abs(tx)), (hw * s + hh * c) / (hh - abs(ty))))
    }
}

/** Наклон горизонта по изображению: доминирующая ориентация градиентов с точностью до 90° (вертикали и горизонтали сцены). Это ОЦЕНКА, а не измерение. */
object HorizonEstimator {
    class Tilt(val rad: Double, val confidence: Double)
    /** rad > 0 — вертикальные линии сцены наклонены верхом вправо (по часовой на экране). confidence 0..1 — насколько края выстроены по общей сетке; природные сцены дают малую. */
    fun imageTilt(g: Gray, minMag: Float = 0.02f): Tilt? {
        var sc = 0.0; var ss = 0.0; var sw = 0.0
        for (y in 1 until g.h - 1) for (x in 1 until g.w - 1) {
            val gx = (g.d[y * g.w + x + 1] - g.d[y * g.w + x - 1]) * 0.5f
            val gy = (g.d[(y + 1) * g.w + x] - g.d[(y - 1) * g.w + x]) * 0.5f
            val m = hypot(gx, gy)
            if (m < minMag) continue
            val th = atan2(gy.toDouble(), gx.toDouble())
            val w = (m * m).toDouble()
            sc += w * cos(4 * th); ss += w * sin(4 * th); sw += w
        }
        if (sw < 1e-9) return null
        return Tilt(atan2(ss, sc) / 4.0, hypot(sc, ss) / sw)
    }
}

/**
 * Измерение времени считывания матрицы (rolling shutter skew) по изображению. Строка с долей r кадра экспонируется на r·skew позже верхней,
 * поэтому разность сдвигов нижней и верхней полос между кадрами пропорциональна УСКОРЕНИЮ камеры: Δb = Δr·skew·(d₂−d₁)/dt.
 * Оценка — МНК по множеству кадров; пригодна только при достаточных ускорениях (дрожание, резкие движения). Время считывания не «выдумывается»:
 * при малом числе выборок или слабой корреляции результат считается ненадёжным.
 */
class RsEstimator(private val deltaR: Double = 2.0 / 3.0) {
    private var sxy = 0.0; private var sxx = 0.0; private var syy = 0.0; var n = 0; private set
    private var d0 = Double.NaN; private var d1 = Double.NaN          // сдвиги центра кадров k−1 и k
    private var yPend = Double.NaN; private var dtPend = 0.0           // разность полос кадра k ждёт d_{k+1}
    fun reset() { sxy = 0.0; sxx = 0.0; syy = 0.0; n = 0; d0 = Double.NaN; d1 = Double.NaN; yPend = Double.NaN }
    /**
     * @param bFirst/bLast сдвиг первой/последней по порядку считывания полосы между кадрами (px), dMid — сдвиг центральной, dt — интервал кадров (с).
     * Ускорение берётся центральной разностью вокруг кадра k, поэтому оценка запаздывает на один кадр.
     */
    fun add(bFirst: Double, bLast: Double, dMid: Double, dt: Double) {
        if (dt <= 0) return
        if (!yPend.isNaN() && !d0.isNaN()) {
            val acc = (dMid - d0) / (2 * dt)                  // px/с: центральная разность для кадра k
            val x = deltaR * acc
            sxy += x * yPend; sxx += x * x; syy += yPend * yPend; n++
        }
        d0 = d1; d1 = dMid
        yPend = bLast - bFirst; dtPend = dt
    }
    /** Оценка skew (с) или null. */
    fun skewSec(): Double? = if (n < 40 || sxx < 1e-9) null else (sxy / sxx).takeIf { it > 0 && it < 0.2 }
    /** Корреляция 0..1 между предсказанием и измерением. */
    fun reliability(): Double = if (n < 40 || sxx < 1e-9 || syy < 1e-12) 0.0 else (sxy / sqrt(sxx * syy)).coerceIn(0.0, 1.0)
}

/** Сдвиги полос из набора векторов потока: первая/последняя треть (по оси readout) и центр. Возвращает null при недостатке точек в полосе. */
object BandShifts {
    class R(val rowsFirstX: Double, val rowsLastX: Double, val rowsMidX: Double, val colsFirstY: Double, val colsLastY: Double, val colsMidY: Double)
    fun of(g: GlobalMotion, w: Int, h: Int): R? {
        fun med(l: ArrayList<Double>): Double? { if (l.size < 3) return null; l.sort(); return l[l.size / 2] }
        val rt = ArrayList<Double>(); val rm = ArrayList<Double>(); val rb = ArrayList<Double>()
        val cl = ArrayList<Double>(); val cm = ArrayList<Double>(); val cr = ArrayList<Double>()
        for (i in g.vx0.indices) {
            if (!g.vin[i]) continue
            val dx = (g.vx1[i] - g.vx0[i]).toDouble(); val dy = (g.vy1[i] - g.vy0[i]).toDouble()
            val fy = (g.vy0[i] + (h - 1) / 2.0) / h; val fx = (g.vx0[i] + (w - 1) / 2.0) / w
            when { fy < 1.0 / 3 -> rt.add(dx); fy > 2.0 / 3 -> rb.add(dx); else -> rm.add(dx) }
            when { fx < 1.0 / 3 -> cl.add(dy); fx > 2.0 / 3 -> cr.add(dy); else -> cm.add(dy) }
        }
        return R(med(rt) ?: return null, med(rb) ?: return null, med(rm) ?: return null, med(cl) ?: return null, med(cr) ?: return null, med(cm) ?: return null)
    }
}

/**
 * Централизованная временная обработка: реальные метки кадров, история, защита от устаревших кадров, режимы задержки.
 * Не вносит задержки в видеопоток и не трогает PTS — синхронизация звука и видео остаётся как у камеры.
 */
class TemporalManager(var mode: Mode = Mode.BALANCED) {
    enum class Mode(val label: String) { LOW_LATENCY("Low Latency"), BALANCED("Balanced"), MAX_QUALITY("Maximum Quality") }

    /** Что режим меняет в АЛГОРИТМАХ (параметры записи не трогает). */
    class Profile(val analysisW: Int, val analysisEvery: Int, val flowLevels: Int, val maxFeatures: Int, val ransacIters: Int, val nrTemporalScale: Float, val futureWindowSec: Double)

    class Frame(val dtNs: Long, val gap: Boolean, val dropped: Int, val fps: Double)

    private var last = 0L
    private var nominalNs = 33_333_333L
    private val win = LongArray(30); private var wn = 0
    var framesSeen = 0L; private set
    var droppedTotal = 0L; private set
    var gapResets = 0L; private set

    private var lastFps = 0.0
    fun fpsNow() = lastFps
    fun setNominalFps(fps: Int) { nominalNs = 1_000_000_000L / fps.coerceAtLeast(1) }
    fun reset() { last = 0L; wn = 0 }

    fun profile(): Profile = profileOf(mode)

    companion object {
        fun profileOf(mode: Mode): Profile = when (mode) {
            Mode.LOW_LATENCY -> Profile(96, 2, 2, 60, 40, 0.6f, 0.05)
            Mode.BALANCED -> Profile(128, 1, 3, 100, 60, 1.0f, 0.15)
            Mode.MAX_QUALITY -> Profile(160, 1, 4, 160, 100, 1.25f, 0.30)
        }
    }

    /**
     * Регистрирует кадр по его метке (нс). Разрыв > 3.5 кадров — «устаревшая» история: потребители сбрасывают накопление (NR, поток), чтобы не смешивать кадры из разных моментов.
     * Если метки не растут — кадр считается недействительным (dtNs=0).
     */
    fun onFrame(tsNs: Long): Frame {
        framesSeen++
        if (last == 0L) { last = tsNs; return Frame(nominalNs, false, 0, 1e9 / nominalNs) }
        val dt = tsNs - last
        if (dt <= 0) return Frame(0, true, 0, 0.0)
        last = tsNs
        val dropped = max(0, Math.round(dt.toDouble() / nominalNs).toInt() - 1)
        droppedTotal += dropped
        val gap = dt > nominalNs * 3.5
        if (gap) gapResets++
        if (wn < win.size) win[wn++] = dt else { System.arraycopy(win, 1, win, 0, win.size - 1); win[win.size - 1] = dt }
        var s = 0L; for (i in 0 until wn) s += win[i]
        lastFps = if (wn > 0) 1e9 * wn / s else 0.0
        return Frame(dt, gap, dropped, lastFps)
    }
}
