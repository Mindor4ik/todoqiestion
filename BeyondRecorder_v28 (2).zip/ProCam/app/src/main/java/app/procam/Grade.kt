package app.procam

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Ручная цветокоррекция. Порядок (один и тот же для превью и записи, шейдер повторяет его):
 *  1) линейный рабочий охват: баланс белого (матрица), экспозиция (×2^EV);
 *  2) «домен градации»: кодирование sRGB-подобной кривой (воспринимаемо-равномерный домен);
 *  3) тональные: Blacks → Shadows → Highlights → Whites → Contrast, Lift/Gamma/Gain, RGB-кривые;
 *  4) цветовые: Saturation, Vibrance, Hue, 6 цветовых полос (Hue vs Hue/Sat/Lum), Split Toning;
 *  5) обратно в линейный охват.
 * Каждый параметр в нейтральном положении тождественен: при значениях по умолчанию изображение не меняется.
 */
class GradeParams(
    val exposureEv: Double = 0.0, val kelvin: Double = 6500.0, val tint: Double = 0.0,
    val contrast: Double = 0.0, val highlights: Double = 0.0, val shadows: Double = 0.0, val whites: Double = 0.0, val blacks: Double = 0.0,
    val saturation: Double = 1.0, val vibrance: Double = 0.0, val hue: Double = 0.0,
    /** lift (аддитивно, 0 = нейтрально), gamma (1 = нейтрально), gain (1 = нейтрально): общий + по каналам R,G,B. */
    val lift: DoubleArray = doubleArrayOf(0.0, 0.0, 0.0, 0.0),
    val gamma: DoubleArray = doubleArrayOf(1.0, 1.0, 1.0, 1.0),
    val gain: DoubleArray = doubleArrayOf(1.0, 1.0, 1.0, 1.0),
    /** Кривые: 5 узлов (x = 0, 0.25, 0.5, 0.75, 1) для M, R, G, B подряд (20 значений). */
    val curves: DoubleArray = IDENTITY_CURVES.copyOf(),
    /** Цветовые полосы: 6 якорей по оттенку (R, Y, G, C, B, M): сдвиг оттенка (градусы), насыщенность (−1…1), яркость (−1…1). */
    val hueShift: DoubleArray = DoubleArray(6), val hueSat: DoubleArray = DoubleArray(6), val hueLum: DoubleArray = DoubleArray(6),
    /** Split toning: оттенок (градусы) и сила (0…1) для теней и светов, баланс −1…1. */
    val splitShHue: Double = 220.0, val splitShAmt: Double = 0.0, val splitHiHue: Double = 40.0, val splitHiAmt: Double = 0.0, val splitBalance: Double = 0.0
) {
    companion object {
        val IDENTITY_CURVES = DoubleArray(20) { (it % 5) / 4.0 }
        const val PIVOT = 0.46
        /** 256/27: нормировка окон теней (пик в 1/4) и светов (пик в 3/4) на 1. */
        const val SHW = 256.0 / 27.0
    }
    fun isNeutral(): Boolean = GradeMath.isNeutral(this)
}

object GradeMath {
    val NEUTRAL = GradeParams()

    fun isNeutral(p: GradeParams): Boolean =
        p.exposureEv == 0.0 && p.kelvin == 6500.0 && p.tint == 0.0 && p.contrast == 0.0 && p.highlights == 0.0 && p.shadows == 0.0 &&
            p.whites == 0.0 && p.blacks == 0.0 && p.saturation == 1.0 && p.vibrance == 0.0 && p.hue == 0.0 &&
            p.lift.all { it == 0.0 } && p.gamma.all { it == 1.0 } && p.gain.all { it == 1.0 } &&
            p.curves.contentEquals(GradeParams.IDENTITY_CURVES) &&
            p.hueShift.all { it == 0.0 } && p.hueSat.all { it == 0.0 } && p.hueLum.all { it == 0.0 } &&
            p.splitShAmt == 0.0 && p.splitHiAmt == 0.0

    /** Кривая по 5 узлам: кубическая Эрмита с касательными Catmull-Rom; вне 0..1 продолжается с наклоном 1 (HDR не обрезается). */
    fun curve(v: DoubleArray, off: Int, x: Double): Double {
        if (x <= 0.0) return x + v[off]
        if (x >= 1.0) return x + (v[off + 4] - 1.0)
        val t = x * 4.0
        val i = min(t.toInt(), 3)
        val f = t - i
        val p0 = v[off + i]; val p1 = v[off + i + 1]
        val m0 = if (i == 0) (p1 - p0) else (v[off + i + 1] - v[off + i - 1]) * 0.5
        val m1 = if (i == 3) (p1 - p0) else (v[off + i + 2] - v[off + i]) * 0.5
        val f2 = f * f; val f3 = f2 * f
        return (2 * f3 - 3 * f2 + 1) * p0 + (f3 - 2 * f2 + f) * m0 + (-2 * f3 + 3 * f2) * p1 + (f3 - f2) * m1
    }

    fun tonal(g0: Double, p: GradeParams): Double {
        var g = g0
        val c = g.coerceIn(0.0, 1.0)
        g += p.blacks * 0.10 * (1 - c).pow(6)
        g += p.shadows * 0.25 * GradeParams.SHW * c * (1 - c) * (1 - c) * (1 - c)
        g += p.highlights * 0.25 * GradeParams.SHW * c * c * c * (1 - c)
        g += p.whites * 0.10 * c.pow(6)
        g = GradeParams.PIVOT + (g - GradeParams.PIVOT) * (1.0 + p.contrast)
        return g
    }

    fun hueAnchor(v: DoubleArray, hueDeg: Double): Double {
        val h = ((hueDeg % 360.0) + 360.0) % 360.0
        val t = h / 60.0
        val i = min(t.toInt(), 5)
        val f = t - i
        val w = (1 - cos(PI * f)) * 0.5
        return v[i] * (1 - w) + v[(i + 1) % 6] * w
    }

    private val U = doubleArrayOf(2 / sqrt(6.0), -1 / sqrt(6.0), -1 / sqrt(6.0))
    private val V = doubleArrayOf(0.0, 1 / sqrt(2.0), -1 / sqrt(2.0))

    /** Цветовые операции в домене градации. [lw] — яркостные коэффициенты рабочего охвата. */
    fun chroma(g: DoubleArray, p: GradeParams, lw: DoubleArray): DoubleArray {
        val y0 = lw[0] * g[0] + lw[1] * g[1] + lw[2] * g[2]
        var r = g.copyOf()
        // Saturation
        if (p.saturation != 1.0) r = DoubleArray(3) { y0 + (r[it] - y0) * p.saturation }
        // Vibrance: сильнее влияет на малонасыщенные пиксели
        if (p.vibrance != 0.0) {
            val mx = max(r[0], max(r[1], r[2])); val mn = min(r[0], min(r[1], r[2]))
            val sat = if (mx > 1e-6) ((mx - mn) / mx).coerceIn(0.0, 1.0) else 0.0
            val k = 1.0 + p.vibrance * (1.0 - sat)
            r = DoubleArray(3) { y0 + (r[it] - y0) * k }
        }
        // Hue / 6 полос: разложение на серую ось и плоскость цветности (u, v), поворот и масштаб цветности
        val needBands = p.hue != 0.0 || p.hueShift.any { it != 0.0 } || p.hueSat.any { it != 0.0 } || p.hueLum.any { it != 0.0 }
        if (needBands) {
            val m = (r[0] + r[1] + r[2]) / 3.0
            val cu = (r[0] - m) * U[0] + (r[1] - m) * U[1] + (r[2] - m) * U[2]
            val cv = (r[0] - m) * V[0] + (r[1] - m) * V[1] + (r[2] - m) * V[2]
            val ch = sqrt(cu * cu + cv * cv)
            val hd = Math.toDegrees(atan2(cv, cu))
            val wgt = (ch * 6.0).coerceIn(0.0, 1.0)             // серые не получают цветового сдвига
            val dh = p.hue + hueAnchor(p.hueShift, hd) * wgt
            val sm = 1.0 + hueAnchor(p.hueSat, hd) * wgt
            val a = Math.toRadians(dh)
            val nu = (cu * cos(a) - cv * sin(a)) * sm
            val nv = (cu * sin(a) + cv * cos(a)) * sm
            val lumAdd = hueAnchor(p.hueLum, hd) * wgt * 0.25
            r = DoubleArray(3) { m + nu * U[it] + nv * V[it] + lumAdd }
            val y1 = lw[0] * r[0] + lw[1] * r[1] + lw[2] * r[2]
            val target = y0 + lumAdd                           // яркость сохраняется, кроме явной Hue vs Lum
            r = DoubleArray(3) { r[it] + (target - y1) }
        }
        // Split Toning
        if (p.splitShAmt != 0.0 || p.splitHiAmt != 0.0) {
            val y = (lw[0] * r[0] + lw[1] * r[1] + lw[2] * r[2]).coerceIn(0.0, 1.0)
            val bal = p.splitBalance * 0.5
            val ws = (1.0 - (y + bal).coerceIn(0.0, 1.0)).pow(2)
            val wh = (y + bal).coerceIn(0.0, 1.0).pow(2)
            val ts = tintVec(p.splitShHue, lw); val th = tintVec(p.splitHiHue, lw)
            r = DoubleArray(3) { r[it] + ts[it] * p.splitShAmt * 0.25 * ws + th[it] * p.splitHiAmt * 0.25 * wh }
        }
        return r
    }

    /** Цветность оттенка (угол, градусы) с нулевой яркостью: прибавляется к пикселю при тонировании. */
    fun tintVec(hueDeg: Double, lw: DoubleArray): DoubleArray {
        val a = Math.toRadians(hueDeg)
        val v = DoubleArray(3) { cos(a) * U[it] + sin(a) * V[it] }
        val y = lw[0] * v[0] + lw[1] * v[1] + lw[2] * v[2]
        return DoubleArray(3) { v[it] - y }
    }

    /** Обратная к sRGB-кодированию без ограничения сверху (значения выше 1 — HDR — возвращаются точно). */
    fun srgbDecodeExt(y: Double): Double = if (y <= 0.04045) max(y, 0.0) / 12.92 else ((y + 0.055) / 1.055).pow(2.4)

    /** Полная градация линейного значения рабочего охвата. [wb] — матрица баланса белого (WhiteBalance.matrix). */
    fun apply(lin: DoubleArray, p: GradeParams, wb: DoubleArray, lw: DoubleArray): DoubleArray {
        val ex = 2.0.pow(p.exposureEv)
        val x = M3.mulV(wb, lin)
        val g = DoubleArray(3) { TfMath.encode(Tf.SRGB, max(x[it] * ex, 0.0)) }
        for (k in 0 until 3) {
            var v = tonal(g[k], p)
            val gm = p.gamma[0] * p.gamma[1 + k]
            val gn = p.gain[0] * p.gain[1 + k]
            val lf = p.lift[0] + p.lift[1 + k]
            val vv = gn * (v + lf * (1.0 - v.coerceIn(0.0, 1.0)))
            v = if (vv <= 0.0) vv else vv.pow(1.0 / gm)
            v = curve(p.curves, 0, v)
            v = curve(p.curves, 5 * (1 + k), v)
            g[k] = v
        }
        val c = chroma(g, p, lw)
        return DoubleArray(3) { srgbDecodeExt(c[it]) }
    }
}
