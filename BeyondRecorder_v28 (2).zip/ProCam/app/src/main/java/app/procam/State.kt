package app.procam

/** Состояние камеры (Camera2). Менять только через [AppState.camera]. */
enum class CameraState { Closed, Opening, Configuring, Preview, Error }

/** Состояние записи. Менять только через [AppState.recording]. */
enum class RecordingState { Idle, Preparing, Recording, Paused, Finalizing, Completed, Error }

/** Состояние обработки кадра: куда идёт кадр от камеры. */
enum class ProcessingState { Idle, Direct, GlPipeline, SwitchingLens }

/**
 * Конечный автомат с явной таблицей допустимых переходов. Недопустимый переход не выполняется,
 * а записывается в [violations] (ошибка логики, а не пользователя) — состояние не становится противоречивым.
 * Потокобезопасен; слушатели вызываются вне блокировки.
 */
class StateMachine<S : Enum<S>>(
    initial: S,
    private val allowed: Map<S, Set<S>>,
    private val name: String
) {
    data class Change<S>(val from: S, val to: S, val reason: String, val atMs: Long)

    @Volatile var state: S = initial; private set
    private val lock = Any()
    private val history = ArrayDeque<Change<S>>()
    private val bad = ArrayList<String>()
    private val listeners = ArrayList<(Change<S>) -> Unit>()

    fun listen(l: (Change<S>) -> Unit) { synchronized(lock) { listeners.add(l) } }

    fun canGo(to: S): Boolean = to == state || allowed[state]?.contains(to) == true

    /** Переход в [to]. Возвращает true, если состояние теперь [to] (в т.ч. если оно уже было таким). */
    fun go(to: S, reason: String = "", nowMs: Long = System.currentTimeMillis()): Boolean {
        val ch: Change<S>
        val ls: List<(Change<S>) -> Unit>
        synchronized(lock) {
            val from = state
            if (from == to) return true
            if (allowed[from]?.contains(to) != true) {
                bad.add("$name: $from → $to запрещён ($reason)")
                if (bad.size > 50) bad.removeAt(0)
                return false
            }
            state = to
            ch = Change(from, to, reason, nowMs)
            history.addLast(ch)
            if (history.size > 100) history.removeFirst()
            ls = listeners.toList()
        }
        ls.forEach { it(ch) }
        return true
    }

    /** Принудительный сброс (аварийное закрытие камеры, смерть сессии): допустим из любого состояния, фиксируется в истории. */
    fun force(to: S, reason: String, nowMs: Long = System.currentTimeMillis()) {
        val ch: Change<S>
        val ls: List<(Change<S>) -> Unit>
        synchronized(lock) {
            val from = state
            if (from == to) return
            state = to
            ch = Change(from, to, "force: $reason", nowMs)
            history.addLast(ch)
            if (history.size > 100) history.removeFirst()
            ls = listeners.toList()
        }
        ls.forEach { it(ch) }
    }

    fun recent(n: Int = 10): List<Change<S>> = synchronized(lock) { history.toList().takeLast(n) }
    fun violations(): List<String> = synchronized(lock) { bad.toList() }
}

/** Все состояния приложения в одном месте. */
class AppState {
    companion object {
        val cameraTable: Map<CameraState, Set<CameraState>> = mapOf(
            CameraState.Closed to setOf(CameraState.Opening, CameraState.Error),
            CameraState.Opening to setOf(CameraState.Configuring, CameraState.Closed, CameraState.Error),
            CameraState.Configuring to setOf(CameraState.Preview, CameraState.Configuring, CameraState.Closed, CameraState.Error),
            CameraState.Preview to setOf(CameraState.Configuring, CameraState.Closed, CameraState.Error),
            CameraState.Error to setOf(CameraState.Closed, CameraState.Opening)
        )
        val recordingTable: Map<RecordingState, Set<RecordingState>> = mapOf(
            RecordingState.Idle to setOf(RecordingState.Preparing),
            RecordingState.Preparing to setOf(RecordingState.Recording, RecordingState.Error, RecordingState.Idle),
            RecordingState.Recording to setOf(RecordingState.Paused, RecordingState.Finalizing, RecordingState.Error),
            RecordingState.Paused to setOf(RecordingState.Recording, RecordingState.Finalizing, RecordingState.Error),
            RecordingState.Finalizing to setOf(RecordingState.Completed, RecordingState.Error),
            RecordingState.Completed to setOf(RecordingState.Idle, RecordingState.Preparing),
            RecordingState.Error to setOf(RecordingState.Idle, RecordingState.Preparing)
        )
        val processingTable: Map<ProcessingState, Set<ProcessingState>> = ProcessingState.values().associateWith { ProcessingState.values().toSet() - it }
    }

    val camera = StateMachine(CameraState.Closed, cameraTable, "Camera")
    val recording = StateMachine(RecordingState.Idle, recordingTable, "Recording")
    val processing = StateMachine(ProcessingState.Idle, processingTable, "Processing")

    /** Запись активна, пока камера не в Preview, быть не может: проверка инварианта для диагностики. */
    fun invariantViolations(): List<String> {
        val out = ArrayList<String>()
        val rec = recording.state
        val active = rec == RecordingState.Recording || rec == RecordingState.Paused || rec == RecordingState.Preparing
        if (active && camera.state == CameraState.Closed) out.add("Идёт запись при закрытой камере")
        return out + camera.violations() + recording.violations() + processing.violations()
    }
}
