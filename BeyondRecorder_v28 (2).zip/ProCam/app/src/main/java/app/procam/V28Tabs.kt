package app.procam

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Вкладки v0.28: «Уведомления», «Оформление» (темы и профили), «Экран камеры» (раскладка), «Поиск настроек». Логика — в чистых классах, здесь только экран. */
internal class V28Tabs(private val a: MainActivity) {
    private val MATCH get() = a.MATCH
    private val WRAP get() = a.WRAP
    private fun dp(v: Int) = a.dp(v)
    private val store get() = PrefsStore(a.prefs)
    private val timeFmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

    // ------------------------------------------------------------ общие помощники

    private fun btn(text: String, size: Float = 12.5f, on: Boolean = false, click: () -> Unit): android.widget.Button {
        val b = a.flatButton(text, size); a.segStyle(b, on); b.setOnClickListener { click() }; return b
    }

    private fun row(): LinearLayout = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun txt(s: String, size: Float = 12f, color: Int = Ui.dim): TextView = TextView(a).apply { text = s; textSize = size; setTextColor(color) }

    private fun field(hint: String, value: String, numeric: Boolean): EditText = EditText(a).apply {
        setText(value); this.hint = hint; setSingleLine(true); textSize = 13f
        setTextColor(Ui.text); setHintTextColor(Ui.dim); background = Ui.bg(Ui.Kind.BUTTON)
        setPadding(dp(10), 0, dp(10), 0)
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
    }

    private fun addTo(box: LinearLayout, v: android.view.View, top: Int = 6, h: Int = -1) =
        box.addView(v, LinearLayout.LayoutParams(MATCH, if (h < 0) WRAP else dp(h)).apply { topMargin = dp(top) })

    private fun askName(title: String, initial: String = "", ok: (String) -> Unit) {
        val et = EditText(a); et.setText(initial); et.setSingleLine(true)
        android.app.AlertDialog.Builder(a).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString()) }.setNegativeButton("Отмена", null).show()
    }

    private fun clip(text: String) {
        (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Beyond Recorder", text))
        a.toast("Скопировано в буфер обмена")
    }

    private fun clipText(): String = try {
        (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(a)?.toString() ?: ""
    } catch (e: Exception) { "" }

    private fun reopen(tab: Int) = a.showTab(tab, true)

    // ------------------------------------------------------------ Уведомления

    private var nGroup = 0
    private var cGroup: AlertGroup? = null
    private var cSev: Severity? = null
    private var cUnread = false
    private var cQuery = ""

    fun buildNotifications() {
        val al = a.alerts
        a.card("Как это работает",
            "Каждое предупреждение настраивается отдельно. Отключение показа НЕ отключает мониторинг: температура, память, нагрузка и место измеряются всегда, значения видны в «Диагностике», " +
                "защита файла (остановка записи при 200 МБ) работает всегда. Приложение никогда не меняет параметры записи само и не обходит защиту Android от перегрева. " +
                "Звук и вибрация не воспроизводятся во время записи со звуком — иначе они попали бы в файл.")

        // --- центр уведомлений
        val box = a.card("Центр уведомлений", "Непрочитанных: ${al.unread()}. Одинаковые события склеиваются в одну запись со счётчиком.")
        val groups = listOf<AlertGroup?>(null) + AlertGroup.values().toList()
        val rg = row(); groups.forEachIndexed { i, g -> rg.addView(btn(if (g == null) "Все" else g.label.substringBefore(' ').take(11), 11.5f, cGroup == g) { cGroup = g; reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), 0, dp(2), 0) }) }
        addTo(box, rg)
        val sevs = listOf<Severity?>(null) + Severity.values().toList()
        val rs = row(); sevs.forEach { s -> rs.addView(btn(s?.label ?: "Любая", 11.5f, cSev == s) { cSev = s; reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), 0, dp(2), 0) }) }
        addTo(box, rs)
        val rq = row()
        val q = field("Поиск по истории", cQuery, false)
        rq.addView(q, LinearLayout.LayoutParams(0, dp(40), 1f))
        rq.addView(btn("Найти") { cQuery = q.text.toString(); reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(WRAP, dp(40)).apply { leftMargin = dp(4) })
        rq.addView(btn(if (cUnread) "Новые ✓" else "Новые", 12f, cUnread) { cUnread = !cUnread; reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(WRAP, dp(40)).apply { leftMargin = dp(4) })
        addTo(box, rq)
        val list = al.list(cGroup, cSev, cUnread, cQuery)
        if (list.isEmpty()) addTo(box, txt("Записей нет"), 8)
        for (e in list.take(40)) {
            val r = LinearLayout(a); r.orientation = LinearLayout.VERTICAL
            r.setPadding(dp(8), dp(6), dp(8), dp(6)); r.background = Ui.bg(Ui.Kind.CHIP)
            val head = (if (e.read) "" else "● ") + "${e.severity.label} · ${e.type.title}" + (if (e.count > 1) " ×${e.count}" else "") + " · " + timeFmt.format(Date(e.lastMs))
            r.addView(txt(head, 11.5f, Ui.text)); r.addView(txt(e.text, 11.5f))
            r.setOnClickListener { al.markRead(e.id); reopen(Tabs.NOTIF) }
            addTo(box, r, 6)
        }
        val rb = row()
        rb.addView(btn("Прочитать всё") { al.markAllRead(); reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(4) })
        rb.addView(btn("Очистить историю") { al.clear(); reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        addTo(box, rb, 8)

        a.seg("Срок хранения истории", "Старые записи удаляются сами.", listOf("7 дн", "30 дн", "90 дн", "1 год", "Бессрочно"),
            { listOf(7, 30, 90, 365, 0).indexOf(al.retentionDays()).coerceAtLeast(0) }) { i -> al.setRetentionDays(listOf(7, 30, 90, 365, 0)[i]); al.prune() }
        a.seg("Период мониторинга", "Как часто проверяются температура, память, нагрузка и пороги. Мониторинг лёгкий, но чаще — не значит лучше.",
            listOf("0.5 с", "1 с", "2 с", "5 с", "10 с"),
            { listOf(500, 1000, 2000, 5000, 10000).indexOf(a.prefs.getInt("perf28_mon", 2000)).let { if (it < 0) 2 else it } }) { i ->
            a.prefs.edit().putInt("perf28_mon", listOf(500, 1000, 2000, 5000, 10000)[i]).apply() }

        // --- настройки по типам
        a.seg("Настройка уведомлений", "Выберите категорию, затем настройте каждое уведомление отдельно.", AlertGroup.values().map { it.label.substringBefore(' ') },
            { nGroup }) { i -> nGroup = i; reopen(Tabs.NOTIF) }
        for (t in AlertType.values().filter { it.group == AlertGroup.values()[nGroup] }) typeCard(t)
    }

    private fun typeCard(t: AlertType) {
        val al = a.alerts; val c = al.config(t)
        val box = a.card("${t.title}  ·  ${t.severity.label}", t.about + if (t.dataLoss) "\nМожет привести к потере записи: для отключения показа потребуется подтверждение." else "")
        AlertMode.values().toList().chunked(3).forEach { chunk ->
            val r = row()
            for (m in chunk) r.addView(btn(m.label, 11.5f, c.mode == m) { setMode(t, m) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(2), dp(2), 0) })
            addTo(box, r, 2)
        }
        val rr = row()
        val thr = t.threshold
        var thF: EditText? = null
        if (thr != null) {
            rr.addView(txt("Порог, ${thr.unit}:"), LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(4) })
            thF = field("${thr.min}…${thr.max}", (c.threshold ?: thr.default).toString(), true)
            rr.addView(thF, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        rr.addView(txt("  Повтор, с:"), LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(4) })
        val repF = field("0…86400", c.repeatSec.toString(), true)
        rr.addView(repF, LinearLayout.LayoutParams(0, dp(40), 1f))
        rr.addView(btn("OK") {
            var err: String? = null
            thF?.let { f -> val v = f.text.toString().replace(',', '.').toFloatOrNull(); val r = if (v == null) AlertCenter.SetResult.Invalid("не число") else al.setThreshold(t, v); if (r is AlertCenter.SetResult.Invalid) err = r.why }
            val sec = repF.text.toString().toIntOrNull()
            val r2 = if (sec == null) AlertCenter.SetResult.Invalid("не число") else al.setRepeat(t, sec)
            if (r2 is AlertCenter.SetResult.Invalid) err = r2.why
            if (err != null) a.toast("Не применено: $err") else { a.toast("Сохранено"); reopen(Tabs.NOTIF) }
        }, LinearLayout.LayoutParams(WRAP, dp(40)).apply { leftMargin = dp(4) })
        addTo(box, rr, 6)
        val rf = row()
        fun flag(label: String, field: String, on: Boolean) =
            rf.addView(btn(label, 11.5f, on) { al.setFlag(t, field, !on); reopen(Tabs.NOTIF) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        flag("Поверх превью", "over", c.overPreview); flag("Звук", "sound", c.sound); flag("Вибрация", "vib", c.vibration)
        addTo(box, rf, 6)
        addTo(box, btn("Сбросить это уведомление", 11.5f) { al.resetType(t); reopen(Tabs.NOTIF) }, 6, 36)
    }

    private fun setMode(t: AlertType, m: AlertMode) {
        when (val r = a.alerts.setMode(t, m)) {
            is AlertCenter.SetResult.NeedsConfirm -> android.app.AlertDialog.Builder(a).setTitle("Отключить «${t.title}»?").setMessage(r.why)
                .setPositiveButton("Отключить") { _, _ -> a.alerts.setMode(t, m, confirmed = true); reopen(Tabs.NOTIF) }
                .setNegativeButton("Оставить", null).show()
            is AlertCenter.SetResult.Invalid -> a.toast(r.why)
            else -> reopen(Tabs.NOTIF)
        }
    }

    // ------------------------------------------------------------ Оформление и профили

    fun buildTheme() {
        val p = a.prefs
        fun put(k: String, v: Int) = a.idle { p.edit().putInt(k, v).apply(); a.recreateApplyingPrefs() }
        a.seg("Стиль интерфейса", "Material 3 — стандартный. Применяется перезапуском экрана; запись и параметры съёмки не затрагиваются.", listOf("Material", "Liquid Glass", "Material 3"),
            { p.getInt("ui_style", 2) }) { put("ui_style", it) }
        val note = { if (Ui.m3) "" else "Темы работают только в стиле Material 3" }
        a.seg("Тема", ThemeVariant.values().joinToString("\n") { "${it.label} — ${it.about}" }, ThemeVariant.values().map { it.label },
            { p.getInt("th28_variant", 0).coerceIn(0, 5) }, note) { put("th28_variant", it) }
        a.seg("Светлая / тёмная", "Для тем Material и Custom. Остальные темы тёмные: экран камеры должен оставаться тёмным.", listOf("Тёмная", "Светлая", "Системная"),
            { p.getInt("th28_mode", 0).coerceIn(0, 2) }) { put("th28_mode", it) }
        a.toggle("Динамические цвета (Material You)", "Цвета берутся из обоев и системы. Android 12 и новее; на более старых ничего не изменится. Контраст таких палитр обеспечивает система.",
            { p.getBoolean("th28_dynamic", false) }, { if (android.os.Build.VERSION.SDK_INT < 31) "Недоступно на этом Android" else "" }) {
            a.idle { p.edit().putBoolean("th28_dynamic", it).apply(); a.recreateApplyingPrefs() } }
        val box = a.card("Свой акцентный цвет", "Выбор включает тему Custom; светлота подбирается так, чтобы текст читался (контраст не ниже 4.5:1).")
        val seeds = listOf(0xFF4F8CFF, 0xFF2EC4B6, 0xFF7BC96F, 0xFFF4B942, 0xFFFF7A59, 0xFFE05A9C, 0xFFA77BFF, 0xFF9AA5B1)
        val rs = row()
        for (c in seeds) {
            val b = android.widget.Button(a); b.background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(c.toInt()) }
            b.setOnClickListener { a.idle { p.edit().putInt("th28_seed", c.toInt()).putInt("th28_variant", ThemeVariant.CUSTOM.ordinal).apply(); a.recreateApplyingPrefs() } }
            rs.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        addTo(box, rs, 8)
        a.toggle("Анимации интерфейса", "Выкл — всё переключается мгновенно. Системное «Удалить анимацию» учитывается всегда. Анимации интерфейса не затрагивают превью и запись.",
            { p.getBoolean("anim28", true) }) { p.edit().putBoolean("anim28", it).apply() }
        buildProfiles()
    }

    private fun buildProfiles() {
        val box = a.card("Профили интерфейса",
            "UI-профиль меняет только внешний вид: стиль, тему, раскладку левой панели. Параметры записи, цвет и обработка не меняются. " +
                "Профили съёмки — это пресеты в «Настройки»; режимы оптимизации (Performance / Balanced / Quality) — в «Диагностике»: они только предлагают изменения и ничего не ухудшают сами.")
        for (pr in UiProfiles.BUILT_IN) {
            val r = row(); val col = LinearLayout(a); col.orientation = LinearLayout.VERTICAL
            col.addView(txt(pr.name, 14f, Ui.text)); col.addView(txt(pr.about, 11f))
            r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(btn("Применить") { a.idle { UiProfiles.apply(store, pr); a.recreateApplyingPrefs() } }, LinearLayout.LayoutParams(WRAP, dp(40)))
            addTo(box, r, 8)
        }
        for (n in UiProfiles.customNames(store)) {
            val r = row(); r.addView(txt(n, 14f, Ui.text), LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(btn("Применить", 11.5f) { a.idle { if (UiProfiles.applyCustom(store, n)) a.recreateApplyingPrefs() else a.toast("Профиль повреждён") } }, LinearLayout.LayoutParams(WRAP, dp(38)).apply { leftMargin = dp(2) })
            r.addView(btn("Копия", 11.5f) { askName("Имя копии", "$n 2") { if (UiProfiles.duplicate(store, n, it)) reopen(Tabs.THEME) } }, LinearLayout.LayoutParams(WRAP, dp(38)).apply { leftMargin = dp(2) })
            r.addView(btn("Имя", 11.5f) { askName("Новое имя", n) { if (UiProfiles.rename(store, n, it)) reopen(Tabs.THEME) } }, LinearLayout.LayoutParams(WRAP, dp(38)).apply { leftMargin = dp(2) })
            r.addView(btn("Экспорт", 11.5f) { UiProfiles.export(store, n)?.let { clip(it) } }, LinearLayout.LayoutParams(WRAP, dp(38)).apply { leftMargin = dp(2) })
            r.addView(btn("✕", 11.5f) { UiProfiles.delete(store, n); reopen(Tabs.THEME) }, LinearLayout.LayoutParams(WRAP, dp(38)).apply { leftMargin = dp(2) })
            addTo(box, r, 8)
        }
        addTo(box, btn("Сохранить текущий вид как профиль…", 13f) { askName("Имя профиля") { if (UiProfiles.saveCurrent(store, it) == null) a.toast("Введите имя") else reopen(Tabs.THEME) } }, 10, 44)
        addTo(box, btn("Импорт профиля из буфера обмена", 13f) {
            val (n, err) = UiProfiles.importProfile(store, clipText())
            if (err != null) a.toast("Не импортировано: $err") else { a.toast("Профиль «$n» добавлен"); reopen(Tabs.THEME) }
        }, 6, 44)
    }

    // ------------------------------------------------------------ Экран камеры (редактор раскладки)

    private var draft: HomeLayout? = null

    fun buildHome() {
        val d = draft ?: a.layouts.active().also { draft = it }
        a.card("Редактор левой панели",
            "Выберите, какие кнопки быстрого доступа стоят слева, в каком порядке и насколько прозрачна панель. Кнопки записи, паузы, зума, «РУЧН.» и «МЕНЮ» закреплены справа и в раскладку не входят — их нельзя убрать или перекрыть. " +
                "Изменения применяются кнопкой внизу; до этого экран камеры не меняется. Перетаскивание и произвольные размеры в этой версии не реализованы.")
        val pv = a.card("Предпросмотр панели (сверху вниз)", if (d.visible().isEmpty()) "Панель пуста" else d.visible().joinToString("  ›  ") { it.title } + "\nПрозрачность: ${d.railOpacity}%" + if (d.locked) "  ·  🔒 заблокирована" else "")
        pv.alpha = 1f
        val names = HomeLayouts.PRESETS.keys.toList()
        a.seg("Готовые раскладки", "Default повторяет панель v0.27.", names, { names.indexOfFirst { HomeLayouts.PRESETS[it]?.entries == d.entries }.coerceAtLeast(-1) }) { i ->
            draft = HomeLayouts.PRESETS[names[i]]!!.copy(locked = false); reopen(Tabs.HOME) }
        val box = a.card("Кнопки", if (d.locked) "Раскладка заблокирована: снимите блокировку, чтобы менять." else "▲ ▼ — порядок, «Вкл/Выкл» — показывать ли кнопку.")
        for (e in d.entries) {
            val r = row(); val col = LinearLayout(a); col.orientation = LinearLayout.VERTICAL
            col.addView(txt(e.item.title, 13.5f, if (e.enabled) Ui.text else Ui.dim)); col.addView(txt(e.item.about, 10.5f))
            r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(btn(if (e.enabled) "Вкл" else "Выкл", 12f, e.enabled) { draft = HomeLayouts.setEnabled(d, e.item, !e.enabled); reopen(Tabs.HOME) }, LinearLayout.LayoutParams(dp(56), dp(40)))
            r.addView(btn("▲", 12f) { draft = HomeLayouts.move(d, e.item, -1); reopen(Tabs.HOME) }, LinearLayout.LayoutParams(dp(44), dp(40)).apply { leftMargin = dp(4) })
            r.addView(btn("▼", 12f) { draft = HomeLayouts.move(d, e.item, 1); reopen(Tabs.HOME) }, LinearLayout.LayoutParams(dp(44), dp(40)).apply { leftMargin = dp(4) })
            addTo(box, r, 6)
        }
        val ops = listOf(30, 50, 70, 85, 100)
        a.seg("Прозрачность панели", "Не ниже 30 %: иначе кнопки становятся неразличимы.", ops.map { "$it %" }, { ops.indexOf(d.railOpacity).let { if (it < 0) 4 else it } }) { i ->
            draft = HomeLayouts.setOpacity(d, ops[i]); reopen(Tabs.HOME) }
        a.toggle("Заблокировать раскладку", "Защита от случайных изменений состава, порядка и прозрачности.", { d.locked }) { draft = HomeLayouts.setLocked(d, it); reopen(Tabs.HOME) }

        val cb = a.card("Свои раскладки", "Сохраняются отдельно и переживают обновление.")
        addTo(cb, btn("Сохранить как раскладку…", 13f) { askName("Имя раскладки", d.name) { n -> if (a.layouts.saveCustom(d.copy(name = n)) == null) a.toast("Введите имя") else reopen(Tabs.HOME) } }, 6, 44)
        for (n in a.layouts.customNames()) {
            val r = row(); r.addView(txt(n, 14f, Ui.text), LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(btn("Загрузить", 11.5f) { a.layouts.loadCustom(n)?.let { draft = it; reopen(Tabs.HOME) } ?: a.toast("Раскладка повреждена") }, LinearLayout.LayoutParams(WRAP, dp(38)))
            r.addView(btn("✕", 11.5f) { a.layouts.deleteCustom(n); reopen(Tabs.HOME) }, LinearLayout.LayoutParams(WRAP, dp(38)).apply { leftMargin = dp(4) })
            addTo(cb, r, 6)
        }
        val ab = a.card("Применить", "Экран камеры будет создан заново (запись не должна идти).")
        val r = row()
        r.addView(btn("Применить", 13.5f, true) { a.idle { a.layouts.setActive(draft ?: d); draft = null; a.recreateApplyingPrefs() } }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(4) })
        r.addView(btn("Отменить изменения", 13f) { draft = null; reopen(Tabs.HOME) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        addTo(ab, r, 8)
    }

    // ------------------------------------------------------------ Поиск настроек, избранное, история, экспорт

    private var sQuery = ""

    fun buildSearch() {
        val box = a.card("Поиск", "Ищет по названию, описанию, ключу и категории (13 категорий). Каждый результат ведёт в раздел, где живёт настоящий переключатель.")
        val r = row(); val q = field("Например: шум, fps, зебра", sQuery, false)
        r.addView(q, LinearLayout.LayoutParams(0, dp(44), 1f))
        r.addView(btn("Найти", 13f) { sQuery = q.text.toString(); reopen(Tabs.SEARCH) }, LinearLayout.LayoutParams(WRAP, dp(44)).apply { leftMargin = dp(4) })
        addTo(box, r, 8)
        val res: List<SettingInfo> = if (sQuery.isBlank()) a.favorites.get().mapNotNull { SettingsCatalog.info(it) } else SettingsCatalog.search(sQuery).take(30)
        val title = if (sQuery.isBlank()) "Избранное" else "Найдено: ${res.size}"
        val rb = a.card(title, if (res.isEmpty()) (if (sQuery.isBlank()) "Пока пусто: найдите настройку и нажмите ☆" else "Ничего не найдено") else "")
        for (s in res) {
            val cell = LinearLayout(a); cell.orientation = LinearLayout.VERTICAL; cell.setPadding(dp(8), dp(6), dp(8), dp(6)); cell.background = Ui.bg(Ui.Kind.CHIP)
            cell.addView(txt("${s.title}  ·  ${s.category.label}", 13f, Ui.text))
            cell.addView(txt("Значение: ${SettingsCatalog.valueText(s.key, store)}  ·  Диапазон: ${SettingsCatalog.rangeText(s.key)}", 11f))
            cell.addView(txt(s.about + if (s.effect.isNotEmpty()) "\nЭффект: ${s.effect}" else "", 11f))
            val br = row()
            br.addView(btn(if (a.favorites.isFav(s.key)) "★" else "☆", 13f) { a.favorites.toggle(s.key); reopen(Tabs.SEARCH) }, LinearLayout.LayoutParams(dp(48), dp(38)))
            br.addView(btn("Открыть раздел", 11.5f) { a.showTab(s.tab) }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(4) })
            cell.addView(br, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
            addTo(rb, cell, 6)
        }
        val hb = a.card("История изменений", "Что менялось и с какого значения на какое (последние 30).")
        val rows = a.history.newestFirst().take(30)
        if (rows.isEmpty()) addTo(hb, txt("Изменений пока нет"), 6)
        for (h in rows) addTo(hb, txt("${timeFmt.format(Date(h.atMs))}  ${SettingsCatalog.info(h.key)?.title ?: h.key}: ${h.old} → ${h.new}", 11f), 4)
        addTo(hb, btn("Очистить историю", 12f) { a.history.clear(); reopen(Tabs.SEARCH) }, 8, 38)

        val eb = a.card("Перенос и резервная копия",
            "Экспорт — текст с контрольной суммой: при вставке проверяются формат, сумма и допустимые значения; файл применяется целиком или не применяется вовсе. Калибровка гироскопа и выбранная камера не переносятся.")
        addTo(eb, btn("Скопировать все настройки", 13f) { clip(SettingsPorter.exportAll(store)) }, 6, 44)
        addTo(eb, btn("Вставить из буфера и применить", 13f) {
            a.idle {
                val rep = SettingsPorter.importAll(store, clipText())
                if (rep.fatal != null) a.toast("Не применено: ${rep.fatal}")
                else { a.toast("Применено: ${rep.applied}" + if (rep.rejected.isNotEmpty()) ", отклонено: ${rep.rejected.size}" else ""); a.recreateApplyingPrefs() }
            }
        }, 6, 44)
        for (n in a.settings.presetNames()) addTo(eb, btn("Экспорт пресета съёмки «$n»", 12f) { SettingsPorter.exportPreset(store, n)?.let { clip(it) } }, 6, 40)
        addTo(eb, btn("Импорт пресета съёмки из буфера", 12.5f) {
            val (n, err) = SettingsPorter.importPreset(store, clipText())
            if (err != null) a.toast("Не импортировано: $err") else a.toast("Пресет «$n» добавлен")
        }, 6, 40)
        if (SettingsPorter.hasBackup(store)) addTo(eb, btn("Восстановить из резервной копии (до обновления схемы)", 12f) {
            a.idle {
                val rep = SettingsPorter.restoreBackup(store)
                if (rep.fatal != null) a.toast("Не восстановлено: ${rep.fatal}") else { a.toast("Восстановлено: ${rep.applied}"); a.recreateApplyingPrefs() }
            }
        }, 6, 40)
    }
}
