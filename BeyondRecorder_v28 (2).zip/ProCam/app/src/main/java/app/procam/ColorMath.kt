package app.procam

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Эталонная (CPU, Double) реализация математики цвета v0.26. Шейдер повторяет эти формулы;
 * совпадение проверяется численными тестами по контрольным значениям, а не «на глаз».
 *
 * Цветовой охват (primaries), передаточная функция (transfer) и белая точка — три независимых параметра.
 */

/** Матрицы 3×3 в виде DoubleArray(9), по строкам. */
object M3 {
    val I = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
    fun mul(a: DoubleArray, b: DoubleArray) = DoubleArray(9) { i ->
        val r = i / 3; val c = i % 3
        a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c]
    }
    fun mulV(a: DoubleArray, v: DoubleArray) = DoubleArray(3) { r -> a[r * 3] * v[0] + a[r * 3 + 1] * v[1] + a[r * 3 + 2] * v[2] }
    fun inv(m: DoubleArray): DoubleArray {
        val a = m[0]; val b = m[1]; val c = m[2]; val d = m[3]; val e = m[4]; val f = m[5]; val g = m[6]; val h = m[7]; val i = m[8]
        val det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
        require(abs(det) > 1e-12) { "вырожденная матрица" }
        return doubleArrayOf(
            (e * i - f * h) / det, (c * h - b * i) / det, (b * f - c * e) / det,
            (f * g - d * i) / det, (a * i - c * g) / det, (c * d - a * f) / det,
            (d * h - e * g) / det, (b * g - a * h) / det, (a * e - b * d) / det
        )
    }
    fun isIdentity(m: DoubleArray, eps: Double = 1e-9) = (0 until 9).all { abs(m[it] - I[it]) < eps }
}

/** Цветовой охват: координаты основных цветов и белой точки в xy. */
data class Primaries(
    val name: String,
    val rx: Double, val ry: Double, val gx: Double, val gy: Double, val bx: Double, val by: Double,
    val wx: Double, val wy: Double
) {
    /** Линейный RGB этого охвата → XYZ. */
    fun toXyz(): DoubleArray {
        fun xyz(x: Double, y: Double) = doubleArrayOf(x / y, 1.0, (1 - x - y) / y)
        val r = xyz(rx, ry); val g = xyz(gx, gy); val b = xyz(bx, by); val w = xyz(wx, wy)
        val p = doubleArrayOf(r[0], g[0], b[0], r[1], g[1], b[1], r[2], g[2], b[2])
        val s = M3.mulV(M3.inv(p), w)
        return doubleArrayOf(p[0] * s[0], p[1] * s[1], p[2] * s[2], p[3] * s[0], p[4] * s[1], p[5] * s[2], p[6] * s[0], p[7] * s[1], p[8] * s[2])
    }
    fun white(): DoubleArray = doubleArrayOf(wx / wy, 1.0, (1 - wx - wy) / wy)
    /** Яркостные коэффициенты (строка Y матрицы RGB→XYZ). */
    fun lumaWeights(): DoubleArray { val m = toXyz(); return doubleArrayOf(m[3], m[4], m[5]) }
}

object Spaces {
    private const val D65X = 0.3127
    private const val D65Y = 0.3290
    val REC709 = Primaries("Rec.709", 0.640, 0.330, 0.300, 0.600, 0.150, 0.060, D65X, D65Y)
    val REC2020 = Primaries("Rec.2020", 0.708, 0.292, 0.170, 0.797, 0.131, 0.046, D65X, D65Y)
    val DISPLAY_P3 = Primaries("Display P3", 0.680, 0.320, 0.265, 0.690, 0.150, 0.060, D65X, D65Y)
    /** ACES AP1 (ACEScg), белая точка D60 — адаптируется к D65 по Брэдфорду. */
    val ACES_AP1 = Primaries("ACEScg (AP1)", 0.713, 0.293, 0.165, 0.830, 0.128, 0.044, 0.32168, 0.33767)
    val builtIn = listOf(REC709, REC2020, DISPLAY_P3, ACES_AP1)

    private val BRADFORD = doubleArrayOf(0.8951, 0.2664, -0.1614, -0.7502, 1.7135, 0.0367, 0.0389, -0.0685, 1.0296)

    /** Матрица хроматической адаптации Брэдфорда XYZ(src white) → XYZ(dst white). */
    fun adapt(srcWhite: DoubleArray, dstWhite: DoubleArray): DoubleArray {
        val s = M3.mulV(BRADFORD, srcWhite); val d = M3.mulV(BRADFORD, dstWhite)
        val diag = doubleArrayOf(d[0] / s[0], 0.0, 0.0, 0.0, d[1] / s[1], 0.0, 0.0, 0.0, d[2] / s[2])
        return M3.mul(M3.inv(BRADFORD), M3.mul(diag, BRADFORD))
    }

    /** Линейный RGB охвата [from] → линейный RGB охвата [to] (с адаптацией белой точки, если она различается). */
    fun convert(from: Primaries, to: Primaries): DoubleArray {
        var m = from.toXyz()
        if (abs(from.wx - to.wx) > 1e-6 || abs(from.wy - to.wy) > 1e-6) m = M3.mul(adapt(from.white(), to.white()), m)
        return M3.mul(M3.inv(to.toXyz()), m)
    }
}

/** Передаточные функции. encode: линейный (сцена/дисплей, 0..1 = диапазон кода) → код; decode — обратная. */
enum class Tf(val id: Int, val label: String) {
    LINEAR(0, "Linear"), SRGB(1, "sRGB"), BT709(2, "Rec.709 OETF"), GAMMA22(3, "Gamma 2.2"), GAMMA24(4, "Gamma 2.4"),
    HLG(5, "HLG"), PQ(6, "PQ (ST 2084)"), SLOG3(7, "S-Log3"), VLOG(8, "V-Log"), LOGC(9, "LogC3"), FLAT(10, "Flat (Beyond)");

    fun encode(x: Double): Double = TfMath.encode(this, x)
    fun decode(y: Double): Double = TfMath.decode(this, y)

    companion object {
        fun byId(id: Int) = values().firstOrNull { it.id == id } ?: SRGB
    }
}

object TfMath {
    const val HLG_A = 0.17883277
    const val HLG_B = 0.28466892
    const val HLG_C = 0.55991073
    /** Сцена-линейный уровень SDR-белого (~203 нит) в HLG — то же значение, что в шейдере v0.25. */
    const val HLG_WHITE = 0.265

    private const val PQ_M1 = 2610.0 / 16384
    private const val PQ_M2 = 2523.0 / 4096 * 128
    private const val PQ_C1 = 3424.0 / 4096
    private const val PQ_C2 = 2413.0 / 4096 * 32
    private const val PQ_C3 = 2392.0 / 4096 * 32

    fun encode(t: Tf, x0: Double): Double {
        val x = max(x0, 0.0)
        return when (t) {
            Tf.LINEAR -> x0
            Tf.SRGB -> if (x <= 0.0031308) 12.92 * x else 1.055 * x.pow(1 / 2.4) - 0.055
            Tf.BT709 -> if (x < 0.018) 4.5 * x else 1.099 * x.pow(0.45) - 0.099
            Tf.GAMMA22 -> x.pow(1 / 2.2)
            Tf.GAMMA24 -> x.pow(1 / 2.4)
            Tf.HLG -> { val e = min(x, 1.0); if (e <= 1.0 / 12) sqrt(3 * e) else HLG_A * ln(max(12 * e - HLG_B, 1e-6)) + HLG_C }
            Tf.PQ -> { val p = min(x, 1.0).pow(PQ_M1); ((PQ_C1 + PQ_C2 * p) / (1 + PQ_C3 * p)).pow(PQ_M2) }
            Tf.SLOG3 -> if (x >= 0.01125) (420.0 + log10((x + 0.01) / 0.19) * 261.5) / 1023.0 else (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0
            Tf.VLOG -> if (x < 0.01) 5.6 * x + 0.125 else 0.241514 * log10(x + 0.00873) + 0.598206
            Tf.LOGC -> if (x > 0.010591) 0.247190 * log10(5.555556 * x + 0.052272) + 0.385537 else 5.367655 * x + 0.092809
            Tf.FLAT -> log2(1.0 + 31.0 * x) / 5.0
        }
    }

    fun decode(t: Tf, y0: Double): Double {
        val y = min(max(y0, 0.0), 1.0)
        return when (t) {
            Tf.LINEAR -> y0
            Tf.SRGB -> if (y <= 0.04045) y / 12.92 else ((y + 0.055) / 1.055).pow(2.4)
            Tf.BT709 -> if (y < 0.081) y / 4.5 else ((y + 0.099) / 1.099).pow(1 / 0.45)
            Tf.GAMMA22 -> y.pow(2.2)
            Tf.GAMMA24 -> y.pow(2.4)
            Tf.HLG -> if (y <= 0.5) y * y / 3 else (exp((y - HLG_C) / HLG_A) + HLG_B) / 12
            Tf.PQ -> { val p = y.pow(1 / PQ_M2); (max(p - PQ_C1, 0.0) / (PQ_C2 - PQ_C3 * p)).pow(1 / PQ_M1) }
            Tf.SLOG3 -> { val v = y * 1023.0; if (v >= 171.2102946929) 10.0.pow((v - 420.0) / 261.5) * 0.19 - 0.01 else (v - 95.0) * 0.01125 / (171.2102946929 - 95.0) }
            Tf.VLOG -> if (y < 0.181) (y - 0.125) / 5.6 else 10.0.pow((y - 0.598206) / 0.241514) - 0.00873
            Tf.LOGC -> if (y > 0.149658) (10.0.pow((y - 0.385537) / 0.247190) - 0.052272) / 5.555556 else (y - 0.092809) / 5.367655
            Tf.FLAT -> (2.0.pow(5.0 * y) - 1.0) / 31.0
        }
    }
}

/**
 * Пользовательская LOG-кривая: y = c·log2(a·x + b) + d (для x ≥ 0), значения ограничены 0..1.
 * [a] — усиление, [b] — смещение (задаёт чёрную точку и мягкость тени), [c] — наклон (динамический диапазон), [d] — уровень.
 * Это параметрическая кривая пользователя: она не является паспортной кривой производителя.
 */
data class CustomLog(val name: String, val a: Double = 5.0, val b: Double = 0.05, val c: Double = 0.12, val d: Double = 0.45) {
    fun encode(x: Double): Double = (c * log2(a * max(x, 0.0) + b) + d).coerceIn(0.0, 1.0)
    fun decode(y: Double): Double = (2.0.pow((y - d) / c) - b) / a
    fun valid() = a > 0 && b > 0 && c > 0 && listOf(a, b, c, d).all { it.isFinite() }
}

/** Тон-мэппинг HDR/широкого диапазона в диапазон 0..1. NONE — только ограничение (как в v0.25). */
enum class ToneMap(val id: Int, val label: String) {
    NONE(0, "Нет (обрезка)"), REINHARD(1, "Reinhard"), FILMIC(2, "Filmic (ACES-подобный)"), HABLE(3, "Hable");

    /** Применяется к линейному значению канала (после экспозиции). [white] — значение, которое отображается в 1.0 (для Reinhard/Hable). */
    fun apply(x: Double, white: Double = 4.0): Double = when (this) {
        NONE -> x.coerceIn(0.0, 1.0)
        REINHARD -> { val v = max(x, 0.0); (v * (1 + v / (white * white)) / (1 + v)).coerceIn(0.0, 1.0) }
        FILMIC -> { val v = max(x, 0.0); ((v * (2.51 * v + 0.03)) / (v * (2.43 * v + 0.59) + 0.14)).coerceIn(0.0, 1.0) }
        HABLE -> { fun h(t: Double) = ((t * (0.15 * t + 0.10 * 0.50) + 0.20 * 0.02) / (t * (0.15 * t + 0.50) + 0.20 * 0.30)) - 0.02 / 0.30
            (h(max(x, 0.0) * 2.0) / h(white * 2.0)).coerceIn(0.0, 1.0) }
    }
    companion object { fun byId(id: Int) = values().firstOrNull { it.id == id } ?: NONE }
}

enum class GamutMap(val id: Int, val label: String) {
    CLIP(0, "Обрезка"), DESAT(1, "Мягкое обесцвечивание");
    /** Приводит линейный RGB выходного охвата к 0..1 по каналам. [lw] — яркостные коэффициенты охвата. */
    fun apply(c: DoubleArray, lw: DoubleArray): DoubleArray {
        if (this == CLIP) return DoubleArray(3) { c[it].coerceIn(0.0, 1.0) }
        val y = (lw[0] * c[0] + lw[1] * c[1] + lw[2] * c[2]).coerceIn(0.0, 1.0)
        // Ближайшая точка на луче «серый → цвет», у которой все каналы ≥ 0: сохраняет яркость и оттенок.
        var t = 1.0
        for (k in 0 until 3) if (c[k] < 0.0) t = min(t, y / (y - c[k]))
        return DoubleArray(3) { (y + (c[it] - y) * t).coerceIn(0.0, 1.0) }
    }
    companion object { fun byId(id: Int) = values().firstOrNull { it.id == id } ?: CLIP }
}

/** Баланс белого: температура источника (К) и оттенок (зелёный↔пурпурный). Матрица в линейном рабочем охвате. */
object WhiteBalance {
    /** CCT → xy (аппроксимация Kim et al., 4000–25000 К; ниже 4000 К — планковская кривая по Крыстеку/Kang). */
    fun cctToXy(k0: Double): DoubleArray {
        val k = k0.coerceIn(1667.0, 25000.0)
        val t = 1000.0 / k
        val x = if (k <= 4000.0) -0.2661239 * t * t * t - 0.2343589 * t * t + 0.8776956 * t + 0.179910
                else -3.0258469 * t * t * t + 2.1070379 * t * t + 0.2226347 * t + 0.240390
        val y = when {
            k <= 2222.0 -> -1.1063814 * x * x * x - 1.34811020 * x * x + 2.18555832 * x - 0.20219683
            k <= 4000.0 -> -0.9549476 * x * x * x - 1.37418593 * x * x + 2.09137015 * x - 0.16748867
            else -> 3.0817580 * x * x * x - 5.87338670 * x * x + 3.75112997 * x - 0.37001483
        }
        return doubleArrayOf(x, y)
    }

    /** Белая точка сцены: [kelvin] с поворотом по нормали к кривой на [tint] (−100…+100; + — к пурпурному). */
    fun sceneWhite(kelvin: Double, tint: Double): DoubleArray {
        val a = cctToXy(kelvin - 100.0); val b = cctToXy(kelvin + 100.0); val c = cctToXy(kelvin)
        var tx = b[0] - a[0]; var ty = b[1] - a[1]
        val n = sqrt(tx * tx + ty * ty).coerceAtLeast(1e-9); tx /= n; ty /= n
        // нормаль: выше кривой — зеленее (y растёт), поэтому для «+ пурпурный» смещаем вниз
        val nx = ty; val ny = -tx
        val s = -tint / 100.0 * 0.02 * (if (ny < 0) -1 else 1)
        // Смещение относительно 6500 К: 6500 К соответствует D65 (иначе сказывалась бы разница планковской кривой и D65 ≈ 0.003 Duv).
        val ref = cctToXy(6500.0)
        return doubleArrayOf(Spaces.REC709.wx + (c[0] - ref[0]) + nx * s, Spaces.REC709.wy + (c[1] - ref[1]) + ny * s)
    }

    /**
     * Матрица, которая «приводит» кадр, снятый при освещении [kelvin]/[tint], к нейтральному D65:
     * kelvin = 6500 и tint = 0 дают единичную матрицу.
     */
    fun matrix(kelvin: Double, tint: Double, work: Primaries): DoubleArray {
        val sw = sceneWhite(kelvin, tint)
        val src = doubleArrayOf(sw[0] / sw[1], 1.0, (1 - sw[0] - sw[1]) / sw[1])
        val d65 = Spaces.REC709.white()
        val toXyz = work.toXyz()
        return M3.mul(M3.inv(toXyz), M3.mul(Spaces.adapt(src, d65), toXyz))
    }
}
