package app.procam

/** Кнопки левой панели главного экрана, которые пользователь может включать, выключать и переставлять. */
enum class RailItem(val title: String, val about: String) {
    ZEBRA("ЗЕБРА", "Зебра: уровни 90 / 95 / 100 %"),
    PEAKING("ПИКИНГ", "Focus peaking: подсветка резких краёв"),
    FALSE_COLOR("FALSE COLOR", "Ложные цвета для оценки экспозиции"),
    HIST("ГИСТОГРАММА", "Гистограмма на превью"),
    GRID("СЕТКА", "Сетки композиции"),
    LEVEL("УРОВЕНЬ", "Электронный уровень"),
    LOG("LOG", "Переключение SDR ⇄ LOG"),
    LUT("LUT", "Лента LUT"),
    EIS("EIS", "Электронная стабилизация"),
    NR("NR", "Программное шумоподавление")
}

data class RailEntry(val item: RailItem, val enabled: Boolean)

/**
 * Раскладка левой панели. Кнопки записи, паузы, меню, ручных настроек и зума в раскладку НЕ входят — они закреплены
 * на правой панели, поэтому никакая раскладка не может убрать их или перекрыть: это и есть защита критических кнопок.
 * [locked] — положение и состав заблокированы от случайных изменений.
 */
data class HomeLayout(val name: String, val entries: List<RailEntry>, val railOpacity: Int = 100, val locked: Boolean = false) {
    fun visible(): List<RailItem> = entries.filter { it.enabled }.map { it.item }
}

object HomeLayouts {
    const val ACTIVE = "l28.active"
    const val CUSTOM_PREFIX = "l28.custom."
    const val MIN_OPACITY = 30

    private fun build(name: String, on: List<RailItem>, order: List<RailItem>, opacity: Int = 100): HomeLayout {
        val seq = order + RailItem.values().filter { it !in order }
        return HomeLayout(name, seq.map { RailEntry(it, it in on) }, opacity, false)
    }

    /** «Default» воспроизводит раскладку v0.27 один в один (те же восемь кнопок в том же порядке). */
    val DEFAULT = build("Default",
        listOf(RailItem.ZEBRA, RailItem.PEAKING, RailItem.GRID, RailItem.LEVEL, RailItem.LOG, RailItem.LUT, RailItem.EIS, RailItem.NR),
        listOf(RailItem.ZEBRA, RailItem.PEAKING, RailItem.GRID, RailItem.LEVEL, RailItem.LOG, RailItem.LUT, RailItem.EIS, RailItem.NR))
    val MINIMAL = build("Minimal", listOf(RailItem.ZEBRA, RailItem.LOG, RailItem.LUT), listOf(RailItem.ZEBRA, RailItem.LOG, RailItem.LUT))
    val PROFESSIONAL = build("Professional",
        RailItem.values().toList(),
        listOf(RailItem.ZEBRA, RailItem.PEAKING, RailItem.FALSE_COLOR, RailItem.HIST, RailItem.LEVEL, RailItem.LOG, RailItem.LUT, RailItem.EIS, RailItem.NR, RailItem.GRID))
    val CINEMA = build("Cinema",
        listOf(RailItem.GRID, RailItem.LEVEL, RailItem.ZEBRA, RailItem.LOG, RailItem.LUT, RailItem.EIS),
        listOf(RailItem.GRID, RailItem.LEVEL, RailItem.ZEBRA, RailItem.LOG, RailItem.LUT, RailItem.EIS), opacity = 90)

    val PRESETS: Map<String, HomeLayout> = linkedMapOf("Default" to DEFAULT, "Minimal" to MINIMAL, "Professional" to PROFESSIONAL, "Cinema" to CINEMA)

    // ------------------------------------------------------------ изменения (чистые функции; заблокированная раскладка не меняется)

    fun move(l: HomeLayout, item: RailItem, delta: Int): HomeLayout {
        if (l.locked) return l
        val i = l.entries.indexOfFirst { it.item == item }
        if (i < 0) return l
        val j = (i + delta).coerceIn(0, l.entries.size - 1)
        if (i == j) return l
        val m = l.entries.toMutableList()
        val e = m.removeAt(i); m.add(j, e)
        return l.copy(entries = m)
    }

    fun setEnabled(l: HomeLayout, item: RailItem, on: Boolean): HomeLayout =
        if (l.locked) l else l.copy(entries = l.entries.map { if (it.item == item) it.copy(enabled = on) else it })

    fun setLocked(l: HomeLayout, locked: Boolean): HomeLayout = l.copy(locked = locked)

    /** Прозрачность подложки панели в процентах; меньше [MIN_OPACITY] кнопки становятся неразличимы. Заблокированная раскладка не меняется. */
    fun setOpacity(l: HomeLayout, pct: Int): HomeLayout = if (l.locked) l else l.copy(railOpacity = pct.coerceIn(MIN_OPACITY, 100))

    fun rename(l: HomeLayout, name: String): HomeLayout = l.copy(name = cleanName(name).ifEmpty { l.name })

    fun cleanName(n: String) = n.trim().replace(Regex("[\\r\\n\\t]"), " ").take(40)

    // ------------------------------------------------------------ запись и чтение

    fun encode(l: HomeLayout): String =
        "BRL1\t" + Codec28.esc(l.name) + "\t" + l.railOpacity + "\t" + (if (l.locked) 1 else 0) + "\t" +
            l.entries.joinToString(",") { it.item.name + ":" + (if (it.enabled) 1 else 0) }

    class Decoded(val layout: HomeLayout?, val problems: List<String>)

    /** Строгая проверка: неизвестные кнопки отбрасываются с пометкой, пропавшие добавляются выключенными, повторы игнорируются. */
    fun decode(text: String): Decoded {
        val p = text.trim().split('\t')
        if (p.size != 5 || p[0] != "BRL1") return Decoded(null, listOf("не раскладка Beyond Recorder (формат не распознан)"))
        val problems = ArrayList<String>()
        val op = p[2].toIntOrNull()
        if (op == null) return Decoded(null, listOf("прозрачность не число"))
        if (op !in MIN_OPACITY..100) problems.add("прозрачность $op % вне $MIN_OPACITY…100 — исправлена")
        val seen = LinkedHashSet<RailItem>(); val entries = ArrayList<RailEntry>()
        for (tok in p[4].split(',')) {
            if (tok.isEmpty()) continue
            val kv = tok.split(':')
            val item = RailItem.values().firstOrNull { it.name == kv[0] }
            if (item == null) { problems.add("неизвестная кнопка «${kv[0]}» пропущена"); continue }
            if (!seen.add(item)) { problems.add("повтор «${kv[0]}» пропущен"); continue }
            entries.add(RailEntry(item, kv.getOrNull(1) == "1"))
        }
        for (it in RailItem.values()) if (it !in seen) entries.add(RailEntry(it, false))
        val name = cleanName(Codec28.unesc(p[1])).ifEmpty { "Custom" }
        return Decoded(HomeLayout(name, entries, op.coerceIn(MIN_OPACITY, 100), p[3] == "1"), problems)
    }
}

/** Хранение активной и пользовательских раскладок. Повреждённая запись заменяется «Default», а не роняет экран. */
class HomeLayoutStore(private val store: KeyValueStore) {
    fun active(): HomeLayout {
        val raw = store.all()[HomeLayouts.ACTIVE] as? String ?: return HomeLayouts.DEFAULT
        return HomeLayouts.decode(raw).layout ?: HomeLayouts.DEFAULT
    }
    fun setActive(l: HomeLayout) { store.commit(mapOf(HomeLayouts.ACTIVE to HomeLayouts.encode(l))) }
    fun customNames(): List<String> = store.all().keys.filter { it.startsWith(HomeLayouts.CUSTOM_PREFIX) }.map { it.removePrefix(HomeLayouts.CUSTOM_PREFIX) }.sorted()
    fun saveCustom(l: HomeLayout): String? {
        val n = HomeLayouts.cleanName(l.name); if (n.isEmpty()) return null
        store.commit(mapOf(HomeLayouts.CUSTOM_PREFIX + n to HomeLayouts.encode(l.copy(name = n)))); return n
    }
    fun loadCustom(name: String): HomeLayout? = (store.all()[HomeLayouts.CUSTOM_PREFIX + name] as? String)?.let { HomeLayouts.decode(it).layout }
    fun deleteCustom(name: String) { store.commit(emptyMap(), setOf(HomeLayouts.CUSTOM_PREFIX + name)) }
}
