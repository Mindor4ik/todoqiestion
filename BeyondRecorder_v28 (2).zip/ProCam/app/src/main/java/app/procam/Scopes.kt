package app.procam

import kotlin.math.roundToInt

/**
 * Анализ реального кадра для мониторинга. Вход — пиксели RGBA8 (то, что видит монитор, после той же цепочки цвета).
 * Никаких имитаций: каждое значение — счётчик реальных пикселей кадра. Эталонная CPU-реализация проверяется тестами
 * на кадрах с известными значениями.
 */
object Scopes {
    const val LEVELS = 256

    fun luma709(r: Int, g: Int, b: Int): Int = (0.2126 * r + 0.7152 * g + 0.0722 * b).roundToInt().coerceIn(0, 255)

    class Hist(val r: IntArray = IntArray(LEVELS), val g: IntArray = IntArray(LEVELS), val b: IntArray = IntArray(LEVELS), val luma: IntArray = IntArray(LEVELS), var pixels: Int = 0) {
        fun clippedHigh(): Float = if (pixels == 0) 0f else (luma[255] + 0f) / pixels
        fun clippedLow(): Float = if (pixels == 0) 0f else (luma[0] + 0f) / pixels
    }

    fun histogram(px: ByteArray, n: Int): Hist {
        val h = Hist()
        var i = 0
        for (k in 0 until n) {
            val r = px[i].toInt() and 255; val g = px[i + 1].toInt() and 255; val b = px[i + 2].toInt() and 255; i += 4
            h.r[r]++; h.g[g]++; h.b[b]++; h.luma[luma709(r, g, b)]++
        }
        h.pixels = n
        return h
    }

    /** Waveform: [cols] столбцов по горизонтали кадра × 256 уровней; индекс = col*256 + level (level 0 — чёрный). channel: −1 яркость, 0/1/2 — R/G/B. */
    fun waveform(px: ByteArray, w: Int, h: Int, cols: Int, channel: Int = -1): IntArray {
        val out = IntArray(cols * LEVELS)
        for (y in 0 until h) for (x in 0 until w) {
            val i = (y * w + x) * 4
            val r = px[i].toInt() and 255; val g = px[i + 1].toInt() and 255; val b = px[i + 2].toInt() and 255
            val lv = when (channel) { 0 -> r; 1 -> g; 2 -> b; else -> luma709(r, g, b) }
            out[(x * cols / w) * LEVELS + lv]++
        }
        return out
    }

    /** RGB Parade: три waveform рядом (R | G | B); каждый — [colsPer] столбцов. */
    fun parade(px: ByteArray, w: Int, h: Int, colsPer: Int): Array<IntArray> = Array(3) { waveform(px, w, h, colsPer, it) }

    /** Позиция цвета на векторскопе (BT.709 Cb/Cr): центр = серый, радиус ∝ насыщенности. Возвращает (x, y) в сетке size×size, y вверх. */
    fun vectorPos(r: Int, g: Int, b: Int, size: Int): Pair<Int, Int> {
        val rf = r / 255.0; val gf = g / 255.0; val bf = b / 255.0
        val y = 0.2126 * rf + 0.7152 * gf + 0.0722 * bf
        val cb = (bf - y) / 1.8556      // −0.5…0.5
        val cr = (rf - y) / 1.5748
        val x = ((cb + 0.5) * (size - 1)).roundToInt().coerceIn(0, size - 1)
        val yy = ((cr + 0.5) * (size - 1)).roundToInt().coerceIn(0, size - 1)
        return x to yy
    }

    fun vectorscope(px: ByteArray, n: Int, size: Int): IntArray {
        val out = IntArray(size * size)
        var i = 0
        for (k in 0 until n) {
            val (x, y) = vectorPos(px[i].toInt() and 255, px[i + 1].toInt() and 255, px[i + 2].toInt() and 255, size); i += 4
            out[y * size + x]++
        }
        return out
    }

    /** Координаты целей векторскопа (75 % цветные полосы): R, Yl, G, Cy, B, Mg. */
    fun vectorTargets(size: Int): List<Pair<String, Pair<Int, Int>>> {
        fun t(n: String, r: Int, g: Int, b: Int) = n to vectorPos(r, g, b, size)
        val k = 191
        return listOf(t("R", k, 0, 0), t("Yl", k, k, 0), t("G", 0, k, 0), t("Cy", 0, k, k), t("B", 0, 0, k), t("Mg", k, 0, k))
    }
}

/** Диапазон ложных цветов по яркости монитора (0..1). */
class FalseColorRange(val lo: Float, val hi: Float, val rgb: Int)

class FalseColorMap(val name: String, val ranges: List<FalseColorRange>) {
    /** Цвет для яркости y (0..1) или null — показывать исходную картинку. Первый подходящий диапазон. */
    fun colorFor(y: Double): Int? = ranges.firstOrNull { y >= it.lo && y < it.hi }?.rgb

    companion object {
        /** Карта v0.25 (по умолчанию). */
        val BEYOND = FalseColorMap("Beyond (v0.25)", listOf(
            FalseColorRange(0f, 0.03f, 0x660099), FalseColorRange(0.03f, 0.10f, 0x4040F2), FalseColorRange(0.38f, 0.48f, 0x00BF33),
            FalseColorRange(0.55f, 0.62f, 0xFF8CB3), FalseColorRange(0.90f, 0.97f, 0xFFE600), FalseColorRange(0.97f, 1.01f, 0xFF0000)))
        /** Полный спектр: 10 полос по 10 %. */
        val SPECTRUM = FalseColorMap("Спектр (10 полос)", listOf(
            FalseColorRange(0.0f, 0.1f, 0x300050), FalseColorRange(0.1f, 0.2f, 0x0000FF), FalseColorRange(0.2f, 0.3f, 0x0080FF),
            FalseColorRange(0.3f, 0.4f, 0x00FFFF), FalseColorRange(0.4f, 0.5f, 0x00C000), FalseColorRange(0.5f, 0.6f, 0x80FF00),
            FalseColorRange(0.6f, 0.7f, 0xFFFF00), FalseColorRange(0.7f, 0.8f, 0xFF8000), FalseColorRange(0.8f, 0.9f, 0xFF0000), FalseColorRange(0.9f, 1.01f, 0xFFFFFF)))
        /** Для оценки экспозиции кожи: серый 18 % и диапазон кожи. */
        val SKIN = FalseColorMap("Кожа и серый", listOf(
            FalseColorRange(0f, 0.02f, 0x660099), FalseColorRange(0.40f, 0.46f, 0x00BF33), FalseColorRange(0.50f, 0.70f, 0xFF8CB3), FalseColorRange(0.98f, 1.01f, 0xFF0000)))
        val presets = listOf(BEYOND, SPECTRUM, SKIN)
        fun custom(lo1: Float, hi1: Float, lo2: Float, hi2: Float, lo3: Float, hi3: Float) = FalseColorMap("Пользовательская", listOf(
            FalseColorRange(lo1, hi1, 0x4040F2), FalseColorRange(lo2, hi2, 0x00BF33), FalseColorRange(lo3, hi3, 0xFF0000)))
    }
}

/** Две независимые «зебры»: света (≥ level) и тени (≤ level). Интенсивность — непрозрачность полос. */
class ZebraConfig(val hiOn: Boolean = false, val hiLevel: Float = 0.95f, val loOn: Boolean = false, val loLevel: Float = 0.05f, val intensity: Float = 1f) {
    /** 0 — нет, 1 — света, 2 — тени. */
    fun hit(y: Double): Int = when {
        hiOn && y >= hiLevel -> 1
        loOn && y <= loLevel -> 2
        else -> 0
    }
}
