package app.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/** Диагностический оверлей вычислительного конвейера: векторы потока, траектория коррекции, кроп, задержка, FPS. */
class CiDiagView(c: Context) : View(c) {
    private var d: CiDiag? = null
    private val bg = Paint().apply { color = 0xB0000000.toInt() }
    private val ok = Paint().apply { color = 0xFF40E070.toInt(); strokeWidth = 2f }
    private val bad = Paint().apply { color = 0xFFFF5050.toInt(); strokeWidth = 2f }
    private val ln = Paint().apply { color = 0x66FFFFFF; strokeWidth = 1f; style = Paint.Style.STROKE }
    private val tx = Paint().apply { color = 0xFFFFFFFF.toInt(); textSize = 22f; isAntiAlias = true }
    private val px = Paint().apply { color = 0xFFFFC040.toInt(); strokeWidth = 2f; style = Paint.Style.STROKE }
    private val py = Paint().apply { color = 0xFF50B0FF.toInt(); strokeWidth = 2f; style = Paint.Style.STROKE }

    fun set(v: CiDiag) { d = v; invalidate() }

    override fun onDraw(cv: Canvas) {
        val g = d ?: return
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawRect(0f, 0f, w, h, bg)
        val lines = listOf(
            "Источник: ${g.source}",
            "Движение камеры: dx=%.2f dy=%.2f px · поворот %.2f° · масштаб %.3f".format(g.tx, g.ty, g.rotDeg, g.scale),
            "Уверенность %.0f%% · согласных точек %d из %d".format(g.conf * 100, g.inliers, g.tracked),
            "Кроп ×%.3f: потеря %.1f%% по сторонам, %.1f%% площади · коррекция применена на %.0f%%%s".format(g.crop, CropMath.lossLinearPct(g.crop), CropMath.lossAreaPct(g.crop), g.alpha * 100, if (g.cropLimited) " (ограничена запасом кадра)" else ""),
            "Скорость камеры %.2f рад/с · окно сглаживания σ=%.0f мс".format(g.speed, g.sigmaSec * 1000),
            "Горизонт: %.1f° (%s)".format(g.horizonDeg, when (g.horizonSrc) { 1 -> "акселерометр"; 2 -> "оценка по изображению"; else -> "не применяется" }),
            "Rolling shutter по изображению: строки %.1f мс, столбцы %.1f мс (надёжность %.0f%%)".format(g.rsRowsMs, g.rsColsMs, g.rsRel * 100),
            "Обработка кадра %.1f мс (анализ %.1f мс) · FPS %.1f · потеряно кадров %d · сбросов истории %d".format(g.procMs, g.analysisMs, g.fps, g.dropped, g.gaps),
            if (g.nrOn) "NR: накопление ≈ %.0f кадров на статике (%s)".format(g.nrFrames, if (g.shaderNr) "шейдер NR v4" else "запасной фильтр") else "NR выключен"
        )
        val lh = tx.textSize + 6
        var y = 26f
        for (l in lines) { cv.drawText(l, 10f, y, tx); y += lh }
        // кадр с векторами
        val fh = h - y - 8f
        if (fh < 40f) return
        val fw = fh * 16f / 9f
        val fr = RectF(10f, y, 10f + fw, y + fh)
        cv.drawRect(fr, ln)
        val v = g.vecs
        for (i in g.vin.indices) {
            val a = fr.left + v[i * 4] * fr.width(); val b = fr.top + v[i * 4 + 1] * fr.height()
            val c = fr.left + v[i * 4 + 2] * fr.width(); val e = fr.top + v[i * 4 + 3] * fr.height()
            val p = if (g.vin[i]) ok else bad
            // вектор усилен ×4 для видимости (подпись ниже)
            cv.drawLine(a, b, a + (c - a) * 4, b + (e - b) * 4, p)
            cv.drawCircle(a, b, 2.5f, p)
        }
        cv.drawText("потоки ×4: зелёные — камера, красные — объекты/шум", fr.left + 4, fr.bottom - 6, tx.apply { textSize = 16f }); tx.textSize = 22f
        // траектория коррекции
        val gx = fr.right + 16f
        val gr = RectF(gx, y, w - 10f, y + fh)
        cv.drawRect(gr, ln)
        val n = g.trajX.size
        if (n > 1) {
            var m = 5f
            for (i in 0 until n) m = max(m, max(abs(g.trajX[i]), abs(g.trajY[i])))
            fun plot(a: FloatArray, p: Paint) {
                var px0 = 0f; var py0 = 0f
                for (i in 0 until n) {
                    val x = gr.left + gr.width() * i / (n - 1); val yy = gr.centerY() - a[i] / m * gr.height() * 0.45f
                    if (i > 0) cv.drawLine(px0, py0, x, yy, p)
                    px0 = x; py0 = yy
                }
            }
            plot(g.trajX, px); plot(g.trajY, py)
            cv.drawText("коррекция, px (±%.0f): жёлтая — по X, синяя — по Y".format(m), gr.left + 4, gr.bottom - 6, tx.apply { textSize = 16f }); tx.textSize = 22f
        }
    }
}
