package app.procam

import java.io.BufferedReader
import java.io.StringReader
import kotlin.math.floor
import kotlin.math.min

/** 1D LUT из .cube: по одной кривой на канал. [data] — size × 3 (R,G,B подряд). */
class Lut1D(
    val title: String, val size: Int, val data: FloatArray,
    val domainMin: FloatArray = floatArrayOf(0f, 0f, 0f), val domainMax: FloatArray = floatArrayOf(1f, 1f, 1f)
)

/** Загруженный LUT: 1D или 3D. */
sealed class AnyLut {
    abstract val title: String
    class D1(val lut: Lut1D) : AnyLut() { override val title get() = lut.title }
    class D3(val lut: CubeLut) : AnyLut() { override val title get() = lut.title }
}

enum class LutInterp(val id: Int, val label: String) {
    TRILINEAR(0, "Trilinear"), TETRAHEDRAL(1, "Tetrahedral");
    companion object { fun byId(id: Int) = values().firstOrNull { it.id == id } ?: TRILINEAR }
}

/** Где применяется LUT: два независимых режима вместо путаницы «превью/запись». */
enum class LutScope(val id: Int, val label: String, val hint: String) {
    MONITOR(0, "Только монитор", "LUT виден на экране, в файл не попадает"),
    RECORD(1, "Только запись", "LUT запекается в файл, монитор показывает картинку без него"),
    BOTH(2, "Монитор и запись", "то, что на экране, и записывается (запись через GL)");
    val onMonitor get() = this != RECORD
    val onRecord get() = this != MONITOR
    companion object { fun byId(id: Int) = values().firstOrNull { it.id == id } ?: MONITOR }
}

/** Цветовое пространство LUT: охват + передаточная функция. [followLog] — вход «как выбранная LOG-кривая». */
/** [raw] (только для выхода): код на выходе LUT уже является итоговым кодом картинки — без преобразований (поведение v0.25). */
data class LutSpace(val tf: Tf, val prim: Primaries, val followLog: Boolean = false, val raw: Boolean = false)

/** Что LUT ждёт на входе и что выдаёт. */
data class LutIo(val input: LutSpace, val output: LutSpace) {
    companion object {
        /** v0.25: вход — выбранная LOG-кривая (Rec.709), выход — то же пространство, что у картинки (look). */
        val LOG_LOOK = LutIo(LutSpace(Tf.FLAT, Spaces.REC709, followLog = true), LutSpace(Tf.SRGB, Spaces.REC709, raw = true))
        val REC709_LOOK = LutIo(LutSpace(Tf.SRGB, Spaces.REC709), LutSpace(Tf.SRGB, Spaces.REC709))
        val REC709_G24_LOOK = LutIo(LutSpace(Tf.GAMMA24, Spaces.REC709), LutSpace(Tf.GAMMA24, Spaces.REC709))
        val HLG_2020 = LutIo(LutSpace(Tf.HLG, Spaces.REC2020), LutSpace(Tf.GAMMA24, Spaces.REC709))
        val presets = listOf(
            "LOG-кривая съёмки → итоговая картинка (как v0.25)" to LOG_LOOK,
            "LOG-кривая съёмки → Rec.709 Gamma 2.4" to LutIo(LutSpace(Tf.FLAT, Spaces.REC709, followLog = true), LutSpace(Tf.GAMMA24, Spaces.REC709)),
            "Rec.709 sRGB → Rec.709 sRGB" to REC709_LOOK,
            "Rec.709 Gamma 2.4 → Rec.709 Gamma 2.4" to REC709_G24_LOOK,
            "Rec.2020 HLG → Rec.709 Gamma 2.4" to HLG_2020
        )
    }
}

data class LutInfo(
    val kind: String, val size: Int, val title: String, val entries: Long,
    val domainMin: FloatArray, val domainMax: FloatArray,
    val outMin: Float, val outMax: Float, val identity: Boolean, val gpuBytes: Long
) {
    fun text(): String = "$kind $size${if (kind == "3D") "³" else ""} · «$title»\n" +
        "значений: $entries · диапазон входа: %.3f…%.3f\n".format(domainMin.min(), domainMax.max()) +
        "диапазон выхода: %.3f…%.3f%s\n".format(outMin, outMax, if (outMin < -0.001f || outMax > 1.001f) " (выходит за 0…1 — результат будет обрезан при записи)" else "") +
        "видеопамять: ≈ %.1f МБ%s".format(gpuBytes / 1048576.0, if (identity) "\nLUT тождественный — изображение не изменит" else "")
}

object LutEngine {
    const val MAX_1D = 65536

    /** Единый тип для всех путей: 1D LUT упаковывается в [CubeLut] с полем oneD. */
    fun toCube(l: AnyLut): CubeLut = when (l) {
        is AnyLut.D3 -> l.lut
        is AnyLut.D1 -> CubeLut(l.lut.title, 2, FloatArray(24) { i -> val c = i / 3; floatArrayOf((c and 1).toFloat(), ((c shr 1) and 1).toFloat(), ((c shr 2) and 1).toFloat())[i % 3] },
            l.lut.domainMin, l.lut.domainMax, oneD = l.lut)
    }
    fun fromCube(c: CubeLut): AnyLut = c.oneD?.let { AnyLut.D1(it) } ?: AnyLut.D3(c)

    /** Разбирает .cube: 1D или 3D. Ошибки — с номером строки и причиной на русском. */
    fun parse(text: String): AnyLut {
        var has1 = false; var has3 = false
        for (raw in text.lineSequence()) {
            val t = raw.trimStart('﻿').substringBefore('#').trim()
            if (t.startsWith("LUT_1D_SIZE", true)) has1 = true
            if (t.startsWith("LUT_3D_SIZE", true)) has3 = true
        }
        if (has1 && has3) error("В файле одновременно LUT_1D_SIZE и LUT_3D_SIZE: связка 1D+3D не поддерживается — разделите на два файла")
        if (has3) return AnyLut.D3(CubeLutReader.read(BufferedReader(StringReader(text))))
        if (!has1) error("В файле нет ни LUT_1D_SIZE, ни LUT_3D_SIZE — это не .cube")
        return AnyLut.D1(parse1D(text))
    }

    private fun parse1D(text: String): Lut1D {
        var title = "Custom 1D LUT"; var size = 0
        var dMin = floatArrayOf(0f, 0f, 0f); var dMax = floatArrayOf(1f, 1f, 1f)
        var data = FloatArray(0); var count = 0; var no = 0
        for (raw in text.lineSequence()) {
            no++
            val line = raw.trimStart('﻿').substringBefore('#').trim()
            if (line.isEmpty()) continue
            val p = line.split(Regex("\\s+"))
            if (p[0][0].isLetter()) {
                when (p[0].uppercase()) {
                    "TITLE" -> title = line.substring(p[0].length).trim().trim('"').ifBlank { title }
                    "LUT_1D_SIZE" -> {
                        val n = p.getOrNull(1)?.toIntOrNull() ?: error("Строка $no: некорректный LUT_1D_SIZE")
                        if (n !in 2..MAX_1D) error("Поддерживается LUT_1D_SIZE от 2 до $MAX_1D (в файле $n)")
                        size = n; data = FloatArray(n * 3); count = 0
                    }
                    "DOMAIN_MIN", "DOMAIN_MAX" -> {
                        if (p.size != 4) error("Строка $no: ожидалось 3 числа после ${p[0]}")
                        val v = FloatArray(3) { k -> p[k + 1].toFloatOrNull()?.takeIf { it.isFinite() } ?: error("Строка $no: «${p[k + 1]}» — не число") }
                        if (p[0].uppercase() == "DOMAIN_MIN") dMin = v else dMax = v
                    }
                    else -> Unit
                }
                continue
            }
            if (size == 0) error("Строка $no: данные раньше LUT_1D_SIZE")
            if (p.size != 3) error("Строка $no: ожидалось 3 числа, найдено ${p.size}")
            if (count + 3 > data.size) error("Слишком много значений: ожидалось $size троек")
            for (k in 0..2) data[count++] = p[k].toFloatOrNull()?.takeIf { it.isFinite() } ?: error("Строка $no: «${p[k]}» — не число")
        }
        if (count != data.size) error("Число троек ${count / 3}, ожидалось $size")
        for (k in 0..2) if (dMax[k] <= dMin[k]) error("DOMAIN_MAX должен быть больше DOMAIN_MIN")
        return Lut1D(title, size, data, dMin, dMax)
    }

    fun info(l: AnyLut): LutInfo = when (l) {
        is AnyLut.D1 -> { val d = l.lut; val mm = minMax(d.data); LutInfo("1D", d.size, d.title, d.size.toLong() * 3, d.domainMin, d.domainMax, mm.first, mm.second, isIdentity1D(d), d.size * 3L * 2) }
        is AnyLut.D3 -> { val d = l.lut; val mm = minMax(d.data); LutInfo("3D", d.size, d.title, d.data.size.toLong(), d.domainMin, d.domainMax, mm.first, mm.second, isIdentity3D(d), gpuBytes3D(d.size)) }
    }

    /** RGB16F: на большинстве драйверов выравнивается до 4 каналов (8 байт на тексель); считаем с запасом. */
    fun gpuBytes3D(n: Int): Long = n.toLong() * n * n * 8

    private fun minMax(a: FloatArray): Pair<Float, Float> { var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE; for (v in a) { if (v < lo) lo = v; if (v > hi) hi = v }; return lo to hi }

    fun isIdentity3D(l: CubeLut, eps: Float = 1e-4f): Boolean {
        val n = l.size
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val i = ((b * n + g) * n + r) * 3
            val e = floatArrayOf(r.toFloat() / (n - 1), g.toFloat() / (n - 1), b.toFloat() / (n - 1))
            for (c in 0..2) {
                val ex = l.domainMin[c] + e[c] * (l.domainMax[c] - l.domainMin[c])
                if (kotlin.math.abs(l.data[i + c] - ex) > eps) return false
            }
        }
        return true
    }

    fun isIdentity1D(l: Lut1D, eps: Float = 1e-4f): Boolean {
        for (i in 0 until l.size) for (c in 0..2) {
            val ex = l.domainMin[c] + i.toFloat() / (l.size - 1) * (l.domainMax[c] - l.domainMin[c])
            if (kotlin.math.abs(l.data[i * 3 + c] - ex) > eps) return false
        }
        return true
    }

    // ------------------------------------------------------------ эталонная интерполяция (CPU)

    private fun norm(l: CubeLut, c: Int, v: Double): Double = ((v - l.domainMin[c]) / (l.domainMax[c] - l.domainMin[c])).coerceIn(0.0, 1.0)

    fun sample3D(l: CubeLut, rgb: DoubleArray, interp: LutInterp): DoubleArray {
        val n = l.size
        val pos = DoubleArray(3) { norm(l, it, rgb[it]) * (n - 1) }
        val i0 = IntArray(3) { min(floor(pos[it]).toInt(), n - 2) }
        val f = DoubleArray(3) { pos[it] - i0[it] }
        fun v(dr: Int, dg: Int, db: Int, c: Int): Double = l.data[(((i0[2] + db) * n + (i0[1] + dg)) * n + (i0[0] + dr)) * 3 + c].toDouble()
        val out = DoubleArray(3)
        for (c in 0..2) {
            out[c] = if (interp == LutInterp.TRILINEAR) {
                val c00 = v(0, 0, 0, c) * (1 - f[0]) + v(1, 0, 0, c) * f[0]
                val c10 = v(0, 1, 0, c) * (1 - f[0]) + v(1, 1, 0, c) * f[0]
                val c01 = v(0, 0, 1, c) * (1 - f[0]) + v(1, 0, 1, c) * f[0]
                val c11 = v(0, 1, 1, c) * (1 - f[0]) + v(1, 1, 1, c) * f[0]
                val c0 = c00 * (1 - f[1]) + c10 * f[1]; val c1 = c01 * (1 - f[1]) + c11 * f[1]
                c0 * (1 - f[2]) + c1 * f[2]
            } else {
                val fr = f[0]; val fg = f[1]; val fb = f[2]
                val c000 = v(0, 0, 0, c); val c111 = v(1, 1, 1, c)
                if (fr > fg) {
                    if (fg > fb) c000 + fr * (v(1, 0, 0, c) - c000) + fg * (v(1, 1, 0, c) - v(1, 0, 0, c)) + fb * (c111 - v(1, 1, 0, c))
                    else if (fr > fb) c000 + fr * (v(1, 0, 0, c) - c000) + fb * (v(1, 0, 1, c) - v(1, 0, 0, c)) + fg * (c111 - v(1, 0, 1, c))
                    else c000 + fb * (v(0, 0, 1, c) - c000) + fr * (v(1, 0, 1, c) - v(0, 0, 1, c)) + fg * (c111 - v(1, 0, 1, c))
                } else {
                    if (fb > fg) c000 + fb * (v(0, 0, 1, c) - c000) + fg * (v(0, 1, 1, c) - v(0, 0, 1, c)) + fr * (c111 - v(0, 1, 1, c))
                    else if (fb > fr) c000 + fg * (v(0, 1, 0, c) - c000) + fb * (v(0, 1, 1, c) - v(0, 1, 0, c)) + fr * (c111 - v(0, 1, 1, c))
                    else c000 + fg * (v(0, 1, 0, c) - c000) + fr * (v(1, 1, 0, c) - v(0, 1, 0, c)) + fb * (c111 - v(1, 1, 0, c))
                }
            }
        }
        return out
    }

    fun sample1D(l: Lut1D, rgb: DoubleArray): DoubleArray = DoubleArray(3) { c ->
        val t = ((rgb[c] - l.domainMin[c]) / (l.domainMax[c] - l.domainMin[c])).coerceIn(0.0, 1.0) * (l.size - 1)
        val i = min(floor(t).toInt(), l.size - 2); val f = t - i
        l.data[i * 3 + c] * (1 - f) + l.data[(i + 1) * 3 + c] * f
    }

    fun sample(l: AnyLut, rgb: DoubleArray, interp: LutInterp): DoubleArray = when (l) {
        is AnyLut.D1 -> sample1D(l.lut, rgb)
        is AnyLut.D3 -> sample3D(l.lut, rgb, interp)
    }

    /** Предупреждения о смысле применения LUT (защита от «двойного» эффекта и путаницы пространств). */
    fun warnings(io: LutIo, scope: LutScope, recordTf: Tf?, recordIsLogOrHlg: Boolean, info: LutInfo?): List<String> {
        val w = ArrayList<String>()
        if (scope.onRecord && recordIsLogOrHlg && !io.output.raw && !io.output.tf.let { it == Tf.SLOG3 || it == Tf.VLOG || it == Tf.LOGC || it == Tf.FLAT || it == Tf.HLG })
            w.add("LUT на выходе даёт готовую (display) картинку, а запись идёт в LOG/HLG: файл перестанет быть LOG/HLG. Для сохранения LOG используйте «Только монитор».")
        if (io.input.tf == io.output.tf && io.input.prim == io.output.prim && info?.identity == false && (io.input.tf in listOf(Tf.SLOG3, Tf.VLOG, Tf.LOGC, Tf.FLAT)))
            w.add("Вход и выход LUT в одной LOG-кривой: убедитесь, что это креативный LUT внутри LOG, а не технический LUT LOG→Rec.709.")
        if (info != null && (info.outMin < -0.01f || info.outMax > 1.01f)) w.add("Значения LUT выходят за 0…1: часть изображения будет обрезана.")
        return w
    }
}
