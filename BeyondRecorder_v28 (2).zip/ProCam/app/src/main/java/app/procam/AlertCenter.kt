package app.procam

/** Уровень важности: CRITICAL — риск потери данных / остановки записи / повреждения результата; WARNING — потенциальная проблема; INFO — подсказки. */
enum class Severity(val label: String, val rank: Int) { INFO("INFO", 0), WARNING("WARNING", 1), CRITICAL("CRITICAL", 2) }

enum class AlertGroup(val label: String) {
    THERMAL("Температура и производительность"), STORAGE("Хранилище"), CAMERA("Камера и запись"), INFO("Информационные сообщения")
}

enum class AlertMode(val label: String) {
    ALWAYS("Всегда"), CRITICAL_ONLY("Только критические"), ONCE("Один раз"),
    CENTER_ONLY("Только в центре"), SILENT("Без звука"), OFF("Отключено")
}

/** Порог срабатывания: диапазон ограничен только физическим смыслом величины. */
class Threshold(val unit: String, val min: Float, val max: Float, val default: Float)

/**
 * Типы уведомлений. [dataLoss] — событие, способное привести к потере записи: отключение его показа требует отдельного подтверждения.
 * [repeatSec] — задержка повторного показа и окно склейки одинаковых записей в центре уведомлений.
 */
enum class AlertType(
    val group: AlertGroup, val severity: Severity, val title: String, val about: String,
    val dataLoss: Boolean = false, val repeatSec: Int = 120, val threshold: Threshold? = null, val mode: AlertMode = AlertMode.ALWAYS
) {
    OVERHEAT(AlertGroup.THERMAL, Severity.WARNING, "Перегрев устройства", "Система сообщает о сильном нагреве (статус «сильный» и выше). Мониторинг идёт всегда; приложение ничего не отключает и не обходит защиту Android."),
    TEMP_HIGH(AlertGroup.THERMAL, Severity.WARNING, "Повышенная температура", "Умеренный нагрев по статусу системы или температура батареи выше порога.", threshold = Threshold("°C", 30f, 70f, 42f)),
    CPU_HIGH(AlertGroup.THERMAL, Severity.WARNING, "Высокая нагрузка CPU", "Процесс приложения занимает больше порога (в % одного ядра: 400 % = четыре ядра целиком).", threshold = Threshold("% ядра", 50f, 1600f, 400f)),
    GPU_HIGH(AlertGroup.THERMAL, Severity.WARNING, "Высокая нагрузка GPU", "В Android нет публичного API загрузки GPU: уведомление сработает только на устройстве, которое отдаёт этот показатель.", threshold = Threshold("%", 10f, 100f, 90f)),
    LOW_RAM(AlertGroup.THERMAL, Severity.WARNING, "Недостаток оперативной памяти", "Свободной RAM меньше порога или система сообщает о нехватке памяти.", threshold = Threshold("МБ", 50f, 8192f, 400f)),
    PERF_DROP(AlertGroup.THERMAL, Severity.WARNING, "Снижение производительности", "Прогноз системы (thermal headroom): доля пути до принудительного снижения частот. 1.0 — система начнёт ограничивать производительность.", threshold = Threshold("доля", 0.5f, 1.5f, 0.95f)),

    STORAGE_LOW(AlertGroup.STORAGE, Severity.WARNING, "Недостаток свободного места", "Свободного места меньше порога.", threshold = Threshold("МБ", 300f, 100_000f, 2000f)),
    STORAGE_FULL(AlertGroup.STORAGE, Severity.CRITICAL, "Хранилище почти заполнено", "Места осталось так мало, что запись скоро остановится штатно (при 200 МБ файл корректно закрывается).", dataLoss = true, repeatSec = 60, threshold = Threshold("МБ", 200f, 10_000f, 500f)),
    WRITE_ERROR(AlertGroup.STORAGE, Severity.CRITICAL, "Ошибка записи файла", "Файл не удалось записать или закрыть.", dataLoss = true, repeatSec = 30),
    STORAGE_ACCESS(AlertGroup.STORAGE, Severity.CRITICAL, "Нет доступа к памяти", "Приложение не может открыть место для сохранения видео.", dataLoss = true, repeatSec = 30),

    CAMERA_ERROR(AlertGroup.CAMERA, Severity.CRITICAL, "Ошибка камеры", "Camera2 сообщила об ошибке; запись может быть прервана.", dataLoss = true, repeatSec = 30),
    FRAME_DROP(AlertGroup.CAMERA, Severity.WARNING, "Потеря кадров", "Доля потерянных кадров в записи выше порога (по разрывам временных меток).", threshold = Threshold("% кадров", 0.1f, 50f, 1f)),
    ENCODE_PROBLEM(AlertGroup.CAMERA, Severity.CRITICAL, "Проблемы кодирования", "Кодек сообщил об ошибке или перестал принимать кадры.", dataLoss = true, repeatSec = 30),
    REC_PROBLEM(AlertGroup.CAMERA, Severity.CRITICAL, "Проблемы записи", "Запись остановилась не по команде пользователя или не стартовала.", dataLoss = true, repeatSec = 30),
    AUDIO_LOSS(AlertGroup.CAMERA, Severity.CRITICAL, "Потеря звука", "Источник звука недоступен: в файле будет тишина или не будет звука.", dataLoss = true, repeatSec = 60),
    AV_SYNC(AlertGroup.CAMERA, Severity.WARNING, "Рассинхронизация звука и видео", "Разница стартов или дрейф звука и видео больше допустимого."),
    PARAM_UNAVAILABLE(AlertGroup.CAMERA, Severity.WARNING, "Выбранные параметры недоступны", "Камера не приняла выбранный режим и применила ближайший."),

    TIP(AlertGroup.INFO, Severity.INFO, "Подсказки", "Короткие советы по работе с приложением.", mode = AlertMode.ONCE),
    RECOMMENDATION(AlertGroup.INFO, Severity.INFO, "Рекомендации", "Предложения по настройкам; применяются только по вашему согласию.", mode = AlertMode.ONCE),
    TUTORIAL(AlertGroup.INFO, Severity.INFO, "Обучающие сообщения", "Пояснения к функциям при первом использовании.", mode = AlertMode.ONCE),
    SETTING_CHANGED(AlertGroup.INFO, Severity.INFO, "Изменение настроек", "Сообщения о том, что настройка изменена или применена.", mode = AlertMode.CENTER_ONLY),
    WHATS_NEW(AlertGroup.INFO, Severity.INFO, "Новые возможности", "Сведения о новых функциях после обновления.", mode = AlertMode.ONCE)
}

/** Ключи хранилища и правила проверки значений (подключаются к SettingsSchema). */
object AlertKeys {
    const val HISTORY = "n28.history"
    const val RETENTION_DAYS = "n28.retention_days"
    fun key(t: AlertType, f: String) = "n28.${t.name}.$f"

    fun defOverPreview(t: AlertType) = t.group != AlertGroup.INFO
    fun defSound(t: AlertType) = t.severity == Severity.CRITICAL
    fun defVibration(t: AlertType) = t.severity == Severity.CRITICAL

    val rules: Map<String, Rule> = LinkedHashMap<String, Rule>().also { m ->
        m[RETENTION_DAYS] = Rule.IntR(0, 3650, 30)
        val names = AlertMode.values().map { it.name }.toSet()
        for (t in AlertType.values()) {
            m[key(t, "mode")] = Rule.TextR(t.mode.name, names)
            m[key(t, "repeat")] = Rule.IntR(0, 86_400, t.repeatSec)
            t.threshold?.let { th -> m[key(t, "thr")] = Rule.FloatR(th.min, th.max, th.default) }
            m[key(t, "over")] = Rule.BoolR(defOverPreview(t))
            m[key(t, "sound")] = Rule.BoolR(defSound(t))
            m[key(t, "vib")] = Rule.BoolR(defVibration(t))
            m[key(t, "seen")] = Rule.BoolR(false)
        }
    }
}

/** Тип уведомления по тексту сообщения движка (Camera2, кодек, файл): правила в порядке убывания специфичности. */
object AlertClassifier {
    fun classify(msg: String): AlertType {
        val m = msg.lowercase()
        return when {
            m.contains("звук потерян") || m.contains("звука") && m.contains("потер") -> AlertType.AUDIO_LOSS
            m.contains("файл не сохранён") || m.contains("не удалось записать") -> AlertType.WRITE_ERROR
            m.contains("нет доступа к памяти") || m.contains("доступа к хранилищу") -> AlertType.STORAGE_ACCESS
            m.contains("поверхность кодека") || m.contains("кодек не создан") || m.startsWith("видео:") -> AlertType.ENCODE_PROBLEM
            m.contains("старт записи") || m.contains("конфигурацию записи") || m.contains("запись остановлена") -> AlertType.REC_PROBLEM
            m.contains("ошибка камеры") || m.contains("запрос камеры") -> AlertType.CAMERA_ERROR
            m.contains("недоступен") || m.contains("не отдаёт") || m.contains("не заявляет") || m.contains("не включить") || m.contains("гироскоп") -> AlertType.PARAM_UNAVAILABLE
            else -> AlertType.CAMERA_ERROR
        }
    }
}

/** Что показать на экране для одного события. [banner] false — только запись в центре уведомлений. */
class AlertDelivery(val entry: AlertCenter.Entry, val banner: Boolean, val sound: Boolean, val vibrate: Boolean, val overPreview: Boolean)

/**
 * Единый центр уведомлений: настройки по каждому типу, задержка повторов, «один раз», подтверждение отключения опасных
 * предупреждений, история с фильтрами и сроком хранения. Не знает ни о камере, ни о настройках записи: менять параметры
 * съёмки он не может (пишет только ключи «n28.*»). Мониторинг ведётся независимо — см. [AlertRules].
 */
class AlertCenter(private val store: KeyValueStore) {
    data class Config(val mode: AlertMode, val repeatSec: Int, val threshold: Float?, val overPreview: Boolean, val sound: Boolean, val vibration: Boolean)
    data class Entry(val id: Long, val type: AlertType, val severity: Severity, val text: String,
                     val firstMs: Long, val lastMs: Long, val count: Int, val read: Boolean)
    sealed class SetResult {
        object Ok : SetResult()
        class NeedsConfirm(val why: String) : SetResult()
        class Invalid(val why: String) : SetResult()
    }

    private val entries = ArrayList<Entry>()
    private val lastShown = HashMap<String, Long>()
    private val keyEntry = HashMap<String, Long>()
    private var dirty = false
    private var nextId = 1L
    val maxEntries = 500

    init { load() }

    // ------------------------------------------------------------ настройки

    fun config(t: AlertType, all: Map<String, Any?> = store.all()): Config {
        val modeName = all[AlertKeys.key(t, "mode")] as? String
        val mode = AlertMode.values().firstOrNull { it.name == modeName } ?: t.mode
        val rep = (all[AlertKeys.key(t, "repeat")] as? Int)?.takeIf { it in 0..86_400 } ?: t.repeatSec
        val thr = t.threshold?.let { th -> (all[AlertKeys.key(t, "thr")] as? Float)?.takeIf { !it.isNaN() && it in th.min..th.max } ?: th.default }
        val over = all[AlertKeys.key(t, "over")] as? Boolean ?: AlertKeys.defOverPreview(t)
        val snd = all[AlertKeys.key(t, "sound")] as? Boolean ?: AlertKeys.defSound(t)
        val vib = all[AlertKeys.key(t, "vib")] as? Boolean ?: AlertKeys.defVibration(t)
        return Config(mode, rep, thr, over, snd, vib)
    }

    fun threshold(t: AlertType): Float? = config(t).threshold

    /** Отключение показа события, способного привести к потере записи, требует [confirmed] = true. */
    fun setMode(t: AlertType, m: AlertMode, confirmed: Boolean = false): SetResult {
        if (t.dataLoss && (m == AlertMode.OFF || m == AlertMode.CENTER_ONLY) && !confirmed)
            return SetResult.NeedsConfirm("«${t.title}» — событие, из-за которого запись может быть потеряна или оборваться. Если отключить показ, вы можете не заметить проблему вовремя. Мониторинг и защита файла продолжат работать.")
        store.commit(mapOf(AlertKeys.key(t, "mode") to m.name))
        return SetResult.Ok
    }

    fun setRepeat(t: AlertType, sec: Int): SetResult {
        if (sec !in 0..86_400) return SetResult.Invalid("задержка от 0 до 86400 с")
        store.commit(mapOf(AlertKeys.key(t, "repeat") to sec)); return SetResult.Ok
    }

    fun setThreshold(t: AlertType, v: Float): SetResult {
        val th = t.threshold ?: return SetResult.Invalid("у этого уведомления нет порога")
        if (v.isNaN() || v < th.min || v > th.max) return SetResult.Invalid("допустимо ${th.min}…${th.max} ${th.unit}")
        store.commit(mapOf(AlertKeys.key(t, "thr") to v)); return SetResult.Ok
    }

    fun setFlag(t: AlertType, field: String, v: Boolean): SetResult {
        if (field != "over" && field != "sound" && field != "vib") return SetResult.Invalid("неизвестное поле")
        store.commit(mapOf(AlertKeys.key(t, field) to v)); return SetResult.Ok
    }

    /** Вернуть настройки типа к значениям по умолчанию и снова разрешить «один раз». */
    fun resetType(t: AlertType) {
        val rm = HashSet<String>()
        for (f in listOf("mode", "repeat", "thr", "over", "sound", "vib", "seen")) rm.add(AlertKeys.key(t, f))
        store.commit(emptyMap(), rm)
    }

    fun retentionDays(): Int = (store.all()[AlertKeys.RETENTION_DAYS] as? Int)?.takeIf { it in 0..3650 } ?: 30
    fun setRetentionDays(d: Int) { if (d in 0..3650) store.commit(mapOf(AlertKeys.RETENTION_DAYS to d)) }

    // ------------------------------------------------------------ приём событий

    /**
     * Принять событие. null — показ отключён пользователем (запись в центр не ведётся). Одинаковые события внутри окна
     * повтора склеиваются в одну запись со счётчиком, баннер повторно не показывается раньше, чем через [Config.repeatSec].
     */
    fun post(t: AlertType, text: String, severity: Severity = t.severity, nowMs: Long = System.currentTimeMillis(), key: String = t.name): AlertDelivery? {
        val all = store.all()
        val c = config(t, all)
        if (c.mode == AlertMode.OFF) return null
        val cd = c.repeatSec * 1000L
        prune(nowMs)

        val kid = keyEntry[key]
        val idx = if (kid != null) entries.indexOfFirst { it.id == kid } else -1
        val entry: Entry
        if (idx >= 0 && nowMs - entries[idx].lastMs < cd) {
            val e = entries[idx]
            entry = e.copy(text = text, severity = if (severity.rank > e.severity.rank) severity else e.severity, lastMs = nowMs, count = e.count + 1)
            entries[idx] = entry
            dirty = true
        } else {
            entry = Entry(nextId++, t, severity, text, nowMs, nowMs, 1, false)
            entries.add(entry)
            keyEntry[key] = entry.id
            while (entries.size > maxEntries) entries.removeAt(0)
            persist()
        }

        val seen = all[AlertKeys.key(t, "seen")] == true
        val wants = when (c.mode) {
            AlertMode.ALWAYS, AlertMode.SILENT -> true
            AlertMode.CRITICAL_ONLY -> severity == Severity.CRITICAL
            AlertMode.ONCE -> !seen
            AlertMode.CENTER_ONLY, AlertMode.OFF -> false
        }
        val last = lastShown[key]
        val banner = wants && (last == null || nowMs - last >= cd)
        if (banner) {
            lastShown[key] = nowMs
            if (c.mode == AlertMode.ONCE) store.commit(mapOf(AlertKeys.key(t, "seen") to true))
        }
        val audible = banner && c.mode != AlertMode.SILENT
        return AlertDelivery(entry, banner, audible && c.sound, audible && c.vibration, c.overPreview)
    }

    // ------------------------------------------------------------ центр уведомлений

    fun list(group: AlertGroup? = null, severity: Severity? = null, unreadOnly: Boolean = false, query: String = ""): List<Entry> {
        val q = query.trim().lowercase()
        return entries.asReversed().filter { e ->
            (group == null || e.type.group == group) && (severity == null || e.severity == severity) && (!unreadOnly || !e.read) &&
                (q.isEmpty() || e.text.lowercase().contains(q) || e.type.title.lowercase().contains(q) || e.type.about.lowercase().contains(q))
        }
    }

    fun unread(): Int = entries.count { !it.read }
    fun markRead(id: Long) { val i = entries.indexOfFirst { it.id == id }; if (i >= 0 && !entries[i].read) { entries[i] = entries[i].copy(read = true); persist() } }
    fun markAllRead() { var ch = false; for (i in entries.indices) if (!entries[i].read) { entries[i] = entries[i].copy(read = true); ch = true }; if (ch) persist() }
    fun clear() { entries.clear(); lastShown.clear(); keyEntry.clear(); persist() }

    /** Убирает записи старше срока хранения (0 — хранить бессрочно). */
    fun prune(nowMs: Long = System.currentTimeMillis()) {
        val d = retentionDays()
        if (d == 0) return
        val lim = nowMs - d * 86_400_000L
        if (entries.removeAll { it.lastMs < lim }) dirty = true
    }

    fun flushIfDirty() { if (dirty) persist() }

    // ------------------------------------------------------------ хранение

    private fun persist() {
        val sb = StringBuilder()
        for (e in entries) {
            sb.append(e.id).append('\t').append(e.type.name).append('\t').append(e.severity.name).append('\t')
                .append(e.firstMs).append('\t').append(e.lastMs).append('\t').append(e.count).append('\t')
                .append(if (e.read) 1 else 0).append('\t').append(Codec28.esc(e.text)).append('\n')
        }
        store.commit(mapOf(AlertKeys.HISTORY to sb.toString()))
        dirty = false
    }

    private fun load() {
        entries.clear()
        val raw = store.all()[AlertKeys.HISTORY] as? String ?: return
        for (line in raw.split('\n')) {
            if (line.isEmpty()) continue
            val p = line.split('\t')
            if (p.size < 8) continue
            try {
                val t = AlertType.values().firstOrNull { it.name == p[1] } ?: continue
                val s = Severity.values().firstOrNull { it.name == p[2] } ?: continue
                entries.add(Entry(p[0].toLong(), t, s, Codec28.unesc(p[7]), p[3].toLong(), p[4].toLong(), p[5].toInt(), p[6] == "1"))
            } catch (e: NumberFormatException) { /* повреждённая строка пропускается, остальные читаются */ }
        }
        nextId = (entries.maxOfOrNull { it.id } ?: 0L) + 1
    }
}

// ---------------------------------------------------------------- мониторинг: не зависит от того, включены ли уведомления

data class MonitorInput(
    val thermalStatus: Int?, val thermalHeadroom: Float?, val batteryTempC: Float?,
    val cpuPercentOfCore: Float?, val gpuLoadPercent: Float?,
    val ramAvailMb: Long?, val lowMemory: Boolean,
    val freeStorageMb: Long?, val recording: Boolean, val dropRatioPercent: Float?
)

data class Finding(val type: AlertType, val severity: Severity, val text: String)

object AlertRules {
    /**
     * Находит текущие проблемы по реальным показателям. Недоступный показатель (null) не создаёт событий и не выдумывается.
     * Функция ничего не знает о настройках уведомлений: даже если все предупреждения отключены, список остаётся прежним,
     * а диагностика показывает те же факты. [thr] даёт порог типа (из настроек пользователя или по умолчанию).
     */
    fun evaluate(m: MonitorInput, thr: (AlertType) -> Float?): List<Finding> {
        val out = ArrayList<Finding>()
        val st = m.thermalStatus ?: 0
        if (st >= 3) {
            out.add(Finding(AlertType.OVERHEAT, if (st >= 5) Severity.CRITICAL else Severity.WARNING,
                "Телефон сильно нагрелся (${thermalName(st)}). Параметры записи не менялись — при желании снизьте частоту кадров или разрешение (Меню → Диагностика). Система может сама ограничить производительность."))
        } else {
            val tThr = thr(AlertType.TEMP_HIGH) ?: AlertType.TEMP_HIGH.threshold!!.default
            val bt = m.batteryTempC
            if (st == 2 || (bt != null && bt >= tThr))
                out.add(Finding(AlertType.TEMP_HIGH, Severity.WARNING, "Повышенная температура: " + (if (bt != null) "батарея %.1f °C".format(bt) else thermalName(st)) + ", статус системы — ${thermalName(m.thermalStatus)}"))
        }
        m.cpuPercentOfCore?.let { v ->
            val th = thr(AlertType.CPU_HIGH) ?: AlertType.CPU_HIGH.threshold!!.default
            if (v >= th) out.add(Finding(AlertType.CPU_HIGH, Severity.WARNING, "Высокая нагрузка CPU: %.0f %% одного ядра (порог %.0f)".format(v, th)))
            Unit
        }
        m.gpuLoadPercent?.let { v ->
            val th = thr(AlertType.GPU_HIGH) ?: AlertType.GPU_HIGH.threshold!!.default
            if (v >= th) out.add(Finding(AlertType.GPU_HIGH, Severity.WARNING, "Высокая нагрузка GPU: %.0f %%".format(v)))
            Unit
        }
        val ramTh = thr(AlertType.LOW_RAM) ?: AlertType.LOW_RAM.threshold!!.default
        if (m.lowMemory || (m.ramAvailMb != null && m.ramAvailMb < ramTh))
            out.add(Finding(AlertType.LOW_RAM, Severity.WARNING, "Мало свободной памяти" + (m.ramAvailMb?.let { ": $it МБ" } ?: "") + ". Система может закрыть приложение; закройте другие программы."))
        m.thermalHeadroom?.let { h ->
            val th = thr(AlertType.PERF_DROP) ?: AlertType.PERF_DROP.threshold!!.default
            if (h >= th) out.add(Finding(AlertType.PERF_DROP, Severity.WARNING, "Система вскоре может снизить производительность (прогноз %.2f, 1.0 — начало ограничений)".format(h)))
            Unit
        }
        m.freeStorageMb?.let { f ->
            val full = thr(AlertType.STORAGE_FULL) ?: AlertType.STORAGE_FULL.threshold!!.default
            val low = thr(AlertType.STORAGE_LOW) ?: AlertType.STORAGE_LOW.threshold!!.default
            if (f < full) {
                out.add(Finding(AlertType.STORAGE_FULL, Severity.CRITICAL, "Свободно всего $f МБ: при 200 МБ запись остановится штатно, файл сохранится"))
            } else if (f < low) {
                out.add(Finding(AlertType.STORAGE_LOW, Severity.WARNING, "Свободно $f МБ"))
            } else {
                // места достаточно
            }
            Unit
        }
        if (m.recording) m.dropRatioPercent?.let { d ->
            val th = thr(AlertType.FRAME_DROP) ?: AlertType.FRAME_DROP.threshold!!.default
            if (d >= th) out.add(Finding(AlertType.FRAME_DROP, Severity.WARNING, "Потеряно %.2f %% кадров (порог %.2f)".format(d, th)))
            Unit
        }
        return out
    }
}
