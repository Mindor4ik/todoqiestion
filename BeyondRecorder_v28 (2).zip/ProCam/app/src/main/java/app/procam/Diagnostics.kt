package app.procam

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Данные движка для диагностики — только реальные измерения и состояния. */
data class EngineFacts(
    val cameraState: CameraState, val recordingState: RecordingState, val processingState: ProcessingState,
    val activeCameraId: String, val activeCameraLabel: String,
    val sizeText: String, val selectedFps: Int, val codecLabel: String, val encoderName: String?, val mode: String, val route: String,
    val measuredCameraFps: Float, val captureCompleted: Long, val captureFailed: Long, val bufferLost: Long,
    val rec: RecStats?, val lastRec: RecStats?, val glToEncoder: Long?, val glSwapFailures: Long?, val glDrawMs: Float?,
    val transitions: List<String>, val violations: List<String>, val errors: List<String>
)

object DiagnosticsReport {
    private fun mb(v: Long) = if (v >= 1024) "%.1f ГБ".format(v / 1024f) else "$v МБ"
    private fun na() = "недоступно"
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun device(p: DeviceProfile?): String {
        if (p == null) return "профиль устройства ещё собирается…"
        val sb = StringBuilder()
        sb.append("${p.manufacturer} ${p.model} (${p.device})\n")
        sb.append("Android SDK ${p.sdk} · ${p.abi}\n")
        sb.append("Процессор/SoC: ${p.soc.ifBlank { na() }}\n")
        sb.append("Память: ${mb(p.ramTotalMb)} всего; лимит приложения ${p.memoryClassMb} МБ (large ${p.largeMemoryClassMb} МБ)\n")
        sb.append("GPU: ${p.glRenderer} (${p.glVendor})\n")
        sb.append("OpenGL: ${p.glEsVersion}; рендер во float-текстуры: ${if (p.glFloatRender) "есть" else "нет"}\n")
        sb.append("Датчики: " + p.sensors.entries.joinToString(", ") { "${it.key} ${if (it.value) "✓" else "✗"}" } + "\n")
        sb.append("Thermal API: ${if (p.thermalApi) "есть" else na()}")
        return sb.toString()
    }

    fun cameras(p: DeviceProfile?, activeId: String): String {
        if (p == null) return "…"
        return p.cameras.joinToString("\n\n") { c ->
            val mark = if (c.id == activeId) "▶ " else ""
            "${mark}Камера ${c.id} · ${c.facing} · ${c.hardwareLevel}\n" +
                "  фокусное ${"%.1f".format(c.focalMm)} мм · сенсор ${c.sensorMm} · макс. размер ${c.maxSize} · до ${c.maxFps} к/с · зум ${c.zoomRange}\n" +
                "  " + listOfNotNull(
                    if (c.logicalMulti) "логическая (физические: ${c.physicalIds.joinToString()})" else null,
                    if (c.hwStab) "видеостабилизация" else null, if (c.ois) "OIS" else null,
                    if (c.hwNrModes) "NR ISP" else null, if (c.hwLog) "аппаратная LOG-кривая" else null,
                    if (c.hlg10) "HLG10" else null, if (c.manualSensor) "ручной сенсор" else null
                ).ifEmpty { listOf("базовые возможности") }.joinToString(" · ")
        }
    }

    fun codecs(p: DeviceProfile?): String {
        if (p == null) return "…"
        if (p.codecs.isEmpty()) return "видеокодеров не найдено"
        return p.codecs.joinToString("\n") {
            "${it.name} · ${it.mime.removePrefix("video/")} · ${if (it.hardware) "аппаратный" else "программный"} · до ${it.maxWidth}×${it.maxHeight}, ${it.maxFps} к/с, ${it.maxBitrateMbps} Мбит/с${if (it.tenBit) " · 10-bit" else ""}"
        }
    }

    fun plans(plans: List<FeaturePlan>): String = plans.joinToString("\n") { "• ${it.feature}: ${it.path.label} — ${it.note}" }

    fun engine(f: EngineFacts): String {
        val sb = StringBuilder()
        sb.append("Камера: ${f.cameraState} · Запись: ${f.recordingState} · Обработка: ${f.processingState}\n")
        sb.append("Активная камера: ${f.activeCameraId} (${f.activeCameraLabel})\n")
        sb.append("Выбрано: ${f.sizeText} @ ${f.selectedFps} к/с · ${f.codecLabel} · режим ${f.mode}\n")
        sb.append("Маршрут: ${f.route}\n")
        sb.append("Кодек (энкодер): ${f.encoderName ?: na()}\n")
        sb.append("Камера отдаёт сейчас: ${if (f.measuredCameraFps > 0f) "%.1f к/с".format(f.measuredCameraFps) else na()} " +
            "(выбрано ${f.selectedFps})\n")
        sb.append("Camera2: кадров ${f.captureCompleted}, потеряно ${f.captureFailed}, потеряно буферов ${f.bufferLost}")
        if (f.glToEncoder != null) sb.append("\nGL → кодек: ${f.glToEncoder} кадров, ошибок подачи ${f.glSwapFailures}, CPU-время кадра ≈ ${"%.1f".format(f.glDrawMs ?: 0f)} мс (время GPU недоступно)")
        return sb.toString()
    }

    fun recording(live: RecStats?, last: RecStats?, selectedFps: Int): String {
        fun fmt(s: RecStats, title: String): String {
            val sb = StringBuilder(title).append('\n')
            sb.append("видео: ${s.videoFrames} кадр. за ${"%.1f".format(s.videoSeconds)} с → фактически ${"%.2f".format(s.actualFps)} к/с (выбрано $selectedFps)\n")
            sb.append("пропущено кадров (по разрывам таймстампов): ${s.droppedVideo}, максимальный разрыв ${"%.0f".format(s.maxVideoGapMs)} мс\n")
            sb.append("звук: ${s.audioFrames} пакетов, ${"%.1f".format(s.audioSeconds)} с\n")
            sb.append("начало видео относительно звука: ${s.avStartOffsetMs?.let { "%+.0f мс".format(it) } ?: na()}\n")
            sb.append("исправлений таймстампов: ${s.ptsCorrections}; записано ${"%.1f".format(s.bytes / 1048576.0)} МБ")
            return sb.toString()
        }
        return when {
            live != null -> fmt(live, "Идёт запись:")
            last != null -> fmt(last, "Последняя запись:")
            else -> "записей в этом запуске ещё не было"
        }
    }

    fun resources(r: ResourceSnapshot?): String {
        if (r == null) return "…"
        val sb = StringBuilder()
        sb.append("CPU приложения: ${r.cpuProcessPercentOfCore?.let { "%.0f%% одного ядра (ядер: ${r.cpuCores})".format(it) } ?: "измеряется…"}\n")
        sb.append("CPU системы: ${r.cpuSystemPercent?.let { "%.0f%%".format(it) } ?: na()}\n")
        sb.append("GPU загрузка: ${r.gpuLoad?.let { "%.0f%%".format(it) } ?: na() + " (Android не даёт приложениям)"}\n")
        sb.append("RAM: свободно ${mb(r.ramAvailMb)} из ${mb(r.ramTotalMb)}${if (r.lowMemory) " ⚠ мало памяти" else ""}; приложение ≈ ${r.appPssMb?.let { "$it МБ" } ?: na()}\n")
        sb.append("Thermal: ${r.thermalLabel}${r.thermalHeadroom?.let { " · запас до троттлинга ${"%.2f".format(it)} (1.0 — порог)" } ?: ""}\n")
        sb.append("Батарея: ${r.batteryTempC?.let { "%.1f °C".format(it) } ?: na()}, ${r.batteryPercent?.let { "$it%" } ?: na()}")
        return sb.toString()
    }

    fun states(f: EngineFacts): String {
        val sb = StringBuilder()
        if (f.violations.isEmpty()) sb.append("Недопустимых переходов состояний не было\n") else {
            sb.append("⚠ Недопустимые переходы:\n"); f.violations.takeLast(5).forEach { sb.append("  $it\n") }
        }
        sb.append("Последние переходы:\n")
        if (f.transitions.isEmpty()) sb.append("  —") else f.transitions.takeLast(8).forEach { sb.append("  $it\n") }
        return sb.toString().trimEnd()
    }

    fun errors(f: EngineFacts): String = if (f.errors.isEmpty()) "ошибок камеры и записи в этом запуске нет" else f.errors.takeLast(12).joinToString("\n")

    fun fmtChange(c: StateMachine.Change<*>): String = "${timeFmt.format(Date(c.atMs))}  ${c.from} → ${c.to}${if (c.reason.isNotEmpty()) " (${c.reason})" else ""}"
}
