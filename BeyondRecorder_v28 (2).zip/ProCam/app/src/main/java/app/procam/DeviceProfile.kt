package app.procam

import android.app.ActivityManager
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES30
import android.os.Build

/**
 * Реальные характеристики устройства. Профиль ничего не запрещает: он только описывает железо и
 * помогает [FeatureRouter] выбрать способ реализации функции (аппаратный / программный на GPU / недоступно).
 */
data class CameraProfile(
    val id: String, val facing: String, val hardwareLevel: String,
    val focalMm: Float, val sensorMm: String, val maxFps: Int, val maxSize: String,
    val logicalMulti: Boolean, val physicalIds: List<String>,
    val hwStab: Boolean, val ois: Boolean, val hwNrModes: Boolean,
    val hwLog: Boolean, val hlg10: Boolean, val manualSensor: Boolean, val zoomRange: String
)

data class CodecProfile(
    val name: String, val mime: String, val hardware: Boolean,
    val maxWidth: Int, val maxHeight: Int, val maxFps: Int, val maxBitrateMbps: Int, val tenBit: Boolean
)

data class DeviceProfile(
    val manufacturer: String, val model: String, val device: String, val sdk: Int, val soc: String, val abi: String,
    val ramTotalMb: Long, val memoryClassMb: Int, val largeMemoryClassMb: Int,
    val glEsVersion: String, val glRenderer: String, val glVendor: String, val glFloatRender: Boolean,
    val sensors: Map<String, Boolean>,
    val cameras: List<CameraProfile>,
    val codecs: List<CodecProfile>,
    val thermalApi: Boolean
) {
    val hasGyro get() = sensors["гироскоп"] == true
}

object DeviceProfiler {
    @Volatile private var cached: DeviceProfile? = null

    /** Собирается один раз (запросы к камерам и кодекам небыстрые) — вызывать не из UI-потока. */
    @Synchronized
    fun collect(ctx: Context): DeviceProfile {
        cached?.let { return it }
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val gl = probeGl()
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        fun has(t: Int) = sm.getDefaultSensor(t) != null
        val sensors = linkedMapOf(
            "гироскоп" to has(Sensor.TYPE_GYROSCOPE),
            "акселерометр" to has(Sensor.TYPE_ACCELEROMETER),
            "гравитация" to has(Sensor.TYPE_GRAVITY),
            "вектор вращения" to has(Sensor.TYPE_ROTATION_VECTOR),
            "магнитометр" to has(Sensor.TYPE_MAGNETIC_FIELD)
        )
        val p = DeviceProfile(
            manufacturer = Build.MANUFACTURER, model = Build.MODEL, device = Build.DEVICE, sdk = Build.VERSION.SDK_INT,
            soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "?",
            ramTotalMb = mi.totalMem / (1024 * 1024), memoryClassMb = am.memoryClass, largeMemoryClassMb = am.largeMemoryClass,
            glEsVersion = gl.version, glRenderer = gl.renderer, glVendor = gl.vendor, glFloatRender = gl.floatRender,
            sensors = sensors, cameras = cameras(ctx), codecs = codecs(),
            thermalApi = Build.VERSION.SDK_INT >= 29
        )
        cached = p
        return p
    }

    private class GlInfo(val version: String, val renderer: String, val vendor: String, val floatRender: Boolean)

    /** Короткий офскринный контекст ES 3.0: реальные строки GPU и поддержка рендера во float-текстуры. */
    private fun probeGl(): GlInfo {
        var dpy = EGL14.EGL_NO_DISPLAY
        var ctx = EGL14.EGL_NO_CONTEXT
        var surf = EGL14.EGL_NO_SURFACE
        try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val v = IntArray(2)
            if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) return GlInfo("недоступно", "недоступно", "недоступно", false)
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            val attr = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, 0x40 /* EGL_OPENGL_ES3_BIT */, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_NONE
            )
            if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0) || n[0] == 0) return GlInfo("ES 3.0 не поддерживается", "недоступно", "недоступно", false)
            ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
            surf = EGL14.eglCreatePbufferSurface(dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
            if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) return GlInfo("недоступно", "недоступно", "недоступно", false)
            val ext = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: ""
            return GlInfo(
                GLES30.glGetString(GLES30.GL_VERSION) ?: "?", GLES30.glGetString(GLES30.GL_RENDERER) ?: "?",
                GLES30.glGetString(GLES30.GL_VENDOR) ?: "?",
                ext.contains("EXT_color_buffer_float") || ext.contains("EXT_color_buffer_half_float")
            )
        } catch (e: Throwable) {
            return GlInfo("недоступно", "недоступно", "недоступно", false)
        } finally {
            try {
                if (dpy != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf)
                    if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                    EGL14.eglTerminate(dpy)
                }
            } catch (e: Throwable) { }
        }
    }

    private fun cameras(ctx: Context): List<CameraProfile> {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val out = ArrayList<CameraProfile>()
        for (id in cm.cameraIdList) try {
            val ch = cm.getCameraCharacteristics(id)
            val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toSet() ?: emptySet()
            val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "фронтальная"
                CameraCharacteristics.LENS_FACING_BACK -> "тыловая"
                else -> "внешняя"
            }
            val level = when (ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
                else -> "?"
            }
            val phys = if (Build.VERSION.SDK_INT >= 28) ch.physicalCameraIds.toList() else emptyList()
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val big = map?.getOutputSizes(android.graphics.SurfaceTexture::class.java)?.maxByOrNull { it.width.toLong() * it.height }
            val fpsMax = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.maxOfOrNull { it.upper } ?: 0
            val ss = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val zr = if (Build.VERSION.SDK_INT >= 30) ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null
            val nr = ch.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)?.toSet() ?: emptySet()
            val modes = ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.toSet() ?: emptySet()
            out.add(CameraProfile(
                id = id, facing = facing, hardwareLevel = level,
                focalMm = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f,
                sensorMm = if (ss != null) "%.1f×%.1f мм".format(ss.width, ss.height) else "—",
                maxFps = fpsMax, maxSize = if (big != null) "${big.width}×${big.height}" else "—",
                logicalMulti = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA),
                physicalIds = phys,
                hwStab = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true,
                ois = (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.size ?: 0) > 1,
                hwNrModes = nr.contains(CameraMetadata.NOISE_REDUCTION_MODE_FAST) || nr.contains(CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY),
                hwLog = modes.contains(CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE) && (ch.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS) ?: 0) >= 16,
                hlg10 = Build.VERSION.SDK_INT >= 33 &&
                    ch.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)?.supportedProfiles?.contains(android.hardware.camera2.params.DynamicRangeProfiles.HLG10) == true,
                manualSensor = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR),
                zoomRange = if (zr != null) "%.1f–%.1f×".format(zr.lower, zr.upper) else "—"
            ))
        } catch (e: Exception) { }
        return out
    }

    private fun codecs(): List<CodecProfile> {
        val out = ArrayList<CodecProfile>()
        val wanted = listOf("video/avc", "video/hevc", "video/av01")
        for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
            if (!info.isEncoder) continue
            for (mime in info.supportedTypes) {
                if (wanted.none { it.equals(mime, true) }) continue
                try {
                    val caps = info.getCapabilitiesForType(mime)
                    val v = caps.videoCapabilities ?: continue
                    val ten = caps.profileLevels.any {
                        it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 ||
                            it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10 ||
                            it.profile == MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10
                    }
                    out.add(CodecProfile(
                        name = info.name, mime = mime,
                        hardware = if (Build.VERSION.SDK_INT >= 29) info.isHardwareAccelerated else !info.name.startsWith("OMX.google") && !info.name.startsWith("c2.android"),
                        maxWidth = v.supportedWidths.upper, maxHeight = v.supportedHeights.upper,
                        maxFps = v.supportedFrameRates.upper, maxBitrateMbps = v.bitrateRange.upper / 1_000_000, tenBit = ten
                    ))
                } catch (e: Exception) { }
            }
        }
        return out
    }
}

// ---------------------------------------------------------------- выбор способа реализации

enum class ImplPath(val label: String) {
    Hardware("аппаратно"), SoftwareGpu("программно (GPU)"), SoftwareCpu("программно (CPU)"), Unavailable("недоступно")
}

data class FeaturePlan(val feature: String, val path: ImplPath, val note: String)

/** Факты, от которых зависит выбор (чистые данные — проверяются юнит-тестами). */
data class RouteFacts(
    val hwStab: Boolean, val hasGyro: Boolean, val hwNrModes: Boolean, val hwLog: Boolean,
    val hlg10Native: Boolean, val hevcMain10: Boolean, val gles3: Boolean, val gateAvailable: Boolean
)

/**
 * Для каждой функции выбирает способ реализации. Ничего не скрывает и не запрещает:
 * «Недоступно» ставится только если нет ни аппаратного, ни программного пути, с честной причиной.
 */
object FeatureRouter {
    fun plan(f: RouteFacts): List<FeaturePlan> = listOf(
        when {
            f.hwStab -> FeaturePlan("Стабилизация", ImplPath.Hardware, "видеостабилизация камеры; дополнительно доступна EIS v2 по гироскопу")
            f.hasGyro && f.gles3 -> FeaturePlan("Стабилизация", ImplPath.SoftwareGpu, "аппаратной нет — EIS v2 по гироскопу в шейдере")
            else -> FeaturePlan("Стабилизация", ImplPath.Unavailable,
                if (!f.hasGyro) "нет гироскопа, а программной стабилизации по одному изображению в приложении нет" else "нужен OpenGL ES 3.0")
        },
        when {
            f.hwNrModes && f.gles3 -> FeaturePlan("Шумоподавление", ImplPath.Hardware, "шумоподавление ISP; поверх можно включить NR v3 (GPU)")
            f.hwNrModes -> FeaturePlan("Шумоподавление", ImplPath.Hardware, "шумоподавление ISP")
            f.gles3 -> FeaturePlan("Шумоподавление", ImplPath.SoftwareGpu, "режимов ISP нет — NR v3 (временное + пространственное) в шейдере")
            else -> FeaturePlan("Шумоподавление", ImplPath.Unavailable, "нет режимов ISP и нет OpenGL ES 3.0")
        },
        when {
            f.hwLog -> FeaturePlan("LOG", ImplPath.Hardware, "кривая тональности камеры (может отличаться от паспортных кривых)")
            f.gles3 -> FeaturePlan("LOG", ImplPath.SoftwareGpu, "эмуляция кривой в шейдере — это не сенсорный LOG")
            else -> FeaturePlan("LOG", ImplPath.Unavailable, "нужен OpenGL ES 3.0")
        },
        when {
            f.hlg10Native && f.hevcMain10 -> FeaturePlan("HLG", ImplPath.Hardware, "нативный 10-бит HLG10 от камеры в HEVC Main10")
            f.gles3 -> FeaturePlan("HLG", ImplPath.SoftwareGpu, "эмуляция HLG в шейдере (${if (f.hevcMain10) "10" else "8"}-bit), это не нативный HLG10")
            else -> FeaturePlan("HLG", ImplPath.Unavailable, "нужен OpenGL ES 3.0")
        },
        if (f.gles3) FeaturePlan("LUT (.cube)", ImplPath.SoftwareGpu, "3D-текстура в шейдере, можно запекать в файл")
        else FeaturePlan("LUT (.cube)", ImplPath.Unavailable, "нужен OpenGL ES 3.0 (CPU-запись LUT в видео не реализована)"),
        if (f.gles3) FeaturePlan("Зебра / ложные цвета / пикинг / гистограмма", ImplPath.SoftwareGpu, "анализ кадра в шейдере")
        else FeaturePlan("Зебра / ложные цвета / пикинг / гистограмма", ImplPath.Unavailable, "нужен OpenGL ES 3.0"),
        if (f.hevcMain10) FeaturePlan("10-bit запись", ImplPath.Hardware, "HEVC Main10 кодек телефона")
        else FeaturePlan("10-bit запись", ImplPath.Unavailable, "кодек телефона не заявляет HEVC Main10"),
        if (f.gateAvailable) FeaturePlan("Open Gate", ImplPath.Hardware, "камера отдаёт кадр всей активной области сенсора")
        else FeaturePlan("Open Gate", ImplPath.Unavailable, "камера не заявляет размеров всей области сенсора (физика прошивки камеры)")
    )
}
