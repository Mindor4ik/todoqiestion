package app.procam

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Кадр яркости 0..1, строки сверху вниз. */
class Gray(val w: Int, val h: Int, val d: FloatArray) {
    init { require(d.size == w * h) }
    fun at(x: Int, y: Int): Float = d[y * w + x]
    /** Билинейная выборка; координаты центров пикселей. Вне кадра — ближайший край (используйте inside() для проверки). */
    fun bil(x: Float, y: Float): Float {
        val xc = x.coerceIn(0f, (w - 1).toFloat()); val yc = y.coerceIn(0f, (h - 1).toFloat())
        val x0 = min(xc.toInt(), w - 2).coerceAtLeast(0); val y0 = min(yc.toInt(), h - 2).coerceAtLeast(0)
        val fx = xc - x0; val fy = yc - y0
        val x1 = min(x0 + 1, w - 1); val y1 = min(y0 + 1, h - 1)
        val a = d[y0 * w + x0]; val b = d[y0 * w + x1]; val c = d[y1 * w + x0]; val e = d[y1 * w + x1]
        return (a + (b - a) * fx) * (1 - fy) + (c + (e - c) * fx) * fy
    }
    fun inside(x: Float, y: Float, m: Float) = x >= m && y >= m && x <= w - 1 - m && y <= h - 1 - m
    fun half(): Gray {
        val nw = max(w / 2, 1); val nh = max(h / 2, 1)
        val o = FloatArray(nw * nh)
        for (y in 0 until nh) for (x in 0 until nw) {
            val x0 = min(2 * x, w - 1); val x1 = min(2 * x + 1, w - 1); val y0 = min(2 * y, h - 1); val y1 = min(2 * y + 1, h - 1)
            o[y * nw + x] = (d[y0 * w + x0] + d[y0 * w + x1] + d[y1 * w + x0] + d[y1 * w + x1]) * 0.25f
        }
        return Gray(nw, nh, o)
    }
}

/** Методы оценки движения. Переключаются для сравнения; все три работают на CPU по маленькому кадру яркости. */
enum class FlowMethod(val label: String) {
    LK_PYRAMID("Пирамидальный Lucas-Kanade + RANSAC"),
    BLOCK_MATCH("Block matching (SAD) + RANSAC"),
    PHASE("Проекции строк/столбцов (только сдвиг)")
}

/**
 * Глобальное движение камеры как подобие: p' = s·R(rot)·p + t в координатах от центра кадра (x вправо, y вниз, пиксели кадра анализа).
 * rot > 0 — содержимое повёрнуто по часовой стрелке на экране.
 */
class GlobalMotion(
    val tx: Double, val ty: Double, val rot: Double, val scale: Double,
    val inliers: Int, val tracked: Int, val conf: Double, val method: FlowMethod,
    /** Доля отслеженных точек, не согласных с движением камеры (движущиеся объекты или шум). */
    val localRatio: Double,
    val vx0: FloatArray = FloatArray(0), val vy0: FloatArray = FloatArray(0),
    val vx1: FloatArray = FloatArray(0), val vy1: FloatArray = FloatArray(0), val vin: BooleanArray = BooleanArray(0)
)

object FlowEngine {
    class Params(
        val maxFeatures: Int = 120, val cell: Int = 8, val levels: Int = 3, val win: Int = 3, val iters: Int = 8,
        val ransacIters: Int = 80, val inlierPx: Double = 0.8, val minInliers: Int = 8, val searchPx: Int = 8, val seed: Long = 12345L
    )

    // ------------------------------------------------------------ признаки (Shi-Tomasi, один лучший на ячейку)
    class Pts(val x: FloatArray, val y: FloatArray, val n: Int)

    fun goodFeatures(g: Gray, p: Params, margin: Int = 6): Pts {
        val w = g.w; val h = g.h
        val gx = FloatArray(w * h); val gy = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            gx[y * w + x] = (g.d[y * w + x + 1] - g.d[y * w + x - 1]) * 0.5f
            gy[y * w + x] = (g.d[(y + 1) * w + x] - g.d[(y - 1) * w + x]) * 0.5f
        }
        val cs = max(p.cell, 4)
        val cols = (w + cs - 1) / cs; val rows = (h + cs - 1) / cs
        val bestV = FloatArray(cols * rows) { 0f }
        val bx = FloatArray(cols * rows); val by = FloatArray(cols * rows)
        var maxV = 0f
        val r = 2
        for (y in margin until h - margin) for (x in margin until w - margin) {
            var a = 0f; var b = 0f; var c = 0f
            for (j in -r..r) for (i in -r..r) {
                val ix = gx[(y + j) * w + x + i]; val iy = gy[(y + j) * w + x + i]
                a += ix * ix; b += ix * iy; c += iy * iy
            }
            val tr = a + c; val det = a * c - b * b
            val lmin = tr * 0.5f - sqrt(max(0f, tr * tr * 0.25f - det))
            val cell = (y / cs) * cols + x / cs
            if (lmin > bestV[cell]) { bestV[cell] = lmin; bx[cell] = x.toFloat(); by[cell] = y.toFloat() }
            if (lmin > maxV) maxV = lmin
        }
        if (maxV <= 0f) return Pts(FloatArray(0), FloatArray(0), 0)
        val thr = maxV * 0.02f
        val idx = (0 until cols * rows).filter { bestV[it] > thr }.sortedByDescending { bestV[it] }.take(p.maxFeatures)
        return Pts(FloatArray(idx.size) { bx[idx[it]] }, FloatArray(idx.size) { by[idx[it]] }, idx.size)
    }

    // ------------------------------------------------------------ пирамидальный Lucas-Kanade
    fun pyramid(g: Gray, levels: Int): List<Gray> {
        val l = ArrayList<Gray>(levels); l.add(g)
        for (i in 1 until levels) { val last = l.last(); if (min(last.w, last.h) < 24) break; l.add(last.half()) }
        return l
    }

    class Tracked(val x1: FloatArray, val y1: FloatArray, val ok: BooleanArray)

    fun trackLK(pa: List<Gray>, pb: List<Gray>, pts: Pts, p: Params): Tracked {
        val n = pts.n
        val ox = FloatArray(n); val oy = FloatArray(n); val ok = BooleanArray(n)
        val r = p.win
        val levels = min(pa.size, pb.size)
        for (k in 0 until n) {
            var vx = 0f; var vy = 0f
            var good = true
            for (lv in levels - 1 downTo 0) {
                val a = pa[lv]; val b = pb[lv]
                val sc = 1f / (1 shl lv)
                val px = pts.x[k] * sc; val py = pts.y[k] * sc
                if (!a.inside(px, py, r + 1f)) { good = lv != 0 && good; if (lv == 0) good = false; vx *= 2; vy *= 2; continue }
                // матрица градиентов окна
                var gxx = 0f; var gxy = 0f; var gyy = 0f
                for (j in -r..r) for (i in -r..r) {
                    val xx = px + i; val yy = py + j
                    val ix = (a.bil(xx + 1, yy) - a.bil(xx - 1, yy)) * 0.5f
                    val iy = (a.bil(xx, yy + 1) - a.bil(xx, yy - 1)) * 0.5f
                    gxx += ix * ix; gxy += ix * iy; gyy += iy * iy
                }
                val det = gxx * gyy - gxy * gxy
                val tr = gxx + gyy
                if (det < 1e-9f * (1 + tr * tr) || det < 1e-7f) { if (lv == 0) good = false; vx *= 2; vy *= 2; continue }
                var dx = 0f; var dy = 0f
                for (it in 0 until p.iters) {
                    var bx = 0f; var by = 0f
                    for (j in -r..r) for (i in -r..r) {
                        val xx = px + i; val yy = py + j
                        val ix = (a.bil(xx + 1, yy) - a.bil(xx - 1, yy)) * 0.5f
                        val iy = (a.bil(xx, yy + 1) - a.bil(xx, yy - 1)) * 0.5f
                        val e = a.bil(xx, yy) - b.bil(xx + vx + dx, yy + vy + dy)
                        bx += ix * e; by += iy * e
                    }
                    val ddx = (gyy * bx - gxy * by) / det
                    val ddy = (-gxy * bx + gxx * by) / det
                    dx += ddx; dy += ddy
                    if (abs(ddx) + abs(ddy) < 0.01f) break
                }
                vx += dx; vy += dy
                if (lv > 0) { vx *= 2; vy *= 2 }
            }
            val fx = pts.x[k] + vx; val fy = pts.y[k] + vy
            ox[k] = fx; oy[k] = fy
            ok[k] = good && pa[0].inside(fx, fy, 1f) && abs(vx) < pa[0].w && abs(vy) < pa[0].h
        }
        return Tracked(ox, oy, ok)
    }

    // ------------------------------------------------------------ block matching (SAD, целочисленно + параболическое уточнение)
    fun trackBlocks(a: Gray, b: Gray, pts: Pts, p: Params): Tracked {
        val n = pts.n; val rb = 4; val sr = p.searchPx
        val ox = FloatArray(n); val oy = FloatArray(n); val ok = BooleanArray(n)
        for (k in 0 until n) {
            val cx = pts.x[k].toInt(); val cy = pts.y[k].toInt()
            if (cx < rb + sr || cy < rb + sr || cx >= a.w - rb - sr || cy >= a.h - rb - sr) { ox[k] = pts.x[k]; oy[k] = pts.y[k]; continue }
            val cost = Array(2 * sr + 1) { FloatArray(2 * sr + 1) }
            var best = Float.MAX_VALUE; var bi = 0; var bj = 0
            for (j in -sr..sr) for (i in -sr..sr) {
                var s = 0f
                for (v in -rb..rb) for (u in -rb..rb) s += abs(a.d[(cy + v) * a.w + cx + u] - b.d[(cy + v + j) * b.w + cx + u + i])
                cost[j + sr][i + sr] = s
                if (s < best) { best = s; bi = i; bj = j }
            }
            var fx = bi.toFloat(); var fy = bj.toFloat()
            if (abs(bi) < sr && abs(bj) < sr) {
                fun par(m: Float, c: Float, pl: Float): Float { val d = m - 2 * c + pl; return if (d > 1e-9f) 0.5f * (m - pl) / d else 0f }
                fx += par(cost[bj + sr][bi + sr - 1], cost[bj + sr][bi + sr], cost[bj + sr][bi + sr + 1]).coerceIn(-0.5f, 0.5f)
                fy += par(cost[bj + sr - 1][bi + sr], cost[bj + sr][bi + sr], cost[bj + sr + 1][bi + sr]).coerceIn(-0.5f, 0.5f)
                ok[k] = true
            }
            ox[k] = pts.x[k] + fx; oy[k] = pts.y[k] + fy
        }
        return Tracked(ox, oy, ok)
    }

    // ------------------------------------------------------------ RANSAC для подобия (комплексная форма z' = a·z + b)
    class Fit(val ax: Double, val ay: Double, val bx: Double, val by: Double, val inl: BooleanArray, val nIn: Int)

    private fun lcg(s: LongArray): Int { s[0] = s[0] * 6364136223846793005L + 1442695040888963407L; return ((s[0] ushr 33) and 0x7fffffff).toInt() }

    /** Координаты уже центрированы. Возвращает null, если согласованных точек меньше minInliers. */
    fun ransacSimilarity(x0: DoubleArray, y0: DoubleArray, x1: DoubleArray, y1: DoubleArray, n: Int, p: Params, translationOnly: Boolean = false): Fit? {
        if (n < max(p.minInliers, 2)) return null
        val seed = longArrayOf(p.seed)
        var bestN = -1; var bestMask = BooleanArray(n)
        val mask = BooleanArray(n)
        val t2 = p.inlierPx * p.inlierPx
        repeat(p.ransacIters) {
            val i = lcg(seed) % n; var j = lcg(seed) % n
            if (j == i) j = (j + 1) % n
            var ax: Double; var ay: Double; var bx: Double; var by: Double
            if (translationOnly) { ax = 1.0; ay = 0.0; bx = x1[i] - x0[i]; by = y1[i] - y0[i] }
            else {
                val dxr = x0[i] - x0[j]; val dyr = y0[i] - y0[j]
                val den = dxr * dxr + dyr * dyr
                if (den < 16.0) return@repeat
                val dxp = x1[i] - x1[j]; val dyp = y1[i] - y1[j]
                ax = (dxp * dxr + dyp * dyr) / den; ay = (dyp * dxr - dxp * dyr) / den
                val s = hypot(ax, ay)
                if (s < 0.5 || s > 2.0) return@repeat
                bx = x1[i] - (ax * x0[i] - ay * y0[i]); by = y1[i] - (ay * x0[i] + ax * y0[i])
            }
            var c = 0
            for (k in 0 until n) {
                val ex = ax * x0[k] - ay * y0[k] + bx - x1[k]; val ey = ay * x0[k] + ax * y0[k] + by - y1[k]
                val ok = ex * ex + ey * ey <= t2
                mask[k] = ok; if (ok) c++
            }
            if (c > bestN) { bestN = c; System.arraycopy(mask, 0, bestMask, 0, n) }
        }
        if (bestN < p.minInliers) return null
        // МНК по согласованным точкам, затем повторная отметка
        var m = bestMask; var nin = bestN
        var ax = 1.0; var ay = 0.0; var bx = 0.0; var by = 0.0
        repeat(2) {
            var sx0 = 0.0; var sy0 = 0.0; var sx1 = 0.0; var sy1 = 0.0
            for (k in 0 until n) if (m[k]) { sx0 += x0[k]; sy0 += y0[k]; sx1 += x1[k]; sy1 += y1[k] }
            val mx0 = sx0 / nin; val my0 = sy0 / nin; val mx1 = sx1 / nin; val my1 = sy1 / nin
            if (translationOnly) { ax = 1.0; ay = 0.0 }
            else {
                var nr = 0.0; var ni = 0.0; var dn = 0.0
                for (k in 0 until n) if (m[k]) {
                    val zx = x0[k] - mx0; val zy = y0[k] - my0; val wx = x1[k] - mx1; val wy = y1[k] - my1
                    nr += zx * wx + zy * wy; ni += zx * wy - zy * wx; dn += zx * zx + zy * zy
                }
                if (dn < 1e-9) return null
                ax = nr / dn; ay = ni / dn
            }
            bx = mx1 - (ax * mx0 - ay * my0); by = my1 - (ay * mx0 + ax * my0)
            val nm = BooleanArray(n); var c = 0
            for (k in 0 until n) {
                val ex = ax * x0[k] - ay * y0[k] + bx - x1[k]; val ey = ay * x0[k] + ax * y0[k] + by - y1[k]
                if (ex * ex + ey * ey <= t2) { nm[k] = true; c++ }
            }
            if (c < p.minInliers) return null
            m = nm; nin = c
        }
        return Fit(ax, ay, bx, by, m, nin)
    }

    // ------------------------------------------------------------ верхний уровень
    /** Оценка глобального движения между кадрами яркости одинакового размера; null — недостаточно текстуры/согласованных точек. */
    fun estimate(prev: Gray, cur: Gray, method: FlowMethod, p: Params = Params(), prevPyr: List<Gray>? = null, curPyr: List<Gray>? = null): GlobalMotion? {
        require(prev.w == cur.w && prev.h == cur.h)
        if (method == FlowMethod.PHASE) {
            val r = MotionProbe.shift(prev.d, cur.d, prev.w, prev.h) ?: return null
            return GlobalMotion(r[0], r[1], 0.0, 1.0, 0, 0, r[2].coerceIn(0.0, 1.0), method, 0.0)
        }
        val pts = goodFeatures(prev, p)
        if (pts.n < p.minInliers) return null
        val tr = if (method == FlowMethod.LK_PYRAMID) trackLK(prevPyr ?: pyramid(prev, p.levels), curPyr ?: pyramid(cur, p.levels), pts, p) else trackBlocks(prev, cur, pts, p)
        val idx = (0 until pts.n).filter { tr.ok[it] }
        val m = idx.size
        if (m < p.minInliers) return null
        val cx = (prev.w - 1) * 0.5; val cy = (prev.h - 1) * 0.5
        val x0 = DoubleArray(m) { pts.x[idx[it]] - cx }; val y0 = DoubleArray(m) { pts.y[idx[it]] - cy }
        val x1 = DoubleArray(m) { tr.x1[idx[it]] - cx }; val y1 = DoubleArray(m) { tr.y1[idx[it]] - cy }
        val fit = ransacSimilarity(x0, y0, x1, y1, m, p) ?: return null
        val s = hypot(fit.ax, fit.ay)
        val rot = atan2(fit.ay, fit.ax)
        val inFrac = fit.nIn.toDouble() / m
        // уверенность: доля согласных точек × насыщение числом точек
        val conf = (inFrac * min(1.0, fit.nIn / 30.0)).coerceIn(0.0, 1.0)
        return GlobalMotion(fit.bx, fit.by, rot, s, fit.nIn, m, conf, method, 1.0 - inFrac,
            FloatArray(m) { x0[it].toFloat() }, FloatArray(m) { y0[it].toFloat() }, FloatArray(m) { x1[it].toFloat() }, FloatArray(m) { y1[it].toFloat() }, fit.inl)
    }

    /** Остаточный сдвиг по трём горизонтальным третям кадра (верх/середина/низ): формат [gx, gy, conf, b0x, b0y, b1x, b1y, b2x, b2y] как у MotionProbe.bands. */
    fun bands(prev: Gray, cur: Gray, method: FlowMethod, p: Params = Params()): DoubleArray? {
        if (method == FlowMethod.PHASE) return MotionProbe.bands(prev.d, cur.d, prev.w, prev.h)
        val g = estimate(prev, cur, method, p) ?: return null
        val out = DoubleArray(9)
        // translation в центре кадра (вычитаем вращение/масштаб в точке) — для глобального
        out[0] = g.tx; out[1] = g.ty; out[2] = g.conf
        val third = prev.h / 3.0
        val h2 = (prev.h - 1) * 0.5
        for (k in 0..2) {
            val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
            for (i in g.vx0.indices) {
                if (!g.vin[i]) continue
                val row = ((g.vy0[i] + h2) / third).toInt().coerceIn(0, 2)
                if (row != k) continue
                xs.add((g.vx1[i] - g.vx0[i]).toDouble()); ys.add((g.vy1[i] - g.vy0[i]).toDouble())
            }
            if (xs.size < 3) { out[3 + k * 2] = g.tx; out[4 + k * 2] = g.ty }
            else { xs.sort(); ys.sort(); out[3 + k * 2] = xs[xs.size / 2]; out[4 + k * 2] = ys[ys.size / 2] }
        }
        return out
    }

    /** Содержимое сместилось на (dx,dy) пикселей и повернулось на rot: ось камеры (рад) — тот же знак, что в калибровке гироскопа (px = −f·c1, py = f·c0, roll c2 = −rot). */
    fun toCameraRotvec(g: GlobalMotion, focalPx: Double): DoubleArray {
        val f = max(focalPx, 1.0)
        return doubleArrayOf(atan2(g.ty, f), -atan2(g.tx, f), -g.rot)
    }
}
