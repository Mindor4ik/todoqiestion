package app.procam

/** Итоги записи по реальным таймстампам файла (не оценка по часам). */
data class RecStats(
    val videoFrames: Long = 0,
    val audioFrames: Long = 0,
    /** Кадры, пропущенные по разрыву между таймстампами видео (разрыв > 1.5 кадра). */
    val droppedVideo: Long = 0,
    /** Сколько раз пришлось исправлять немонотонный таймстамп. */
    val ptsCorrections: Long = 0,
    val maxVideoGapMs: Float = 0f,
    val videoSeconds: Double = 0.0,
    val audioSeconds: Double = 0.0,
    /** Фактическая частота кадров файла = кадры / длительность видеодорожки. */
    val actualFps: Float = 0f,
    /** Разница начала видео и звука в файле (мс): >0 — звук начался раньше. null — одной из дорожек нет. */
    val avStartOffsetMs: Float? = null,
    val bytes: Long = 0
)

/**
 * Приведение «сырых» таймстампов кодеков к единой шкале файла: общая база для аудио и видео,
 * вырезание паузы без дыры, гарантия монотонности и подсчёт потерянных кадров.
 * Чистая логика без Android — покрыта юнит-тестами.
 */
class PtsNormalizer(private val common: Boolean) {
    private val bases = LongArray(4) { -1L }
    private var base = -1L
    private val shift = LongArray(4)
    private val lastRaw = LongArray(4) { -1L }
    private val lastStep = LongArray(4) { 20_000L }
    private val gapNext = BooleanArray(4)
    private val monotonic = BooleanArray(4)
    private val nominalUs = LongArray(4)          // ожидаемая длительность кадра (видео), 0 — не учитывать потери
    private val lastOut = LongArray(4) { -1L }
    private val firstOut = LongArray(4) { -1L }
    private val counts = LongArray(4)
    private val dropped = LongArray(4)
    private val maxGap = LongArray(4)
    private var corrections = 0L
    private var bytes = 0L

    fun setMonotonic(track: Int, on: Boolean) { if (track in 0..3) monotonic[track] = on }
    fun setNominalFrameUs(track: Int, us: Long) { if (track in 0..3) nominalUs[track] = us }

    /** Общая база времени — самый ранний из накопленных сэмплов (раньше брался «кто первый пришёл»). */
    fun setCommonBase(rawMin: Long) { if (common && rawMin >= 0) base = rawMin }

    /** Продолжение после паузы: первый сэмпл каждой дорожки «приклеивается» к предыдущему. */
    fun markResume() { for (i in 0..3) gapNext[i] = true }

    fun normalize(track: Int, raw: Long, size: Int = 0): Long {
        val b: Long
        if (common) {
            if (base < 0) base = raw
            b = base
        } else {
            if (track in 0..3) { if (bases[track] < 0) bases[track] = raw; b = bases[track] } else b = raw
        }
        if (track !in 0..3) return (raw - b).coerceAtLeast(0L)
        if (gapNext[track] && lastRaw[track] >= 0) {
            shift[track] += (raw - lastRaw[track] - lastStep[track]).coerceAtLeast(0L)
        }
        gapNext[track] = false
        if (lastRaw[track] >= 0 && raw > lastRaw[track]) lastStep[track] = (raw - lastRaw[track]).coerceIn(1_000L, 200_000L)
        lastRaw[track] = raw
        var pts = (raw - b - shift[track]).coerceAtLeast(0L)
        val prev = lastOut[track]
        if (monotonic[track] && prev >= 0 && pts <= prev) {
            pts = prev + 1          // строго возрастающее время для звука и видео без B-кадров
            corrections++
        }
        if (prev >= 0 && nominalUs[track] > 0 && pts > prev) {
            val gap = pts - prev
            if (gap > maxGap[track]) maxGap[track] = gap
            if (gap > nominalUs[track] * 3 / 2) dropped[track] += (gap + nominalUs[track] / 2) / nominalUs[track] - 1
        }
        if (firstOut[track] < 0) firstOut[track] = pts
        if (pts > lastOut[track]) lastOut[track] = pts
        counts[track]++
        bytes += size
        return pts
    }

    fun stats(video: Int, audio: Int): RecStats {
        val v = video in 0..3 && counts[video] > 0
        val a = audio in 0..3 && counts[audio] > 0
        val vs = if (v) (lastOut[video] - firstOut[video]) / 1e6 else 0.0
        // Фактическая частота — по интервалам между кадрами: (кадры − 1) / длительность.
        val fps = if (v && vs > 0.2) ((counts[video] - 1) / vs).toFloat() else 0f
        return RecStats(
            videoFrames = if (v) counts[video] else 0,
            audioFrames = if (a) counts[audio] else 0,
            droppedVideo = if (v) dropped[video] else 0,
            ptsCorrections = corrections,
            maxVideoGapMs = if (v) maxGap[video] / 1000f else 0f,
            videoSeconds = vs,
            audioSeconds = if (a) (lastOut[audio] - firstOut[audio]) / 1e6 else 0.0,
            actualFps = fps,
            avStartOffsetMs = if (v && a) (firstOut[video] - firstOut[audio]) / 1000f else null,
            bytes = bytes
        )
    }

    /** Конец последнего сэмпла дорожки, секунды (для проверки «видео оборвалось раньше звука»). */
    fun endSeconds(track: Int): Double = if (track in 0..3 && lastOut[track] >= 0) lastOut[track] / 1e6 else -1.0
    fun count(track: Int): Long = if (track in 0..3) counts[track] else 0
}
