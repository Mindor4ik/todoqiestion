package app.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.sqrt

/**
 * Оверлей приборов по реальным пикселям кадра мониторинга (после всей цветовой цепочки, как на экране).
 * Маска: 1 — waveform (яркость), 2 — RGB parade, 4 — вектороскоп, 8 — гистограмма RGB + яркость.
 * Несколько приборов показываются одновременно, делят экран по горизонтали.
 */
class ScopeView(c: Context) : View(c) {
    @Volatile var mask = 0
    private var px: ByteArray? = null
    private var w = 0
    private var h = 0
    private val bg = Paint().apply { color = 0x99000000.toInt() }
    private val dot = Paint()
    private val line = Paint().apply { color = 0x55FFFFFF; strokeWidth = 1f }
    private val txt = Paint().apply { color = 0xCCFFFFFF.toInt(); textSize = 20f; isAntiAlias = true }

    fun set(p: ByteArray, ww: Int, hh: Int) { px = p; w = ww; h = hh; if (mask != 0) invalidate() }

    override fun onDraw(cv: Canvas) {
        val p = px ?: return
        val bits = (0..3).filter { mask and (1 shl it) != 0 }
        if (bits.isEmpty()) return
        val cw = width / bits.size
        for ((n, bit) in bits.withIndex()) {
            val x0 = n * cw
            cv.drawRect(x0.toFloat(), 0f, (x0 + cw).toFloat(), height.toFloat(), bg)
            when (bit) {
                0 -> drawWave(cv, p, x0, cw, -1, 0xFFFFFFFF.toInt(), "Waveform")
                1 -> { val t = cw / 3; for (ch in 0..2) drawWave(cv, p, x0 + ch * t, t, ch, intArrayOf(0xFFFF4040.toInt(), 0xFF40FF40.toInt(), 0xFF4080FF.toInt())[ch], if (ch == 0) "Parade" else "") }
                2 -> drawVec(cv, p, x0, cw)
                3 -> drawHist(cv, p, x0, cw)
            }
        }
    }

    private fun drawWave(cv: Canvas, p: ByteArray, x0: Int, cw: Int, ch: Int, color: Int, title: String) {
        val cols = cw.coerceIn(16, 256)
        val wf = Scopes.waveform(p, w, h, cols, ch)
        val mx = (wf.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val cwf = cw.toFloat() / cols; val hh = height.toFloat()
        for (c in 0 until cols) for (lv in 0 until 256) {
            val v = wf[c * 256 + lv]; if (v == 0) continue
            val a = (60 + 195 * sqrt(v / mx)).toInt().coerceIn(0, 255)
            dot.color = (a shl 24) or (color and 0xFFFFFF)
            val y = hh - (lv / 255f) * hh
            cv.drawRect(x0 + c * cwf, y - 1.5f, x0 + (c + 1) * cwf + 0.5f, y + 1.5f, dot)
        }
        for (k in 0..4) { val y = hh - hh * k / 4f; cv.drawLine(x0.toFloat(), y, (x0 + cw).toFloat(), y, line) }
        if (title.isNotEmpty()) cv.drawText(title, x0 + 6f, 22f, txt)
    }

    private fun drawVec(cv: Canvas, p: ByteArray, x0: Int, cw: Int) {
        val size = minOf(cw, height).coerceAtMost(256)
        val v = Scopes.vectorscope(p, w * h, size)
        val mx = (v.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val s = minOf(cw, height).toFloat() / size
        val ox = x0 + (cw - size * s) / 2f
        for (y in 0 until size) for (x in 0 until size) {
            val c = v[y * size + x]; if (c == 0) continue
            dot.color = ((60 + 195 * sqrt(c / mx)).toInt().coerceIn(0, 255) shl 24) or 0x40FF80
            cv.drawRect(ox + x * s, (size - 1 - y) * s, ox + (x + 1) * s + 0.5f, (size - y) * s + 0.5f, dot)
        }
        for ((n, pos) in Scopes.vectorTargets(size)) {
            val tx = ox + pos.first * s; val ty = (size - 1 - pos.second) * s
            cv.drawCircle(tx, ty, 5f, line.apply { style = Paint.Style.STROKE }); line.style = Paint.Style.FILL
            cv.drawText(n, tx + 6f, ty - 4f, txt.apply { textSize = 16f }); txt.textSize = 20f
        }
        cv.drawText("Vectorscope", x0 + 6f, 22f, txt)
    }

    private fun drawHist(cv: Canvas, p: ByteArray, x0: Int, cw: Int) {
        val hs = Scopes.histogram(p, w * h)
        val mx = maxOf(hs.r.max(), hs.g.max(), hs.b.max(), hs.luma.max()).coerceAtLeast(1).toFloat()
        val bw = cw / 256f; val hh = height.toFloat()
        fun plot(a: IntArray, color: Int) {
            dot.color = color
            for (i in 0 until 256) { val t = sqrt(a[i] / mx) * hh; cv.drawRect(x0 + i * bw, hh - t, x0 + (i + 1) * bw + 0.5f, hh, dot) }
        }
        plot(hs.r, 0x66FF3030); plot(hs.g, 0x6630FF30); plot(hs.b, 0x663060FF); plot(hs.luma, 0x55FFFFFF)
        cv.drawText("Histogram  ≥255: ${"%.1f".format(hs.clippedHigh() * 100)}%  0: ${"%.1f".format(hs.clippedLow() * 100)}%", x0 + 6f, 22f, txt)
    }
}
