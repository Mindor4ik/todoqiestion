package app.procam

/**
 * Настройки Color Science 2.0. Хранятся в общем хранилище настроек (схема v3), поэтому автоматически
 * попадают в пресеты, проходят проверку значений и сброс. Все ключи начинаются с «c26_».
 */
object ColorKeys {
    val SDR_TFS = listOf(Tf.SRGB, Tf.GAMMA24, Tf.GAMMA22, Tf.BT709)
    val WORK = listOf(Spaces.REC709, Spaces.REC2020, Spaces.DISPLAY_P3, Spaces.ACES_AP1)
    const val CURVES_ID = "0,0.25,0.5,0.75,1"
    const val BANDS_ID = "0,0,0,0,0,0"

    private fun f(lo: Float, hi: Float, d: Float) = Rule.FloatR(lo, hi, d)
    private fun i(lo: Int, hi: Int, d: Int) = Rule.IntR(lo, hi, d)
    private fun b(d: Boolean) = Rule.BoolR(d)

    val rules: Map<String, Rule> = linkedMapOf(
        // управление цветом
        "c26_work" to i(0, 3, 0), "c26_sdr_in" to i(0, 3, 0), "c26_sdr_out" to i(0, 3, 0),
        "c26_tone" to i(0, 3, 0), "c26_tone_w" to f(1f, 16f, 4f), "c26_gamut" to i(0, 1, 0),
        "c26_rec2020" to b(false),
        // этапы (можно отключать по отдельности)
        "c26_en_wb" to b(true), "c26_en_grade" to b(true), "c26_en_tone" to b(true), "c26_en_lut" to b(true),
        // LOG/HLG
        "c26_hlg_white" to f(0.05f, 1f, 0.265f), "c26_custom_log" to b(false),
        "c26_cl_a" to f(0.01f, 100f, 5f), "c26_cl_b" to f(0.0001f, 1f, 0.05f), "c26_cl_c" to f(0.01f, 1f, 0.12f), "c26_cl_d" to f(-1f, 2f, 0.45f),
        // LUT
        "c26_lut_interp" to i(0, 1, 0), "c26_lut_io" to i(0, 4, 0), "c26_lut_mix" to f(0f, 1f, 1f),
        // градация
        "c26_ev" to f(-5f, 5f, 0f), "c26_kelvin" to f(1700f, 25000f, 6500f), "c26_tint" to f(-100f, 100f, 0f),
        "c26_contrast" to f(-1f, 1f, 0f), "c26_hi" to f(-1f, 1f, 0f), "c26_sh" to f(-1f, 1f, 0f), "c26_wh" to f(-1f, 1f, 0f), "c26_bl" to f(-1f, 1f, 0f),
        "c26_sat" to f(0f, 4f, 1f), "c26_vib" to f(-1f, 1f, 0f), "c26_hue" to f(-180f, 180f, 0f),
        "c26_lift_m" to f(-0.5f, 0.5f, 0f), "c26_lift_r" to f(-0.5f, 0.5f, 0f), "c26_lift_g" to f(-0.5f, 0.5f, 0f), "c26_lift_b" to f(-0.5f, 0.5f, 0f),
        "c26_gamma_m" to f(0.2f, 5f, 1f), "c26_gamma_r" to f(0.2f, 5f, 1f), "c26_gamma_g" to f(0.2f, 5f, 1f), "c26_gamma_b" to f(0.2f, 5f, 1f),
        "c26_gain_m" to f(0f, 4f, 1f), "c26_gain_r" to f(0f, 4f, 1f), "c26_gain_g" to f(0f, 4f, 1f), "c26_gain_b" to f(0f, 4f, 1f),
        "c26_cv_m" to Rule.TextR(CURVES_ID), "c26_cv_r" to Rule.TextR(CURVES_ID), "c26_cv_g" to Rule.TextR(CURVES_ID), "c26_cv_b" to Rule.TextR(CURVES_ID),
        "c26_hb_shift" to Rule.TextR(BANDS_ID), "c26_hb_sat" to Rule.TextR(BANDS_ID), "c26_hb_lum" to Rule.TextR(BANDS_ID),
        "c26_sp_sh_hue" to f(0f, 360f, 220f), "c26_sp_sh_amt" to f(0f, 1f, 0f), "c26_sp_hi_hue" to f(0f, 360f, 40f), "c26_sp_hi_amt" to f(0f, 1f, 0f), "c26_sp_bal" to f(-1f, 1f, 0f),
        // мониторинг
        "c26_scope_mask" to i(0, 63, 0), "c26_scope_hz" to i(1, 60, 6), "c26_scope_res" to i(0, 4, 0),
        "c26_fc_map" to i(0, 3, 0), "c26_dither" to i(0, 2, 0),
        "c26_fc_l1" to f(0f, 1f, 0f), "c26_fc_h1" to f(0f, 1.01f, 0.1f), "c26_fc_l2" to f(0f, 1f, 0.4f), "c26_fc_h2" to f(0f, 1.01f, 0.5f), "c26_fc_l3" to f(0f, 1f, 0.9f), "c26_fc_h3" to f(0f, 1.01f, 1.01f),
        "c26_zlo_on" to b(false), "c26_zlo_level" to f(0f, 0.7f, 0.05f), "c26_z_alpha" to f(0.1f, 1f, 1f)
    )

    fun parseArr(s: String, n: Int, def: Double): DoubleArray {
        val p = s.split(',')
        return DoubleArray(n) { p.getOrNull(it)?.trim()?.toDoubleOrNull()?.takeIf { v -> v.isFinite() } ?: if (n == 5) it / 4.0 else def }
    }
    fun joinArr(a: DoubleArray) = a.joinToString(",") { "%.4f".format(java.util.Locale.ROOT, it) }
}

/** Живые значения цветовых настроек поверх хранилища. */
class ColorSettings(private val store: KeyValueStore) {
    /** Не сохраняется: временно отключить градацию, тон-мэппинг и LUT, чтобы сравнить «до и после». */
    @Volatile var bypass = false

    private fun raw(k: String): Any? = store.all()[k]
    fun f(k: String): Float { val r = ColorKeys.rules[k] as Rule.FloatR; val v = raw(k); return if (v != null && r.ok(v)) v as Float else r.default }
    fun i(k: String): Int { val r = ColorKeys.rules[k] as Rule.IntR; val v = raw(k); return if (v != null && r.ok(v)) v as Int else r.default }
    fun b(k: String): Boolean { val r = ColorKeys.rules[k] as Rule.BoolR; val v = raw(k); return if (v != null && r.ok(v)) v as Boolean else r.default }
    fun s(k: String): String { val r = ColorKeys.rules[k] as Rule.TextR; val v = raw(k); return if (v != null && r.ok(v)) v as String else r.default }

    fun set(k: String, v: Any) {
        val r = ColorKeys.rules[k] ?: return
        val fixed: Any = when (r) {
            is Rule.FloatR -> (v as Number).toFloat().coerceIn(r.min, r.max)
            is Rule.IntR -> (v as Number).toInt().coerceIn(r.min, r.max)
            else -> v
        }
        store.commit(mapOf(k to fixed))
    }
    fun reset(keys: Collection<String>) = store.commit(emptyMap(), keys.toSet())
    fun resetAll() = reset(ColorKeys.rules.keys)

    fun work(): Primaries = ColorKeys.WORK[i("c26_work")]
    fun grade(): GradeParams {
        fun tri(m: String, r: String, g: String, bl: String, p: String, d: Double) = doubleArrayOf(f("c26_${p}_m").toDouble(), f("c26_${p}_r").toDouble(), f("c26_${p}_g").toDouble(), f("c26_${p}_b").toDouble())
        val cv = DoubleArray(20)
        for ((n, k) in listOf("c26_cv_m", "c26_cv_r", "c26_cv_g", "c26_cv_b").withIndex()) ColorKeys.parseArr(s(k), 5, 0.0).copyInto(cv, n * 5)
        val enWb = b("c26_en_wb")
        return GradeParams(
            exposureEv = f("c26_ev").toDouble(), kelvin = if (enWb) f("c26_kelvin").toDouble() else 6500.0, tint = if (enWb) f("c26_tint").toDouble() else 0.0,
            contrast = f("c26_contrast").toDouble(), highlights = f("c26_hi").toDouble(), shadows = f("c26_sh").toDouble(), whites = f("c26_wh").toDouble(), blacks = f("c26_bl").toDouble(),
            saturation = f("c26_sat").toDouble(), vibrance = f("c26_vib").toDouble(), hue = f("c26_hue").toDouble(),
            lift = tri("", "", "", "", "lift", 0.0), gamma = tri("", "", "", "", "gamma", 1.0), gain = tri("", "", "", "", "gain", 1.0),
            curves = cv,
            hueShift = ColorKeys.parseArr(s("c26_hb_shift"), 6, 0.0), hueSat = ColorKeys.parseArr(s("c26_hb_sat"), 6, 0.0), hueLum = ColorKeys.parseArr(s("c26_hb_lum"), 6, 0.0),
            splitShHue = f("c26_sp_sh_hue").toDouble(), splitShAmt = f("c26_sp_sh_amt").toDouble(),
            splitHiHue = f("c26_sp_hi_hue").toDouble(), splitHiAmt = f("c26_sp_hi_amt").toDouble(), splitBalance = f("c26_sp_bal").toDouble()
        )
    }
    fun customLog(): CustomLog = CustomLog("Пользовательская", f("c26_cl_a").toDouble(), f("c26_cl_b").toDouble(), f("c26_cl_c").toDouble(), f("c26_cl_d").toDouble())
    fun falseColorMap(): FalseColorMap = when (i("c26_fc_map")) {
        1 -> FalseColorMap.SPECTRUM
        2 -> FalseColorMap.SKIN
        3 -> FalseColorMap.custom(f("c26_fc_l1"), f("c26_fc_h1"), f("c26_fc_l2"), f("c26_fc_h2"), f("c26_fc_l3"), f("c26_fc_h3"))
        else -> FalseColorMap.BEYOND
    }
    fun lutIo(): LutIo = LutIo.presets[i("c26_lut_io").coerceIn(0, LutIo.presets.size - 1)].second
    fun hlgWhite(): Double = f("c26_hlg_white").toDouble()
    fun scopeSize(): Pair<Int, Int> = listOf(128 to 72, 192 to 108, 256 to 144, 384 to 216, 512 to 288)[i("c26_scope_res")]
}

/** Всё, что шейдер получает как uniform для цветовой цепочки. Неизменяемый набор, считается на CPU из [ColorSettings]. */
class ColorUniforms(
    val inKind: Int, val inTf: Int, val hlgWhite: Float,
    val toWork: FloatArray, val toWorkRec: FloatArray, val wb: FloatArray, val lumaW: FloatArray,
    val workToView: FloatArray, val workToRec: FloatArray, val lumaView: FloatArray, val lumaRec: FloatArray,
    val gradeOn: Boolean, val ex: Float, val contrast: Float, val hi: Float, val sh: Float, val wh: Float, val bl: Float,
    val sat: Float, val vib: Float, val hueRot: Float, val lift: FloatArray, val gamma: FloatArray, val gain: FloatArray,
    val curves: FloatArray, val hue: FloatArray, val bands: Boolean, val splitOn: Boolean, val splitSh: FloatArray, val splitHi: FloatArray, val splitBal: Float,
    val tone: Int, val toneWhite: Float, val gamut: Int, val sdrTf: Int,
    val lutInterp: Int, val lutInTf: Int, val lutInView: FloatArray, val lutInRec: FloatArray, val lutOutTf: Int, val lutOutRaw: Boolean,
    val lutOutView: FloatArray, val lutOutRec: FloatArray, val lutMix: Float,
    val customLog: FloatArray?,
    val fcN: Int, val fcLo: FloatArray, val fcHi: FloatArray, val fcCol: FloatArray,
    val zHiOn: Boolean, val zHiLv: Float, val zLoOn: Boolean, val zLoLv: Float, val zAlpha: Float,
    val bypassView: Boolean
) {
    companion object {
        private fun f9(m: DoubleArray) = FloatArray(9) { m[it].toFloat() }
        private fun f3(m: DoubleArray) = FloatArray(3) { m[it].toFloat() }
        val IDENT = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
        private val TF_FOR_CURVE = intArrayOf(Tf.FLAT.id, Tf.SLOG3.id, Tf.VLOG.id, Tf.LOGC.id)

        /**
         * [inKind]: 0 SDR, 1 HLG-превью, 2 LOG с камеры (HW). [curve]: 0 Flat, 1 S-Log3, 2 V-Log, 3 LogC.
         * [outMode]: 0 SDR, 1 LOG, 2 HLG (выход записи). [hwLog] — LOG сделала камера (кривая паспортная).
         */
        fun build(cs: ColorSettings, inKind: Int, curve: Int, outMode: Int, hwLog: Boolean, zebraHiOn: Boolean, zebraHiLevel: Float): ColorUniforms {
            val work = cs.work()
            val inPrim = if (inKind == 1) Spaces.REC2020 else Spaces.REC709
            val recPrim = if (outMode == 2 || cs.b("c26_rec2020")) Spaces.REC2020 else Spaces.REC709
            val view = Spaces.REC709
            val p = cs.grade()
            val wb = WhiteBalance.matrix(p.kelvin, p.tint, work)
            val lw = work.lumaWeights()
            val gradeOn = cs.b("c26_en_grade") && !p.isNeutral() || (cs.b("c26_en_wb") && !M3.isIdentity(wb, 1e-12))
            val g = if (cs.b("c26_en_grade")) p else GradeParams(kelvin = p.kelvin, tint = p.tint)
            fun comb(a: DoubleArray, mul: Boolean) = FloatArray(3) { (if (mul) a[0] * a[1 + it] else a[0] + a[1 + it]).toFloat() }
            val bandsOn = g.hue != 0.0 || g.hueShift.any { it != 0.0 } || g.hueSat.any { it != 0.0 } || g.hueLum.any { it != 0.0 }
            val splitOn = g.splitShAmt != 0.0 || g.splitHiAmt != 0.0
            val tsh = GradeMath.tintVec(g.splitShHue, lw); val thi = GradeMath.tintVec(g.splitHiHue, lw)
            val hue = FloatArray(18)
            for (i in 0 until 6) { hue[i * 3] = g.hueShift[i].toFloat(); hue[i * 3 + 1] = g.hueSat[i].toFloat(); hue[i * 3 + 2] = g.hueLum[i].toFloat() }
            val io = cs.lutIo()
            val lutInTf = if (io.input.followLog) (if (cs.b("c26_custom_log") && !hwLog) 11 else TF_FOR_CURVE[curve.coerceIn(0, 3)]) else io.input.tf.id
            val lutInView = f9(Spaces.convert(view, io.input.prim)); val lutInRec = f9(Spaces.convert(recPrim, io.input.prim))
            val lutOutView = f9(Spaces.convert(io.output.prim, view)); val lutOutRec = f9(Spaces.convert(io.output.prim, recPrim))
            val fc = cs.falseColorMap().ranges.take(8)
            val fcLo = FloatArray(8); val fcHi = FloatArray(8); val fcCol = FloatArray(24)
            fc.forEachIndexed { i, r ->
                fcLo[i] = r.lo; fcHi[i] = r.hi
                fcCol[i * 3] = ((r.rgb shr 16) and 255) / 255f; fcCol[i * 3 + 1] = ((r.rgb shr 8) and 255) / 255f; fcCol[i * 3 + 2] = (r.rgb and 255) / 255f
            }
            return ColorUniforms(
                inKind = inKind, inTf = ColorKeys.SDR_TFS[cs.i("c26_sdr_in")].id, hlgWhite = cs.hlgWhite().toFloat(),
                toWork = f9(Spaces.convert(inPrim, work)), toWorkRec = f9(Spaces.convert(Spaces.REC709, work)), wb = f9(wb), lumaW = f3(lw),
                workToView = f9(Spaces.convert(work, view)), workToRec = f9(Spaces.convert(work, recPrim)),
                lumaView = f3(view.lumaWeights()), lumaRec = f3(recPrim.lumaWeights()),
                gradeOn = gradeOn, ex = Math.pow(2.0, g.exposureEv).toFloat(), contrast = g.contrast.toFloat(), hi = g.highlights.toFloat(), sh = g.shadows.toFloat(),
                wh = g.whites.toFloat(), bl = g.blacks.toFloat(), sat = g.saturation.toFloat(), vib = g.vibrance.toFloat(), hueRot = g.hue.toFloat(),
                lift = comb(g.lift, false), gamma = comb(g.gamma, true), gain = comb(g.gain, true),
                curves = FloatArray(20) { g.curves[it].toFloat() }, hue = hue, bands = bandsOn, splitOn = splitOn,
                splitSh = FloatArray(3) { (tsh[it] * g.splitShAmt * 0.25).toFloat() }, splitHi = FloatArray(3) { (thi[it] * g.splitHiAmt * 0.25).toFloat() }, splitBal = (g.splitBalance * 0.5).toFloat(),
                tone = if (cs.b("c26_en_tone")) cs.i("c26_tone") else 0, toneWhite = cs.f("c26_tone_w"), gamut = cs.i("c26_gamut"), sdrTf = ColorKeys.SDR_TFS[cs.i("c26_sdr_out")].id,
                lutInterp = cs.i("c26_lut_interp"), lutInTf = lutInTf, lutInView = lutInView, lutInRec = lutInRec, lutOutTf = io.output.tf.id, lutOutRaw = io.output.raw,
                lutOutView = lutOutView, lutOutRec = lutOutRec, lutMix = if (cs.b("c26_en_lut")) cs.f("c26_lut_mix") else 0f,
                customLog = if (cs.b("c26_custom_log") && !hwLog) cs.customLog().let { floatArrayOf(it.a.toFloat(), it.b.toFloat(), it.c.toFloat(), it.d.toFloat()) } else null,
                fcN = fc.size, fcLo = fcLo, fcHi = fcHi, fcCol = fcCol,
                zHiOn = zebraHiOn, zHiLv = zebraHiLevel, zLoOn = cs.b("c26_zlo_on"), zLoLv = cs.f("c26_zlo_level"), zAlpha = cs.f("c26_z_alpha"),
                bypassView = cs.bypass
            )
        }
    }
}
