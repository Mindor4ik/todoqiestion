package app.procam

import kotlin.math.max
import kotlin.math.min

/**
 * Единый конвейер цвета v0.26 (эталон на CPU; шейдер ColorChain повторяет его шаги один в один).
 *
 *  1 Input Acquisition       — код пикселя 0..1 от камеры (8/10 бит);
 *  2 Input Interpretation    — что это за сигнал: SDR (передаточная функция + охват), HLG (BT.2100), LOG (кривая);
 *  3 Input Transform         — в линейный свет входного охвата;
 *  4 Working Color Space     — линейный рабочий охват (Rec.709 / Rec.2020 / Display P3 / ACEScg), БЕЗ обрезки;
 *  5 Image Processing        — баланс белого, экспозиция, градация ([GradeMath]);
 *  6 Tone / Look             — тон-мэппинг, затем креативный LUT (вход/выход LUT задаются пространствами);
 *  7 Output Transform        — в выходной охват, gamut mapping, передаточная функция выхода;
 *  8 Display/Recording Out   — код 0..1 для экрана или кодека.
 *
 * Превью и запись проходят ОДНУ цепочку и различаются только шагами 7–8 (выходная функция), поэтому
 * порядок преобразований у них одинаков по построению.
 */
enum class InKind(val id: Int, val label: String) {
    SDR(0, "SDR (камера)"), HLG(1, "HLG (BT.2100)"), LOG(2, "LOG-кривая");
    companion object { fun byId(i: Int) = values().firstOrNull { it.id == i } ?: SDR }
}

class OutSpec(val prim: Primaries = Spaces.REC709, val tf: Tf = Tf.SRGB, val gain: Double = 1.0, val hlgWhite: Double = TfMath.HLG_WHITE)

class ColorConfig(
    val input: InKind = InKind.SDR,
    val inTf: Tf = Tf.SRGB,
    val inPrim: Primaries = Spaces.REC709,
    val logCurve: Tf = Tf.FLAT,
    val logGain: Double = 1.0,
    val hlgWhite: Double = TfMath.HLG_WHITE,
    val work: Primaries = Spaces.REC709,
    val grade: GradeParams = GradeParams(),
    val toneMap: ToneMap = ToneMap.NONE,
    val toneWhite: Double = 4.0,
    val gamutMap: GamutMap = GamutMap.CLIP,
    val lut: AnyLut? = null,
    val lutIo: LutIo = LutIo.LOG_LOOK,
    val lutInterp: LutInterp = LutInterp.TRILINEAR,
    val lutMix: Double = 1.0,
    val out: OutSpec = OutSpec()
)

object ColorPipeline {
    /** Шаги 1–3: код камеры → линейный свет в ВХОДНОМ охвате (значения выше 1 не обрезаются). */
    fun inputLinear(c: ColorConfig, src: DoubleArray): DoubleArray = when (c.input) {
        InKind.SDR -> DoubleArray(3) { c.inTf.decode(src[it]) }
        InKind.HLG -> DoubleArray(3) { Tf.HLG.decode(src[it]) / c.hlgWhite }
        InKind.LOG -> DoubleArray(3) { c.logCurve.decode(src[it]) / c.logGain }
    }

    /** Шаги 1–6: линейный свет в РАБОЧЕМ охвате после градации и тон-мэппинга (для скоупов и тестов). */
    fun workingLinear(c: ColorConfig, src: DoubleArray): DoubleArray {
        val lin = M3.mulV(Spaces.convert(c.inPrim, c.work), inputLinear(c, src))
        val wb = WhiteBalance.matrix(c.grade.kelvin, c.grade.tint, c.work)
        val g = GradeMath.apply(lin, c.grade, wb, c.work.lumaWeights())
        return DoubleArray(3) { if (c.toneMap == ToneMap.NONE) g[it] else c.toneMap.apply(g[it], c.toneWhite) }
    }

    /** Линейный свет выходного охвата 0..1 (после gamut mapping) — «что должен показать дисплей». */
    fun outputLinear(c: ColorConfig, src: DoubleArray): DoubleArray {
        val w = workingLinear(c, src)
        val o = M3.mulV(Spaces.convert(c.work, c.out.prim), w)
        return c.gamutMap.apply(o, c.out.prim.lumaWeights())
    }

    fun encodeOut(c: ColorConfig, lin: DoubleArray): DoubleArray = when (c.out.tf) {
        Tf.HLG -> DoubleArray(3) { Tf.HLG.encode(lin[it] * c.out.hlgWhite) }
        Tf.SLOG3, Tf.VLOG, Tf.LOGC, Tf.FLAT -> DoubleArray(3) { c.out.tf.encode(lin[it] * c.out.gain) }
        else -> DoubleArray(3) { c.out.tf.encode(lin[it]) }
    }

    fun decodeOut(c: ColorConfig, code: DoubleArray): DoubleArray = when (c.out.tf) {
        Tf.HLG -> DoubleArray(3) { Tf.HLG.decode(code[it]) / c.out.hlgWhite }
        Tf.SLOG3, Tf.VLOG, Tf.LOGC, Tf.FLAT -> DoubleArray(3) { c.out.tf.decode(code[it]) / c.out.gain }
        else -> DoubleArray(3) { c.out.tf.decode(code[it]) }
    }

    /** Полная цепочка: код камеры → код выхода (экран или кодек). */
    fun process(c: ColorConfig, src: DoubleArray): DoubleArray {
        val lin = outputLinear(c, src)
        val plain = encodeOut(c, lin)
        val lut = c.lut ?: return plain
        // вход LUT: линейный свет (в охвате входа LUT), закодированный функцией входа LUT; LOG-вход «как LOG-кривая съёмки» — без LOG-яркости
        val inTf = if (c.lutIo.input.followLog) c.logCurve else c.lutIo.input.tf
        val li = M3.mulV(Spaces.convert(c.out.prim, c.lutIo.input.prim), lin)
        val lutIn = DoubleArray(3) { inTf.encode(li[it]).coerceIn(0.0, 1.0) }
        val lo = LutEngine.sample(lut, lutIn, c.lutInterp)
        val withLut = if (c.lutIo.output.raw) DoubleArray(3) { lo[it].coerceIn(0.0, 1.0) } else {
            val lutLin = M3.mulV(Spaces.convert(c.lutIo.output.prim, c.out.prim), DoubleArray(3) { c.lutIo.output.tf.decode(lo[it]) })
            encodeOut(c, DoubleArray(3) { lutLin[it].coerceIn(0.0, 1.0) })
        }
        val k = c.lutMix.coerceIn(0.0, 1.0)
        return DoubleArray(3) { plain[it] + (withLut[it] - plain[it]) * k }
    }
}
