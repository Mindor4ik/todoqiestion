package app.procam

import java.util.zip.CRC32

/** Общие мелкие помощники v0.28: экранирование строк и контрольная сумма для экспорта/импорта (чистая логика, без android.*). */
object Codec28 {
    fun esc(s: String) = s.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t")
    fun unesc(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 'n' -> sb.append('\n'); 't' -> sb.append('\t'); else -> sb.append(s[i + 1]) }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    fun crc(s: String): String { val c = CRC32(); c.update(s.toByteArray(Charsets.UTF_8)); return java.lang.Long.toHexString(c.value) }

    /** Типизированное значение в строку «тип\tзначение». Типы те же, что в SettingsManager: b i l f s. */
    fun typed(v: Any?): Pair<String, String>? = when (v) {
        is Boolean -> "b" to v.toString(); is Int -> "i" to v.toString(); is Long -> "l" to v.toString()
        is Float -> "f" to v.toString(); is String -> "s" to v; else -> null
    }

    fun parse(type: String, s: String): Any? = try {
        when (type) { "b" -> s.toBooleanStrict(); "i" -> s.toInt(); "l" -> s.toLong(); "f" -> s.toFloat(); "s" -> s; else -> null }
    } catch (e: Exception) { null }

    /**
     * Текстовый контейнер с заголовком, видом и контрольной суммой: «BR28|kind|crc»\nстроки «ключ\tтип\tзначение».
     * Импорт отвергает чужой вид, повреждённую сумму и неизвестный заголовок — файл не применяется частично.
     */
    fun pack(kind: String, values: Map<String, Any?>): String {
        val body = StringBuilder()
        for ((k, v) in values) { val t = typed(v) ?: continue; body.append(esc(k)).append('\t').append(t.first).append('\t').append(esc(t.second)).append('\n') }
        return "BR28|$kind|${crc(body.toString())}\n$body"
    }

    class Unpacked(val values: Map<String, Any?>, val error: String?)

    fun unpack(kind: String, text: String): Unpacked {
        val nl = text.indexOf('\n')
        if (nl < 0) return Unpacked(emptyMap(), "пустой или неполный файл")
        val head = text.substring(0, nl).trim().split('|')
        if (head.size != 3 || head[0] != "BR28") return Unpacked(emptyMap(), "это не файл настроек Beyond Recorder (заголовок не распознан)")
        if (head[1] != kind) return Unpacked(emptyMap(), "вид файла «${head[1]}», ожидался «$kind»")
        val body = text.substring(nl + 1)
        if (crc(body) != head[2]) return Unpacked(emptyMap(), "контрольная сумма не совпала: файл повреждён или изменён")
        val out = LinkedHashMap<String, Any?>()
        for (line in body.split('\n')) {
            if (line.isEmpty()) continue
            val p = line.split('\t')
            if (p.size < 3) return Unpacked(emptyMap(), "повреждённая строка")
            val v = parse(p[1], unesc(p[2])) ?: return Unpacked(emptyMap(), "значение «${unesc(p[0])}» не разобрано")
            out[unesc(p[0])] = v
        }
        return Unpacked(out, null)
    }
}
