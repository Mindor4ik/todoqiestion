package app.procam

/**
 * Настройки Computational Imaging v0.27 (ключи «ci_»). Лежат в общем хранилище (схема v4): пресеты, сброс, проверка значений, миграция работают сами.
 * Прежние ключи eis / eis_horizon / eis_lock / nr_soft остаются главными включателями и быстрыми уровнями.
 */
object CiKeys {
    private fun f(lo: Float, hi: Float, d: Float) = Rule.FloatR(lo, hi, d)
    private fun i(lo: Int, hi: Int, d: Int) = Rule.IntR(lo, hi, d)
    private fun b(d: Boolean) = Rule.BoolR(d)
    val AN_W = intArrayOf(0, 96, 128, 160, 192)

    val rules: Map<String, Rule> = linkedMapOf(
        // стабилизация
        "ci_src" to i(0, 2, 0), "ci_strength" to f(0f, 4f, 1f), "ci_char" to f(0f, 1f, 0.5f), "ci_adapt" to b(false),
        "ci_maxcrop" to f(-1f, 90f, -1f), "ci_dyncrop" to b(false), "ci_border" to i(0, 2, 0), "ci_jump" to b(false),
        // Frame Lock
        "ci_lock_str" to f(0f, 2f, 1f), "ci_lock_smooth" to f(0f, 1f, 0.5f), "ci_lock_flow" to i(0, 2, 2),
        // оптический поток
        "ci_flow" to i(0, 2, 0),
        // rolling shutter
        "ci_rs" to b(true), "ci_rs_str" to f(0f, 2f, 1f), "ci_rs_skew" to f(0f, 100f, 0f), "ci_rs_meas" to b(false),
        // горизонт
        "ci_hz_str" to f(0f, 1f, 1f), "ci_hz_trim" to f(-20f, 20f, 0f), "ci_hz_src" to i(0, 2, 0),
        // шумоподавление 4.0
        "ci_nr_adv" to b(false), "ci_nr_spat" to b(true), "ci_nr_temp" to b(true),
        "ci_nr_luma" to f(0f, 1f, 0.6f), "ci_nr_chroma" to f(0f, 1f, 0.6f), "ci_nr_detail" to f(0f, 1f, 0.5f), "ci_nr_mc" to b(false),
        // low light
        "ci_ll" to b(false), "ci_ll_str" to f(0f, 1f, 0.6f),
        // производительность
        "ci_proc" to i(0, 2, 1), "ci_an_w" to i(0, 4, 0), "ci_an_div" to i(0, 8, 0), "ci_diag" to b(false)
    )
}

class CiSettings(private val store: KeyValueStore) {
    /** Не сохраняется: показать превью без вычислительной обработки (стабилизация, NR) для сравнения. В файл не влияет. */
    @Volatile var compare = false

    private fun raw(k: String): Any? = store.all()[k]
    fun f(k: String): Float { val r = CiKeys.rules[k] as Rule.FloatR; val v = raw(k); return if (v != null && r.ok(v)) v as Float else r.default }
    fun i(k: String): Int { val r = CiKeys.rules[k] as Rule.IntR; val v = raw(k); return if (v != null && r.ok(v)) v as Int else r.default }
    fun b(k: String): Boolean { val r = CiKeys.rules[k] as Rule.BoolR; val v = raw(k); return if (v != null && r.ok(v)) v as Boolean else r.default }
    fun set(k: String, v: Any) {
        val r = CiKeys.rules[k] ?: return
        val fixed: Any = when (r) {
            is Rule.FloatR -> (v as Number).toFloat().coerceIn(r.min, r.max)
            is Rule.IntR -> (v as Number).toInt().coerceIn(r.min, r.max)
            else -> v
        }
        store.commit(mapOf(k to fixed))
    }
    fun reset(keys: Collection<String>) = store.commit(emptyMap(), keys.toSet())

    fun temporal(): TemporalManager.Mode = TemporalManager.Mode.values()[i("ci_proc")]
    fun flow(): FlowMethod = FlowMethod.values()[i("ci_flow")]
    fun lockFlow(): FlowMethod = FlowMethod.values()[i("ci_lock_flow")]

    /** Параметры анализа с учётом режима обработки и ручных переопределений. */
    fun analysis(p: TemporalManager.Profile): Analysis {
        val w = CiKeys.AN_W[i("ci_an_w")].let { if (it == 0) p.analysisW else it }
        val div = i("ci_an_div").let { if (it == 0) p.analysisEvery else it }
        return Analysis(w, div, p.flowLevels, p.maxFeatures, p.ransacIters)
    }
    class Analysis(val w: Int, val every: Int, val levels: Int, val features: Int, val ransac: Int)

    fun nr(level: Int, profile: TemporalManager.Profile): NrSettings = NrSettings(
        level = level, advanced = b("ci_nr_adv"), spatial = b("ci_nr_spat"), temporal = b("ci_nr_temp"),
        luma = f("ci_nr_luma"), chroma = f("ci_nr_chroma"), detail = f("ci_nr_detail"),
        lowLight = b("ci_ll"), lowLightStrength = f("ci_ll_str"), temporalScale = profile.nrTemporalScale
    )
}

/** Что GL-конвейер получает от настроек Computational Imaging. */
class CiGl(
    val visual: Boolean,                 // ориентация камеры берётся из оптического потока
    val method: FlowMethod,
    val lockMethod: FlowMethod,
    val anW: Int, val anEvery: Int, val levels: Int, val features: Int, val ransac: Int,
    val rsMeasure: Boolean, val horizonImage: Boolean,
    val nr: NrShaderParams?, val nrMc: Boolean,
    val compare: Boolean, val diag: Boolean, val nominalFps: Int
)

/** Снимок диагностики вычислительного конвейера (для оверлея и вкладки). Векторы нормированы в 0..1 по кадру анализа. */
class CiDiag(
    val method: String, val source: String,
    val tx: Double, val ty: Double, val rotDeg: Double, val scale: Double, val conf: Double, val inliers: Int, val tracked: Int,
    val vecs: FloatArray,          // x0,y0,x1,y1 (0..1), по 4 числа; inlier-флаги в vin
    val vin: BooleanArray,
    val trajX: FloatArray, val trajY: FloatArray,   // последние оценки смещения (px анализа) для графика траектории
    val crop: Double, val alpha: Double, val cropLimited: Boolean,
    val speed: Double, val sigmaSec: Double,
    val horizonDeg: Double, val horizonSrc: Int,
    val rsRowsMs: Double, val rsColsMs: Double, val rsRel: Double,
    val procMs: Double, val analysisMs: Double, val fps: Double, val dropped: Long, val gaps: Long,
    val nrFrames: Float, val nrOn: Boolean, val shaderNr: Boolean
)
