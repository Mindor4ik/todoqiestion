package app.procam

import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View

enum class UiStyle(val label: String) { MATERIAL("Material"), GLASS("Liquid Glass") }

/** Centralized palette and surfaces for the two UI styles. */
object Ui {
    var style: UiStyle = UiStyle.MATERIAL
    val glass: Boolean get() = style == UiStyle.GLASS
    val accent: Int get() = 0xFFFFB300.toInt()
    val onAccent: Int get() = 0xFF1A1200.toInt()
    val text: Int get() = if (glass) 0xFFF2F7FC.toInt() else 0xFFECEFF2.toInt()
    val dim: Int get() = if (glass) 0xFFA8B6C6.toInt() else 0xFF9AA7B2.toInt()
    val root: Int get() = if (glass) 0xFF05070C.toInt() else 0xFF0B0E11.toInt()
    val dock: Int get() = if (glass) 0xB30A1018.toInt() else 0xFF101010.toInt()
    enum class Kind { PANEL, CHIP, BUTTON, HUD, MENU }
    private fun radius(k: Kind) = when (k) {
        Kind.PANEL, Kind.MENU -> if (glass) 24f else 16f
        Kind.HUD -> if (glass) 16f else 10f
        else -> if (glass) 20f else 12f
    }
    private fun base(k: Kind, active: Boolean): GradientDrawable {
        val g = GradientDrawable(); g.cornerRadius = radius(k)
        if (active) { g.setColor(accent); g.setStroke(1, accent); return g }
        when (k) {
            Kind.HUD -> { g.setColor(if (glass) 0x660A1018 else 0x88000000.toInt()); g.setStroke(1, if (glass) 0x2AFFFFFF else 0x00000000) }
            Kind.PANEL, Kind.MENU -> { g.setColor(if (glass) 0x8C141C28.toInt() else 0xFF151A20.toInt()); g.setStroke(1, if (glass) 0x2EFFFFFF else 0xFF2A333D.toInt()) }
            else -> { g.setColor(if (glass) 0x731E2A3A else 0xFF1D242C.toInt()); g.setStroke(1, if (glass) 0x24FFFFFF else 0xFF3C454D.toInt()) }
        }
        return g
    }
    fun bg(k: Kind, active: Boolean = false): Drawable {
        val b = base(k, active)
        if (!glass || active) return b
        val sheen = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x30FFFFFF, 0x0CFFFFFF, 0x00000000))
        sheen.cornerRadius = radius(k)
        return LayerDrawable(arrayOf(b, sheen))
    }
    fun ripple(content: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(if (glass) 0x33FFFFFF else 0x33FFB300.toInt()), content, null)
    fun skin(v: View, k: Kind, active: Boolean = false) { v.background = ripple(bg(k, active)); v.elevation = if (glass) 8f else 1f }
}
