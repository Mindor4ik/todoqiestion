package app.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Сетка-композиция поверх превью. В запись не попадает. */
enum class Grid(val label: String, val desc: String) {
    OFF("Выкл", "Сетка выключена."),
    THIRDS("3×3", "Правило третей: ставьте главный объект на пересечения линий, горизонт — на одну из горизонталей."),
    GRID4("4×4", "Мелкая сетка: удобно выравнивать горизонт и вертикали зданий."),
    PHI("Золотое", "Золотое сечение (1 : 1,618) — линии ближе к центру, чем в правиле третей; мягкая композиция."),
    CROSS("Крест", "Центральный крест — для симметричных кадров и точного центрирования."),
    DIAG("Диагонали", "Сетка 3×3 и диагонали кадра — для динамичных композиций и ведущих линий.")
}

class GridView(c: Context) : View(c) {
    var grid: Grid = Grid.OFF
        set(v) { field = v; invalidate() }

    private val px = resources.displayMetrics.density
    private val light = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3FFFFFF.toInt(); strokeWidth = 1.5f * px }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000; strokeWidth = 1.5f * px }

    private fun line(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        cv.drawLine(x1 + px, y1 + px, x2 + px, y2 + px, dark)   // тень, чтобы линии читались на светлом
        cv.drawLine(x1, y1, x2, y2, light)
    }

    private fun vertical(cv: Canvas, fr: FloatArray) { for (f in fr) line(cv, width * f, 0f, width * f, height.toFloat()) }
    private fun horizontal(cv: Canvas, fr: FloatArray) { for (f in fr) line(cv, 0f, height * f, width.toFloat(), height * f) }

    override fun onDraw(cv: Canvas) {
        if (grid == Grid.OFF) return
        val w = width.toFloat()
        val h = height.toFloat()
        val thirds = floatArrayOf(1f / 3f, 2f / 3f)
        when (grid) {
            Grid.THIRDS -> { vertical(cv, thirds); horizontal(cv, thirds) }
            Grid.GRID4 -> { val q = floatArrayOf(0.25f, 0.5f, 0.75f); vertical(cv, q); horizontal(cv, q) }
            Grid.PHI -> { val p = floatArrayOf(0.381966f, 0.618034f); vertical(cv, p); horizontal(cv, p) }
            Grid.CROSS -> { vertical(cv, floatArrayOf(0.5f)); horizontal(cv, floatArrayOf(0.5f)) }
            Grid.DIAG -> {
                vertical(cv, thirds); horizontal(cv, thirds)
                line(cv, 0f, 0f, w, h); line(cv, 0f, h, w, 0f)
            }
            else -> {}
        }
    }
}
