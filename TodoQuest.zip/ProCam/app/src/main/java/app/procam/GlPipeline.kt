package app.procam

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import kotlin.math.max

/** Параметры шейдера. out: 0 = без обработки, 1 = LOG, 2 = HLG (только для кодера). */
data class GlParams(
    val out: Int = 0,
    val curve: Int = 1,
    val inLog: Boolean = false,      // камера уже отдаёт LOG (аппаратная кривая)
    val inHlg: Boolean = false,      // превью-выход камеры в HLG10
    val viewLog: Boolean = false,    // монитор показывает плоскую LOG-картинку
    val zebra: Boolean = false,
    val zebraLevel: Float = 0.95f,
    val peaking: Boolean = false,
    val falseColor: Boolean = false,
    val hist: Boolean = true,
    val rotate180: Boolean = false
)

/**
 * Камера -> SurfaceTexture (OES) -> шейдер -> [окно превью] и (опционально) [входная поверхность кодека].
 * Здесь же эмуляция LOG/HLG для телефонов без нативной поддержки и все мониторные ассисты.
 */
class GlPipeline(private val onHistogram: (IntArray) -> Unit) {
    companion object {
        private const val TAG = "ProCamGL"
        const val SW = 128
        const val SH = 72

        private const val VS = """#version 300 es
uniform mat4 uTexMat;
uniform float uSign;
out vec2 vUv;
void main() {
  vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
  gl_Position = vec4(p * uSign, 0.0, 1.0);
  vUv = (uTexMat * vec4(p * 0.5 + 0.5, 0.0, 1.0)).xy;
}
"""

        private const val FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES uTex;
uniform int uPass;      // 0 = запись, 1 = превью, 2 = скоуп (гистограмма)
uniform int uOut;       // 0 sdr, 1 log, 2 hlg
uniform int uCurve;     // 0 flat, 1 slog3, 2 vlog, 3 logc
uniform int uInLog;
uniform int uInHlg;
uniform int uViewLog;
uniform int uZebra;
uniform float uZebraLevel;
uniform int uPeak;
uniform int uFalse;
uniform vec2 uTexel;
in vec2 vUv;
out vec4 oColor;

const float L10 = 0.30103;      // log10(2)
const float HLG_WHITE = 0.265;  // сцена-линейный уровень SDR-белого (~203 нит) в HLG
const mat3 TO2020 = mat3(0.6274039, 0.0690973, 0.0163914,
                         0.3292830, 0.9195404, 0.0880133,
                         0.0433131, 0.0113623, 0.8955953);
const mat3 TO709 = mat3(1.6604910, -0.1245505, -0.0181508,
                        -0.5876411, 1.1328999, -0.1005789,
                        -0.0728499, -0.0083494, 1.1187297);

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 srgbDec(vec3 v) { return mix(v / 12.92, pow((v + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), v)); }
vec3 srgbEnc(vec3 l) { l = clamp(l, 0.0, 1.0); return mix(l * 12.92, 1.055 * pow(l, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), l)); }

float logEncC(int c, float x) {
  x = max(x, 0.0);
  if (c == 1) return x >= 0.01125 ? (420.0 + log2((x + 0.01) / 0.19) * L10 * 261.5) / 1023.0
                                  : (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0;
  if (c == 2) return x < 0.01 ? 5.6 * x + 0.125 : 0.241514 * log2(x + 0.00873) * L10 + 0.598206;
  if (c == 3) return x > 0.010591 ? 0.247190 * log2(5.555556 * x + 0.052272) * L10 + 0.385537
                                  : 5.367655 * x + 0.092809;
  return log2(1.0 + 31.0 * x) / 5.0;
}
float logDecC(int c, float y) {
  y = clamp(y, 0.0, 1.0);
  if (c == 1) { float v = y * 1023.0; return v >= 171.2102946929 ? pow(10.0, (v - 420.0) / 261.5) * 0.19 - 0.01
                                                                 : (v - 95.0) * 0.01125 / (171.2102946929 - 95.0); }
  if (c == 2) return y < 0.181 ? (y - 0.125) / 5.6 : pow(10.0, (y - 0.598206) / 0.241514) - 0.00873;
  if (c == 3) return y > 0.149658 ? (pow(10.0, (y - 0.385537) / 0.247190) - 0.052272) / 5.555556
                                  : (y - 0.092809) / 5.367655;
  return (exp2(5.0 * y) - 1.0) / 31.0;
}
vec3 logEnc(vec3 l) { return vec3(logEncC(uCurve, l.r), logEncC(uCurve, l.g), logEncC(uCurve, l.b)); }
vec3 logDec(vec3 v) { return vec3(logDecC(uCurve, v.r), logDecC(uCurve, v.g), logDecC(uCurve, v.b)); }

float hlgOetf(float e) {
  e = clamp(e, 0.0, 1.0);
  return e <= 1.0 / 12.0 ? sqrt(3.0 * e) : 0.17883277 * log(max(12.0 * e - 0.28466892, 1e-6)) + 0.55991073;
}
float hlgInv(float v) {
  v = clamp(v, 0.0, 1.0);
  return v <= 0.5 ? v * v / 3.0 : (exp((v - 0.55991073) / 0.17883277) + 0.28466892) / 12.0;
}

vec3 falseColor(float y) {
  if (y < 0.03) return vec3(0.4, 0.0, 0.6);
  if (y < 0.10) return vec3(0.0, 0.25, 0.95);
  if (y > 0.97) return vec3(1.0, 0.0, 0.0);
  if (y > 0.90) return vec3(1.0, 0.9, 0.0);
  if (y > 0.55 && y < 0.62) return vec3(1.0, 0.55, 0.7);
  if (y > 0.38 && y < 0.48) return vec3(0.0, 0.75, 0.2);
  return vec3(y);
}

void main() {
  vec3 src = clamp(texture(uTex, vUv).rgb, 0.0, 1.0);
  if (uPass == 0) {
    vec3 lin = srgbDec(src);
    vec3 c = src;
    if (uOut == 1) {
      c = logEnc(lin);
    } else if (uOut == 2) {
      vec3 e = TO2020 * lin * HLG_WHITE;
      c = vec3(hlgOetf(e.r), hlgOetf(e.g), hlgOetf(e.b));
    }
    oColor = vec4(c, 1.0);
    return;
  }
  vec3 lin;
  if (uInLog == 1) {
    lin = logDec(src);
  } else if (uInHlg == 1) {
    vec3 e = vec3(hlgInv(src.r), hlgInv(src.g), hlgInv(src.b)) / HLG_WHITE;
    lin = clamp(TO709 * e, 0.0, 1.0);
  } else {
    lin = srgbDec(src);
  }
  vec3 v = srgbEnc(lin);
  if (uViewLog == 1) v = (uInLog == 1) ? src : logEnc(lin);
  if (uPass == 1) {
    float y = lum(v);
    if (uFalse == 1) v = falseColor(y);
    if (uPeak == 1) {
      float gx = lum(texture(uTex, vUv + vec2(uTexel.x, 0.0)).rgb) - lum(texture(uTex, vUv - vec2(uTexel.x, 0.0)).rgb);
      float gy = lum(texture(uTex, vUv + vec2(0.0, uTexel.y)).rgb) - lum(texture(uTex, vUv - vec2(0.0, uTexel.y)).rgb);
      if (abs(gx) + abs(gy) > 0.18) v = vec3(1.0, 0.15, 0.15);
    }
    if (uZebra == 1 && y >= uZebraLevel) {
      if (fract((gl_FragCoord.x + gl_FragCoord.y) / 14.0) > 0.5) v = vec3(0.0);
    }
  }
  oColor = vec4(v, 1.0);
}
"""
    }

    private val thread = HandlerThread("procam-gl").also { it.start() }
    private val handler = Handler(thread.looper)
    @Volatile var params = GlParams()

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var prevSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var encSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var prevW = 1
    private var prevH = 1
    private var encW = 1
    private var encH = 1
    private var st: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private var tex = 0
    private var prog = 0
    private var scopeTex = 0
    private var fbo = 0
    private val tm = FloatArray(16)
    private val locs = HashMap<String, Int>()
    private var texel = floatArrayOf(0f, 0f)
    private var lastScope = 0L
    private val px = ByteBuffer.allocateDirect(SW * SH * 4)

    /** Запускается в GL-потоке. ready(поверхность для камеры, активен ли 10-bit, ошибка). */
    fun start(preview: Surface, camW: Int, camH: Int, wantTenBit: Boolean, ready: (Surface?, Boolean, String?) -> Unit) {
        handler.post {
            try {
                var ten = false
                var created = false
                for (t in if (wantTenBit) listOf(true, false) else listOf(false)) {
                    try {
                        initEgl(t)
                        prevSurf = EGL14.eglCreateWindowSurface(dpy, cfg, preview, intArrayOf(EGL14.EGL_NONE), 0)
                        if (prevSurf == EGL14.EGL_NO_SURFACE) throw RuntimeException("eglCreateWindowSurface")
                        if (!EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)) throw RuntimeException("eglMakeCurrent")
                        ten = t
                        created = true
                        break
                    } catch (e: Exception) {
                        Log.w(TAG, "EGL init (10-bit=$t) failed: ${e.message}")
                        releaseEgl()
                    }
                }
                if (!created) throw RuntimeException("не удалось создать EGL")
                EGL14.eglSwapInterval(dpy, 0)
                val sz = IntArray(1)
                EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_WIDTH, sz, 0); prevW = sz[0]
                EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_HEIGHT, sz, 0); prevH = sz[0]
                initGl()
                val k = max(1f, camW / 1280f)
                texel = floatArrayOf(k / camW, k / camH)
                val s = SurfaceTexture(tex)
                s.setDefaultBufferSize(camW, camH)
                s.setOnFrameAvailableListener({ drawFrame() }, handler)
                st = s
                camSurface = Surface(s)
                ready(camSurface, ten, null)
            } catch (e: Throwable) {
                Log.e(TAG, "start failed", e)
                ready(null, false, e.message)
            }
        }
    }

    fun startEncoding(surface: Surface, w: Int, h: Int) {
        handler.post {
            try {
                encSurf = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
                encW = w
                encH = h
                if (encSurf != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)
                    EGL14.eglSwapInterval(dpy, 0)
                    EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                }
            } catch (e: Exception) {
                Log.e(TAG, "startEncoding", e)
                encSurf = EGL14.EGL_NO_SURFACE
            }
        }
    }

    fun stopEncoding(done: () -> Unit) {
        handler.post {
            if (encSurf != EGL14.EGL_NO_SURFACE && dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                EGL14.eglDestroySurface(dpy, encSurf)
            }
            encSurf = EGL14.EGL_NO_SURFACE
            done()
        }
    }

    fun stop() {
        handler.post {
            try {
                st?.setOnFrameAvailableListener(null)
                st?.release(); st = null
                camSurface?.release(); camSurface = null
                releaseEgl()
            } catch (e: Exception) {
                Log.w(TAG, "stop", e)
            }
            thread.quitSafely()
        }
    }

    // ---------------------------------------------------------------- EGL / GL

    private fun initEgl(tenBit: Boolean) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw RuntimeException("eglInitialize")
        cfg = chooseConfig(tenBit)
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        if (ctx == EGL14.EGL_NO_CONTEXT) throw RuntimeException("eglCreateContext (нужен GLES 3.0)")
    }

    private fun chooseConfig(tenBit: Boolean): EGLConfig {
        val bits = if (tenBit) 10 else 8
        val alpha = if (tenBit) 2 else 8
        for (recordable in listOf(true, false)) {
            val a = ArrayList<Int>()
            a.addAll(listOf(EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR))
            a.addAll(listOf(EGL14.EGL_RED_SIZE, bits, EGL14.EGL_GREEN_SIZE, bits, EGL14.EGL_BLUE_SIZE, bits, EGL14.EGL_ALPHA_SIZE, alpha))
            if (recordable) a.addAll(listOf(0x3142, 1)) // EGL_RECORDABLE_ANDROID
            a.add(EGL14.EGL_NONE)
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (EGL14.eglChooseConfig(dpy, a.toIntArray(), 0, cfgs, 0, 1, n, 0) && n[0] > 0 && cfgs[0] != null) return cfgs[0]!!
        }
        throw RuntimeException("нет подходящего EGLConfig (10-bit=$tenBit)")
    }

    private fun releaseEgl() {
        if (dpy != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (encSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, encSurf)
            if (prevSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, prevSurf)
            if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(dpy)
        }
        dpy = EGL14.EGL_NO_DISPLAY; ctx = EGL14.EGL_NO_CONTEXT
        prevSurf = EGL14.EGL_NO_SURFACE; encSurf = EGL14.EGL_NO_SURFACE
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            throw RuntimeException("шейдер: $log")
        }
        return s
    }

    private fun initGl() {
        val vs = compile(GLES30.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, FS)
        prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: ${GLES30.glGetProgramInfoLog(prog)}")
        locs.clear()

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        tex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, tex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glGenTextures(1, t, 0)
        scopeTex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, scopeTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SW, SH, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, scopeTex, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun loc(name: String): Int = locs.getOrPut(name) { GLES30.glGetUniformLocation(prog, name) }

    private fun b(v: Boolean) = if (v) 1 else 0

    private fun draw(p: GlParams, pass: Int) {
        GLES30.glUseProgram(prog)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, tm, 0)
        GLES30.glUniform1f(loc("uSign"), if (pass == 1 && p.rotate180) -1f else 1f)
        GLES30.glUniform1i(loc("uPass"), pass)
        GLES30.glUniform1i(loc("uOut"), p.out)
        GLES30.glUniform1i(loc("uCurve"), p.curve)
        GLES30.glUniform1i(loc("uInLog"), b(p.inLog))
        GLES30.glUniform1i(loc("uInHlg"), b(p.inHlg))
        GLES30.glUniform1i(loc("uViewLog"), b(p.viewLog))
        GLES30.glUniform1i(loc("uZebra"), b(p.zebra))
        GLES30.glUniform1f(loc("uZebraLevel"), p.zebraLevel)
        GLES30.glUniform1i(loc("uPeak"), b(p.peaking))
        GLES30.glUniform1i(loc("uFalse"), b(p.falseColor))
        GLES30.glUniform2f(loc("uTexel"), texel[0], texel[1])
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun drawFrame() {
        val s = st ?: return
        if (dpy == EGL14.EGL_NO_DISPLAY) return
        try {
            s.updateTexImage()
            s.getTransformMatrix(tm)
            val ts = s.timestamp
            val p = params

            if (encSurf != EGL14.EGL_NO_SURFACE) {
                EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)
                GLES30.glViewport(0, 0, encW, encH)
                draw(p, 0)
                EGLExt.eglPresentationTimeANDROID(dpy, encSurf, ts)
                EGL14.eglSwapBuffers(dpy, encSurf)
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
            }

            GLES30.glViewport(0, 0, prevW, prevH)
            draw(p, 1)
            EGL14.eglSwapBuffers(dpy, prevSurf)

            if (p.hist) {
                val now = SystemClock.uptimeMillis()
                if (now - lastScope > 160) {
                    lastScope = now
                    scope(p)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "drawFrame: ${e.message}")
        }
    }

    private fun scope(p: GlParams) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glViewport(0, 0, SW, SH)
        draw(p, 2)
        px.clear()
        GLES30.glReadPixels(0, 0, SW, SH, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, px)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        val bins = IntArray(64)
        px.rewind()
        for (i in 0 until SW * SH) {
            val r = px.get().toInt() and 255
            val g = px.get().toInt() and 255
            val bl = px.get().toInt() and 255
            px.get()
            val y = 0.2126 * r + 0.7152 * g + 0.0722 * bl
            bins[(y / 4.0).toInt().coerceIn(0, 63)]++
        }
        onHistogram(bins)
    }
}
