package app.procam

import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

/** Порядок enum = индекс в шейдере (uCurve). */
enum class Curve(val label: String) {
    FLAT("Flat"), SLOG3("S-Log3"), VLOG("V-Log"), LOGC("LogC")
}

/** Те же формулы, что в шейдере; нужны для аппаратной tone-curve (Camera2 TONEMAP_CURVE). */
object LogMath {
    fun encode(c: Curve, xIn: Float): Float {
        val x = max(0f, xIn).toDouble()
        val y = when (c) {
            Curve.SLOG3 ->
                if (x >= 0.01125) (420.0 + log10((x + 0.01) / 0.19) * 261.5) / 1023.0
                else (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0
            Curve.VLOG ->
                if (x < 0.01) 5.6 * x + 0.125 else 0.241514 * log10(x + 0.00873) + 0.598206
            Curve.LOGC ->
                if (x > 0.010591) 0.247190 * log10(5.555556 * x + 0.052272) + 0.385537
                else 5.367655 * x + 0.092809
            Curve.FLAT -> ln(1.0 + 31.0 * x) / ln(2.0) / 5.0
        }
        return y.coerceIn(0.0, 1.0).toFloat()
    }

    /** Интерлив (x0,y0,x1,y1,...), точки сгущены в тенях. */
    fun tonemapPoints(c: Curve, n: Int): FloatArray {
        val a = FloatArray(n * 2)
        for (i in 0 until n) {
            val t = i / (n - 1f)
            val x = t.pow(2.2f)
            a[2 * i] = x
            a[2 * i + 1] = encode(c, x)
        }
        return a
    }
}
