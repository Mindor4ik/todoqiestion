package app.procam

import java.io.BufferedReader
import java.io.InputStreamReader

data class CubeLut(val title: String, val size: Int, val values: List<FloatArray>)

object CubeLutReader {
    fun read(reader: BufferedReader): CubeLut {
        var title = "Custom LUT"
        var size = 0
        val values = mutableListOf<FloatArray>()
        reader.forEachLine { raw ->
            val line = raw.substringBefore("#").trim()
            if (line.isEmpty()) return@forEachLine
            val parts = line.split(Regex("\\s+"))
            when (parts[0].uppercase()) {
                "TITLE" -> title = line.substringAfter("TITLE").trim().trim('"').ifBlank { title }
                "LUT_3D_SIZE" -> size = parts.getOrNull(1)?.toIntOrNull() ?: error("Некорректный LUT_3D_SIZE")
                "DOMAIN_MIN", "DOMAIN_MAX" -> Unit
                else -> {
                    if (parts.size != 3) error("Неизвестная строка: $line")
                    val rgb = parts.map { it.toFloatOrNull() ?: error("Не число в LUT") }
                    require(rgb.all { it.isFinite() }) { "В LUT есть NaN/Infinity" }
                    values.add(rgb.toFloatArray())
                }
            }
        }
        require(size in 2..65) { "Поддерживается LUT_3D_SIZE от 2 до 65" }
        require(values.size == size * size * size) {
            "Число RGB-значений ${values.size}, ожидалось ${size * size * size}"
        }
        return CubeLut(title, size, values)
    }
}
