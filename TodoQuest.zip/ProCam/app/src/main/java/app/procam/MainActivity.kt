package app.procam

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Простая гистограмма яркости (64 столбца, корневая шкала). */
class HistogramView(c: Context) : View(c) {
    private var bins = IntArray(64)
    private val p = Paint().apply { color = 0xCCFFFFFF.toInt() }
    private val bg = Paint().apply { color = 0x66000000 }

    fun set(b: IntArray) { bins = b; invalidate() }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val mx = (bins.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val bw = width / 64f
        for (i in 0 until 64) {
            val h = sqrt(bins[i] / mx) * height
            cv.drawRect(i * bw, height - h, (i + 1) * bw, height.toFloat(), p)
        }
    }
}

class MainActivity : Activity(), SurfaceHolder.Callback, CameraEngine.Listener {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val stripH = 44                       // dp, нижняя полоса быстрых кнопок
    private val sideW = 92                        // dp, правая колонка
    private val tabLut = 2
    private val tabNames = listOf("Видео", "Цвет", "LUT", "Монитор", "Камера")
    private val amber = 0xFFFFB300.toInt()

    private lateinit var engine: CameraEngine
    private lateinit var root: FrameLayout
    private lateinit var host: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var gridView: GridView
    private lateinit var hud: TextView
    private lateinit var expHud: TextView
    private lateinit var recHud: TextView
    private lateinit var hist: HistogramView
    private lateinit var panel: LinearLayout
    private lateinit var strip: LinearLayout
    private lateinit var side: LinearLayout
    private lateinit var recBtn: Button
    private lateinit var isoBar: SeekBar
    private lateinit var shutBar: SeekBar
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar
    // меню
    private lateinit var menu: FrameLayout
    private lateinit var menuBody: LinearLayout
    private lateinit var menuScroll: ScrollView
    private lateinit var menuTabsBox: LinearLayout
    private val tabButtons = ArrayList<Button>()
    private var menuTab = 0

    private val main = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()       // быстрые кнопки
    private val menuRefreshers = ArrayList<() -> Unit>()   // строки текущей вкладки меню
    private var lenses: List<Lens> = emptyList()
    private var shutters: List<Int> = emptyList()
    private var ready = false
    private var recording = false
    private var recStart = 0L
    private var gridIdx = 1

    private val lutPicker = 44
    private val maxLutBytes = 40L * 1024 * 1024
    private val prefs by lazy { getSharedPreferences("procam", MODE_PRIVATE) }
    private val lutLib by lazy { LutLibrary(prefs) }
    private val lutCache = LinkedHashMap<String, CubeLut>()   // последние 2 разобранных LUT — переключение мгновенное
    @Volatile private var pendingLut: String? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun toastLong(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    /** Во время записи смены маршрута запрещены: restart() остановил бы запись. */
    private fun idle(block: () -> Unit) {
        if (recording) toast("Сначала остановите запись") else block()
    }

    // ------------------------------------------------------------ LUT: библиотека

    private fun activeLutName(): String = lutLib.active()?.name ?: "нет"

    private fun pickLutFiles() = idle {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, lutPicker)
    }

    @Deprecated("Legacy SAF result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != lutPicker || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        // Без постоянного доступа сохранённый URI после перезапуска приложения уже не откроется.
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        }
        importLuts(uris)
    }

    private fun displayName(u: Uri): String {
        var n: String? = null
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        } catch (e: Exception) { }
        return (n ?: u.lastPathSegment ?: "LUT").removeSuffix(".cube").removeSuffix(".CUBE")
    }

    /** Разбор .cube (LUT 65³ — сотни мс и десятки МБ): только в фоне. */
    private fun parseLut(uri: Uri): CubeLut {
        val len = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        if (len > maxLutBytes) error("файл слишком большой для .cube (${len / 1_000_000} МБ)")
        return contentResolver.openInputStream(uri)?.use { input ->
            CubeLutReader.read(BufferedReader(InputStreamReader(input, Charsets.UTF_8)))
        } ?: error("не удалось открыть файл")
    }

    private fun importLuts(uris: List<Uri>) {
        toast("Читаю LUT: ${uris.size}…")
        Thread({
            val ok = ArrayList<Pair<LutEntry, CubeLut?>>()
            val errors = ArrayList<String>()
            for (u in uris) {
                val name = displayName(u)
                try {
                    val lut = parseLut(u)
                    // Объект LUT оставляем только у первого файла (его можно сразу включить) — остальные не держим в памяти.
                    ok.add(LutEntry(name, u.toString(), lut.size) to (if (ok.isEmpty()) lut else null))
                } catch (e: OutOfMemoryError) {
                    errors.add("$name: недостаточно памяти")
                } catch (e: Exception) {
                    errors.add("$name: ${e.message ?: "неверный .cube"}")
                }
            }
            runOnUiThread { if (!isDestroyed) onLutsImported(ok, errors, uris.size == 1) }
        }, "lut-import").start()
    }

    private fun onLutsImported(ok: List<Pair<LutEntry, CubeLut?>>, errors: List<String>, single: Boolean) {
        ok.forEach { lutLib.add(it.first) }
        if (errors.isNotEmpty()) toastLong("Не загружено:\n" + errors.joinToString("\n"))
        else if (ok.isNotEmpty()) toast("Добавлено LUT: ${ok.size}")
        val first = ok.firstOrNull()
        val lut = first?.second
        if (first != null && lut != null && (single || lutLib.activeUri == null)) {
            cacheLut(first.first.uri, lut)
            applyLut(first.first, lut, true)
        } else {
            refreshAll()
        }
    }

    private fun cacheLut(uri: String, lut: CubeLut) {
        lutCache[uri] = lut
        while (lutCache.size > 2) lutCache.remove(lutCache.keys.first())
    }

    /** Выбрать LUT из списка (null = без LUT). */
    private fun selectLut(e: LutEntry?, fromUser: Boolean = true, silent: Boolean = false) {
        val routeChange = engine.cfg.lutMode == 2 && ((lutLib.activeUri == null) != (e == null))
        if (recording && routeChange) { toast("Сначала остановите запись"); return }
        if (e == null) {
            pendingLut = null
            lutLib.setActive(null)
            engine.setLut(null)
            engine.lutConfigChanged()
            refreshAll()
            return
        }
        val cached = lutCache[e.uri]
        if (cached != null) { applyLut(e, cached, fromUser); return }
        pendingLut = e.uri
        if (!silent) toast("Загрузка LUT «${e.name}»…")
        Thread({
            var lut: CubeLut? = null
            var err: String? = null
            try {
                lut = parseLut(Uri.parse(e.uri))
            } catch (x: OutOfMemoryError) {
                err = "недостаточно памяти"
            } catch (x: Exception) {
                err = x.message ?: "неверный .cube"
            }
            val result = lut
            val message = err
            runOnUiThread {
                if (isDestroyed || pendingLut != e.uri) return@runOnUiThread   // пользователь уже выбрал другой
                pendingLut = null
                if (result != null) {
                    cacheLut(e.uri, result)
                    applyLut(e, result, fromUser)
                } else {
                    if (lutLib.activeUri == e.uri) lutLib.setActive(null)
                    toastLong("LUT «${e.name}» недоступен: ${message ?: "ошибка"}. Его можно убрать из списка (✕).")
                    refreshAll()
                }
            }
        }, "lut-load").start()
    }

    private fun applyLut(e: LutEntry, lut: CubeLut, fromUser: Boolean) {
        if (e.size == 0) lutLib.add(e.copy(size = lut.size))
        lutLib.setActive(e.uri)
        if (fromUser && engine.cfg.lutMode == 0) { engine.cfg.lutMode = 1; saveLutPrefs() }
        engine.setLut(lut)
        engine.lutConfigChanged()
        refreshAll()
    }

    private fun deleteLut(e: LutEntry) = idle {
        lutCache.remove(e.uri)
        try { contentResolver.releasePersistableUriPermission(Uri.parse(e.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (x: Exception) { }
        val wasActive = lutLib.activeUri == e.uri
        lutLib.remove(e.uri)
        if (wasActive) { engine.setLut(null); engine.lutConfigChanged() }
        refreshAll()
    }

    private fun saveLutPrefs() {
        prefs.edit().putInt("lut_mode", engine.cfg.lutMode).putBoolean("lut_in_log", engine.cfg.lutInLog).apply()
    }

    private fun setGrid(i: Int) {
        gridIdx = i.coerceIn(0, Grid.values().size - 1)
        gridView.grid = Grid.values()[gridIdx]
        prefs.edit().putInt("grid", gridIdx).apply()
    }

    // ------------------------------------------------------------ жизненный цикл

    /** Повороты экрана landscape <-> reverse landscape: превью и тап-фокус должны следовать сразу. */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { if (ready) engine.setRotation(rotationDeg()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildBase()
        setGrid(prefs.getInt("grid", 1))
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) initEngine()
        else requestPermissions(need, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!ready) initEngine()
        } else {
            Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::menu.isInitialized && menuVisible()) closeMenu() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
        if (ready && surface.holder.surface.isValid) startEngine()
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        if (ready) engine.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (ready) engine.release()
    }

    // ------------------------------------------------------------ поверхность

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { if (ready) startEngine() }
    override fun surfaceDestroyed(holder: SurfaceHolder) { if (ready) engine.stop() }

    @Suppress("DEPRECATION")
    private fun rotationDeg(): Int {
        return when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    }

    private fun startEngine() { engine.start(surface.holder.surface, rotationDeg()) }

    // ------------------------------------------------------------ UI: каркас

    private fun tv(size: Float, gravity: Int, l: Int, t: Int, r: Int, b: Int): TextView {
        val v = TextView(this)
        v.setTextColor(Color.WHITE)
        v.textSize = size
        v.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        host.addView(v, FrameLayout.LayoutParams(WRAP, WRAP, gravity).apply { setMargins(l, t, r, b) })
        return v
    }

    private fun buildBase() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        host = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.setFixedSize(1280, 720)
        surface.holder.addCallback(this)
        host.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH))

        gridView = GridView(this)
        host.addView(gridView, FrameLayout.LayoutParams(MATCH, MATCH))

        hist = HistogramView(this)
        host.addView(hist, FrameLayout.LayoutParams(dp(150), dp(52), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(8), 0) })
        hud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(6), 0, 0)
        recHud = tv(14f, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, dp(6), 0, 0)
        expHud = tv(12f, Gravity.BOTTOM or Gravity.END, 0, 0, dp(8), dp(6))

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(0xAA000000.toInt())
        panel.setPadding(dp(8), dp(6), dp(8), dp(6))
        panel.visibility = View.GONE
        host.addView(panel, FrameLayout.LayoutParams(dp(250), WRAP, Gravity.START or Gravity.BOTTOM).apply { setMargins(dp(6), 0, 0, dp(26)) })

        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.TOP or Gravity.START))

        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER
        root.addView(side, FrameLayout.LayoutParams(dp(sideW), MATCH, Gravity.END))

        strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        val sc = HorizontalScrollView(this)
        sc.setBackgroundColor(0xFF101010.toInt())
        sc.isHorizontalScrollBarEnabled = false
        sc.addView(strip)
        root.addView(sc, FrameLayout.LayoutParams(MATCH, dp(stripH), Gravity.BOTTOM or Gravity.START))

        buildMenuShell()

        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fit(r - l, b - t) }
        setContentView(root)
    }

    private fun fit(w: Int, h: Int) {
        val aw = w - dp(sideW)
        val ah = h - dp(stripH)
        if (aw <= 0 || ah <= 0) return
        var pw = aw
        var ph = pw * 9 / 16
        if (ph > ah) { ph = ah; pw = ph * 16 / 9 }
        val lp = host.layoutParams as FrameLayout.LayoutParams
        if (lp.width != pw || lp.height != ph) {
            lp.width = pw
            lp.height = ph
            host.layoutParams = lp
        }
    }

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoom(engine.cfg.zoom * d.scaleFactor); return true }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                engine.tapFocus(e.x / host.width, e.y / host.height)
                return true
            }
            override fun onLongPress(e: MotionEvent) { engine.clearFocus() }
        })
        host.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) gd.onTouchEvent(ev)
            true
        }
    }

    // ------------------------------------------------------------ UI: быстрые кнопки

    private fun refreshChips() {
        refreshers.toList().forEach { it() }
        menuRefreshers.toList().forEach { it() }
    }

    /** Перерисовать состояние; если открыт список LUT — пересобрать его. */
    private fun refreshAll() {
        if (::menu.isInitialized && menuVisible() && menuTab == tabLut) showTab(tabLut, true) else refreshChips()
    }

    private fun styled(b: Button, activeFn: () -> Boolean, textFn: () -> String) {
        b.setAllCaps(false)
        b.textSize = 11f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(10), dp(4), dp(10), dp(4))
        b.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xE61B2025.toInt()); setStroke(dp(1), 0xFF3C454D.toInt()) }
        refreshers.add {
            b.text = textFn()
            b.setTextColor(if (activeFn()) amber else 0xFFEEEEEE.toInt())
        }
    }

    private fun chip(text: () -> String, active: () -> Boolean = { false }, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, active, text)
        b.setOnClickListener { onClick(); refreshChips() }
        if (onLong != null) b.setOnLongClickListener { onLong(); refreshChips(); true }
        strip.addView(b, LinearLayout.LayoutParams(WRAP, dp(36)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
    }

    private fun sideBtn(text: () -> String, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, { false }, text)
        b.setOnClickListener { onClick(); refreshChips() }
        side.addView(b, LinearLayout.LayoutParams(dp(76), dp(38)).apply { setMargins(0, dp(4), 0, dp(4)) })
    }

    private fun zebraIdx(): Int {
        val c = engine.cfg
        return if (!c.zebra) 0 else if (c.zebraLevel < 0.93f) 1 else if (c.zebraLevel < 0.97f) 2 else 3
    }

    private fun setZebra(i: Int) {
        val c = engine.cfg
        c.zebra = i != 0
        if (i == 1) c.zebraLevel = 0.90f else if (i == 2) c.zebraLevel = 0.95f else if (i == 3) c.zebraLevel = 1.0f
        engine.update()
    }

    /** Нижняя полоса — только то, что нужно во время съёмки. Всё остальное — в меню с описаниями. */
    private fun buildStrip() {
        val cfg = engine.cfg
        // LUT: тап — следующий LUT по кругу (в т.ч. «нет»), долгое нажатие — открыть список.
        chip({ "LUT: " + activeLutName().take(14) }, { lutLib.activeUri != null && cfg.lutMode != 0 }, { openMenu(tabLut) }) {
            if (lutLib.items.isEmpty()) openMenu(tabLut) else selectLut(lutLib.next())
        }
        chip({ "LUT→видео: " + if (cfg.lutMode == 2) "вкл" else "выкл" }, { cfg.lutMode == 2 }) {
            if (lutLib.activeUri == null) toast("Сначала выберите LUT") else setLutBake(cfg.lutMode != 2)
        }
        chip({ "СЕТКА: " + Grid.values()[gridIdx].label }, { gridIdx != 0 }) { setGrid((gridIdx + 1) % Grid.values().size) }
        chip({ if (cfg.zebra) "ZEBRA ${(cfg.zebraLevel * 100).roundToInt()}" else "ZEBRA" }, { cfg.zebra }) { setZebra((zebraIdx() + 1) % 4) }
        chip({ "PEAK" }, { cfg.peaking }) { cfg.peaking = !cfg.peaking; engine.update() }
        chip({ "FALSE" }, { cfg.falseColor }) { cfg.falseColor = !cfg.falseColor; engine.update() }
        chip({ "HIST" }, { cfg.hist }) { cfg.hist = !cfg.hist; engine.update() }
        chip({ if (cfg.viewLog) "VIEW: LOG" else "VIEW: 709" }, { cfg.viewLog }) { cfg.viewLog = !cfg.viewLog; engine.update() }
        refreshers.add { hist.visibility = if (cfg.hist) View.VISIBLE else View.GONE }
    }

    private fun buildSide() {
        val cfg = engine.cfg
        sideBtn({ lenses.firstOrNull { it.id == cfg.cameraId }?.label ?: "cam" }) {
            idle {
                if (lenses.size > 1) {
                    val i = lenses.indexOfFirst { it.id == cfg.cameraId }
                    cfg.cameraId = lenses[(i + 1) % lenses.size].id
                    cfg.zoom = 1f
                    engine.restart()
                }
            }
        }
        sideBtn({ "%.1fx".format(cfg.zoom) }) { cycleZoom() }

        recBtn = Button(this)
        recBtn.text = "●"
        recBtn.textSize = 24f
        recBtn.setTextColor(Color.WHITE)
        recBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE53935.toInt()) }
        recBtn.setOnClickListener { engine.toggleRecord() }
        side.addView(recBtn, LinearLayout.LayoutParams(dp(64), dp(64)).apply { setMargins(0, dp(6), 0, dp(6)) })

        sideBtn({ "РУЧН." }) { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        sideBtn({ "МЕНЮ" }) { openMenu(menuTab) }
    }

    // ------------------------------------------------------------ UI: меню с описаниями

    private fun menuVisible() = menu.visibility == View.VISIBLE

    private fun openMenu(tab: Int) {
        if (!ready) return
        menu.visibility = View.VISIBLE
        showTab(tab)
    }

    private fun closeMenu() { menu.visibility = View.GONE }

    private fun segStyle(b: Button, on: Boolean) {
        b.background = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (on) amber else 0xFF222A31.toInt())
            setStroke(dp(1), if (on) amber else 0xFF3C454D.toInt())
        }
        b.setTextColor(if (on) Color.BLACK else 0xFFEEEEEE.toInt())
    }

    private fun flatButton(text: String, size: Float): Button {
        val b = Button(this)
        b.setAllCaps(false)
        b.textSize = size
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.text = text
        return b
    }

    private fun buildMenuShell() {
        menu = FrameLayout(this)
        menu.setBackgroundColor(0xF2101418.toInt())
        menu.visibility = View.GONE
        menu.isClickable = true      // перехватывает касания, чтобы не попадали на превью

        val tabsScroll = ScrollView(this)
        menuTabsBox = LinearLayout(this)
        menuTabsBox.orientation = LinearLayout.VERTICAL
        menuTabsBox.setPadding(dp(8), dp(12), dp(4), dp(8))
        tabsScroll.addView(menuTabsBox)
        menu.addView(tabsScroll, FrameLayout.LayoutParams(dp(128), MATCH, Gravity.START))
        for (i in tabNames.indices) {
            val b = flatButton(tabNames[i], 13f)
            b.setOnClickListener { showTab(i) }
            tabButtons.add(b)
            menuTabsBox.addView(b, LinearLayout.LayoutParams(MATCH, dp(42)).apply { setMargins(0, dp(3), 0, dp(3)) })
        }

        menuScroll = ScrollView(this)
        menuBody = LinearLayout(this)
        menuBody.orientation = LinearLayout.VERTICAL
        menuBody.setPadding(dp(8), dp(12), dp(8), dp(16))
        menuScroll.addView(menuBody)
        menu.addView(menuScroll, FrameLayout.LayoutParams(MATCH, MATCH).apply { leftMargin = dp(132); rightMargin = dp(60) })

        val close = flatButton("✕", 18f)
        segStyle(close, false)
        close.setOnClickListener { closeMenu() }
        menu.addView(close, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(10), dp(8), 0) })

        root.addView(menu, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun showTab(i: Int, keepScroll: Boolean = false) {
        val y = menuScroll.scrollY
        menuTab = i
        tabButtons.forEachIndexed { k, b -> segStyle(b, k == i) }
        menuBody.removeAllViews()
        menuRefreshers.clear()
        when (i) {
            0 -> buildVideoTab()
            1 -> buildColorTab()
            2 -> buildLutTab()
            3 -> buildMonitorTab()
            else -> buildCameraTab()
        }
        refreshChips()
        menuScroll.post { menuScroll.scrollTo(0, if (keepScroll) y else 0) }
    }

    /** Карточка: заголовок + описание функции. Возвращает контейнер, куда добавляются элементы управления. */
    private fun card(title: String, desc: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(8), dp(12), dp(8))
        c.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFF1A2026.toInt()) }
        val t = TextView(this)
        t.text = title
        t.textSize = 14f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Color.WHITE)
        c.addView(t)
        if (desc.isNotEmpty()) {
            val d = TextView(this)
            d.text = desc
            d.textSize = 11.5f
            d.setTextColor(0xFFA0ABB4.toInt())
            c.addView(d)
        }
        menuBody.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) })
        return c
    }

    /** Строка выбора из нескольких вариантов: все варианты видны сразу, активный подсвечен. */
    private fun seg(
        title: String, desc: String, options: List<String>, selected: () -> Int,
        note: () -> String = { "" }, onPick: (Int) -> Unit
    ) {
        val box = card(title, desc)
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val btns = options.mapIndexed { i, label ->
            val b = flatButton(label, 12f)
            b.setOnClickListener { onPick(i); refreshChips() }
            bar.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(2), dp(6), dp(2), dp(2)) })
            b
        }
        val noteTv = TextView(this)
        noteTv.textSize = 11f
        noteTv.setTextColor(amber)
        box.addView(bar)
        box.addView(noteTv)
        menuRefreshers.add {
            val sel = selected()
            btns.forEachIndexed { i, b -> segStyle(b, i == sel) }
            val n = note()
            noteTv.text = n
            noteTv.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun toggle(title: String, desc: String, get: () -> Boolean, note: () -> String = { "" }, set: (Boolean) -> Unit) =
        seg(title, desc, listOf("Выкл", "Вкл"), { if (get()) 1 else 0 }, note) { set(it == 1) }

    private fun estMbps(): Int {
        val c = engine.cfg
        val s = c.size
        val bpp = doubleArrayOf(0.10, 0.15, 0.22)[c.bppIdx.coerceIn(0, 2)] * (if (c.codec == Codec.AVC) 1.5 else 1.0)
        val br = (s.width.toLong() * s.height * c.fps * bpp).toLong().coerceIn(8_000_000L, Enc.maxBitrate(c.codec.mime).toLong())
        return (br / 1_000_000).toInt()
    }

    private fun buildVideoTab() {
        val cfg = engine.cfg
        val sizes = engine.sizeOptions()
        seg("Разрешение", "Размер кадра записи. 4K даёт максимум детализации и самые большие файлы. В списке только то, что реально отдаёт камера вашего телефона.",
            sizes.map { if (it.width >= 3840) "4K" else "${it.height}p" }, { sizes.indexOf(cfg.size) }) { i ->
            idle { cfg.size = sizes[i]; engine.restart() }
        }
        val fpsList = engine.fpsOptions()
        seg("Частота кадров", "24/25 — «киношный» вид, 30 — универсальный вариант, 50/60 — плавное движение и возможность растянуть в слоумо при монтаже. Значения, которые телефон не тянет, скрыты.",
            fpsList.map { "$it" }, { fpsList.indexOf(cfg.fps) }) { i ->
            idle { cfg.fps = fpsList[i]; engine.restart() }
        }
        seg("Кодек", "HEVC (H.265) — примерно вдвое экономнее H.264 при том же качестве и нужен для 10-bit. H.264 — максимальная совместимость с любыми плеерами и редакторами.",
            listOf("HEVC", "H.264"), { cfg.codec.ordinal }) { i ->
            idle { cfg.codec = Codec.values()[i]; engine.restart() }
        }
        seg("Качество (битрейт)", "Чем выше битрейт, тем чище картинка и больше файл. Для цветокоррекции и LOG берите «Высокое».",
            listOf("Низкое", "Среднее", "Высокое"), { cfg.bppIdx }, { "≈ ${estMbps()} Мбит/с для текущих настроек" }) { i -> cfg.bppIdx = i }
        toggle("Звук", "Запись со встроенного микрофона (AAC 192 кбит/с, стерео — если телефон отдаёт).", { cfg.audio }) { cfg.audio = it }
    }

    private fun buildColorTab() {
        val cfg = engine.cfg
        seg("Режим записи", "SDR — обычная картинка Rec.709, готова к просмотру. LOG — плоская картинка с запасом по теням и светам для цветокоррекции. HLG — HDR-запись (BT.2020 + HLG), выглядит правильно на HDR-экранах.",
            listOf("SDR", "LOG", "HLG"), { cfg.mode.ordinal }) { i ->
            idle { cfg.mode = Mode.values()[i]; engine.restart() }
        }
        seg("LOG-кривая", "Какую логарифмическую кривую писать. Выбирайте ту, под которую сделан ваш LUT: S-Log3, V-Log или LogC. Flat — простая универсальная плоская кривая. Работает в режиме LOG.",
            Curve.values().map { it.label }, { cfg.curve.ordinal }) { i -> cfg.curve = Curve.values()[i]; engine.update() }
        seg("Источник LOG", "Шейдер — кривая считается в приложении, работает на любом телефоне, но новых деталей в светах и тенях не добавляет. Камера — телефон сам применяет tone-кривую: картинка реально плоская и деталей больше, но запись идёт напрямую, поэтому LUT в файл запечь нельзя (только превью).",
            listOf("Шейдер (SW)", "Камера (HW)"), { if (cfg.hwLog && engine.caps?.hwLog == true) 1 else 0 },
            { if (engine.caps?.hwLog == true) "" else "Этот телефон не принимает аппаратную tone-кривую — работает шейдер" }) { i ->
            idle {
                if (i == 1 && engine.caps?.hwLog != true) toast("Аппаратная tone-кривая недоступна")
                else { cfg.hwLog = i == 1; engine.restart() }
            }
        }
        seg("Источник HLG", "Нативный — настоящий 10-bit HLG10 от камеры (Android 13+ и поддержка в телефоне). Эмуляция — HLG считается шейдером из обычной SDR-картинки: файл помечен как HLG, но динамического диапазона больше не становится.",
            listOf("Нативный", "Эмуляция"), { if (cfg.emuHlg || engine.caps?.hlg10Native != true) 1 else 0 },
            { if (engine.caps?.hlg10Native == true) "" else "Нативный HLG10 на этом телефоне недоступен — используется эмуляция" }) { i ->
            idle {
                if (i == 0 && engine.caps?.hlg10Native != true) toast("Нативный HLG10 не поддерживается")
                else { cfg.emuHlg = i == 1; engine.restart() }
            }
        }
        toggle("10-bit для эмуляции", "Экспериментально: запись эмулируемых LOG/HLG в 10-bit (только HEVC). Меньше бандинга в градиентах. Если телефон не примет 10-bit, будет 8-bit.", { cfg.tenBitEmu }) { v ->
            idle { cfg.tenBitEmu = v; engine.restart() }
        }
    }

    private fun lutRow(box: LinearLayout, name: String, sub: String, active: Boolean, e: LutEntry?) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val b = flatButton((if (active) "●  " else "○  ") + name + (if (sub.isNotEmpty()) "     $sub" else ""), 13f)
        b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        b.setPadding(dp(12), 0, dp(12), 0)
        segStyle(b, active)
        b.setOnClickListener { selectLut(e) }
        r.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        if (e != null) {
            val x = flatButton("✕", 14f)
            segStyle(x, false)
            x.setOnClickListener { deleteLut(e) }
            r.addView(x, LinearLayout.LayoutParams(dp(44), dp(40)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        box.addView(r)
    }

    /** Что сейчас произойдёт с LUT при записи — простым языком. */
    private fun lutBakeNote(): String {
        val cfg = engine.cfg
        val lut = lutLib.active()
        val noBake = cfg.mode == Mode.HLG || (cfg.mode == Mode.LOG && cfg.hwLog && engine.caps?.hwLog == true)
        return when {
            lut == null -> "Сначала выберите LUT в списке ниже"
            cfg.lutMode != 2 -> "Сейчас LUT «${lut.name}» НЕ записывается в видео"
            noBake -> "В режимах HLG и «LOG: камера (HW)» запечь LUT нельзя — он будет только на экране"
            else -> "Включено: видео запишется сразу с LUT «${lut.name}»"
        }
    }

    /** Применять LUT к видео = режим 2 (запекание); иначе остаётся только показ на экране или ничего. */
    private fun setLutBake(v: Boolean) = idle {
        val cfg = engine.cfg
        cfg.lutMode = if (v) 2 else (if (cfg.lutMode == 0) 0 else 1)
        saveLutPrefs()
        engine.lutConfigChanged()
        if (v && lutLib.activeUri == null) toast("Выберите LUT в списке")
    }

    private fun setLutPreview(v: Boolean) = idle {
        val cfg = engine.cfg
        cfg.lutMode = if (v) (if (cfg.lutMode == 2) 2 else 1) else 0
        saveLutPrefs()
        engine.lutConfigChanged()
    }

    private fun buildLutTab() {
        val cfg = engine.cfg
        toggle("Применять LUT к видео",
            "Вкл — LUT «запекается» в файл: ролик записывается сразу с look-ом LUT, убрать его потом нельзя. " +
                "Выкл — файл пишется без LUT (чистый SDR/LOG), а LUT виден только на экране; наложить его можно при монтаже.",
            { cfg.lutMode == 2 }, { lutBakeNote() }) { setLutBake(it) }

        val box = card("Список LUT",
            "Файлы .cube (3D, размер 2…65). Нажмите на LUT, чтобы выбрать его, ✕ — убрать из списка (сам файл не удаляется). " +
                "Быстро переключать LUT по кругу можно кнопкой «LUT» в нижней полосе.")
        lutRow(box, "Без LUT", "", lutLib.activeUri == null, null)
        for (e in lutLib.items) lutRow(box, e.name, if (e.size > 0) "${e.size}³" else "", e.uri == lutLib.activeUri, e)
        val add = flatButton("+  Добавить файлы .cube", 13f)
        segStyle(add, false)
        add.setOnClickListener { pickLutFiles() }
        box.addView(add, LinearLayout.LayoutParams(MATCH, dp(42)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })

        toggle("Показывать LUT на экране",
            "Включает LUT в превью, чтобы видеть итоговую картинку. На записанный файл это не влияет — за файл отвечает переключатель «Применять LUT к видео».",
            { cfg.lutMode != 0 }, { if (lutLib.activeUri != null && cfg.lutMode == 0) "LUT выбран, но на экране выключен" else "" }) { setLutPreview(it) }
        seg("Вход LUT", "LOG — LUT получает сигнал в выбранной LOG-кривой (для технических LUT вроде «S-Log3 → Rec.709»). Rec.709 — для обычных творческих LUT, рассчитанных на Rec.709.",
            listOf("LOG", "Rec.709"), { if (cfg.lutInLog) 0 else 1 }) { i ->
            idle {
                cfg.lutInLog = i == 0
                saveLutPrefs()
                engine.lutConfigChanged()
            }
        }
    }

    private fun buildMonitorTab() {
        val cfg = engine.cfg
        seg("Сетка", "Направляющие поверх превью (в видео не попадают). Помогают с композицией и ровным горизонтом.",
            Grid.values().map { it.label }, { gridIdx }, { Grid.values()[gridIdx].desc }) { i -> setGrid(i) }
        seg("Зебра", "Штрихует кадр там, где яркость выше порога. Нужна, чтобы не «сжечь» света: 95–100% — уже почти пересвет.",
            listOf("Выкл", "90%", "95%", "100%"), { zebraIdx() }) { i -> setZebra(i) }
        toggle("Focus peaking", "Красным подсвечивает резкие края — помогает точно навести ручной фокус.", { cfg.peaking }) { cfg.peaking = it; engine.update() }
        toggle("False color", "Раскрашивает кадр по яркости: синий и фиолетовый — тёмные тени, зелёный — средние тона (кожа), жёлтый и красный — света и пересвет.", { cfg.falseColor }) { cfg.falseColor = it; engine.update() }
        toggle("Гистограмма", "Распределение яркости в кадре: пик у правого края — пересвет, у левого — провалы в тенях.", { cfg.hist }) { cfg.hist = it; engine.update() }
        seg("Просмотр", "709 — картинка, как она будет выглядеть после коррекции или LUT. LOG — плоская картинка, как она записывается в файл (удобно оценивать экспозицию).",
            listOf("709", "LOG"), { if (cfg.viewLog) 1 else 0 }) { i -> cfg.viewLog = i == 1; engine.update() }
    }

    private fun buildCameraTab() {
        val cfg = engine.cfg
        toggle("Стабилизация", "Электронная и оптическая стабилизация (если есть у выбранного объектива). Со штатива лучше выключить — иначе кадр может «плавать».", { cfg.stab }) { cfg.stab = it; engine.update() }
        toggle("Фонарик", "Постоянный свет вспышки — для тёмных помещений и заброшек.", { cfg.torch }) { cfg.torch = it; engine.update() }
        val manual = card("Ручные настройки", "ISO, выдержка, экспозиция (EV), ручной фокус и баланс белого. Любой ползунок сам переключает параметр в ручной режим.")
        val open = flatButton("Открыть панель", 13f)
        segStyle(open, false)
        open.setOnClickListener { closeMenu(); panel.visibility = View.VISIBLE }
        manual.addView(open, LinearLayout.LayoutParams(MATCH, dp(40)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
        card("Жесты и кнопки справа",
            "Тап по превью — фокус и экспозиция по точке, долгое нажатие — сброс. Щипок — зум. Кнопка с размером в мм переключает объектив, «1.0x» — быстрые значения зума. " +
                "Строка в левом верхнем углу показывает, как именно сейчас идёт запись (нативно или через GL-эмуляцию).")
    }

    // ------------------------------------------------------------ UI: ручная панель

    private fun addSeek(title: String, onChange: (Int) -> String): SeekBar {
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.text = title
        val sb = SeekBar(this)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) t.text = "$title  ${onChange(p)}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        panel.addView(t)
        panel.addView(sb)
        return sb
    }

    private fun panelButton(text: () -> String, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, { false }, text)
        b.setOnClickListener { onClick(); refreshChips() }
        panel.addView(b, LinearLayout.LayoutParams(MATCH, dp(34)).apply { setMargins(0, dp(2), 0, dp(2)) })
    }

    private fun buildPanel() {
        val cfg = engine.cfg
        val hint = TextView(this)
        hint.text = "Ручные настройки. Ползунок включает ручной режим; кнопки ниже возвращают авто."
        hint.textSize = 10.5f
        hint.setTextColor(0xFFA0ABB4.toInt())
        panel.addView(hint)
        panelButton({ "EXPOSURE: " + if (cfg.aeManual) "MANUAL" else "AUTO" }) { cfg.aeManual = !cfg.aeManual; engine.update() }
        isoBar = addSeek("ISO") { p ->
            val r = engine.caps?.isoRange
            if (r == null) "—" else {
                val iso = (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
                cfg.iso = iso; cfg.aeManual = true; engine.update(); refreshChips(); "$iso"
            }
        }
        shutBar = addSeek("SHUTTER") { p ->
            val d = shutters.getOrNull(p)
            if (d == null) "—" else {
                cfg.expNs = 1_000_000_000L / d; cfg.aeManual = true; engine.update(); refreshChips(); "1/$d"
            }
        }
        evBar = addSeek("EV") { p ->
            val c = engine.caps
            val r = c?.aeRange
            if (c == null || r == null) "—" else {
                cfg.ev = r.lower + p; engine.update(); "%+.1f".format(cfg.ev * c.aeStep)
            }
        }
        panelButton({ "FOCUS: " + if (cfg.afManual) "MF" else "AF" }) { cfg.afManual = !cfg.afManual; engine.update() }
        focusBar = addSeek("FOCUS") { p ->
            val c = engine.caps
            if (c == null || c.minFocus <= 0f) "—" else {
                cfg.focus = c.minFocus * p / 100f; cfg.afManual = true; engine.update(); refreshChips()
                if (cfg.focus < 0.05f) "∞" else "%.0f см".format(100f / cfg.focus)
            }
        }
        panelButton({ "WB: " + AWB_PRESETS[cfg.awbIdx].first }) { cfg.awbIdx = (cfg.awbIdx + 1) % AWB_PRESETS.size; engine.update() }
    }

    /** Подгоняет слайдеры под возможности текущей камеры. */
    private fun refreshControls() {
        val c = engine.caps ?: return
        val cfg = engine.cfg
        val manual = c.manualSensor && c.isoRange != null && c.expRange != null
        isoBar.isEnabled = manual
        shutBar.isEnabled = manual
        c.isoRange?.let { r ->
            isoBar.max = 100
            val x = cfg.iso.toDouble().coerceIn(r.lower.toDouble(), r.upper.toDouble())
            isoBar.progress = (ln(x / r.lower) / ln(r.upper.toDouble() / r.lower) * 100).roundToInt().coerceIn(0, 100)
        }
        shutters = listOf(24, 25, 30, 48, 50, 60, 96, 100, 120, 125, 240, 250, 500, 1000, 2000, 4000, 8000).filter { d ->
            d >= cfg.fps && (c.expRange?.let { 1_000_000_000L / d in it.lower..it.upper } == true)
        }
        shutBar.max = (shutters.size - 1).coerceAtLeast(0)
        val cur = (1e9 / cfg.expNs).roundToInt()
        shutBar.progress = shutters.indices.minByOrNull { abs(shutters[it] - cur) } ?: 0
        val r = c.aeRange
        evBar.isEnabled = r != null && c.aeStep > 0f
        if (r != null) { evBar.max = r.upper - r.lower; evBar.progress = cfg.ev - r.lower }
        focusBar.isEnabled = c.minFocus > 0f
        focusBar.max = 100
        if (c.minFocus > 0f) focusBar.progress = (cfg.focus / c.minFocus * 100).roundToInt().coerceIn(0, 100)
        refreshChips()
    }

    private fun setZoom(z: Float) {
        val c = engine.caps ?: return
        engine.cfg.zoom = z.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
        engine.update()
        refreshChips()
    }

    private fun cycleZoom() {
        val c = engine.caps ?: return
        val p = listOf(0.5f, 1f, 2f, 3f, 5f, 10f).filter { it >= c.zoomRange.lower - 0.01f && it <= c.zoomRange.upper + 0.01f }
        if (p.isEmpty()) return
        val cur = engine.cfg.zoom
        setZoom(p.firstOrNull { it > cur + 0.05f } ?: p.first())
    }

    private fun initEngine() {
        engine = CameraEngine(this, this)
        lenses = try { engine.lenses() } catch (e: Exception) { emptyList() }
        engine.cfg.cameraId = (lenses.firstOrNull { it.id == "0" } ?: lenses.firstOrNull())?.id ?: ""
        engine.cfg.lutMode = prefs.getInt("lut_mode", 1).coerceIn(0, 2)
        engine.cfg.lutInLog = prefs.getBoolean("lut_in_log", true)
        buildStrip()
        buildSide()
        buildPanel()
        setupTouch()
        refreshChips()
        ready = true
        if (surface.holder.surface.isValid) startEngine()
        // Выбранный LUT сохраняется между запусками — его нужно разобрать заново.
        lutLib.active()?.let { selectLut(it, fromUser = false, silent = true) }
    }

    // ------------------------------------------------------------ CameraEngine.Listener

    override fun onInfo(text: String) { hud.text = text }
    override fun onExposure(text: String) { expHud.text = text }
    override fun onHist(bins: IntArray) { hist.set(bins) }
    override fun onError(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    override fun onSaved(path: String) { Toast.makeText(this, "Сохранено: $path", Toast.LENGTH_LONG).show() }

    override fun onReady() {
        refreshControls()
        // Список разрешений/fps мог измениться (смена объектива и т.п.) — обновить открытую вкладку.
        if (menuVisible()) showTab(menuTab, true)
    }

    override fun onRecording(on: Boolean) {
        recording = on
        recBtn.text = if (on) "■" else "●"
        if (on) {
            recStart = SystemClock.elapsedRealtime()
            tick()
        } else {
            recHud.text = ""
        }
    }

    private fun tick() {
        main.postDelayed({
            if (recording) {
                val s = (SystemClock.elapsedRealtime() - recStart) / 1000
                recHud.text = "● %02d:%02d".format(s / 60, s % 60)
                tick()
            }
        }, 500)
    }
}
