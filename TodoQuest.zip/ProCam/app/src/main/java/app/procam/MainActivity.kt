package app.procam

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.Uri
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Простая гистограмма яркости (64 столбца, корневая шкала). */
class HistogramView(c: Context) : View(c) {
    private var bins = IntArray(64)
    private val p = Paint().apply { color = 0xCCFFFFFF.toInt() }
    private val bg = Paint().apply { color = 0x66000000 }

    fun set(b: IntArray) { bins = b; invalidate() }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val mx = (bins.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val bw = width / 64f
        for (i in 0 until 64) {
            val h = sqrt(bins[i] / mx) * height
            cv.drawRect(i * bw, height - h, (i + 1) * bw, height.toFloat(), p)
        }
    }
}

class MainActivity : Activity(), SurfaceHolder.Callback, CameraEngine.Listener {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var engine: CameraEngine
    private lateinit var root: FrameLayout
    private lateinit var host: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var hud: TextView
    private lateinit var expHud: TextView
    private lateinit var recHud: TextView
    private lateinit var hist: HistogramView
    private lateinit var panel: LinearLayout
    private lateinit var strip: LinearLayout
    private lateinit var side: LinearLayout
    private lateinit var recBtn: Button
    private lateinit var isoBar: SeekBar
    private lateinit var shutBar: SeekBar
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar

    private val main = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()
    private var lenses: List<Lens> = emptyList()
    private var shutters: List<Int> = emptyList()
    private var ready = false
    private var recording = false
    private var recStart = 0L
    private var loadedLutLabel = "нет"
    private val lutPicker = 44
    private val maxLutBytes = 40L * 1024 * 1024
    private val prefs by lazy { getSharedPreferences("procam", MODE_PRIVATE) }

    /** Во время записи любые смены маршрута/LUT запрещены: restart() остановил бы запись. */
    private fun idle(block: () -> Unit) {
        if (recording) toast("Сначала остановите запись") else block()
    }

    private fun chooseLut() = idle {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, lutPicker)
    }

    @Deprecated("Legacy SAF result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != lutPicker || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        // Без постоянного доступа сохранённый URI после перезапуска приложения уже не откроется.
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        loadLut(uri, true)
    }

    /** Разбор .cube в фоне (LUT 65³ — сотни мс и десятки МБ), результат — в UI-поток. */
    private fun loadLut(uri: Uri, fromUser: Boolean) {
        Thread({
            var lut: CubeLut? = null
            var err: String? = null
            try {
                val len = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                if (len > maxLutBytes) error("файл слишком большой для .cube (${len / 1_000_000} МБ)")
                lut = contentResolver.openInputStream(uri)?.use { input ->
                    CubeLutReader.read(BufferedReader(InputStreamReader(input, Charsets.UTF_8)))
                } ?: error("не удалось открыть файл")
            } catch (e: OutOfMemoryError) {
                err = "недостаточно памяти"
            } catch (e: Exception) {
                err = e.message ?: "неверный .cube"
            }
            runOnUiThread { if (!isDestroyed) onLutLoaded(uri, lut, err, fromUser) }
        }, "lut-load").start()
    }

    private fun onLutLoaded(uri: Uri, lut: CubeLut?, err: String?, fromUser: Boolean) {
        if (lut == null) {
            if (fromUser) {
                toast("Ошибка LUT: ${err ?: "неверный .cube"}")
            } else {
                // Сохранённый файл пропал или доступ отозван — не показываем «загруженный» LUT, которого нет.
                loadedLutLabel = "нет"
                prefs.edit().remove("lut_uri").remove("lut_label").apply()
                refreshChips()
                toast("Сохранённый LUT недоступен: ${err ?: "ошибка"}")
            }
            return
        }
        loadedLutLabel = "${lut.title} · ${lut.size}³"
        prefs.edit().putString("lut_uri", uri.toString()).putString("lut_label", loadedLutLabel).apply()
        if (fromUser && engine.cfg.lutMode == 0) engine.cfg.lutMode = 1
        saveLutPrefs()
        engine.setLut(lut)
        engine.lutConfigChanged()
        if (fromUser) toast("LUT загружен: $loadedLutLabel")
        refreshChips()
    }

    private fun clearLut() = idle {
        loadedLutLabel = "нет"
        prefs.edit().remove("lut_uri").remove("lut_label").apply()
        engine.setLut(null)
        toast("LUT убран")
        refreshChips()
    }

    private fun saveLutPrefs() {
        prefs.edit().putInt("lut_mode", engine.cfg.lutMode).putBoolean("lut_in_log", engine.cfg.lutInLog).apply()
    }

    /** Повороты экрана landscape <-> reverse landscape: превью и тап-фокус должны следовать сразу. */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { if (ready) engine.setRotation(rotationDeg()) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------ жизненный цикл

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        loadedLutLabel = prefs.getString("lut_label", "нет") ?: "нет"
        buildBase()
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) initEngine()
        else requestPermissions(need, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!ready) initEngine()
        } else {
            Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    override fun onResume() {
        super.onResume()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
        if (ready && surface.holder.surface.isValid) startEngine()
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        if (ready) engine.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (ready) engine.release()
    }

    // ------------------------------------------------------------ поверхность

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { if (ready) startEngine() }
    override fun surfaceDestroyed(holder: SurfaceHolder) { if (ready) engine.stop() }

    @Suppress("DEPRECATION")
    private fun rotationDeg(): Int {
        return when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    }

    private fun startEngine() { engine.start(surface.holder.surface, rotationDeg()) }

    // ------------------------------------------------------------ UI: каркас

    private fun tv(size: Float, gravity: Int, l: Int, t: Int, r: Int, b: Int): TextView {
        val v = TextView(this)
        v.setTextColor(Color.WHITE)
        v.textSize = size
        v.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        host.addView(v, FrameLayout.LayoutParams(WRAP, WRAP, gravity).apply { setMargins(l, t, r, b) })
        return v
    }

    private fun buildBase() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        host = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.setFixedSize(1280, 720)
        surface.holder.addCallback(this)
        host.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH))

        hist = HistogramView(this)
        host.addView(hist, FrameLayout.LayoutParams(dp(150), dp(52), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(8), 0) })
        hud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(6), 0, 0)
        recHud = tv(14f, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, dp(6), 0, 0)
        expHud = tv(12f, Gravity.BOTTOM or Gravity.END, 0, 0, dp(8), dp(6))

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(0xAA000000.toInt())
        panel.setPadding(dp(8), dp(6), dp(8), dp(6))
        panel.visibility = View.GONE
        host.addView(panel, FrameLayout.LayoutParams(dp(250), WRAP, Gravity.START or Gravity.BOTTOM).apply { setMargins(dp(6), 0, 0, dp(26)) })

        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.TOP or Gravity.START))

        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER
        root.addView(side, FrameLayout.LayoutParams(dp(92), MATCH, Gravity.END))

        strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        val sc = HorizontalScrollView(this)
        sc.setBackgroundColor(0xFF101010.toInt())
        sc.isHorizontalScrollBarEnabled = false
        sc.addView(strip)
        root.addView(sc, FrameLayout.LayoutParams(MATCH, dp(52), Gravity.BOTTOM or Gravity.START))

        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fit(r - l, b - t) }
        setContentView(root)
    }

    private fun fit(w: Int, h: Int) {
        val aw = w - dp(92)
        val ah = h - dp(44)
        if (aw <= 0 || ah <= 0) return
        var pw = aw
        var ph = pw * 9 / 16
        if (ph > ah) { ph = ah; pw = ph * 16 / 9 }
        val lp = host.layoutParams as FrameLayout.LayoutParams
        if (lp.width != pw || lp.height != ph) {
            lp.width = pw
            lp.height = ph
            host.layoutParams = lp
        }
    }

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoom(engine.cfg.zoom * d.scaleFactor); return true }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                engine.tapFocus(e.x / host.width, e.y / host.height)
                return true
            }
            override fun onLongPress(e: MotionEvent) { engine.clearFocus() }
        })
        host.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) gd.onTouchEvent(ev)
            true
        }
    }

    // ------------------------------------------------------------ UI: кнопки

    private fun refreshChips() { refreshers.forEach { it() } }

    private fun styled(b: Button, activeFn: () -> Boolean, textFn: () -> String) {
        b.setAllCaps(false)
        b.textSize = 11f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(10), dp(4), dp(10), dp(4))
        b.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xE61B2025.toInt()); setStroke(dp(1), 0xFF3C454D.toInt()) }
        refreshers.add {
            b.text = textFn()
            b.setTextColor(if (activeFn()) 0xFFFFB300.toInt() else 0xFFEEEEEE.toInt())
        }
    }

    private fun chip(text: () -> String, active: () -> Boolean = { false }, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, active, text)
        b.setOnClickListener { onClick(); refreshChips() }
        if (onLong != null) b.setOnLongClickListener { onLong(); refreshChips(); true }
        strip.addView(b, LinearLayout.LayoutParams(WRAP, dp(36)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
    }

    private fun sideBtn(text: () -> String, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, { false }, text)
        b.setOnClickListener { onClick(); refreshChips() }
        side.addView(b, LinearLayout.LayoutParams(dp(76), dp(38)).apply { setMargins(0, dp(6), 0, dp(6)) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun buildStrip() {
        val cfg = engine.cfg
        chip({ val s = cfg.size; if (s.width >= 3840) "4K" else "${s.height}p" }) {
            idle {
                val l = engine.sizeOptions()
                if (l.isNotEmpty()) { cfg.size = l[(l.indexOf(cfg.size) + 1) % l.size]; engine.restart() }
            }
        }
        chip({ "${cfg.fps} fps" }) {
            idle {
                val l = engine.fpsOptions()
                cfg.fps = l[(l.indexOf(cfg.fps) + 1) % l.size]
                engine.restart()
            }
        }
        chip({ cfg.codec.label }) {
            idle {
                cfg.codec = if (cfg.codec == Codec.HEVC) Codec.AVC else Codec.HEVC
                engine.restart()
            }
        }
        chip({ "MODE: " + cfg.mode.name }, { cfg.mode != Mode.SDR }) {
            idle {
                cfg.mode = Mode.values()[(cfg.mode.ordinal + 1) % Mode.values().size]
                engine.restart()
            }
        }
        // LUT: тап — выбрать файл .cube, долгое нажатие — убрать.
        chip({ "LUT: " + if (loadedLutLabel == "нет") "импорт" else loadedLutLabel.take(14) },
            { loadedLutLabel != "нет" && cfg.lutMode != 0 }, { clearLut() }) { chooseLut() }
        chip({ "LUT: " + listOf("OFF", "VIEW", "VIEW+REC")[cfg.lutMode] }, { loadedLutLabel != "нет" && cfg.lutMode != 0 }) {
            idle {
                if (loadedLutLabel == "нет") {
                    toast("Сначала импортируйте .cube (кнопка LUT)")
                } else {
                    cfg.lutMode = (cfg.lutMode + 1) % 3
                    saveLutPrefs()
                    engine.lutConfigChanged()
                    val noBake = cfg.mode == Mode.HLG || (cfg.mode == Mode.LOG && cfg.hwLog && engine.caps?.hwLog == true)
                    if (cfg.lutMode == 2 && noBake) toast("В режимах HLG и HW LOG LUT применяется только в превью")
                }
            }
        }
        chip({ "LUT IN: " + if (cfg.lutInLog) "LOG" else "709" }) {
            idle {
                cfg.lutInLog = !cfg.lutInLog
                saveLutPrefs()
                engine.lutConfigChanged()
            }
        }
        chip({ "CURVE: " + cfg.curve.label }) {
            cfg.curve = Curve.values()[(cfg.curve.ordinal + 1) % Curve.values().size]
            engine.update()
        }
        chip({ "LOG: " + if (cfg.hwLog && engine.caps?.hwLog == true) "HW" else "SW" }) {
            idle {
                if (engine.caps?.hwLog == true) { cfg.hwLog = !cfg.hwLog; engine.restart() }
                else toast("Аппаратная tone-кривая недоступна — используется GL-эмуляция")
            }
        }
        chip({ "HLG: " + if (cfg.emuHlg || engine.caps?.hlg10Native != true) "эмуляция" else "нативный" }) {
            idle {
                if (engine.caps?.hlg10Native == true) { cfg.emuHlg = !cfg.emuHlg; engine.restart() }
                else toast("Нативный HLG10 не поддерживается — используется эмуляция")
            }
        }
        chip({ "10-bit GL: " + if (cfg.tenBitEmu) "on" else "off" }, { cfg.tenBitEmu }) {
            idle {
                cfg.tenBitEmu = !cfg.tenBitEmu
                engine.restart()
            }
        }
        chip({ "Q: " + listOf("low", "mid", "high")[cfg.bppIdx] }) { cfg.bppIdx = (cfg.bppIdx + 1) % 3 }
        chip({ "MIC " + if (cfg.audio) "on" else "off" }, { cfg.audio }) { cfg.audio = !cfg.audio }
        chip({ if (cfg.zebra) "ZEBRA ${(cfg.zebraLevel * 100).roundToInt()}" else "ZEBRA" }, { cfg.zebra }) {
            if (!cfg.zebra) { cfg.zebra = true; cfg.zebraLevel = 0.90f }
            else if (cfg.zebraLevel < 0.93f) cfg.zebraLevel = 0.95f
            else if (cfg.zebraLevel < 0.97f) cfg.zebraLevel = 1.0f
            else cfg.zebra = false
            engine.update()
        }
        chip({ "PEAK" }, { cfg.peaking }) { cfg.peaking = !cfg.peaking; engine.update() }
        chip({ "FALSE" }, { cfg.falseColor }) { cfg.falseColor = !cfg.falseColor; engine.update() }
        chip({ "HIST" }, { cfg.hist }) { cfg.hist = !cfg.hist; engine.update() }
        chip({ if (cfg.viewLog) "VIEW: LOG" else "VIEW: 709" }, { cfg.viewLog }) { cfg.viewLog = !cfg.viewLog; engine.update() }
        chip({ "STAB" }, { cfg.stab }) { cfg.stab = !cfg.stab; engine.update() }
        chip({ "TORCH" }, { cfg.torch }) { cfg.torch = !cfg.torch; engine.update() }
        refreshers.add { hist.visibility = if (cfg.hist) View.VISIBLE else View.GONE }
    }

    private fun buildSide() {
        val cfg = engine.cfg
        sideBtn({ lenses.firstOrNull { it.id == cfg.cameraId }?.label ?: "cam" }) {
            idle {
                if (lenses.size > 1) {
                    val i = lenses.indexOfFirst { it.id == cfg.cameraId }
                    cfg.cameraId = lenses[(i + 1) % lenses.size].id
                    cfg.zoom = 1f
                    engine.restart()
                }
            }
        }
        sideBtn({ "%.1fx".format(cfg.zoom) }) { cycleZoom() }

        recBtn = Button(this)
        recBtn.text = "●"
        recBtn.textSize = 24f
        recBtn.setTextColor(Color.WHITE)
        recBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE53935.toInt()) }
        recBtn.setOnClickListener { engine.toggleRecord() }
        side.addView(recBtn, LinearLayout.LayoutParams(dp(64), dp(64)).apply { setMargins(0, dp(8), 0, dp(8)) })

        sideBtn({ "PANEL" }) { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    private fun addSeek(title: String, onChange: (Int) -> String): SeekBar {
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.text = title
        val sb = SeekBar(this)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) t.text = "$title  ${onChange(p)}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        panel.addView(t)
        panel.addView(sb)
        return sb
    }

    private fun panelButton(text: () -> String, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, { false }, text)
        b.setOnClickListener { onClick(); refreshChips() }
        panel.addView(b, LinearLayout.LayoutParams(MATCH, dp(34)).apply { setMargins(0, dp(2), 0, dp(2)) })
    }

    private fun buildPanel() {
        val cfg = engine.cfg
        panelButton({ "EXPOSURE: " + if (cfg.aeManual) "MANUAL" else "AUTO" }) { cfg.aeManual = !cfg.aeManual; engine.update() }
        isoBar = addSeek("ISO") { p ->
            val r = engine.caps?.isoRange
            if (r == null) "—" else {
                val iso = (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
                cfg.iso = iso; cfg.aeManual = true; engine.update(); refreshChips(); "$iso"
            }
        }
        shutBar = addSeek("SHUTTER") { p ->
            val d = shutters.getOrNull(p)
            if (d == null) "—" else {
                cfg.expNs = 1_000_000_000L / d; cfg.aeManual = true; engine.update(); refreshChips(); "1/$d"
            }
        }
        evBar = addSeek("EV") { p ->
            val c = engine.caps
            val r = c?.aeRange
            if (c == null || r == null) "—" else {
                cfg.ev = r.lower + p; engine.update(); "%+.1f".format(cfg.ev * c.aeStep)
            }
        }
        panelButton({ "FOCUS: " + if (cfg.afManual) "MF" else "AF" }) { cfg.afManual = !cfg.afManual; engine.update() }
        focusBar = addSeek("FOCUS") { p ->
            val c = engine.caps
            if (c == null || c.minFocus <= 0f) "—" else {
                cfg.focus = c.minFocus * p / 100f; cfg.afManual = true; engine.update(); refreshChips()
                if (cfg.focus < 0.05f) "∞" else "%.0f см".format(100f / cfg.focus)
            }
        }
        panelButton({ "WB: " + AWB_PRESETS[cfg.awbIdx].first }) { cfg.awbIdx = (cfg.awbIdx + 1) % AWB_PRESETS.size; engine.update() }
    }

    /** Подгоняет слайдеры под возможности текущей камеры. */
    private fun refreshControls() {
        val c = engine.caps ?: return
        val cfg = engine.cfg
        val manual = c.manualSensor && c.isoRange != null && c.expRange != null
        isoBar.isEnabled = manual
        shutBar.isEnabled = manual
        c.isoRange?.let { r ->
            isoBar.max = 100
            val x = cfg.iso.toDouble().coerceIn(r.lower.toDouble(), r.upper.toDouble())
            isoBar.progress = (ln(x / r.lower) / ln(r.upper.toDouble() / r.lower) * 100).roundToInt().coerceIn(0, 100)
        }
        shutters = listOf(24, 25, 30, 48, 50, 60, 96, 100, 120, 125, 240, 250, 500, 1000, 2000, 4000, 8000).filter { d ->
            d >= cfg.fps && (c.expRange?.let { 1_000_000_000L / d in it.lower..it.upper } == true)
        }
        shutBar.max = (shutters.size - 1).coerceAtLeast(0)
        val cur = (1e9 / cfg.expNs).roundToInt()
        shutBar.progress = shutters.indices.minByOrNull { abs(shutters[it] - cur) } ?: 0
        val r = c.aeRange
        evBar.isEnabled = r != null && c.aeStep > 0f
        if (r != null) { evBar.max = r.upper - r.lower; evBar.progress = cfg.ev - r.lower }
        focusBar.isEnabled = c.minFocus > 0f
        focusBar.max = 100
        if (c.minFocus > 0f) focusBar.progress = (cfg.focus / c.minFocus * 100).roundToInt().coerceIn(0, 100)
        refreshChips()
    }

    private fun setZoom(z: Float) {
        val c = engine.caps ?: return
        engine.cfg.zoom = z.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
        engine.update()
        refreshChips()
    }

    private fun cycleZoom() {
        val c = engine.caps ?: return
        val p = listOf(0.5f, 1f, 2f, 3f, 5f, 10f).filter { it >= c.zoomRange.lower - 0.01f && it <= c.zoomRange.upper + 0.01f }
        if (p.isEmpty()) return
        val cur = engine.cfg.zoom
        setZoom(p.firstOrNull { it > cur + 0.05f } ?: p.first())
    }

    private fun initEngine() {
        engine = CameraEngine(this, this)
        lenses = try { engine.lenses() } catch (e: Exception) { emptyList() }
        engine.cfg.cameraId = (lenses.firstOrNull { it.id == "0" } ?: lenses.firstOrNull())?.id ?: ""
        engine.cfg.lutMode = prefs.getInt("lut_mode", 1).coerceIn(0, 2)
        engine.cfg.lutInLog = prefs.getBoolean("lut_in_log", true)
        buildStrip()
        buildSide()
        buildPanel()
        setupTouch()
        refreshChips()
        ready = true
        if (surface.holder.surface.isValid) startEngine()
        // Ярлык LUT сохраняется между запусками — значит, и сам LUT надо загрузить заново.
        prefs.getString("lut_uri", null)?.let { loadLut(Uri.parse(it), false) }
    }

    // ------------------------------------------------------------ CameraEngine.Listener

    override fun onInfo(text: String) { hud.text = text }
    override fun onExposure(text: String) { expHud.text = text }
    override fun onHist(bins: IntArray) { hist.set(bins) }
    override fun onError(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    override fun onSaved(path: String) { Toast.makeText(this, "Сохранено: $path", Toast.LENGTH_LONG).show() }
    override fun onReady() { refreshControls() }

    override fun onRecording(on: Boolean) {
        recording = on
        recBtn.text = if (on) "■" else "●"
        if (on) {
            recStart = SystemClock.elapsedRealtime()
            tick()
        } else {
            recHud.text = ""
        }
    }

    private fun tick() {
        main.postDelayed({
            if (recording) {
                val s = (SystemClock.elapsedRealtime() - recStart) / 1000
                recHud.text = "● %02d:%02d".format(s / 60, s % 60)
                tick()
            }
        }, 500)
    }
}
