package app.procam

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Простая гистограмма яркости (64 столбца, корневая шкала). */
class HistogramView(c: Context) : View(c) {
    private var bins = IntArray(64)
    private val p = Paint().apply { color = 0xCCFFFFFF.toInt() }
    private val bg = Paint().apply { color = 0x66000000 }

    fun set(b: IntArray) { bins = b; invalidate() }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val mx = (bins.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val bw = width / 64f
        for (i in 0 until 64) {
            val h = sqrt(bins[i] / mx) * height
            cv.drawRect(i * bw, height - h, (i + 1) * bw, height.toFloat(), p)
        }
    }
}

class MainActivity : Activity(), SurfaceHolder.Callback, CameraEngine.Listener {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var engine: CameraEngine
    private lateinit var root: FrameLayout
    private lateinit var host: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var hud: TextView
    private lateinit var expHud: TextView
    private lateinit var recHud: TextView
    private lateinit var hist: HistogramView
    private lateinit var panel: LinearLayout
    private lateinit var strip: LinearLayout
    private lateinit var side: LinearLayout
    private lateinit var recBtn: Button
    private lateinit var isoBar: SeekBar
    private lateinit var shutBar: SeekBar
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar

    private val main = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()
    private var lenses: List<Lens> = emptyList()
    private var shutters: List<Int> = emptyList()
    private var ready = false
    private var recording = false
    private var recStart = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------ жизненный цикл

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildBase()
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) initEngine()
        else requestPermissions(need, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!ready) initEngine()
        } else {
            Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    override fun onResume() {
        super.onResume()
        if (ready && surface.holder.surface.isValid) startEngine()
    }

    override fun onPause() {
        super.onPause()
        if (ready) engine.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (ready) engine.release()
    }

    // ------------------------------------------------------------ поверхность

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { if (ready) startEngine() }
    override fun surfaceDestroyed(holder: SurfaceHolder) { if (ready) engine.stop() }

    @Suppress("DEPRECATION")
    private fun rotationDeg(): Int {
        return when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    }

    private fun startEngine() { engine.start(surface.holder.surface, rotationDeg()) }

    // ------------------------------------------------------------ UI: каркас

    private fun tv(size: Float, gravity: Int, l: Int, t: Int, r: Int, b: Int): TextView {
        val v = TextView(this)
        v.setTextColor(Color.WHITE)
        v.textSize = size
        v.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        host.addView(v, FrameLayout.LayoutParams(WRAP, WRAP, gravity).apply { setMargins(l, t, r, b) })
        return v
    }

    private fun buildBase() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        host = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.setFixedSize(1280, 720)
        surface.holder.addCallback(this)
        host.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH))

        hist = HistogramView(this)
        host.addView(hist, FrameLayout.LayoutParams(dp(150), dp(52), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(8), 0) })
        hud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(6), 0, 0)
        recHud = tv(14f, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, dp(6), 0, 0)
        expHud = tv(12f, Gravity.BOTTOM or Gravity.END, 0, 0, dp(8), dp(6))

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(0xAA000000.toInt())
        panel.setPadding(dp(8), dp(6), dp(8), dp(6))
        panel.visibility = View.GONE
        host.addView(panel, FrameLayout.LayoutParams(dp(250), WRAP, Gravity.START or Gravity.BOTTOM).apply { setMargins(dp(6), 0, 0, dp(26)) })

        root.addView(host, FrameLayout.LayoutParams(dp(640), dp(360), Gravity.TOP or Gravity.START))

        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER
        root.addView(side, FrameLayout.LayoutParams(dp(92), MATCH, Gravity.END))

        strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        val sc = HorizontalScrollView(this)
        sc.setBackgroundColor(0xFF101010.toInt())
        sc.isHorizontalScrollBarEnabled = false
        sc.addView(strip)
        root.addView(sc, FrameLayout.LayoutParams(MATCH, dp(44), Gravity.BOTTOM or Gravity.START))

        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fit(r - l, b - t) }
        setContentView(root)
    }

    private fun fit(w: Int, h: Int) {
        val aw = w - dp(92)
        val ah = h - dp(44)
        if (aw <= 0 || ah <= 0) return
        var pw = aw
        var ph = pw * 9 / 16
        if (ph > ah) { ph = ah; pw = ph * 16 / 9 }
        val lp = host.layoutParams as FrameLayout.LayoutParams
        if (lp.width != pw || lp.height != ph) {
            lp.width = pw
            lp.height = ph
            host.layoutParams = lp
        }
    }

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoom(engine.cfg.zoom * d.scaleFactor); return true }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                engine.tapFocus(e.x / host.width, e.y / host.height)
                return true
            }
            override fun onLongPress(e: MotionEvent) { engine.clearFocus() }
        })
        host.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) gd.onTouchEvent(ev)
            true
        }
    }

    // ------------------------------------------------------------ UI: кнопки

    private fun refreshChips() { refreshers.forEach { it() } }

    private fun styled(b: Button, activeFn: () -> Boolean, textFn: () -> String) {
        b.setAllCaps(false)
        b.textSize = 11f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(10), dp(4), dp(10), dp(4))
        b.setBackgroundColor(0xCC202020.toInt())
        refreshers.add {
            b.text = textFn()
            b.setTextColor(if (activeFn()) 0xFFFFB300.toInt() else 0xFFEEEEEE.toInt())
        }
    }

    private fun chip(text: () -> String, active: () -> Boolean = { false }, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, active, text)
        b.setOnClickListener { onClick(); refreshChips() }
        strip.addView(b, LinearLayout.LayoutParams(WRAP, dp(36)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
    }

    private fun sideBtn(text: () -> String, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, { false }, text)
        b.setOnClickListener { onClick(); refreshChips() }
        side.addView(b, LinearLayout.LayoutParams(dp(76), dp(38)).apply { setMargins(0, dp(6), 0, dp(6)) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun buildStrip() {
        val cfg = engine.cfg
        chip({ val s = cfg.size; if (s.width >= 3840) "4K" else "${s.height}p" }) {
            val l = engine.sizeOptions()
            if (l.isNotEmpty()) { cfg.size = l[(l.indexOf(cfg.size) + 1) % l.size]; engine.restart() }
        }
        chip({ "${cfg.fps} fps" }) {
            val l = engine.fpsOptions()
            cfg.fps = l[(l.indexOf(cfg.fps) + 1) % l.size]
            engine.restart()
        }
        chip({ cfg.codec.label }) {
            cfg.codec = if (cfg.codec == Codec.HEVC) Codec.AVC else Codec.HEVC
            engine.restart()
        }
        chip({ "MODE: " + cfg.mode.name }, { cfg.mode != Mode.SDR }) {
            cfg.mode = Mode.values()[(cfg.mode.ordinal + 1) % Mode.values().size]
            engine.restart()
        }
        chip({ "CURVE: " + cfg.curve.label }) {
            cfg.curve = Curve.values()[(cfg.curve.ordinal + 1) % Curve.values().size]
            engine.update()
        }
        chip({ "LOG: " + if (cfg.hwLog && engine.caps?.hwLog == true) "HW" else "SW" }) {
            if (engine.caps?.hwLog == true) { cfg.hwLog = !cfg.hwLog; engine.restart() }
            else toast("Аппаратная tone-кривая недоступна — используется GL-эмуляция")
        }
        chip({ "HLG: " + if (cfg.emuHlg || engine.caps?.hlg10Native != true) "эмуляция" else "нативный" }) {
            if (engine.caps?.hlg10Native == true) { cfg.emuHlg = !cfg.emuHlg; engine.restart() }
            else toast("Нативный HLG10 не поддерживается — используется эмуляция")
        }
        chip({ "10-bit GL: " + if (cfg.tenBitEmu) "on" else "off" }, { cfg.tenBitEmu }) {
            cfg.tenBitEmu = !cfg.tenBitEmu
            engine.restart()
        }
        chip({ "Q: " + listOf("low", "mid", "high")[cfg.bppIdx] }) { cfg.bppIdx = (cfg.bppIdx + 1) % 3 }
        chip({ "MIC " + if (cfg.audio) "on" else "off" }, { cfg.audio }) { cfg.audio = !cfg.audio }
        chip({ if (cfg.zebra) "ZEBRA ${(cfg.zebraLevel * 100).roundToInt()}" else "ZEBRA" }, { cfg.zebra }) {
            if (!cfg.zebra) { cfg.zebra = true; cfg.zebraLevel = 0.90f }
            else if (cfg.zebraLevel < 0.93f) cfg.zebraLevel = 0.95f
            else if (cfg.zebraLevel < 0.97f) cfg.zebraLevel = 1.0f
            else cfg.zebra = false
            engine.update()
        }
        chip({ "PEAK" }, { cfg.peaking }) { cfg.peaking = !cfg.peaking; engine.update() }
        chip({ "FALSE" }, { cfg.falseColor }) { cfg.falseColor = !cfg.falseColor; engine.update() }
        chip({ "HIST" }, { cfg.hist }) { cfg.hist = !cfg.hist; engine.update() }
        chip({ if (cfg.viewLog) "VIEW: LOG" else "VIEW: 709" }, { cfg.viewLog }) { cfg.viewLog = !cfg.viewLog; engine.update() }
        chip({ "STAB" }, { cfg.stab }) { cfg.stab = !cfg.stab; engine.update() }
        chip({ "TORCH" }, { cfg.torch }) { cfg.torch = !cfg.torch; engine.update() }
        refreshers.add { hist.visibility = if (cfg.hist) View.VISIBLE else View.GONE }
    }

    private fun buildSide() {
        val cfg = engine.cfg
        sideBtn({ lenses.firstOrNull { it.id == cfg.cameraId }?.label ?: "cam" }) {
            if (lenses.size > 1) {
                val i = lenses.indexOfFirst { it.id == cfg.cameraId }
                cfg.cameraId = lenses[(i + 1) % lenses.size].id
                cfg.zoom = 1f
                engine.restart()
            }
        }
        sideBtn({ "%.1fx".format(cfg.zoom) }) { cycleZoom() }

        recBtn = Button(this)
        recBtn.text = "●"
        recBtn.textSize = 24f
        recBtn.setTextColor(Color.WHITE)
        recBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE53935.toInt()) }
        recBtn.setOnClickListener { engine.toggleRecord() }
        side.addView(recBtn, LinearLayout.LayoutParams(dp(64), dp(64)).apply { setMargins(0, dp(8), 0, dp(8)) })

        sideBtn({ "PANEL" }) { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    private fun addSeek(title: String, onChange: (Int) -> String): SeekBar {
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.text = title
        val sb = SeekBar(this)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) t.text = "$title  ${onChange(p)}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        panel.addView(t)
        panel.addView(sb)
        return sb
    }

    private fun panelButton(text: () -> String, onClick: () -> Unit) {
        val b = Button(this)
        styled(b, { false }, text)
        b.setOnClickListener { onClick(); refreshChips() }
        panel.addView(b, LinearLayout.LayoutParams(MATCH, dp(34)).apply { setMargins(0, dp(2), 0, dp(2)) })
    }

    private fun buildPanel() {
        val cfg = engine.cfg
        panelButton({ "EXPOSURE: " + if (cfg.aeManual) "MANUAL" else "AUTO" }) { cfg.aeManual = !cfg.aeManual; engine.update() }
        isoBar = addSeek("ISO") { p ->
            val r = engine.caps?.isoRange
            if (r == null) "—" else {
                val iso = (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
                cfg.iso = iso; cfg.aeManual = true; engine.update(); refreshChips(); "$iso"
            }
        }
        shutBar = addSeek("SHUTTER") { p ->
            val d = shutters.getOrNull(p)
            if (d == null) "—" else {
                cfg.expNs = 1_000_000_000L / d; cfg.aeManual = true; engine.update(); refreshChips(); "1/$d"
            }
        }
        evBar = addSeek("EV") { p ->
            val c = engine.caps
            val r = c?.aeRange
            if (c == null || r == null) "—" else {
                cfg.ev = r.lower + p; engine.update(); "%+.1f".format(cfg.ev * c.aeStep)
            }
        }
        panelButton({ "FOCUS: " + if (cfg.afManual) "MF" else "AF" }) { cfg.afManual = !cfg.afManual; engine.update() }
        focusBar = addSeek("FOCUS") { p ->
            val c = engine.caps
            if (c == null || c.minFocus <= 0f) "—" else {
                cfg.focus = c.minFocus * p / 100f; cfg.afManual = true; engine.update(); refreshChips()
                if (cfg.focus < 0.05f) "∞" else "%.0f см".format(100f / cfg.focus)
            }
        }
        panelButton({ "WB: " + AWB_PRESETS[cfg.awbIdx].first }) { cfg.awbIdx = (cfg.awbIdx + 1) % AWB_PRESETS.size; engine.update() }
    }

    /** Подгоняет слайдеры под возможности текущей камеры. */
    private fun refreshControls() {
        val c = engine.caps ?: return
        val cfg = engine.cfg
        val manual = c.manualSensor && c.isoRange != null && c.expRange != null
        isoBar.isEnabled = manual
        shutBar.isEnabled = manual
        c.isoRange?.let { r ->
            isoBar.max = 100
            val x = cfg.iso.toDouble().coerceIn(r.lower.toDouble(), r.upper.toDouble())
            isoBar.progress = (ln(x / r.lower) / ln(r.upper.toDouble() / r.lower) * 100).roundToInt().coerceIn(0, 100)
        }
        shutters = listOf(24, 25, 30, 48, 50, 60, 96, 100, 120, 125, 240, 250, 500, 1000, 2000, 4000, 8000).filter { d ->
            d >= cfg.fps && (c.expRange?.let { 1_000_000_000L / d in it.lower..it.upper } == true)
        }
        shutBar.max = (shutters.size - 1).coerceAtLeast(0)
        val cur = (1e9 / cfg.expNs).roundToInt()
        shutBar.progress = shutters.indices.minByOrNull { abs(shutters[it] - cur) } ?: 0
        val r = c.aeRange
        evBar.isEnabled = r != null && c.aeStep > 0f
        if (r != null) { evBar.max = r.upper - r.lower; evBar.progress = cfg.ev - r.lower }
        focusBar.isEnabled = c.minFocus > 0f
        focusBar.max = 100
        if (c.minFocus > 0f) focusBar.progress = (cfg.focus / c.minFocus * 100).roundToInt().coerceIn(0, 100)
        refreshChips()
    }

    private fun setZoom(z: Float) {
        val c = engine.caps ?: return
        engine.cfg.zoom = z.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
        engine.update()
        refreshChips()
    }

    private fun cycleZoom() {
        val c = engine.caps ?: return
        val p = listOf(0.5f, 1f, 2f, 3f, 5f, 10f).filter { it >= c.zoomRange.lower - 0.01f && it <= c.zoomRange.upper + 0.01f }
        if (p.isEmpty()) return
        val cur = engine.cfg.zoom
        setZoom(p.firstOrNull { it > cur + 0.05f } ?: p.first())
    }

    private fun initEngine() {
        engine = CameraEngine(this, this)
        lenses = try { engine.lenses() } catch (e: Exception) { emptyList() }
        engine.cfg.cameraId = (lenses.firstOrNull { it.id == "0" } ?: lenses.firstOrNull())?.id ?: ""
        buildStrip()
        buildSide()
        buildPanel()
        setupTouch()
        refreshChips()
        ready = true
        if (surface.holder.surface.isValid) startEngine()
    }

    // ------------------------------------------------------------ CameraEngine.Listener

    override fun onInfo(text: String) { hud.text = text }
    override fun onExposure(text: String) { expHud.text = text }
    override fun onHist(bins: IntArray) { hist.set(bins) }
    override fun onError(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    override fun onSaved(path: String) { Toast.makeText(this, "Сохранено: $path", Toast.LENGTH_LONG).show() }
    override fun onReady() { refreshControls() }

    override fun onRecording(on: Boolean) {
        recording = on
        recBtn.text = if (on) "■" else "●"
        if (on) {
            recStart = SystemClock.elapsedRealtime()
            tick()
        } else {
            recHud.text = ""
        }
    }

    private fun tick() {
        main.postDelayed({
            if (recording) {
                val s = (SystemClock.elapsedRealtime() - recStart) / 1000
                recHud.text = "● %02d:%02d".format(s / 60, s % 60)
                tick()
            }
        }, 500)
    }
}
