package app.procam

import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.DynamicRangeProfiles
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.os.Build
import android.util.Range
import android.util.Size

const val MIME_HEVC = "video/hevc"
const val MIME_AVC = "video/avc"

data class Lens(val id: String, val label: String, val eq: Int)

/** Всё, что умеет конкретная камера (по Camera2 characteristics). */
class CamCaps(val id: String, private val ch: CameraCharacteristics) {
    private val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
    private val capSet = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toSet() ?: emptySet()

    val sensorOrientation: Int = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
    val timestampRealtime: Boolean =
        ch.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) == CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
    val fpsRanges: List<Range<Int>> =
        ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: listOf(Range(15, 30))

    val manualSensor = capSet.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
    val isoRange: Range<Int>? = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
    val expRange: Range<Long>? = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    val minFocus: Float = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    val aeStep: Float = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
    val aeRange: Range<Int>? = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
    val activeArray: Rect = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)
    val maxAfRegions: Int = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
    val maxAeRegions: Int = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0

    private val maxDigital: Float = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
    val zoomRange: Range<Float> =
        if (Build.VERSION.SDK_INT >= 30) (ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) ?: Range(1f, maxDigital))
        else Range(1f, maxDigital)

    val awbModes: Set<Int> = ch.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toSet() ?: setOf(CameraMetadata.CONTROL_AWB_MODE_AUTO)
    val afModes: Set<Int> = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.toSet() ?: emptySet()
    val stabModes: Set<Int> = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.toSet() ?: emptySet()
    val oisModes: Set<Int> = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.toSet() ?: emptySet()

    /** Аппаратный LOG через пользовательскую tone-кривую. */
    val maxCurvePoints: Int = ch.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS) ?: 0
    val hwLog: Boolean =
        (ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.contains(CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE) == true) &&
            maxCurvePoints >= 16

    /** Нативный 10-bit HLG10 (Android 13+ и поддержка в HAL). */
    val hlg10Native: Boolean = Build.VERSION.SDK_INT >= 33 &&
        (ch.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)?.supportedProfiles?.contains(DynamicRangeProfiles.HLG10) == true)

    /** Профиль для превью-выхода рядом с HLG10-выходом (STANDARD, если HAL разрешает смешивать). */
    fun previewProfileForHlg(): Long {
        if (Build.VERSION.SDK_INT < 33) return 1L
        val p = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES) ?: return 1L
        return try {
            if (p.getProfileCaptureRequestConstraints(DynamicRangeProfiles.HLG10).contains(DynamicRangeProfiles.STANDARD))
                DynamicRangeProfiles.STANDARD else DynamicRangeProfiles.HLG10
        } catch (e: Exception) {
            DynamicRangeProfiles.HLG10
        }
    }

    private fun is169(s: Size) = s.width * 9 == s.height * 16

    val videoSizes: List<Size> = (map.getOutputSizes(MediaRecorder::class.java)
        ?: map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray<Size>())
        .filter { is169(it) && it.width >= 1280 }.sortedByDescending { it.width }

    private val previewSizes: List<Size> = (map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray<Size>())
        .filter { is169(it) }.sortedBy { it.width }

    fun previewStreamSize(): Size =
        previewSizes.firstOrNull { it.width == 1280 }
            ?: previewSizes.filter { it.width >= 1280 }.minByOrNull { it.width }
            ?: previewSizes.firstOrNull() ?: Size(1280, 720)

    fun maxFps(size: Size): Int {
        val aeMax = fpsRanges.maxOf { it.upper }
        val dur = try { map.getOutputMinFrameDuration(MediaRecorder::class.java, size) } catch (e: Exception) { 0L }
        if (dur <= 0L) return aeMax
        return minOf(aeMax, Math.floor(1e9 / dur + 0.01).toInt())
    }

    fun fpsRangeFor(fps: Int): Range<Int> =
        fpsRanges.firstOrNull { it.lower == fps && it.upper == fps }
            ?: fpsRanges.filter { it.upper == fps }.maxByOrNull { it.lower }
            ?: fpsRanges.filter { it.upper > fps && it.lower <= fps }.minByOrNull { it.upper }
            ?: fpsRanges.first()
}

/** Что умеют видеокодеки телефона. */
object Enc {
    private fun infos(mime: String) = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }

    private fun best(mime: String): MediaCodecInfo? {
        val l = infos(mime)
        return l.firstOrNull { !it.name.startsWith("OMX.google") && !it.name.startsWith("c2.android") } ?: l.firstOrNull()
    }

    fun bestName(mime: String): String? = best(mime)?.name

    fun supports(mime: String, w: Int, h: Int, fps: Int): Boolean = try {
        best(mime)?.getCapabilitiesForType(mime)?.videoCapabilities?.areSizeAndRateSupported(w, h, fps.toDouble()) == true
    } catch (e: Exception) { false }

    fun hevcMain10(w: Int, h: Int, fps: Int): Boolean = try {
        val caps = best(MIME_HEVC)?.getCapabilitiesForType(MIME_HEVC)
        caps != null && caps.profileLevels.any {
            it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 ||
                it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10
        } && supports(MIME_HEVC, w, h, fps)
    } catch (e: Exception) { false }

    fun maxBitrate(mime: String): Int = try {
        best(mime)?.getCapabilitiesForType(mime)?.videoCapabilities?.bitrateRange?.upper ?: 100_000_000
    } catch (e: Exception) { 100_000_000 }
}
