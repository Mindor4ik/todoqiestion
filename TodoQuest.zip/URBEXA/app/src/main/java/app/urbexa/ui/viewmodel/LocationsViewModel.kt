package app.urbexa.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import app.urbexa.data.local.UrbexaDatabase
import app.urbexa.data.local.entity.LocationEntity
import app.urbexa.data.repository.LocationRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class LocationsViewModel(application: Application) : AndroidViewModel(application) {

    private val database = Room.databaseBuilder(
        application,
        UrbexaDatabase::class.java,
        "urbexa_db"
    ).build()

    private val repository = LocationRepository(database.locationDao())

    val allLocations: StateFlow<List<LocationEntity>> = repository.allLocations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val favoriteLocations: StateFlow<List<LocationEntity>> = repository.favoriteLocations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addLocation(location: LocationEntity) {
        viewModelScope.launch {
            repository.insertLocation(location)
        }
    }

    fun updateLocation(location: LocationEntity) {
        viewModelScope.launch {
            repository.updateLocation(location)
        }
    }

    fun deleteLocation(location: LocationEntity) {
        viewModelScope.launch {
            repository.deleteLocation(location)
        }
    }

    fun toggleFavorite(location: LocationEntity) {
        viewModelScope.launch {
            repository.updateLocation(location.copy(isFavorite = !location.isFavorite, updatedAt = System.currentTimeMillis()))
        }
    }
}
