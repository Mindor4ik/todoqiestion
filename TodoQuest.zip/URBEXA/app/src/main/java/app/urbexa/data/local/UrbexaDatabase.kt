package app.urbexa.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import app.urbexa.data.local.dao.ArchiveDao
import app.urbexa.data.local.dao.LocationDao
import app.urbexa.data.local.entity.ArchiveNoteEntity
import app.urbexa.data.local.entity.LocationEntity

@Database(
    entities = [LocationEntity::class, ArchiveNoteEntity::class],
    version = 2,
    exportSchema = false
)
abstract class UrbexaDatabase : RoomDatabase() {
    abstract fun locationDao(): LocationDao
    abstract fun archiveDao(): ArchiveDao
}
