package app.urbexa.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import app.urbexa.ui.navigation.Section
import app.urbexa.ui.screens.ArchiveScreen
import app.urbexa.ui.screens.CommsScreen
import app.urbexa.ui.screens.MapScreen
import app.urbexa.ui.screens.ObjectsScreen
import app.urbexa.ui.screens.ProfileScreen
import app.urbexa.ui.screens.ToolsScreen

private fun NavController.goTo(section: Section) {
    navigate(section.route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UrbexaApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = Section.fromRoute(entry?.destination?.route) ?: Section.Map

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(current.label).uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                    )
                },
                actions = {
                    IconButton(onClick = { nav.goTo(Section.Comms) }) {
                        Icon(Section.Comms.icon, contentDescription = stringResource(Section.Comms.label))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                    actionIconContentColor = if (current == Section.Comms) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                ),
            )
        },
        bottomBar = {
            NavigationBar {
                Section.bottomBar.forEach { section ->
                    NavigationBarItem(
                        selected = current == section,
                        onClick = { nav.goTo(section) },
                        icon = { Icon(section.icon, contentDescription = null) },
                        label = { Text(stringResource(section.label)) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Section.Map.route,
            modifier = Modifier.padding(padding),
        ) {
            composable(Section.Map.route) { MapScreen() }
            composable(Section.Objects.route) { ObjectsScreen() }
            composable(Section.Archive.route) { ArchiveScreen() }
            composable(Section.Tools.route) { ToolsScreen() }
            composable(Section.Profile.route) { ProfileScreen() }
            composable(Section.Comms.route) { CommsScreen() }
        }
    }
}
