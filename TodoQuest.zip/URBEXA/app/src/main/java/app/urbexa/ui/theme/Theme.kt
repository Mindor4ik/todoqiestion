package app.urbexa.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val UrbexaColors = darkColorScheme(
    primary = Amber,
    onPrimary = Graphite900,
    primaryContainer = AmberDim,
    onPrimaryContainer = Amber,
    secondary = Phosphor,
    onSecondary = Graphite900,
    secondaryContainer = AmberDim,
    onSecondaryContainer = Amber,
    background = Graphite900,
    onBackground = Paper,
    surface = Graphite800,
    onSurface = Paper,
    surfaceVariant = Graphite700,
    onSurfaceVariant = PaperDim,
    surfaceContainer = Graphite800,
    outline = Graphite600,
    error = Alert,
)

// Тёмная тема — осознанно единственная: прибор для работы на улице, без светлого варианта на этом этапе.
@Composable
fun UrbexaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = UrbexaColors,
        typography = UrbexaTypography,
        content = content,
    )
}
