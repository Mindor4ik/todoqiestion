package app.urbexa.data.local.dao

import androidx.room.*
import app.urbexa.data.local.entity.ArchiveNoteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ArchiveDao {
    @Query("SELECT * FROM archive_notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<ArchiveNoteEntity>>

    @Query("SELECT * FROM archive_notes WHERE locationId = :locationId ORDER BY timestamp DESC")
    fun getNotesForLocation(locationId: Long): Flow<List<ArchiveNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: ArchiveNoteEntity): Long

    @Delete
    suspend fun deleteNote(note: ArchiveNoteEntity)
}
