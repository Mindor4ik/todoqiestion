package app.urbexa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class VerificationStatus {
    CONFIRMED,          // Подтверждено
    PARTIALLY_CONFIRMED, // Частично подтверждено
    ASSUMPTION,         // Предположение
    UNVERIFIED          // Не проверено
}

@Entity(tableName = "locations")
data class LocationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val category: String,
    val accessStatus: String,
    val verificationStatus: VerificationStatus = VerificationStatus.UNVERIFIED,
    val source: String? = null,
    val checkDate: Long = System.currentTimeMillis(),
    val notes: String? = null,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
