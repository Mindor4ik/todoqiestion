package app.urbexa.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.ui.graphics.vector.ImageVector
import app.urbexa.R

enum class Section(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
    val inBottomBar: Boolean,
) {
    Map("map", R.string.nav_map, Icons.Filled.Place, true),
    Objects("objects", R.string.nav_objects, Icons.AutoMirrored.Filled.List, true),
    Archive("archive", R.string.nav_archive, Icons.Filled.DateRange, true),
    Tools("tools", R.string.nav_tools, Icons.Filled.Build, true),
    Profile("profile", R.string.nav_profile, Icons.Filled.Person, true),
    // Шестой раздел не помещается в нижнюю панель (максимум 5): открывается из верхней панели.
    Comms("comms", R.string.nav_comms, Icons.Filled.Call, false);

    companion object {
        val bottomBar: List<Section> = entries.filter { it.inBottomBar }
        fun fromRoute(route: String?): Section? = entries.firstOrNull { it.route == route }
    }
}
