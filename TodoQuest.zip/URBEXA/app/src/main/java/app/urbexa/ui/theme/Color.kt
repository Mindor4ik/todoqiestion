package app.urbexa.ui.theme

import androidx.compose.ui.graphics.Color

val Graphite900 = Color(0xFF111311)
val Graphite800 = Color(0xFF181B18)
val Graphite700 = Color(0xFF222622)
val Graphite600 = Color(0xFF2E332D)

val Amber = Color(0xFFD9A441)
val AmberDim = Color(0xFF3B2F14)
val Phosphor = Color(0xFF8FB573)

val Paper = Color(0xFFDAD7CB)
val PaperDim = Color(0xFFA09D92)
val Alert = Color(0xFFD9705E)
