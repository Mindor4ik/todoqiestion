package app.urbexa.data.repository

import app.urbexa.data.local.dao.LocationDao
import app.urbexa.data.local.entity.LocationEntity
import kotlinx.coroutines.flow.Flow

class LocationRepository(private val locationDao: LocationDao) {

    val allLocations: Flow<List<LocationEntity>> = locationDao.getAllLocations()
    val favoriteLocations: Flow<List<LocationEntity>> = locationDao.getFavoriteLocations()

    suspend fun getLocationById(id: Long): LocationEntity? {
        return locationDao.getLocationById(id)
    }

    suspend fun insertLocation(location: LocationEntity): Long {
        return locationDao.insertLocation(location)
    }

    suspend fun updateLocation(location: LocationEntity) {
        locationDao.updateLocation(location)
    }

    suspend fun deleteLocation(location: LocationEntity) {
        locationDao.deleteLocation(location)
    }
}
