package app.urbexa.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "archive_notes")
data class ArchiveNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val locationId: Long? = null,
    val title: String,
    val content: String,
    val imagePath: String? = null,
    val tags: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
