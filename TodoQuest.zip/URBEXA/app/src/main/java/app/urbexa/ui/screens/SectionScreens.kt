package app.urbexa.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.urbexa.data.local.entity.LocationEntity
import app.urbexa.data.local.entity.VerificationStatus
import app.urbexa.data.remote.SyncManager
import app.urbexa.ui.components.EmptyState
import app.urbexa.ui.navigation.Section
import app.urbexa.ui.viewmodel.LocationsViewModel

@Composable
fun SectionScreen(
    section: Section,
    viewModel: LocationsViewModel = viewModel()
) {
    val allLocations by viewModel.allLocations.collectAsState()
    val favoriteLocations by viewModel.favoriteLocations.collectAsState()

    when (section) {
        Section.MAP -> MapScreen(allLocations = allLocations)
        Section.LOCATIONS -> LocationsScreen(
            allLocations = allLocations,
            favoriteLocations = favoriteLocations,
            viewModel = viewModel
        )
        Section.ARCHIVE -> ArchiveScreen()
        Section.TOOLS -> ToolsScreen()
        Section.COMMUNICATION -> CommunicationScreen()
        Section.PROFILE -> ProfileScreen(allLocations = allLocations)
    }
}

// ----------------------------------------------------
# 1. Раздел: Карта (MapScreen)
// ----------------------------------------------------
@Composable
fun MapScreen(allLocations: List<LocationEntity>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "GPS ТЕРМИНАЛ: ТЮМЕНЬ / ТЕКУЩИЕ КООРДИНАТЫ",
                        style = MaterialTheme.typography.labelLarge,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "57°09'18.7"N 65°31'37.9"E",
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Точность: 3.2 м | Точек на карте: ${allLocations.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF141818), shape = RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.Place,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "СЕТКА ОФЛАЙН-КАРТЫ АКТИВНА",
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Сохранено объектов в локальном слое: ${allLocations.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray
                )
            }
        }
    }
}

// ----------------------------------------------------
# 2. Раздел: Объекты (LocationsScreen)
// ----------------------------------------------------
@Composable
fun LocationsScreen(
    allLocations: List<LocationEntity>,
    favoriteLocations: List<LocationEntity>,
    viewModel: LocationsViewModel
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Добавить объект")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Все объекты (${allLocations.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Избранное (${favoriteLocations.size})") }
                )
            }

            val displayList = if (selectedTab == 0) allLocations else favoriteLocations

            if (displayList.isEmpty()) {
                EmptyState(
                    message = if (selectedTab == 0) "База объектов пуста. Нажмите +, чтобы добавить точку." : "Список избранного пуст.",
                    icon = Icons.Default.Info
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(displayList, key = { it.id }) { location ->
                        LocationCard(
                            location = location,
                            onToggleFavorite = { viewModel.toggleFavorite(location) },
                            onDelete = { viewModel.deleteLocation(location) }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddLocationDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, desc, lat, lon, cat, access, status ->
                viewModel.addLocation(
                    LocationEntity(
                        name = name,
                        description = desc,
                        latitude = lat,
                        longitude = lon,
                        category = cat,
                        accessStatus = access,
                        verificationStatus = status
                    )
                )
                showAddDialog = false
            }
        )
    }
}

@Composable
fun LocationCard(
    location: LocationEntity,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = location.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (location.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Избранное",
                            tint = if (location.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
            Text(
                text = location.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "Статус: ${location.verificationStatus.name}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${location.latitude}, ${location.longitude}",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
fun AddLocationDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Double, Double, String, String, VerificationStatus) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var latitude by remember { mutableStateOf("57.1522") }
    var longitude by remember { mutableStateOf("65.5272") }
    var category by remember { mutableStateOf("Промышленность") }
    var accessStatus by remember { mutableStateOf("Охраняется") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый объект URBEXA") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название") })
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Описание") })
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Категория") })
                OutlinedTextField(value = accessStatus, onValueChange = { accessStatus = it }, label = { Text("Доступность / Ограничения") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = latitude, onValueChange = { latitude = it }, label = { Text("Широта") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = longitude, onValueChange = { longitude = it }, label = { Text("Долгота") }, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            name,
                            description,
                            latitude.toDoubleOrNull() ?: 0.0,
                            longitude.toDoubleOrNull() ?: 0.0,
                            category,
                            accessStatus,
                            VerificationStatus.CONFIRMED
                        )
                    }
                }
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

// ----------------------------------------------------
# 3. Раздел: Архив (ArchiveScreen)
// ----------------------------------------------------
@Composable
fun ArchiveScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("ПОЛЕВОЙ АРХИВ НАБЛЮДЕНИЙ", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(12.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Заметка #001 — Заводской цех №4", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Зафиксировано разрушение перекрытий в восточном крыле. Вход через северный проход свободный.", style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Теги: #радио #цех #опасность", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

// ----------------------------------------------------
# 4. Раздел: Инструменты (ToolsScreen)
// ----------------------------------------------------
@Composable
fun ToolsScreen() {
    var flashlightOn by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("ПОЛЕВОЙ НАБОР ИНСТРУМЕНТОВ", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Фонарик терминала", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(if (flashlightOn) "Состояние: АКТИВЕН" else "Состояние: ВЫКЛЮЧЕН", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                Switch(checked = flashlightOn, onCheckedChange = { flashlightOn = it })
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Датчики устройства", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("• Магнитометр: ГОТОВ", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                Text("• Барометр / Высотомер: ДОСТУПЕН", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                Text("• Акселерометр: КАЛИБРОВАН", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

// ----------------------------------------------------
# 5. Раздел: Связь (CommunicationScreen)
// ----------------------------------------------------
@Composable
fun CommunicationScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("СВЯЗЬ И ЛОКАЛЬНАЯ СЕТЬ", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Color.Gray)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Meshtastic Протокол", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Статус: Устройство не подключено", style = MaterialTheme.typography.bodyMedium, color = Color.Red)
                Text("Для работы требуется радиомодуль LoRa / Meshtastic.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        }
    }
}

// ----------------------------------------------------
# 6. Раздел: Профиль и Авторизация (ProfileScreen)
// ----------------------------------------------------
@Composable
fun ProfileScreen(allLocations: List<LocationEntity>) {
    var username by remember { mutableStateOf("Исследователь_01") }
    var serverAuthed by remember { mutableStateOf(true) }
    var driveSynced by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("ПРОФИЛЬ И НАСТРОЙКИ", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Пользователь терминала", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Text(username, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Серверная авторизация: АКТИВНА", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Облачная синхронизация (Google Drive)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    if (driveSynced) "Конфигурация URBEXA_Config.json синхронизирована." else "Резервная копия готовит файл URBEXA_Config.json",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { driveSynced = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Синхронизировать с Google Drive")
                }
            }
        }
    }
}
