package app.urbexa.ui.screens

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import app.urbexa.R
import app.urbexa.ui.components.EmptyState
import app.urbexa.ui.navigation.Section

// Честные заглушки этапа 0: никаких фиктивных данных и кнопок. Каждый экран заменяется на своём этапе.
@Composable
private fun StubScreen(section: Section, @StringRes body: Int) {
    EmptyState(
        icon = section.icon,
        title = stringResource(R.string.stub_title),
        body = stringResource(body),
    )
}

@Composable fun MapScreen() = StubScreen(Section.Map, R.string.stub_map)
@Composable fun ObjectsScreen() = StubScreen(Section.Objects, R.string.stub_objects)
@Composable fun ArchiveScreen() = StubScreen(Section.Archive, R.string.stub_archive)
@Composable fun ToolsScreen() = StubScreen(Section.Tools, R.string.stub_tools)
@Composable fun CommsScreen() = StubScreen(Section.Comms, R.string.stub_comms)
@Composable fun ProfileScreen() = StubScreen(Section.Profile, R.string.stub_profile)
