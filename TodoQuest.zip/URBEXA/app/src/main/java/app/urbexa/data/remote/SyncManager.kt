package app.urbexa.data.remote

import android.content.Context
import app.urbexa.data.local.entity.LocationEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object SyncManager {

    fun exportToJson(locations: List<LocationEntity>): String {
        val root = JSONObject()
        root.put("app", "URBEXA")
        root.put("schemaVersion", 1)
        root.put("exportTime", System.currentTimeMillis())

        val array = JSONArray()
        for (loc in locations) {
            val obj = JSONObject()
            obj.put("id", loc.id)
            obj.put("name", loc.name)
            obj.put("description", loc.description)
            obj.put("latitude", loc.latitude)
            obj.put("longitude", loc.longitude)
            obj.put("category", loc.category)
            obj.put("accessStatus", loc.accessStatus)
            obj.put("verificationStatus", loc.verificationStatus.name)
            obj.put("source", loc.source)
            obj.put("notes", loc.notes)
            obj.put("isFavorite", loc.isFavorite)
            array.put(obj)
        }
        root.put("locations", array)
        return root.toString(2)
    }

    fun mockServerAuthenticate(username: String, passwordHash: String): Boolean {
        // Эмуляция проверки учетных данных на внешнем сервере
        return username.isNotBlank() && passwordHash.isNotBlank()
    }
}
