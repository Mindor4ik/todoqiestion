plugins {
  id("com.android.application"); id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.plugin.compose"); id("com.google.devtools.ksp")
}
android {
  namespace = "app.todo"; compileSdk = 35
  defaultConfig { applicationId = "app.todo"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
  buildFeatures { compose = true }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  val room = "2.6.1"
  implementation(platform("androidx.compose:compose-bom:2024.09.03"))
  implementation("androidx.compose.material3:material3")
  implementation("androidx.activity:activity-compose:1.9.2")
  implementation("androidx.room:room-ktx:$room"); ksp("androidx.room:room-compiler:$room")
  implementation("androidx.work:work-runtime-ktx:2.9.1")
  implementation("androidx.glance:glance-appwidget:1.1.0")
  implementation("androidx.glance:glance-material3:1.1.0")
}
