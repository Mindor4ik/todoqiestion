package app.todo
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.compose.ui.geometry.lerp as lerpOffset
import androidx.compose.ui.graphics.lerp as lerpColor

/* ───────────── Эффекты ─────────────
 * Блюр применяется ТОЛЬКО к содержимому, пока открыт диалог/шторка (короткая анимация),
 * а фон-«свечение» нарисован градиентами — это бесплатно для GPU. */
object Fx { var open by mutableIntStateOf(0) }

@Composable fun BlurWhile(active: Boolean) {
  DisposableEffect(active) { if (active) Fx.open++; onDispose { if (active) Fx.open-- } }
}

@Composable fun isDark(): Boolean = MaterialTheme.colorScheme.background.luminance() < .5f

@Composable fun accentBrush(): Brush {
  val a = MaterialTheme.colorScheme.primary
  return Brush.linearGradient(listOf(a, lerpColor(a, Color(0xFFB04CFF), .55f)))
}

/** Мягкий фон: два радиальных «пятна» цвета акцента. */
@Composable fun Modifier.orbs(): Modifier {
  val a = MaterialTheme.colorScheme.primary; val dark = isDark(); val base = MaterialTheme.colorScheme.background
  val b = lerpColor(a, Color(0xFFFF6FA5), .6f)
  return this.background(base).drawBehind {
    drawRect(Brush.radialGradient(listOf(a.copy(alpha = if (dark) .30f else .20f), Color.Transparent), center = Offset(size.width * .95f, size.height * .02f), radius = size.width))
    drawRect(Brush.radialGradient(listOf(b.copy(alpha = if (dark) .16f else .12f), Color.Transparent), center = Offset(0f, size.height * .6f), radius = size.width * .9f))
  }
}

/** «Стеклянная» карточка: полупрозрачная заливка + тонкая кромка. */
@Composable fun Modifier.glass(shape: Shape = RoundedCornerShape(22.dp), strong: Boolean = false): Modifier {
  val dark = isDark()
  val fill = if (dark) Color(0xFF22212B).copy(alpha = if (strong) .94f else .68f) else Color.White.copy(alpha = if (strong) .96f else .74f)
  val edge = if (dark) Color.White.copy(alpha = .08f) else Color(0x14000000)
  // drawBehind вместо clip+background+border: нет обрезки слоя, рисуется один раз
  return this.drawBehind { val o = shape.createOutline(size, layoutDirection, this); drawOutline(o, fill); drawOutline(o, edge, style = Stroke(1.dp.toPx())) }
}

/** Лёгкая «пружинка» при нажатии. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
  val src = remember { MutableInteractionSource() }
  val pressed by src.collectIsPressedAsState()
  val s by animateFloatAsState(if (pressed) .97f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "press")
  this.graphicsLayer { scaleX = s; scaleY = s }.clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Лёгкий тап для строк списка: без composed, interactionSource и анимации — важно для fps при прокрутке. */
@Composable fun Modifier.tap(onClick: () -> Unit): Modifier {
  val cb = rememberUpdatedState(onClick)
  return this.pointerInput(Unit) { detectTapGestures { cb.value() } }
}

/* ───────────── Компоненты ───────────── */
@Composable fun Pill(selected: Boolean, text: String, onClick: () -> Unit, modifier: Modifier = Modifier, padH: Dp = 16.dp, padV: Dp = 9.dp) {
  val cs = MaterialTheme.colorScheme
  val bg = animateColorAsState(if (selected) cs.primary else cs.onSurface.copy(alpha = .08f), tween(220), label = "pb")
  val fg = animateColorAsState(if (selected) cs.onPrimary else cs.onSurface.copy(alpha = .8f), tween(220), label = "pf")
  Box(modifier.pressable(onClick).clip(RoundedCornerShape(50)).drawBehind { drawRect(bg.value) }, contentAlignment = Alignment.Center) {
    Text(text, Modifier.padding(horizontal = padH, vertical = padV), color = fg.value, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
  }
}

@Composable fun GhostBtn(text: String, onClick: () -> Unit) =
  Text(text, Modifier.pressable(onClick).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = .22f)).padding(horizontal = 14.dp, vertical = 7.dp),
    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)

@Composable fun Tag(text: String, color: Color) =
  Text(text, Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = .14f)).padding(horizontal = 7.dp, vertical = 2.dp),
    color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)

@Composable fun Label(text: String) =
  Text(text, Modifier.padding(start = 4.dp, bottom = 6.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))

@Composable fun transparentField() = TextFieldDefaults.colors(
  focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, disabledContainerColor = Color.Transparent,
  focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent)

@Composable fun GlassField(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier,
                           leading: @Composable (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null, onDone: () -> Unit = {}) {
  TextField(value, onChange, modifier.glass(RoundedCornerShape(24.dp)), placeholder = { Text(placeholder) }, singleLine = true,
    leadingIcon = leading, trailingIcon = trailing, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
    keyboardActions = KeyboardActions(onDone = { onDone() }), colors = transparentField())
}

/** Круглый чекбокс: заливка, «рисующаяся» галочка и лёгкий отскок. */
@Composable fun CheckCircle(checked: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, dia: Dp = 26.dp) {
  val accent = MaterialTheme.colorScheme.primary; val ring = MaterialTheme.colorScheme.outline
  val fill by animateFloatAsState(if (checked) 1f else 0f, tween(280, easing = FastOutSlowInEasing), label = "ck")
  val pop by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium), label = "pop")
  Box(modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
    Canvas(Modifier.size(dia).graphicsLayer { val s = .88f + .12f * pop; scaleX = s; scaleY = s }) {
      val w = size.width; val sw = 2.dp.toPx()
      drawCircle(accent.copy(alpha = fill), radius = w / 2 * (.35f + .65f * fill))
      drawCircle(lerpColor(ring, accent, fill), radius = w / 2 - sw / 2, style = Stroke(sw))
      if (fill > 0.02f) {
        val a = Offset(w * .28f, w * .52f); val b = Offset(w * .44f, w * .68f); val c = Offset(w * .74f, w * .35f)
        val e1 = (fill / .4f).coerceIn(0f, 1f); val e2 = ((fill - .4f) / .6f).coerceIn(0f, 1f)
        val st = 2.4.dp.toPx()
        drawLine(Color.White, a, lerpOffset(a, b, e1), strokeWidth = st, cap = StrokeCap.Round)
        if (e2 > 0f) drawLine(Color.White, b, lerpOffset(b, c, e2), strokeWidth = st, cap = StrokeCap.Round)
      }
    }
  }
}

/** Кольцо прогресса. */
@Composable fun Ring(progress: Float, modifier: Modifier = Modifier, stroke: Dp = 8.dp, color: Color = Color.White,
                     track: Color = Color.White.copy(alpha = .25f), content: @Composable BoxScope.() -> Unit = {}) {
  Box(modifier, contentAlignment = Alignment.Center) {
    Canvas(Modifier.fillMaxSize()) {
      val sw = stroke.toPx(); val s = Size(size.width - sw, size.height - sw); val tl = Offset(sw / 2, sw / 2)
      drawArc(track, 0f, 360f, false, tl, s, style = Stroke(sw))
      if (progress > 0.005f) drawArc(color, -90f, 360f * progress.coerceAtMost(1f), false, tl, s, style = Stroke(sw, cap = StrokeCap.Round))
    }
    content()
  }
}

/** Кольцо с собственной анимацией: прогресс читается только в draw-фазе, поэтому экран не перекомпонуется на каждом кадре. */
@Composable fun ProgressRing(pct: Int, modifier: Modifier = Modifier, stroke: Dp = 8.dp, fontSize: Int = 16) {
  val p = animateFloatAsState(pct / 100f, tween(600, easing = FastOutSlowInEasing), label = "ring")
  Box(modifier, contentAlignment = Alignment.Center) {
    Canvas(Modifier.fillMaxSize()) {
      val sw = stroke.toPx(); val s = Size(size.width - sw, size.height - sw); val tl = Offset(sw / 2, sw / 2)
      drawArc(Color.White.copy(alpha = .25f), 0f, 360f, false, tl, s, style = Stroke(sw))
      if (p.value > 0.005f) drawArc(Color.White, -90f, 360f * p.value.coerceAtMost(1f), false, tl, s, style = Stroke(sw, cap = StrokeCap.Round))
    }
    Text("$pct%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = fontSize.sp)
  }
}

/** Тонкая анимированная полоса прогресса. */
@Composable fun Bar(progress: Float, modifier: Modifier = Modifier, height: Dp = 6.dp) {
  val p = animateFloatAsState(progress.coerceIn(0f, 1f), tween(600, easing = FastOutSlowInEasing), label = "bar")
  val a = MaterialTheme.colorScheme.primary; val track = MaterialTheme.colorScheme.onSurface.copy(alpha = .09f)
  Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).drawBehind {
    drawRect(track)
    drawRect(Brush.horizontalGradient(listOf(a, lerpColor(a, Color(0xFFFF6FA5), .6f))), size = Size(size.width * p.value, size.height))
  })
}

/* ───────────── Перестановка ───────────── */
@Composable fun Grip(modifier: Modifier = Modifier) {
  val tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .4f)
  Box(modifier.size(40.dp), contentAlignment = Alignment.Center) {
    Canvas(Modifier.size(16.dp)) {
      for (r in 0..2) for (k in 0..1) drawCircle(tint, 1.7.dp.toPx(), Offset(size.width * (.28f + .44f * k), size.height * (.12f + .38f * r)))
    }
  }
}

/** «Выше / ниже» + ручка для перетаскивания. */
@Composable fun MoveControls(canUp: Boolean, canDown: Boolean, onMove: (Int) -> Unit, grip: Modifier) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    IconButton({ onMove(-1) }, Modifier.size(34.dp), enabled = canUp) { Icon(Icons.Default.KeyboardArrowUp, "Выше") }
    IconButton({ onMove(1) }, Modifier.size(34.dp), enabled = canDown) { Icon(Icons.Default.KeyboardArrowDown, "Ниже") }
    Grip(grip)
  }
}

/** Перестановка перетаскиванием в LazyColumn. Пока тянем — работаем с локальной копией, на отпускание пишем в БД. */
class DragReorder<T : Any>(private val lazy: LazyListState, private val scope: CoroutineScope, private val keyOf: (T) -> Any) {
  var current: List<T> = emptyList()
  var onDrop: (List<T>) -> Unit = {}
  private var list by mutableStateOf<List<T>>(emptyList())
  var dragKey by mutableStateOf<Any?>(null); private set
  var held by mutableStateOf(false); private set
  var dragY by mutableFloatStateOf(0f); private set
  private var pending: Int? = null
  private var settle: Job? = null

  fun items(src: List<T>): List<T> { current = src; return if (dragKey != null) list else src }

  fun start(key: Any) { settle?.cancel(); list = current; dragKey = key; held = true; dragY = 0f; pending = null }
  fun drag(dy: Float) { if (!held) return; dragY += dy; swapIfNeeded() }
  fun end() {
    if (!held) return
    held = false; onDrop(list)
    settle = scope.launch { Animatable(dragY).animateTo(0f, spring(stiffness = Spring.StiffnessMedium)) { dragY = value }; dragKey = null; dragY = 0f }
  }

  private fun swapIfNeeded() {
    val k = dragKey ?: return
    val infos = lazy.layoutInfo.visibleItemsInfo
    val me = infos.firstOrNull { it.key == k } ?: return
    val pd = pending   // ждём, пока раскладка применит прошлый обмен
    if (pd != null) { if (me.offset == pd) return; pending = null }
    val from = list.indexOfFirst { keyOf(it) == k }; if (from < 0) return
    val centre = me.offset + me.size / 2f + dragY
    for (to in intArrayOf(from - 1, from + 1)) {
      if (to !in list.indices) continue
      val tk = keyOf(list[to]); val t = infos.firstOrNull { it.key == tk } ?: continue
      val tc = t.offset + t.size / 2f
      if ((to > from && centre > tc) || (to < from && centre < tc)) {
        val l = list.toMutableList(); l.add(to, l.removeAt(from)); list = l
        dragY += if (to > from) -t.size.toFloat() else t.size.toFloat()
        pending = me.offset
        return
      }
    }
  }

  /** Автопрокрутка у краёв списка. */
  fun autoScroll() {
    val k = dragKey ?: return; if (!held) return
    val li = lazy.layoutInfo; val me = li.visibleItemsInfo.firstOrNull { it.key == k } ?: return
    val vs = li.viewportStartOffset; val ve = li.viewportEndOffset
    val top = me.offset + dragY; val bottom = top + me.size; val edge = (ve - vs) * .14f
    val d = when {
      top < vs + edge -> -((vs + edge - top) / edge).coerceIn(0f, 1f) * 22f
      bottom > ve - edge -> ((bottom - (ve - edge)) / edge).coerceIn(0f, 1f) * 22f
      else -> 0f }
    if (d != 0f) { dragY += lazy.dispatchRawDelta(d); swapIfNeeded() }
  }

  /** Ручка (grip) — вешается на иконку перетаскивания. */
  fun handle(key: Any): Modifier = Modifier.pointerInput(key) {
    detectDragGestures(onDragStart = { start(key) }, onDragEnd = { end() }, onDragCancel = { end() }) { change, amt -> change.consume(); drag(amt.y) }
  }

  /** Корневой модификатор элемента: слой над соседями и смещение пальца. */
  fun root(key: Any): Modifier = Modifier.zIndex(if (dragKey == key) 1f else 0f).graphicsLayer { translationY = if (dragKey == key) dragY else 0f }
}

@Composable fun <T : Any> rememberReorder(lazy: LazyListState, keyOf: (T) -> Any, onDrop: (List<T>) -> Unit): DragReorder<T> {
  val scope = rememberCoroutineScope()
  val r = remember(lazy) { DragReorder(lazy, scope, keyOf) }
  r.onDrop = onDrop
  LaunchedEffect(r.held) { while (r.held) { r.autoScroll(); withFrameNanos { } } }
  return r
}

/** Поднятие карточки при перетаскивании: чуть крупнее + тень (без анимации — нулевая цена для остальных строк). */
fun Modifier.liftFx(on: Boolean, radius: Dp = 22.dp): Modifier =
  if (!on) this else this.graphicsLayer { scaleX = 1.03f; scaleY = 1.03f; shadowElevation = 18.dp.toPx(); shape = RoundedCornerShape(radius); clip = false }
