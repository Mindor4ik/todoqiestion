package app.todo
import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity data class TaskList(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)
@Entity data class Task(
  @PrimaryKey(autoGenerate = true) val id: Long = 0, val listId: Long? = null, val title: String,
  val note: String = "", val done: Boolean = false, val important: Boolean = false,
  val myDay: String? = null, val due: Long? = null, val repeat: String = "NONE",
  val questId: Long? = null, val day: String? = null, @ColumnInfo(defaultValue = "0") val pos: Int = 0,
  @ColumnInfo(defaultValue = "0") val goal: Int = 0, @ColumnInfo(defaultValue = "0") val progress: Int = 0, @ColumnInfo(defaultValue = "1") val step: Int = 1)
@Entity data class Step(@PrimaryKey(autoGenerate = true) val id: Long = 0, val taskId: Long, val text: String, val done: Boolean = false)
@Entity data class Quest(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val threshold: Int = 80, @ColumnInfo(defaultValue = "127") val days: Int = 127,
  @ColumnInfo(defaultValue = "0") val pos: Int = 0)
@Entity data class QuestItem(@PrimaryKey(autoGenerate = true) val id: Long = 0, val questId: Long, val title: String, @ColumnInfo(defaultValue = "0") val pos: Int = 0,
  @ColumnInfo(defaultValue = "0") val goal: Int = 0, @ColumnInfo(defaultValue = "1") val step: Int = 1)
data class QKey(val questId: Long, val title: String)
data class DayStat(val day: String, val total: Int, val done: Int)

@Dao interface TodoDao {
  @Query("SELECT * FROM TaskList") fun lists(): Flow<List<TaskList>>
  @Insert suspend fun add(l: TaskList): Long
  @Query("DELETE FROM TaskList WHERE id=:id") suspend fun delList(id: Long)
  @Query("DELETE FROM Task WHERE listId=:id") suspend fun delListTasks(id: Long)
  @Query("SELECT * FROM Task ORDER BY done, pos, id DESC") fun tasks(): Flow<List<Task>>
  @Query("SELECT * FROM Task ORDER BY done, pos, id DESC") suspend fun tasksNow(): List<Task>
  @Upsert suspend fun save(t: Task): Long
  @Delete suspend fun del(t: Task)
  @Query("SELECT * FROM Step WHERE taskId=:id") fun steps(id: Long): Flow<List<Step>>
  @Upsert suspend fun save(s: Step)
  @Delete suspend fun del(s: Step)
  @Query("SELECT * FROM Quest ORDER BY pos, id") fun quests(): Flow<List<Quest>>
  @Query("SELECT * FROM Quest ORDER BY pos, id") suspend fun questsNow(): List<Quest>
  @Upsert suspend fun save(q: Quest): Long
  @Query("DELETE FROM Quest WHERE id=:id") suspend fun delQuest(id: Long)
  @Query("DELETE FROM QuestItem WHERE questId=:id") suspend fun delItems(id: Long)
  @Query("SELECT * FROM QuestItem ORDER BY pos, id") fun items(): Flow<List<QuestItem>>
  @Query("SELECT * FROM QuestItem WHERE questId=:id ORDER BY pos, id") suspend fun itemsOf(id: Long): List<QuestItem>
  @Upsert suspend fun save(i: QuestItem)
  @Query("UPDATE Task SET title=:n WHERE questId=:q AND day=:d AND title=:o") suspend fun renameToday(q: Long, d: String, o: String, n: String)
  @Delete suspend fun del(i: QuestItem)
  @Query("SELECT questId, title FROM Task WHERE day=:d AND questId IS NOT NULL") suspend fun todayKeys(d: String): List<QKey>
  @Query("UPDATE Task SET goal=:g, step=:s, progress=CASE WHEN :g=0 THEN 0 WHEN done=1 THEN :g WHEN progress>:g THEN :g ELSE progress END WHERE questId=:q AND day=:d AND title=:t")
  suspend fun setGoalToday(q: Long, d: String, t: String, g: Int, s: Int)
  @Query("SELECT * FROM TaskList") suspend fun listsNow(): List<TaskList>
  @Query("SELECT * FROM Step") suspend fun stepsAll(): List<Step>
  @Query("SELECT * FROM QuestItem ORDER BY pos, id") suspend fun itemsAll(): List<QuestItem>
  @Upsert suspend fun saveLists(l: List<TaskList>)
  @Upsert suspend fun saveSteps(l: List<Step>)
  @Query("DELETE FROM TaskList") suspend fun clearLists()
  @Query("DELETE FROM Task") suspend fun clearTasks()
  @Query("DELETE FROM Step") suspend fun clearSteps()
  @Query("DELETE FROM Quest") suspend fun clearQuests()
  @Query("DELETE FROM QuestItem") suspend fun clearItems()
  @Upsert suspend fun saveTasks(t: List<Task>)
  @Upsert suspend fun saveItems(i: List<QuestItem>)
  @Upsert suspend fun saveQuests(q: List<Quest>)
  @Query("UPDATE Task SET pos=:p WHERE questId=:q AND day=:d AND title=:t") suspend fun setPos(q: Long, d: String, t: String, p: Int)
  @Query("DELETE FROM Task WHERE questId=:q AND day=:d AND title=:t AND done=0") suspend fun delTodayOpen(q: Long, d: String, t: String)
  @Query("DELETE FROM Task WHERE questId=:q AND day=:d AND done=0") suspend fun delTodayAllOpen(q: Long, d: String)
  @Query("SELECT COUNT(*) FROM Task WHERE questId=:q AND day=:d AND title=:t") suspend fun has(q: Long, d: String, t: String): Int
  @Query("SELECT day, COUNT(*) AS total, SUM(done) AS done FROM Task WHERE questId IS NOT NULL AND day IS NOT NULL GROUP BY day ORDER BY day")
  fun stats(): Flow<List<DayStat>>
}

@Database(entities = [TaskList::class, Task::class, Step::class, Quest::class, QuestItem::class], version = 4, exportSchema = false)
abstract class DB : RoomDatabase() {
  abstract fun dao(): TodoDao
  companion object {
    @Volatile private var i: DB? = null
    fun get(c: Context): DB = i ?: synchronized(this) {
      i ?: Room.databaseBuilder(c.applicationContext, DB::class.java, "todo.db").addMigrations(M12, M23, M34).build().also { i = it } }
  }
}

val M12 = object : Migration(1, 2) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE Task ADD COLUMN pos INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE QuestItem ADD COLUMN pos INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE Quest ADD COLUMN days INTEGER NOT NULL DEFAULT 127")
  }
}

val M23 = object : Migration(2, 3) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE Quest ADD COLUMN pos INTEGER NOT NULL DEFAULT 0")
  }
}

val M34 = object : Migration(3, 4) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE Task ADD COLUMN goal INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE Task ADD COLUMN progress INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE Task ADD COLUMN step INTEGER NOT NULL DEFAULT 1")
    db.execSQL("ALTER TABLE QuestItem ADD COLUMN goal INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE QuestItem ADD COLUMN step INTEGER NOT NULL DEFAULT 1")
  }
}
