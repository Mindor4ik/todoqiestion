package app.todo
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class TaskList(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)
@Entity data class Task(
  @PrimaryKey(autoGenerate = true) val id: Long = 0, val listId: Long? = null, val title: String,
  val note: String = "", val done: Boolean = false, val important: Boolean = false,
  val myDay: String? = null, val due: Long? = null, val repeat: String = "NONE",
  val questId: Long? = null, val day: String? = null)
@Entity data class Step(@PrimaryKey(autoGenerate = true) val id: Long = 0, val taskId: Long, val text: String, val done: Boolean = false)
@Entity data class Quest(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val threshold: Int = 80)
@Entity data class QuestItem(@PrimaryKey(autoGenerate = true) val id: Long = 0, val questId: Long, val title: String)
data class DayStat(val day: String, val total: Int, val done: Int)

@Dao interface TodoDao {
  @Query("SELECT * FROM TaskList") fun lists(): Flow<List<TaskList>>
  @Insert suspend fun add(l: TaskList): Long
  @Query("DELETE FROM TaskList WHERE id=:id") suspend fun delList(id: Long)
  @Query("DELETE FROM Task WHERE listId=:id") suspend fun delListTasks(id: Long)
  @Query("SELECT * FROM Task ORDER BY done, id DESC") fun tasks(): Flow<List<Task>>
  @Query("SELECT * FROM Task ORDER BY done, id DESC") suspend fun tasksNow(): List<Task>
  @Upsert suspend fun save(t: Task): Long
  @Delete suspend fun del(t: Task)
  @Query("SELECT * FROM Step WHERE taskId=:id") fun steps(id: Long): Flow<List<Step>>
  @Upsert suspend fun save(s: Step)
  @Delete suspend fun del(s: Step)
  @Query("SELECT * FROM Quest") fun quests(): Flow<List<Quest>>
  @Query("SELECT * FROM Quest") suspend fun questsNow(): List<Quest>
  @Upsert suspend fun save(q: Quest): Long
  @Query("DELETE FROM Quest WHERE id=:id") suspend fun delQuest(id: Long)
  @Query("DELETE FROM QuestItem WHERE questId=:id") suspend fun delItems(id: Long)
  @Query("SELECT * FROM QuestItem") fun items(): Flow<List<QuestItem>>
  @Query("SELECT * FROM QuestItem WHERE questId=:id") suspend fun itemsOf(id: Long): List<QuestItem>
  @Upsert suspend fun save(i: QuestItem)
  @Delete suspend fun del(i: QuestItem)
  @Query("SELECT COUNT(*) FROM Task WHERE questId=:q AND day=:d AND title=:t") suspend fun has(q: Long, d: String, t: String): Int
  @Query("SELECT day, COUNT(*) AS total, SUM(done) AS done FROM Task WHERE questId IS NOT NULL AND day IS NOT NULL GROUP BY day ORDER BY day")
  fun stats(): Flow<List<DayStat>>
}

@Database(entities = [TaskList::class, Task::class, Step::class, Quest::class, QuestItem::class], version = 1, exportSchema = false)
abstract class DB : RoomDatabase() {
  abstract fun dao(): TodoDao
  companion object {
    @Volatile private var i: DB? = null
    fun get(c: Context): DB = i ?: synchronized(this) {
      i ?: Room.databaseBuilder(c.applicationContext, DB::class.java, "todo.db").build().also { i = it } }
  }
}
