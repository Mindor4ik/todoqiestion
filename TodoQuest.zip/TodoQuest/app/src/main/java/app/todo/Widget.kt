package app.todo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.*
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.*
import androidx.glance.appwidget.lazy.*
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

val KEY = ActionParameters.Key<Long>("id")

private val WHITE = ColorProvider(Color.White)
private val SOFT = ColorProvider(Color(0xCCFFFFFF))
private val WARN = ColorProvider(Color(0xFFFFCDD2))

/** Кольцо прогресса рисуем сами — у Glance нет Canvas. Готовое — золотое. */
private fun ringBitmap(progress: Float, px: Int = 220): Bitmap {
  val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888); val cv = android.graphics.Canvas(b)
  val sw = px * .12f; val r = RectF(sw / 2, sw / 2, px - sw / 2, px - sw / 2)
  val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw; strokeCap = Paint.Cap.ROUND }
  p.color = 0x40FFFFFF; cv.drawArc(r, 0f, 360f, false, p)
  if (progress > 0.005f) { p.color = if (progress >= 1f) 0xFFFFE082.toInt() else 0xFFFFFFFF.toInt(); cv.drawArc(r, -90f, 360f * progress.coerceAtMost(1f), false, p) }
  return b
}

private fun dueShort(ms: Long): String {
  val d = Date(ms); val same = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).let { it.format(d) == it.format(Date()) }
  return SimpleDateFormat(if (same) "HH:mm" else "d MMM", Locale.getDefault()).format(d)
}

class TodoWidget : GlanceAppWidget() {
  override val sizeMode = SizeMode.Responsive(setOf(DpSize(110.dp, 110.dp), DpSize(250.dp, 110.dp), DpSize(250.dp, 170.dp)))
  override suspend fun provideGlance(context: Context, id: GlanceId) {
    Prefs.load(context)
    val all = DB.get(context).dao().tasksNow().filter { it.myDay == today || it.day == today }
    val bg = listOf(R.drawable.w_bg0, R.drawable.w_bg1, R.drawable.w_bg2, R.drawable.w_bg3, R.drawable.w_bg4, R.drawable.w_bg5)[Prefs.accents.indexOf(Prefs.accent).coerceAtLeast(0)]
    val dn = all.count { it.done }; val p = if (all.isEmpty()) 0 else dn * 100 / all.size
    val ring = ringBitmap(p / 100f)
    val date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())).replaceFirstChar { it.uppercase() }
    provideContent {
      val sz = LocalSize.current
      val base = GlanceModifier.fillMaxSize().background(ImageProvider(bg)).padding(14.dp)
      when {
        sz.width < 200.dp -> SmallW(base, ring, p, dn, all.size)
        sz.height < 170.dp -> MediumW(base, ring, p, dn, all)
        else -> LargeW(base, ring, p, dn, all, date)
      }
    }
  }
}

@Composable private fun Pct(ring: Bitmap, p: Int, dia: androidx.compose.ui.unit.Dp, fs: Int) {
  Box(GlanceModifier.size(dia), contentAlignment = Alignment.Center) {
    Image(ImageProvider(ring), null, GlanceModifier.fillMaxSize(), contentScale = ContentScale.Fit)
    Text("$p%", style = TextStyle(fontSize = fs.sp, fontWeight = FontWeight.Bold, color = WHITE))
  }
}

@Composable private fun SmallW(base: GlanceModifier, ring: Bitmap, p: Int, dn: Int, total: Int) {
  Column(base.clickable(actionStartActivity<MainActivity>()), verticalAlignment = Alignment.CenterVertically, horizontalAlignment = Alignment.CenterHorizontally) {
    Pct(ring, p, 64.dp, 16)
    Spacer(GlanceModifier.height(6.dp))
    Text("$dn из $total", style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium, color = WHITE))
    Text("Мой день", style = TextStyle(fontSize = 11.sp, color = SOFT))
  }
}

@Composable private fun MediumW(base: GlanceModifier, ring: Bitmap, p: Int, dn: Int, all: List<Task>) {
  val next = all.firstOrNull { !it.done }
  Row(base.clickable(actionStartActivity<MainActivity>()), verticalAlignment = Alignment.CenterVertically) {
    Pct(ring, p, 66.dp, 16)
    Spacer(GlanceModifier.width(14.dp))
    Column(GlanceModifier.defaultWeight()) {
      Text("Мой день", style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, color = WHITE))
      Text("$dn из ${all.size} выполнено", style = TextStyle(fontSize = 12.sp, color = SOFT))
      Spacer(GlanceModifier.height(8.dp))
      Box(GlanceModifier.fillMaxWidth().background(ImageProvider(R.drawable.w_card)).padding(horizontal = 10.dp, vertical = 7.dp)) {
        Text(when { all.isEmpty() -> "На сегодня задач нет"; next == null -> "Всё сделано 🎉"; else -> "Далее: ${next.title}" },
          style = TextStyle(fontSize = 13.sp, color = WHITE), maxLines = 1) }
    }
  }
}

@Composable private fun LargeW(base: GlanceModifier, ring: Bitmap, p: Int, dn: Int, all: List<Task>, date: String) {
  val open = actionStartActivity<MainActivity>()
  Column(base) {
    Row(GlanceModifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
      Pct(ring, p, 52.dp, 13)
      Spacer(GlanceModifier.width(12.dp))
      Column(GlanceModifier.defaultWeight().clickable(open)) {
        Text("Мой день", style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Bold, color = WHITE))
        Text("$date · $dn/${all.size}", style = TextStyle(fontSize = 12.sp, color = SOFT), maxLines = 1)
      }
      Box(GlanceModifier.size(36.dp).background(ImageProvider(R.drawable.w_btn)).clickable(open), contentAlignment = Alignment.Center) {
        Text("+", style = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, color = WHITE)) }
    }
    if (all.isEmpty()) Box(GlanceModifier.fillMaxSize().clickable(open), contentAlignment = Alignment.Center) {
      Text("На сегодня задач нет", style = TextStyle(fontSize = 14.sp, color = SOFT)) }
    else LazyColumn { items(all, itemId = { it.id }) { t -> WRow(t) } }
  }
}

@Composable private fun WRow(t: Task) {
  val over = t.due != null && !t.done && t.due < System.currentTimeMillis()
  Box(GlanceModifier.fillMaxWidth().padding(bottom = 5.dp)) {
    Row(GlanceModifier.fillMaxWidth().background(ImageProvider(if (t.done) R.drawable.w_card_done else R.drawable.w_card)).padding(start = 6.dp, end = 12.dp, top = 5.dp, bottom = 5.dp)
      .clickable(actionStartActivity<MainActivity>()), verticalAlignment = Alignment.CenterVertically) {
      Box(GlanceModifier.size(32.dp).clickable(actionRunCallback<Toggle>(actionParametersOf(KEY to t.id))), contentAlignment = Alignment.Center) {
        Image(ImageProvider(if (t.done) R.drawable.w_chk_on else R.drawable.w_chk_off), if (t.done) "Выполнено" else "Не выполнено", GlanceModifier.size(24.dp)) }
      Spacer(GlanceModifier.width(6.dp))
      Text((if (t.questId != null) "⚔ " else "") + t.title, GlanceModifier.defaultWeight(),
        style = TextStyle(fontSize = 14.sp, color = if (t.done) SOFT else WHITE, textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None), maxLines = 1)
      if (t.due != null && !t.done) { Spacer(GlanceModifier.width(8.dp))
        Text(dueShort(t.due), style = TextStyle(fontSize = 11.sp, fontWeight = if (over) FontWeight.Bold else FontWeight.Normal, color = if (over) WARN else SOFT)) }
    }
  }
}

class Toggle : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    val t = DB.get(context).dao().tasksNow().firstOrNull { it.id == parameters[KEY] } ?: return
    toggle(context, t)
  }
}
class WidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = TodoWidget() }
