package app.todo
import android.content.Context
import androidx.compose.ui.unit.dp
import androidx.glance.*
import androidx.glance.action.*
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.*
import androidx.glance.appwidget.lazy.*
import androidx.glance.layout.*
import androidx.glance.text.*

val KEY = ActionParameters.Key<Long>("id")
class TodoWidget : GlanceAppWidget() {
  override suspend fun provideGlance(context: Context, id: GlanceId) {
    val all = DB.get(context).dao().tasksNow().filter { it.myDay == today || it.day == today }
    provideContent {
      GlanceTheme {
        Column(GlanceModifier.fillMaxSize().background(GlanceTheme.colors.background).padding(8.dp)) {
          val p = if (all.isEmpty()) 0 else all.count { it.done } * 100 / all.size
          Text("Мой день · $p%", style = TextStyle(fontWeight = FontWeight.Bold, color = GlanceTheme.colors.onBackground))
          LazyColumn {
            items(all.take(30)) { t ->
              Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                CheckBox(checked = t.done, onCheckedChange = actionRunCallback<Toggle>(actionParametersOf(KEY to t.id)))
                Text(t.title, style = TextStyle(color = GlanceTheme.colors.onBackground))
              }
            }
          }
        }
      }
    }
  }
}
class Toggle : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    val t = DB.get(context).dao().tasksNow().firstOrNull { it.id == parameters[KEY] } ?: return
    toggle(context, t)
  }
}
class WidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = TodoWidget() }
