package app.todo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import kotlin.math.roundToInt
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import androidx.compose.runtime.setValue
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.*
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.*
import androidx.glance.appwidget.lazy.*
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

val KEY = ActionParameters.Key<Long>("id")

private val WHITE get() = ColorProvider(if (Prefs.wDark) Color(0xFF111111) else Color.White)
private val SOFT get() = ColorProvider(if (Prefs.wDark) Color(0xB3000000) else Color(0xCCFFFFFF))
private val WARN get() = ColorProvider(if (Prefs.wDark) Color(0xFFB71C1C) else Color(0xFFFFCDD2))
private fun dk(a: Int, b: Int) = if (Prefs.wDark) b else a   // светлый/тёмный вариант оформления
private val TINT: ColorFilter? get() = if (Prefs.wDark) ColorFilter.tint(ColorProvider(Color(0xFF111111))) else null

/** Кольцо прогресса рисуем сами — у Glance нет Canvas. Готовое — золотое. */
private fun ringBitmap(progress: Float, px: Int = 220, dark: Boolean = false): Bitmap {
  val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888); val cv = android.graphics.Canvas(b)
  val sw = px * .12f; val r = RectF(sw / 2, sw / 2, px - sw / 2, px - sw / 2)
  val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw; strokeCap = Paint.Cap.ROUND }
  p.color = if (dark) 0x40000000 else 0x40FFFFFF; cv.drawArc(r, 0f, 360f, false, p)
  if (progress > 0.005f) { p.color = if (progress >= 1f) (if (dark) 0xFF8A5A00.toInt() else 0xFFFFE082.toInt()) else (if (dark) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()); cv.drawArc(r, -90f, 360f * progress.coerceAtMost(1f), false, p) }
  return b
}

private fun dueShort(ms: Long): String {
  val d = Date(ms); val same = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).let { it.format(d) == it.format(Date()) }
  return SimpleDateFormat(if (same) "HH:mm" else "d MMM", Locale.getDefault()).format(d)
}

class TodoWidget : GlanceAppWidget() {
  override val sizeMode = SizeMode.Responsive(setOf(DpSize(110.dp, 110.dp), DpSize(250.dp, 110.dp), DpSize(250.dp, 170.dp)))
  override suspend fun provideGlance(context: Context, id: GlanceId) {
    Prefs.load(context)
    val dao = DB.get(context).dao()
    val first = dao.tasksNow().let { l -> val t = today; l.filter { it.myDay == t || it.day == t } }
    val bgs = listOf(R.drawable.w_bg0, R.drawable.w_bg1, R.drawable.w_bg2, R.drawable.w_bg3, R.drawable.w_bg4, R.drawable.w_bg5)
    provideContent {
      // Сессия Glance живёт после обновления и НЕ вызывает provideGlance заново, поэтому данные берём подпиской на БД:
      // любое изменение (в том числе нажатие на чекбокс) сразу перерисовывает виджет.
      val all by remember { dao.tasks().map { l -> val t = today; l.filter { it.myDay == t || it.day == t } } }.collectAsState(first)
      val dn = all.count { it.done }; val p = if (all.isEmpty()) 0 else dn * 100 / all.size
      val rp = if (WFx.id != -1L) WFx.from + (WFx.to - WFx.from) * easeOut(WFx.t) else p / 100f   // кольцо плавно «доезжает» до нового значения
      val shown = (rp * 100).roundToInt()
      val ring = remember(shown, Prefs.wDark) { ringBitmap(rp, dark = Prefs.wDark) }
      val date = remember { LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault())).replaceFirstChar { it.uppercase() } }
      val sz = LocalSize.current
      val bgBmp = remember(sz, Prefs.wBg, Prefs.wColor, Prefs.wAlpha, Prefs.accent, Prefs.wImg, Prefs.wDark) { wBgBitmap(context, sz.width.value, sz.height.value) }
      val base = GlanceModifier.fillMaxSize().background(ImageProvider(bgBmp), ContentScale.Crop).cornerRadius(28.dp).padding(14.dp)
      when {
        sz.width < 200.dp -> SmallW(base, ring, shown, dn, all.size)
        sz.height < 170.dp -> MediumW(base, ring, shown, dn, all)
        else -> LargeW(base, ring, shown, dn, all, date)
      }
    }
  }
}

@Composable private fun Pct(ring: Bitmap, p: Int, dia: androidx.compose.ui.unit.Dp, fs: Int) {
  Box(GlanceModifier.size(dia), contentAlignment = Alignment.Center) {
    Image(ImageProvider(ring), null, GlanceModifier.fillMaxSize(), contentScale = ContentScale.Fit)
    Text("$p%", style = TextStyle(fontSize = fs.sp, fontWeight = FontWeight.Bold, color = WHITE))
  }
}

@Composable private fun SmallW(base: GlanceModifier, ring: Bitmap, p: Int, dn: Int, total: Int) {
  Box(base) {
    Column(GlanceModifier.fillMaxSize().clickable(actionStartActivity<MainActivity>()), verticalAlignment = Alignment.CenterVertically, horizontalAlignment = Alignment.CenterHorizontally) {
      Pct(ring, p, 64.dp, 16)
      Spacer(GlanceModifier.height(6.dp))
      Text("$dn из $total", style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium, color = WHITE))
      Text("Мой день", style = TextStyle(fontSize = 11.sp, color = SOFT))
    }
    Box(GlanceModifier.fillMaxSize(), contentAlignment = Alignment.TopEnd) { RefreshBtn(26.dp) }
  }
}

/** Кнопка «Обновить»: досоздаёт задачи квестов на сегодня и перерисовывает виджет. */
@Composable private fun RefreshBtn(dia: androidx.compose.ui.unit.Dp = 34.dp) {
  val spin = WFx.spin
  val icon = when (spin % 4) { 1 -> R.drawable.w_refresh_r1; 2 -> R.drawable.w_refresh_r2; 3 -> R.drawable.w_refresh_r3; else -> R.drawable.w_refresh }
  Box(GlanceModifier.size(dia).background(ImageProvider(if (spin > 0) dk(R.drawable.w_btn_hot, R.drawable.w_btn_hot_k) else dk(R.drawable.w_btn, R.drawable.w_btn_k))).clickable(actionRunCallback<RefreshAction>()), contentAlignment = Alignment.Center) {
    Image(ImageProvider(icon), "Обновить", GlanceModifier.size(dia * 0.58f), colorFilter = TINT) }
}

@Composable private fun MediumW(base: GlanceModifier, ring: Bitmap, p: Int, dn: Int, all: List<Task>) {
  val next = all.firstOrNull { !it.done }
  Row(base, verticalAlignment = Alignment.CenterVertically) {
    Pct(ring, p, 66.dp, 16)
    Spacer(GlanceModifier.width(14.dp))
    Column(GlanceModifier.defaultWeight().clickable(actionStartActivity<MainActivity>())) {
      Text("Мой день", style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, color = WHITE))
      Text("$dn из ${all.size} выполнено", style = TextStyle(fontSize = 12.sp, color = SOFT))
      Spacer(GlanceModifier.height(8.dp))
      Box(GlanceModifier.fillMaxWidth().background(ImageProvider(dk(R.drawable.w_card, R.drawable.w_card_k))).padding(horizontal = 10.dp, vertical = 7.dp)) {
        Text(when { all.isEmpty() -> "На сегодня задач нет"; next == null -> "Всё сделано 🎉"; else -> "Далее: ${next.title}" },
          style = TextStyle(fontSize = 13.sp, color = WHITE), maxLines = 1) }
    }
    Spacer(GlanceModifier.width(8.dp))
    RefreshBtn()
  }
}

@Composable private fun LargeW(base: GlanceModifier, ring: Bitmap, p: Int, dn: Int, all: List<Task>, date: String) {
  val open = actionStartActivity<MainActivity>()
  Column(base) {
    Row(GlanceModifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
      Pct(ring, p, 52.dp, 13)
      Spacer(GlanceModifier.width(12.dp))
      Column(GlanceModifier.defaultWeight().clickable(open)) {
        Text("Мой день", style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Bold, color = WHITE))
        Text("$dn/${all.size} · $date", style = TextStyle(fontSize = 12.sp, color = SOFT), maxLines = 1)
      }
      RefreshBtn(34.dp); Spacer(GlanceModifier.width(6.dp))
      Box(GlanceModifier.size(34.dp).background(ImageProvider(dk(R.drawable.w_btn, R.drawable.w_btn_k))).clickable(open), contentAlignment = Alignment.Center) {
        Image(ImageProvider(R.drawable.w_plus), "Открыть", GlanceModifier.size(20.dp), colorFilter = TINT) }
    }
    if (all.isEmpty()) Box(GlanceModifier.fillMaxSize().clickable(open), contentAlignment = Alignment.Center) {
      Text("На сегодня задач нет", style = TextStyle(fontSize = 14.sp, color = SOFT)) }
    else LazyColumn { items(all, itemId = { it.id * 4_194_304L + (if (it.done) 2_097_152L else 0L) + (if (WFx.id == it.id) ((WFx.t * 12).toInt() + 1) * 131_072L else 0L) + it.progress.coerceIn(0, 131_071) }) { t -> WRow(t) } }
  }
}

@Composable private fun WRow(t: Task) {
  val over = t.due != null && !t.done && t.due < System.currentTimeMillis()
  val anim = WFx.id == t.id && WFx.pop
  val chk = if (anim) (24f * (0.5f + 0.5f * easeOutBack(WFx.t))).dp else 24.dp   // галочка «выпрыгивает» с лёгким перелётом
  val hot = WFx.hotId == t.id && WFx.hot > 0
  val counter = t.goal > 0 && !t.done
  Box(GlanceModifier.fillMaxWidth().padding(bottom = 5.dp)) {
    Row(GlanceModifier.fillMaxWidth().background(ImageProvider(if (anim && WFx.t < .7f) dk(R.drawable.w_card_flash, R.drawable.w_card_flash_k) else if (t.done) dk(R.drawable.w_card_done, R.drawable.w_card_done_k) else dk(R.drawable.w_card, R.drawable.w_card_k))).padding(start = 6.dp, end = 12.dp, top = 5.dp, bottom = 5.dp)
      .clickable(actionStartActivity<MainActivity>()), verticalAlignment = Alignment.CenterVertically) {
      Box(GlanceModifier.size(32.dp).clickable(actionRunCallback<Toggle>(actionParametersOf(KEY to t.id))), contentAlignment = Alignment.Center) {
        Image(ImageProvider(if (t.done) R.drawable.w_chk_on else R.drawable.w_chk_off), if (t.done) "Выполнено" else "Не выполнено", GlanceModifier.size(chk), colorFilter = TINT) }
      Spacer(GlanceModifier.width(6.dp))
      Column(GlanceModifier.defaultWeight()) {
        Text((if (t.questId != null) "⚔ " else "") + t.title,
          style = TextStyle(fontSize = 14.sp, color = if (t.done) SOFT else WHITE, textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None), maxLines = 1)
        if (counter) LinearProgressIndicator(progress = t.progress.toFloat() / t.goal, modifier = GlanceModifier.fillMaxWidth().padding(top = 3.dp),
          color = WHITE, backgroundColor = ColorProvider(Color(if (Prefs.wDark) 0x33000000 else 0x33FFFFFF)))
      }
      if (counter) {
        Spacer(GlanceModifier.width(8.dp))
        Text("${t.progress}/${t.goal}", style = TextStyle(fontSize = 11.sp, color = SOFT))
        Spacer(GlanceModifier.width(6.dp))
        Box(GlanceModifier.height(28.dp).background(ImageProvider(if (hot) dk(R.drawable.w_pill_hot, R.drawable.w_pill_hot_k) else dk(R.drawable.w_pill, R.drawable.w_pill_k))).padding(horizontal = 10.dp)
          .clickable(actionRunCallback<StepAction>(actionParametersOf(KEY to t.id))), contentAlignment = Alignment.Center) {
          Text("+${t.step}", style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WHITE)) }
      } else if (t.due != null && !t.done) { Spacer(GlanceModifier.width(8.dp))
        Text(dueShort(t.due), style = TextStyle(fontSize = 11.sp, fontWeight = if (over) FontWeight.Bold else FontWeight.Normal, color = if (over) WARN else SOFT)) }
    }
  }
}

/** Состояние кадров анимаций виджета. RemoteViews не умеют анимироваться сами, поэтому короткими сериями перерисовок показываем кадры. */
object WFx {
  var spin by mutableIntStateOf(0)                       // кадр вращения кнопки обновления
  var id by mutableLongStateOf(-1L); var pop by mutableStateOf(false)   // анимируемая задача и «отскок» галочки
  var t by mutableFloatStateOf(1f); var from by mutableFloatStateOf(0f); var to by mutableFloatStateOf(0f)   // время 0..1 и диапазон кольца
  var hotId by mutableLongStateOf(-1L); var hot by mutableIntStateOf(0)   // подсветка кнопки +шаг
}
private suspend fun frames(c: Context, n: Int, gap: Long, set: (Int) -> Unit) {
  try { for (i in 1..n) { set(i); TodoWidget().updateAll(c); delay(gap) } } finally { set(0) }
  TodoWidget().updateAll(c)
}

class Toggle : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    val d = DB.get(context).dao(); val t = d.tasksNow().firstOrNull { it.id == parameters[KEY] } ?: return
    val before = dayPct(d.tasksNow())
    toggle(context, t)   // запись в БД и обновление — статус на виджете верный сразу, анимация лишь «украшение»
    animate(context, t.id, !t.done, before, dayPct(d.tasksNow()))
  }
}
private fun dayPct(l: List<Task>): Float { val dd = today; val a = l.filter { it.myDay == dd || it.day == dd }; return if (a.isEmpty()) 0f else a.count { it.done } / a.size.toFloat() }
private fun easeOut(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
private fun easeOutBack(x: Float): Float { val c1 = 1.70158f; val y = x - 1f; return 1f + (c1 + 1f) * y * y * y + c1 * y * y }
private val animLock = Mutex()
/** Анимация по реальному времени (а не по числу кадров): сколько кадров успеет отрисовать телефон, столько и будет. */
private suspend fun animate(c: Context, id: Long, pop: Boolean, from: Float, to: Float, ms: Long = 420) {
  if (!animLock.tryLock()) { delay(150); TodoWidget().updateAll(c); return }   // идёт другая анимация — просто досинхронизируем
  try {
    WFx.id = id; WFx.pop = pop; WFx.from = from; WFx.to = to
    val t0 = System.nanoTime()
    while (true) { val e = ((System.nanoTime() - t0) / 1_000_000f / ms).coerceAtMost(1f); WFx.t = e; TodoWidget().updateAll(c); if (e >= 1f) break; delay(20) }
  } finally {
    withContext(NonCancellable) { WFx.id = -1L; WFx.t = 1f; TodoWidget().updateAll(c); delay(250); TodoWidget().updateAll(c); animLock.unlock() }   // финальная отрисовка с запасом
  }
}
class StepAction : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    val t = DB.get(context).dao().tasksNow().firstOrNull { it.id == parameters[KEY] } ?: return
    WFx.hotId = t.id; WFx.hot = 1; TodoWidget().updateAll(context)   // мгновенная реакция кнопки
    addProgress(context, t, t.step)
    delay(120); WFx.hot = 0; WFx.hotId = -1L; TodoWidget().updateAll(context)
  }
}
class RefreshAction : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    coroutineScope {
      val job = launch { ensureToday(context) }   // досоздаёт задачи квестов на сегодня и обновляет данные
      frames(context, 8, 70) { WFx.spin = it }    // два оборота иконки
      job.join()
    }
  }
}
class WidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = TodoWidget() }
