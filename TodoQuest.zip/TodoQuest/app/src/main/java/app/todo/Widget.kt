package app.todo
import android.content.Context
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.*
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.*
import androidx.glance.appwidget.lazy.*
import androidx.glance.layout.*
import androidx.glance.text.*

val KEY = ActionParameters.Key<Long>("id")
class TodoWidget : GlanceAppWidget() {
  override val sizeMode = SizeMode.Responsive(setOf(DpSize(110.dp, 110.dp), DpSize(250.dp, 110.dp), DpSize(250.dp, 250.dp)))
  override suspend fun provideGlance(context: Context, id: GlanceId) {
    val all = DB.get(context).dao().tasksNow().filter { it.myDay == today || it.day == today }
    provideContent {
      GlanceTheme {
        val w = LocalSize.current.width
        val dn = all.count { it.done }; val p = if (all.isEmpty()) 0 else dn * 100 / all.size
        val open = actionStartActivity<MainActivity>()
        val base = GlanceModifier.fillMaxSize().background(GlanceTheme.colors.widgetBackground).cornerRadius(20.dp).padding(12.dp)
        if (w < 200.dp) {
          Column(base.clickable(open), verticalAlignment = Alignment.CenterVertically, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$p%", style = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold, color = GlanceTheme.colors.primary))
            Text("$dn / ${all.size}", style = TextStyle(color = GlanceTheme.colors.onSurface))
          }
        } else {
          Column(base) {
            Row(GlanceModifier.fillMaxWidth().clickable(open), verticalAlignment = Alignment.CenterVertically) {
              Text("Мой день", GlanceModifier.defaultWeight(), style = TextStyle(fontWeight = FontWeight.Bold, color = GlanceTheme.colors.onSurface))
              Text("$p%", style = TextStyle(fontWeight = FontWeight.Bold, color = GlanceTheme.colors.primary))
            }
            LinearProgressIndicator(progress = p / 100f, modifier = GlanceModifier.fillMaxWidth().padding(vertical = 6.dp))
            LazyColumn {
              items(all) { t ->
                Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                  CheckBox(checked = t.done, onCheckedChange = actionRunCallback<Toggle>(actionParametersOf(KEY to t.id)))
                  Text(t.title, style = TextStyle(color = GlanceTheme.colors.onSurface,
                    textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None))
                }
              }
            }
          }
        }
      }
    }
  }
}
class Toggle : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    val t = DB.get(context).dao().tasksNow().firstOrNull { it.id == parameters[KEY] } ?: return
    toggle(context, t)
  }
}
class WidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = TodoWidget() }
