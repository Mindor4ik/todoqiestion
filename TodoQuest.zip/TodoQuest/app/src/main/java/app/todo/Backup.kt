package app.todo
import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private fun JSONObject.lng(k: String): Long? = if (has(k) && !isNull(k)) getLong(k) else null
private fun JSONObject.str(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null
private fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

/** Вся база + настройки + картинка виджета → один JSON. */
suspend fun buildBackup(c: Context): String {
  val d = DB.get(c).dao(); val root = JSONObject().put("app", "TodoQuest").put("version", 1).put("saved", today)
  root.put("lists", JSONArray().also { a -> d.listsNow().forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) } })
  root.put("tasks", JSONArray().also { a -> d.tasksNow().forEach { t -> a.put(JSONObject().put("id", t.id).put("listId", t.listId).put("title", t.title)
    .put("note", t.note).put("done", t.done).put("important", t.important).put("myDay", t.myDay).put("due", t.due).put("repeat", t.repeat)
    .put("questId", t.questId).put("day", t.day).put("pos", t.pos).put("goal", t.goal).put("progress", t.progress).put("step", t.step)) } })
  root.put("steps", JSONArray().also { a -> d.stepsAll().forEach { a.put(JSONObject().put("id", it.id).put("taskId", it.taskId).put("text", it.text).put("done", it.done)) } })
  root.put("quests", JSONArray().also { a -> d.questsNow().forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("threshold", it.threshold).put("days", it.days).put("pos", it.pos)) } })
  root.put("items", JSONArray().also { a -> d.itemsAll().forEach { a.put(JSONObject().put("id", it.id).put("questId", it.questId).put("title", it.title).put("pos", it.pos).put("goal", it.goal).put("step", it.step)) } })
  root.put("prefs", JSONObject().put("mode", Prefs.mode).put("accent", Prefs.accent).put("showDone", Prefs.showDone).put("fx", Prefs.fx)
    .put("wBg", Prefs.wBg).put("wColor", Prefs.wColor).put("wAlpha", Prefs.wAlpha).put("wDark", Prefs.wDark))
  val f = File(c.filesDir, "widget_bg.jpg"); if (f.exists()) root.put("wImage", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
  return root.toString(1)
}

suspend fun exportTo(c: Context, u: Uri): Boolean = withContext(Dispatchers.IO) {
  try { c.contentResolver.openOutputStream(u, "wt")?.use { it.write(buildBackup(c).toByteArray(Charsets.UTF_8)) } != null } catch (e: Exception) { false }
}

/** Сначала целиком разбираем файл и только потом заменяем данные — битый файл ничего не сотрёт. */
suspend fun importFrom(c: Context, u: Uri): String = withContext(Dispatchers.IO) {
  try {
    val txt = c.contentResolver.openInputStream(u)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return@withContext "Не удалось открыть файл"
    val r = JSONObject(txt)
    if (r.optString("app") != "TodoQuest") return@withContext "Это не файл резервной копии TodoQuest"
    val lists = r.getJSONArray("lists").objs().map { TaskList(it.getLong("id"), it.getString("name")) }
    val tasks = r.getJSONArray("tasks").objs().map { o -> Task(id = o.getLong("id"), listId = o.lng("listId"), title = o.getString("title"), note = o.optString("note", ""),
      done = o.optBoolean("done"), important = o.optBoolean("important"), myDay = o.str("myDay"), due = o.lng("due"), repeat = o.optString("repeat", "NONE"),
      questId = o.lng("questId"), day = o.str("day"), pos = o.optInt("pos"), goal = o.optInt("goal"), progress = o.optInt("progress"), step = o.optInt("step", 1)) }
    val steps = r.getJSONArray("steps").objs().map { Step(it.getLong("id"), it.getLong("taskId"), it.getString("text"), it.optBoolean("done")) }
    val quests = r.getJSONArray("quests").objs().map { Quest(it.getLong("id"), it.getString("title"), it.optInt("threshold", 80), it.optInt("days", 127), it.optInt("pos")) }
    val items = r.getJSONArray("items").objs().map { QuestItem(it.getLong("id"), it.getLong("questId"), it.getString("title"), it.optInt("pos"), it.optInt("goal"), it.optInt("step", 1)) }
    val db = DB.get(c); val d = db.dao()
    db.withTransaction {
      d.clearTasks(); d.clearSteps(); d.clearItems(); d.clearQuests(); d.clearLists()
      d.saveLists(lists); d.saveTasks(tasks); d.saveSteps(steps); d.saveQuests(quests); d.saveItems(items)
    }
    withContext(Dispatchers.Main) {
      r.optJSONObject("prefs")?.let { p ->
        Prefs.mode = p.optInt("mode", Prefs.mode); Prefs.accent = p.optLong("accent", Prefs.accent); Prefs.showDone = p.optBoolean("showDone", Prefs.showDone); Prefs.fx = p.optBoolean("fx", Prefs.fx)
        Prefs.wBg = p.optInt("wBg", Prefs.wBg); Prefs.wColor = p.optLong("wColor", Prefs.wColor); Prefs.wAlpha = p.optInt("wAlpha", Prefs.wAlpha); Prefs.wDark = p.optBoolean("wDark", Prefs.wDark) }
      r.optString("wImage", "").takeIf { it.isNotEmpty() }?.let { File(c.filesDir, "widget_bg.jpg").writeBytes(Base64.decode(it, Base64.DEFAULT)); Prefs.wImg = System.currentTimeMillis() }
      Prefs.save()
    }
    tasks.forEach { remind(c, it) }; ensureToday(c)
    "Готово: задач ${tasks.size}, квестов ${quests.size}, списков ${lists.size}"
  } catch (e: Exception) { "Файл повреждён или имеет другой формат" }
}

@Composable fun BackupSettings() {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  var msg by remember { mutableStateOf("") }; var pending by remember { mutableStateOf<Uri?>(null) }
  val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
    if (u != null) sc.launch { msg = if (exportTo(c, u)) "Файл сохранён" else "Не удалось сохранить файл" } }
  val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) pending = u }
  Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Label("Данные")
    Text("Резервная копия: задачи, списки, квесты, статистика, настройки и фон виджета — одним файлом.", style = MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Button({ exp.launch("todoquest-$today.json") }, Modifier.weight(1f)) { Text("Экспорт") }
      OutlinedButton({ imp.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*")) }, Modifier.weight(1f)) { Text("Импорт") } }
    if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
  }
  pending?.let { u -> AlertDialog({ pending = null }, title = { Text("Заменить данные?") },
    text = { Text("Все текущие задачи, списки и квесты будут заменены данными из файла.") },
    confirmButton = { TextButton({ pending = null; sc.launch { msg = importFrom(c, u) } }) { Text("Заменить") } },
    dismissButton = { TextButton({ pending = null }) { Text("Отмена") } }) }
}
