package app.todo
import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

private val ENDS = intArrayOf(0xFF8E3FC4.toInt(), 0xFF0B5E8A.toInt(), 0xFFB02A9A.toInt(), 0xFFD8432B.toInt(), 0xFF5B4FD6.toInt(), 0xFF4A2CA0.toInt())
private var imgKey = -1L
private var imgBmp: Bitmap? = null
private fun widgetImg(c: Context): Bitmap? {
  val f = File(c.filesDir, "widget_bg.jpg"); if (!f.exists()) return null
  if (imgKey != f.lastModified()) { imgBmp = BitmapFactory.decodeFile(f.path); imgKey = f.lastModified() }
  return imgBmp
}

/** Фон виджета рисуем сами: градиент / один цвет / картинка + общая прозрачность. Размер ограничен ~380 px, чтобы виджет не тормозил. */
fun wBgBitmap(c: Context, wDp: Float, hDp: Float): Bitmap {
  val k = 380f / maxOf(wDp, hDp, 1f)
  val w = (wDp * k).toInt().coerceAtLeast(32); val h = (hDp * k).toInt().coerceAtLeast(32)
  val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
  val rad = 28f * k; val a = Prefs.wAlpha.coerceIn(0, 100) * 255 / 100
  val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
  cv.clipPath(Path().apply { addRoundRect(rect, rad, rad, Path.Direction.CW) })
  val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
  fun fill(shader: Shader?, argb: Int = 0xFF000000.toInt()) { p.shader = shader; p.color = argb; p.alpha = (argb ushr 24) * a / 255; cv.drawRect(rect, p) }
  when (Prefs.wBg) {
    1 -> fill(null, Prefs.wColor.toInt())
    2 -> {
      val src = widgetImg(c)
      if (src == null) fill(null, 0xFF263238.toInt()) else {
        val sa = src.width.toFloat() / src.height; val da = w.toFloat() / h
        val sr = if (sa > da) { val nw = (src.height * da).toInt(); Rect((src.width - nw) / 2, 0, (src.width + nw) / 2, src.height) }
                 else { val nh = (src.width / da).toInt(); Rect(0, (src.height - nh) / 2, src.width, (src.height + nh) / 2) }
        p.shader = null; p.color = 0xFF000000.toInt(); p.alpha = a; cv.drawBitmap(src, sr, rect, p)
        fill(null, 0x55000000)   // лёгкое затемнение, чтобы читался белый текст
      }
    }
    else -> {
      val i = Prefs.accents.indexOf(Prefs.accent).coerceAtLeast(0)
      fill(LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Prefs.accent.toInt(), ENDS[i], Shader.TileMode.CLAMP))
      fill(RadialGradient(w * .92f, 0f, w * .75f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP))
      fill(LinearGradient(0f, 0f, 0f, h.toFloat(), 0x00000000, 0x33000000, Shader.TileMode.CLAMP))
    }
  }
  p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = k; p.color = 0x33FFFFFF; p.alpha = 0x33 * a / 255
  cv.drawRoundRect(RectF(k / 2, k / 2, w - k / 2, h - k / 2), rad, rad, p)
  return bmp
}

/** Копируем выбранную картинку в память приложения (уменьшаем и учитываем поворот), чтобы доступ не пропал. */
suspend fun saveWidgetImage(c: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
  try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1; while (maxOf(o.outWidth, o.outHeight) / s > 1000) s *= 2
    val b = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return@withContext false
    val ori = c.contentResolver.openInputStream(uri)?.use { android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1) } ?: 1
    val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
    val r = if (deg != 0f) Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true) else b
    File(c.filesDir, "widget_bg.jpg").outputStream().use { r.compress(Bitmap.CompressFormat.JPEG, 88, it) }
    true
  } catch (e: Exception) { false }
}

@Composable fun WidgetSettings() {
  val c = LocalContext.current; val sc = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  fun upd() { Prefs.save(); sc.launch { refresh(c) } }
  val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
    if (uri != null) sc.launch { if (saveWidgetImage(c, uri)) { Prefs.wBg = 2; Prefs.wImg = System.currentTimeMillis(); upd() } } }
  val hasImg = remember(Prefs.wImg) { File(c.filesDir, "widget_bg.jpg").exists() }
  Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Label("Фон виджета")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Градиент", "Цвет", "Картинка").forEachIndexed { i, n ->
      Pill(Prefs.wBg == i, n, { Prefs.wBg = i; upd() }, Modifier.weight(1f), padH = 4.dp) } }
    if (Prefs.wBg == 1) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      (Prefs.accents + listOf(0xFF1E1E2E, 0xFF263238, 0xFF000000)).forEach { col ->
        Box(Modifier.size(38.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(col))
          .then(if (Prefs.wColor == col) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
          .clickable { Prefs.wColor = col; upd() }) } }
    if (Prefs.wBg == 2) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedButton({ pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(if (hasImg) "Сменить картинку" else "Выбрать картинку") }
      if (!hasImg) Text("Картинка не выбрана", style = MaterialTheme.typography.bodySmall) }
    Text("Прозрачность фона: ${100 - Prefs.wAlpha}%")
    Slider(1f - Prefs.wAlpha / 100f, { Prefs.wAlpha = 100 - (it * 100).roundToInt() }, onValueChangeFinished = { upd() })
  }
}
