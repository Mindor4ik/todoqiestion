package app.todo
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

object Prefs {
  lateinit var sp: SharedPreferences
  var mode by mutableStateOf(0)
  var accent by mutableStateOf(0xFF5B5BD6)
  var showDone by mutableStateOf(true)
  fun load(c: Context) { sp = c.getSharedPreferences("p", 0); mode = sp.getInt("mode", 0); accent = sp.getLong("accent", 0xFF5B5BD6); showDone = sp.getBoolean("done", true) }
  fun save() { sp.edit().putInt("mode", mode).putLong("accent", accent).putBoolean("done", showDone).apply() }
}
val fmt = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())

class MainActivity : ComponentActivity() {
  override fun onCreate(s: Bundle?) {
    super.onCreate(s)
    Prefs.load(this)
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    schedule(this); lifecycleScope.launch { ensureToday(this@MainActivity) }
    setContent { AppTheme { App() } }
  }
}

@Composable fun AppTheme(content: @Composable () -> Unit) {
  val dark = when (Prefs.mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
  val a = Color(Prefs.accent)
  val cs = if (dark) darkColorScheme(primary = a, onPrimary = Color.White, background = Color(0xFF121212), surface = Color(0xFF121212),
    secondaryContainer = a.copy(alpha = .35f).compositeOver(Color(0xFF1C1B1F)))
  else lightColorScheme(primary = a, onPrimary = Color.White, background = Color(0xFFF7F7FB), surface = Color(0xFFF7F7FB),
    secondaryContainer = a.copy(alpha = .18f).compositeOver(Color.White))
  MaterialTheme(cs, content = content)
}

@Composable fun App() {
  val c = LocalContext.current; val d = remember { DB.get(c).dao() }
  val tasks by d.tasks().collectAsState(emptyList()); val lists by d.lists().collectAsState(emptyList())
  var tab by remember { mutableStateOf(0) }
  val ic = listOf(Icons.Default.Check, Icons.Default.Star, Icons.Default.DateRange, Icons.Default.Settings)
  Scaffold(bottomBar = { NavigationBar { listOf("Задачи", "Квесты", "График", "Настройки").forEachIndexed { i, n ->
    NavigationBarItem(tab == i, { tab = i }, { Icon(ic[i], n) }, label = { Text(n, fontSize = 11.sp) }) } } }) { p ->
    Box(Modifier.padding(p).statusBarsPadding()) { when (tab) { 0 -> Tasks(d, tasks, lists); 1 -> Quests(d, tasks); 2 -> Stats(d); else -> Settings() } } }
}

@Composable fun TaskRow(t: Task, onTap: () -> Unit, onTog: () -> Unit, onStar: () -> Unit) {
  val over = t.due != null && !t.done && t.due < System.currentTimeMillis()
  val dim = MaterialTheme.colorScheme.outline
  Row(Modifier.fillMaxWidth().clickable(onClick = onTap).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
    Checkbox(t.done, { onTog() })
    Column(Modifier.weight(1f)) {
      Text(t.title, textDecoration = if (t.done) TextDecoration.LineThrough else null, color = if (t.done) dim else Color.Unspecified)
      val sub = listOfNotNull(t.due?.let { fmt.format(Date(it)) }, if (t.repeat != "NONE") "🔁" else null,
        if (t.questId != null) "⚔ квест" else null, if (t.note.isNotBlank()) "заметка" else null).joinToString(" · ")
      if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = if (over) MaterialTheme.colorScheme.error else dim)
    }
    IconButton(onStar) { Icon(Icons.Default.Star, null, tint = if (t.important) Color(0xFFFFB300) else dim) }
  }
}

@Composable fun Tasks(d: TodoDao, all: List<Task>, lists: List<TaskList>) {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  var f by remember { mutableStateOf("day") }; var sel by remember { mutableStateOf<Task?>(null) }
  var txt by remember { mutableStateOf("") }; var nl by remember { mutableStateOf("") }
  var q by remember { mutableStateOf("") }; var adding by remember { mutableStateOf(false) }
  val base = all.filter { (when (f) { "day" -> it.myDay == today; "imp" -> it.important; "plan" -> it.due != null; "all" -> true; else -> it.listId == f.toLongOrNull() }) && it.title.contains(q, true) }
  val active = base.filter { !it.done }.let { if (f == "plan") it.sortedBy { t -> t.due } else it }
  val done = base.filter { it.done }; val pct = if (base.isEmpty()) 0 else done.size * 100 / base.size
  val title = when (f) { "day" -> "Мой день"; "imp" -> "Важное"; "plan" -> "Запланировано"; "all" -> "Все задачи"; else -> lists.firstOrNull { it.id.toString() == f }?.name ?: "" }
  Column(Modifier.imePadding()) {
    Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
      Text(title, Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall)
      if (f.toLongOrNull() != null) IconButton({ sc.launch { d.delListTasks(f.toLong()); d.delList(f.toLong()); f = "day" } }) { Icon(Icons.Default.Delete, null) } }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), placeholder = { Text("Поиск") }, singleLine = true,
      leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(24.dp))
    LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(listOf("day" to "Мой день", "imp" to "Важное", "plan" to "Запланировано", "all" to "Все") + lists.map { it.id.toString() to it.name }) { (k, n) ->
        FilterChip(f == k, { f = k }, { Text(n) }) }
      item { AssistChip({ adding = true }, { Text("+ Список") }) } }
    if (base.isNotEmpty()) { LinearProgressIndicator({ pct / 100f }, Modifier.fillMaxWidth().padding(horizontal = 16.dp))
      Text("$pct% · ${done.size}/${base.size}", Modifier.padding(horizontal = 16.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall) }
    LazyColumn(Modifier.weight(1f)) {
      if (base.isEmpty()) item { Text("Пока пусто — добавьте задачу ниже", Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center) }
      items(active, key = { it.id }) { t -> TaskRow(t, { sel = t }, { sc.launch { toggle(c, t) } }, { sc.launch { put(c, t.copy(important = !t.important)) } }) }
      if (done.isNotEmpty() && Prefs.showDone) {
        item { Text("Завершённые (${done.size})", Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall) }
        items(done, key = { it.id }) { t -> TaskRow(t, { sel = t }, { sc.launch { toggle(c, t) } }, { sc.launch { put(c, t.copy(important = !t.important)) } }) } } }
    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
      OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), placeholder = { Text("Добавить задачу") }, singleLine = true, shape = RoundedCornerShape(24.dp))
      FilledIconButton({ if (txt.isNotBlank()) sc.launch {
        put(c, Task(title = txt, listId = f.toLongOrNull(), myDay = if (f == "day") today else null, important = f == "imp")); txt = "" } }) { Icon(Icons.Default.Add, null) } }
  }
  if (adding) AlertDialog({ adding = false }, title = { Text("Новый список") }, text = { OutlinedTextField(nl, { nl = it }, singleLine = true) },
    confirmButton = { TextButton({ if (nl.isNotBlank()) sc.launch { f = d.add(TaskList(name = nl)).toString(); nl = "" }; adding = false }) { Text("Создать") } })
  sel?.let { Detail(d, it, lists) { sel = null } }
}

fun pick(c: Context, cur: Long?, ok: (Long) -> Unit) {
  val z = Calendar.getInstance().apply { timeInMillis = cur ?: System.currentTimeMillis() }
  android.app.DatePickerDialog(c, { _, y, m, dd ->
    android.app.TimePickerDialog(c, { _, h, mi -> ok(Calendar.getInstance().apply { set(y, m, dd, h, mi, 0) }.timeInMillis) },
      z.get(Calendar.HOUR_OF_DAY), z.get(Calendar.MINUTE), true).show()
  }, z.get(Calendar.YEAR), z.get(Calendar.MONTH), z.get(Calendar.DAY_OF_MONTH)).show()
}

@Composable fun Detail(d: TodoDao, t0: Task, lists: List<TaskList>, close: () -> Unit) {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  var t by remember { mutableStateOf(t0) }; var ns by remember { mutableStateOf("") }
  val steps by d.steps(t0.id).collectAsState(emptyList())
  val fin = { sc.launch { put(c, t); close() }; Unit }
  AlertDialog(onDismissRequest = { fin() },
    confirmButton = { TextButton({ fin() }) { Text("Готово") } },
    dismissButton = { TextButton({ sc.launch { d.del(t0); refresh(c); close() } }) { Text("Удалить") } },
    text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      OutlinedTextField(t.title, { t = t.copy(title = it) }, Modifier.fillMaxWidth(), label = { Text("Название") })
      steps.forEach { s -> Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(s.done, { sc.launch { d.save(s.copy(done = !s.done)) } }); Text(s.text, Modifier.weight(1f))
        IconButton({ sc.launch { d.del(s) } }) { Icon(Icons.Default.Close, null) } } }
      Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(ns, { ns = it }, Modifier.weight(1f), label = { Text("Шаг") }, singleLine = true)
        IconButton({ if (ns.isNotBlank()) sc.launch { d.save(Step(taskId = t0.id, text = ns)); ns = "" } }) { Icon(Icons.Default.Add, null) } }
      Row(verticalAlignment = Alignment.CenterVertically) { Text("Мой день", Modifier.weight(1f)); Switch(t.myDay != null, { t = t.copy(myDay = if (it) today else null) }) }
      Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton({ pick(c, t.due) { t = t.copy(due = it) } }) { Text(t.due?.let { fmt.format(Date(it)) } ?: "Срок и напоминание") }
        if (t.due != null) TextButton({ t = t.copy(due = null) }) { Text("Сбросить") } }
      Text("Повтор", style = MaterialTheme.typography.labelMedium)
      Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("NONE" to "Нет", "DAILY" to "Каждый день", "WEEKLY" to "Неделя", "MONTHLY" to "Месяц").forEach { (k, n) -> FilterChip(t.repeat == k, { t = t.copy(repeat = k) }, { Text(n) }) } }
      Text("Список", style = MaterialTheme.typography.labelMedium)
      Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(t.listId == null, { t = t.copy(listId = null) }, { Text("Без списка") })
        lists.forEach { l -> FilterChip(t.listId == l.id, { t = t.copy(listId = l.id) }, { Text(l.name) }) } }
      OutlinedTextField(t.note, { t = t.copy(note = it) }, Modifier.fillMaxWidth(), label = { Text("Заметка") }) } })
}

@Composable fun Quests(d: TodoDao, all: List<Task>) {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  val qs by d.quests().collectAsState(emptyList()); val its by d.items().collectAsState(emptyList())
  var n by remember { mutableStateOf("") }
  LazyColumn(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    item { Text("Ежедневные квесты", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.headlineSmall)
      Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(n, { n = it }, Modifier.weight(1f), placeholder = { Text("Новый квест") }, singleLine = true, shape = RoundedCornerShape(24.dp))
        FilledIconButton({ if (n.isNotBlank()) sc.launch { d.save(Quest(title = n)); n = "" } }) { Icon(Icons.Default.Add, null) } } }
    items(qs, key = { it.id }) { q -> var m by remember { mutableStateOf("") }
      val td = all.filter { it.questId == q.id && it.day == today }; val dn = td.count { it.done }
      Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(q.title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
          IconButton({ sc.launch { d.delItems(q.id); d.delQuest(q.id) } }) { Icon(Icons.Default.Delete, null) } }
        if (td.isNotEmpty()) { LinearProgressIndicator({ dn.toFloat() / td.size }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
          Text("Сегодня $dn/${td.size}", style = MaterialTheme.typography.bodySmall) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Цель на день", Modifier.weight(1f))
          TextButton({ sc.launch { d.save(q.copy(threshold = maxOf(10, q.threshold - 10))) } }) { Text("−") }; Text("${q.threshold}%")
          TextButton({ sc.launch { d.save(q.copy(threshold = minOf(100, q.threshold + 10))) } }) { Text("+") } }
        its.filter { it.questId == q.id }.forEach { i -> Row(verticalAlignment = Alignment.CenterVertically) {
          Text("• " + i.title, Modifier.weight(1f)); IconButton({ sc.launch { d.del(i) } }) { Icon(Icons.Default.Close, null) } } }
        Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(m, { m = it }, Modifier.weight(1f), placeholder = { Text("Задача на каждый день") }, singleLine = true)
          IconButton({ if (m.isNotBlank()) sc.launch { d.save(QuestItem(questId = q.id, title = m)); m = ""; ensureToday(c) } }) { Icon(Icons.Default.Add, null) } }
      } } } }
}

@Composable fun RowScope.Stat(t: String, v: String) {
  Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text(v, style = MaterialTheme.typography.headlineSmall); Text(t, style = MaterialTheme.typography.bodySmall) } }
}

@Composable fun Stats(d: TodoDao) {
  val st by d.stats().collectAsState(emptyList()); val qs by d.quests().collectAsState(emptyList())
  val goal = qs.firstOrNull()?.threshold ?: 80; val data = st.takeLast(14)
  val pc = st.map { it.done * 100 / it.total }
  var streak = 0; for (p in pc.reversed()) { if (p >= goal) streak++ else break }
  val ok = Color(0xFF2E7D32); val bad = Color(0xFFC62828)
  Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Статистика квестов", style = MaterialTheme.typography.headlineSmall)
    if (data.isEmpty()) Text("Пока нет данных — создайте квест и выполняйте задачи.")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Stat("Среднее", if (pc.isEmpty()) "–" else "${pc.average().toInt()}%"); Stat("Серия дней", "$streak"); Stat("Лучший день", "${pc.maxOrNull() ?: 0}%") }
    Text("Выполнение по дням, % (цель $goal%)", style = MaterialTheme.typography.titleMedium)
    Box(Modifier.fillMaxWidth().height(170.dp)) {
      Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.Bottom) { data.forEach { s -> val p = s.done * 100 / s.total
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { Text("$p", fontSize = 10.sp)
          Box(Modifier.fillMaxWidth(.7f).height((130 * p / 100f).dp).background(if (p >= goal) ok else bad, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))) } } }
      HorizontalDivider(Modifier.align(Alignment.BottomCenter).padding(bottom = (130 * goal / 100f).dp)) }
    Row { data.forEach { Text(it.day.substring(8) + "." + it.day.substring(5, 7), Modifier.weight(1f), fontSize = 9.sp, textAlign = TextAlign.Center) } }
    st.reversed().forEach { Text("${it.day}: ${it.done * 100 / it.total}% (${it.done}/${it.total})") }
  }
}

@Composable fun Settings() {
  Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text("Настройки", style = MaterialTheme.typography.headlineSmall)
    Text("Тема", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Системная", "Светлая", "Тёмная").forEachIndexed { i, n ->
      FilterChip(Prefs.mode == i, { Prefs.mode = i; Prefs.save() }, { Text(n) }) } }
    Text("Цвет акцента", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { listOf(0xFF5B5BD6, 0xFF0B8A6F, 0xFFE0457B, 0xFFF57C00, 0xFF1E88E5, 0xFF8E24AA).forEach { col ->
      Box(Modifier.size(40.dp).background(Color(col), CircleShape)
        .then(if (Prefs.accent == col) Modifier.border(3.dp, MaterialTheme.colorScheme.onBackground, CircleShape) else Modifier)
        .clickable { Prefs.accent = col; Prefs.save() }) } }
    Row(verticalAlignment = Alignment.CenterVertically) { Text("Показывать завершённые задачи", Modifier.weight(1f))
      Switch(Prefs.showDone, { Prefs.showDone = it; Prefs.save() }) }
  }
}
