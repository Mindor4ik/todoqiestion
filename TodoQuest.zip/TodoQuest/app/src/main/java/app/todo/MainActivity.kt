package app.todo
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

object Prefs {
  lateinit var sp: SharedPreferences
  val accents = listOf(0xFF5B5BD6, 0xFF0B8A6F, 0xFFE0457B, 0xFFF57C00, 0xFF1E88E5, 0xFF8E24AA)
  var mode by mutableStateOf(0)
  var accent by mutableStateOf(0xFF5B5BD6)
  var showDone by mutableStateOf(true)
  var fx by mutableStateOf(false)   // эффекты размытия
  fun load(c: Context) { sp = c.getSharedPreferences("p", 0); mode = sp.getInt("mode", 0); accent = sp.getLong("accent", 0xFF5B5BD6); showDone = sp.getBoolean("done", true); fx = sp.getBoolean("blur", false) }
  fun save() { sp.edit().putInt("mode", mode).putLong("accent", accent).putBoolean("done", showDone).putBoolean("blur", fx).apply() }
}
val fmt = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())

class MainActivity : ComponentActivity() {
  override fun onCreate(s: Bundle?) {
    super.onCreate(s)
    enableEdgeToEdge()
    Prefs.load(this)
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    schedule(this); lifecycleScope.launch { ensureToday(this@MainActivity) }
    setContent { AppTheme { App() } }
  }
  override fun onStop() { super.onStop(); lifecycleScope.launch { refresh(this@MainActivity) } }   // виджет всегда актуален после выхода из приложения
}

@Composable fun AppTheme(content: @Composable () -> Unit) {
  val dark = when (Prefs.mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
  val a = Color(Prefs.accent)
  val cs = if (dark) darkColorScheme(primary = a, onPrimary = Color.White, background = Color(0xFF0E0D13), surface = Color(0xFF17161D),
    onBackground = Color(0xFFECEAF4), onSurface = Color(0xFFECEAF4), outline = Color(0xFF8E8C9B), surfaceVariant = Color(0xFF22212B),
    secondaryContainer = a.copy(alpha = .35f).compositeOver(Color(0xFF1C1B1F)))
  else lightColorScheme(primary = a, onPrimary = Color.White, background = Color(0xFFF4F3FB), surface = Color(0xFFFBFAFF),
    onBackground = Color(0xFF1B1A22), onSurface = Color(0xFF1B1A22), outline = Color(0xFF7A7886), surfaceVariant = Color(0xFFECEAF5),
    secondaryContainer = a.copy(alpha = .18f).compositeOver(Color.White))
  val ty = Typography().let { it.copy(headlineSmall = it.headlineSmall.copy(fontWeight = FontWeight.Bold), titleMedium = it.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleLarge = it.titleLarge.copy(fontWeight = FontWeight.Bold)) }
  val view = LocalView.current
  SideEffect {
    val w = (view.context as? Activity)?.window
    if (w != null) WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark }
  }
  // Без Surface у Text/Icon цвет по умолчанию чёрный — в тёмной теме нечитаемо. Задаём явно.
  MaterialTheme(colorScheme = cs, typography = ty) { CompositionLocalProvider(LocalContentColor provides cs.onBackground, content = content) }
}

private val tabNames = listOf("Задачи", "Квесты", "График", "Настройки")
private val tabIcons = listOf(Icons.Default.Check, Icons.Default.Star, Icons.Default.DateRange, Icons.Default.Settings)

@Composable fun App() {
  val c = LocalContext.current; val d = remember { DB.get(c).dao() }
  val tasks by d.tasks().collectAsState(emptyList()); val lists by d.lists().collectAsState(emptyList())
  var tab by remember { mutableIntStateOf(0) }
  val ime = WindowInsets.ime.getBottom(LocalDensity.current) > 0
  val blur by animateFloatAsState(if (Fx.open > 0 && Prefs.fx) 14f else 0f, tween(260), label = "blur")
  Box(Modifier.fillMaxSize()) {
    // фон растеризуется один раз в текстуру и дальше просто переиспользуется GPU
    Box(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }.orbs())
    Column(Modifier.fillMaxSize().imePadding().graphicsLayer {
      renderEffect = if (blur > .5f && Build.VERSION.SDK_INT >= 31) BlurEffect(blur, blur) else null }) {
      Box(Modifier.weight(1f).fillMaxWidth().statusBarsPadding()) {
        AnimatedContent(tab, Modifier.fillMaxSize(), transitionSpec = {
          val dir = if (targetState > initialState) 1 else -1
          (fadeIn(tween(240)) + slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { dir * it / 12 }) togetherWith
            (fadeOut(tween(130)) + slideOutHorizontally(tween(220)) { -dir * it / 12 }) }, label = "tab") { t ->
          when (t) { 0 -> Tasks(d, tasks, lists); 1 -> Quests(d, tasks); 2 -> Stats(d); else -> Settings() } }
      }
      AnimatedVisibility(!ime, enter = slideInVertically(tween(220)) { it } + fadeIn(tween(220)), exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(120))) {
        NavBar(tab) { tab = it } }
    }
  }
}

@Composable fun NavBar(tab: Int, onTab: (Int) -> Unit) {
  Row(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp).fillMaxWidth().glass(RoundedCornerShape(30.dp), strong = true).padding(6.dp),
    horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
    tabNames.forEachIndexed { i, n ->
      val sel = tab == i; val cs = MaterialTheme.colorScheme
      val bg = animateColorAsState(if (sel) cs.primary else Color.Transparent, tween(260), label = "nb")
      val fg = animateColorAsState(if (sel) cs.onPrimary else cs.onSurface.copy(alpha = .6f), tween(260), label = "nf")
      Row(Modifier.pressable { onTab(i) }.clip(RoundedCornerShape(24.dp)).drawBehind { drawRect(bg.value) }.padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(tabIcons[i], n, Modifier.size(22.dp), tint = fg.value)
        AnimatedVisibility(sel, enter = expandHorizontally(tween(260)) + fadeIn(tween(260)), exit = shrinkHorizontally(tween(200)) + fadeOut(tween(120))) {
          Text(n, Modifier.padding(start = 8.dp), color = fg.value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
      }
    }
  }
}

@Composable fun StatTile(t: String, v: String, modifier: Modifier = Modifier) {
  Column(modifier.glass().padding(14.dp)) {
    Text(v, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
    Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
  }
}

@Composable fun RowScope.BarCol(p: Int, goal: Int, label: String) {
  val ok = Color(0xFF2EBD85); val bad = Color(0xFFEF5350)
  val h by animateFloatAsState(p / 100f, tween(700, easing = FastOutSlowInEasing), label = "b")
  val col = if (p >= goal) ok else bad
  Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
    Text("$p", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
    Box(Modifier.fillMaxWidth(.62f).height(130.dp * h).clip(RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp))
      .background(Brush.verticalGradient(listOf(col, col.copy(alpha = .55f)))))
  }
}

@Composable fun Stats(d: TodoDao) {
  val st by d.stats().collectAsState(emptyList()); val qs by d.quests().collectAsState(emptyList())
  val goal = qs.firstOrNull()?.threshold ?: 80
  val data = remember(st) { st.takeLast(14) }
  val pc = remember(st) { st.map { it.done * 100 / it.total } }
  val streak = remember(pc, goal) { var n = 0; for (p in pc.reversed()) { if (p >= goal) n++ else break }; n }
  val hist = remember(st) { st.reversed() }
  val pr = MaterialTheme.colorScheme.primary; val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f)
  LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { Text("Статистика квестов", Modifier.padding(start = 4.dp), style = MaterialTheme.typography.headlineSmall) }
    if (data.isEmpty()) item { Text("Пока нет данных — создайте квест и выполняйте задачи.", Modifier.padding(start = 4.dp), color = dim) }
    item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      StatTile("Среднее", if (pc.isEmpty()) "–" else "${pc.average().toInt()}%", Modifier.weight(1f))
      StatTile("Серия дней", "$streak", Modifier.weight(1f)); StatTile("Лучший день", "${pc.maxOrNull() ?: 0}%", Modifier.weight(1f)) } }
    item { Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
      Text("Выполнение по дням, % (цель $goal%)", style = MaterialTheme.typography.titleSmall)
      Spacer(Modifier.height(10.dp))
      Box(Modifier.fillMaxWidth().height(160.dp)) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.Bottom) { data.forEach { s -> BarCol(s.done * 100 / s.total, goal, s.day) } }
        Canvas(Modifier.fillMaxSize()) { val y = size.height - 130.dp.toPx() * goal / 100f
          drawLine(pr.copy(alpha = .7f), Offset(0f, y), Offset(size.width, y), strokeWidth = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))) }
      }
      Row(Modifier.padding(top = 4.dp)) { data.forEach { Text(it.day.substring(8) + "." + it.day.substring(5, 7), Modifier.weight(1f), fontSize = 9.sp, textAlign = TextAlign.Center, color = dim) } }
    } }
    if (st.isNotEmpty()) item { Text("История", Modifier.padding(start = 4.dp, top = 4.dp), style = MaterialTheme.typography.titleMedium) }
    items(hist, key = { it.day }) { s -> val p = s.done * 100 / s.total
      Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(s.day.substring(8) + "." + s.day.substring(5, 7), Modifier.width(52.dp), fontWeight = FontWeight.Medium)
        Bar(p / 100f, Modifier.weight(1f))
        Text("$p%", Modifier.width(48.dp).padding(start = 8.dp), textAlign = TextAlign.End, color = if (p >= goal) Color(0xFF2EBD85) else Color(0xFFEF5350), fontWeight = FontWeight.SemiBold)
        Text("${s.done}/${s.total}", Modifier.width(44.dp), textAlign = TextAlign.End, fontSize = 12.sp, color = dim) } }
  }
}

@Composable fun Settings() {
  val c = LocalContext.current; val sc = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text("Настройки", Modifier.padding(start = 4.dp), style = MaterialTheme.typography.headlineSmall)
    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
      Label("Тема")
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Системная", "Светлая", "Тёмная").forEachIndexed { i, n ->
        Pill(Prefs.mode == i, n, { Prefs.mode = i; Prefs.save() }, Modifier.weight(1f), padH = 4.dp) } }
    }
    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
      Label("Цвет акцента")
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Prefs.accents.forEach { col ->
        val sel = Prefs.accent == col
        val s by animateFloatAsState(if (sel) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "ac")
        Box(Modifier.size(44.dp).graphicsLayer { val k = 1f + .12f * s; scaleX = k; scaleY = k }.clip(CircleShape).background(Color(col))
          .border((3 * s).dp, cs.onSurface.copy(alpha = s), CircleShape)
          .clickable { Prefs.accent = col; Prefs.save(); sc.launch { refresh(c) } }, contentAlignment = Alignment.Center) {
          if (sel) Icon(Icons.Default.Check, null, tint = Color.White) } } }
    }
    Column(Modifier.fillMaxWidth().glass().padding(horizontal = 16.dp, vertical = 8.dp)) {
      Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Показывать завершённые задачи", Modifier.weight(1f)); Switch(Prefs.showDone, { Prefs.showDone = it; Prefs.save() }) }
      HorizontalDivider(color = cs.onSurface.copy(alpha = .08f))
      Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text("Эффекты размытия"); Text("Размытие фона под окнами (Android 12+). Тратит ресурсы GPU, по умолчанию выключено", style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = .6f)) }
        Switch(Prefs.fx, { Prefs.fx = it; Prefs.save() }) }
    }
  }
}
