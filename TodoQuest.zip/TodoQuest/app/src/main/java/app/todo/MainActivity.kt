package app.todo
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(s: Bundle?) {
    super.onCreate(s)
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    schedule(this); lifecycleScope.launch { ensureToday(this@MainActivity) }
    setContent { MaterialTheme { App() } }
  }
}

@Composable fun App() {
  val c = LocalContext.current; val d = remember { DB.get(c).dao() }
  val tasks by d.tasks().collectAsState(emptyList()); val lists by d.lists().collectAsState(emptyList())
  var tab by remember { mutableStateOf(0) }
  val icons = listOf(Icons.Default.Check, Icons.Default.Star, Icons.Default.DateRange)
  Scaffold(bottomBar = { NavigationBar { listOf("Задачи", "Квесты", "График").forEachIndexed { i, n ->
    NavigationBarItem(tab == i, { tab = i }, { Icon(icons[i], n) }, label = { Text(n) }) } } }) { p ->
    Box(Modifier.padding(p)) { when (tab) { 0 -> Tasks(d, tasks, lists); 1 -> Quests(d); else -> Stats(d) } } }
}

@Composable fun Tasks(d: TodoDao, all: List<Task>, lists: List<TaskList>) {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  var f by remember { mutableStateOf("day") }; var sel by remember { mutableStateOf<Task?>(null) }
  var txt by remember { mutableStateOf("") }; var nl by remember { mutableStateOf("") }
  val shown = all.filter { when (f) { "day" -> it.myDay == today; "imp" -> it.important; "plan" -> it.due != null; "all" -> true; else -> it.listId == f.toLongOrNull() } }
  Column {
    LazyRow(contentPadding = PaddingValues(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(listOf("day" to "Мой день", "imp" to "Важное", "plan" to "Запланировано", "all" to "Все") + lists.map { it.id.toString() to it.name }) { (k, n) ->
        FilterChip(f == k, { f = k }, { Text(n) }) } }
    Row(Modifier.padding(horizontal = 8.dp)) {
      OutlinedTextField(nl, { nl = it }, Modifier.weight(1f), label = { Text("Новый список") }, singleLine = true)
      IconButton({ if (nl.isNotBlank()) sc.launch { d.add(TaskList(name = nl)); nl = "" } }) { Icon(Icons.Default.Add, null) } }
    LazyColumn(Modifier.weight(1f)) { items(shown, key = { it.id }) { t ->
      Row(Modifier.fillMaxWidth().clickable { sel = t }, verticalAlignment = Alignment.CenterVertically) {
        Checkbox(t.done, { sc.launch { toggle(c, t) } })
        Text(t.title, Modifier.weight(1f), textDecoration = if (t.done) TextDecoration.LineThrough else null)
        IconButton({ sc.launch { put(c, t.copy(important = !t.important)) } }) {
          Icon(Icons.Default.Star, null, tint = if (t.important) Color(0xFFFFB300) else Color.Gray) } } } }
    Row(Modifier.padding(8.dp)) {
      OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), label = { Text("Добавить задачу") }, singleLine = true)
      IconButton({ if (txt.isNotBlank()) sc.launch {
        put(c, Task(title = txt, listId = f.toLongOrNull(), myDay = if (f == "day") today else null, important = f == "imp")); txt = "" } }) {
        Icon(Icons.Default.Add, null) } }
  }
  sel?.let { Detail(d, it) { sel = null } }
}

@Composable fun Detail(d: TodoDao, t0: Task, close: () -> Unit) {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  var t by remember { mutableStateOf(t0) }; var ns by remember { mutableStateOf("") }
  val steps by d.steps(t0.id).collectAsState(emptyList())
  val now = System.currentTimeMillis(); val day = 86400000L
  val fin = { sc.launch { put(c, t); close() }; Unit }
  AlertDialog(onDismissRequest = { fin() },
    confirmButton = { TextButton({ fin() }) { Text("Готово") } },
    dismissButton = { TextButton({ sc.launch { d.del(t0); refresh(c); close() } }) { Text("Удалить") } },
    text = { Column(Modifier.verticalScroll(rememberScrollState())) {
      OutlinedTextField(t.title, { t = t.copy(title = it) }, label = { Text("Название") })
      steps.forEach { s -> Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(s.done, { sc.launch { d.save(s.copy(done = !s.done)) } }); Text(s.text, Modifier.weight(1f))
        IconButton({ sc.launch { d.del(s) } }) { Icon(Icons.Default.Close, null) } } }
      Row { OutlinedTextField(ns, { ns = it }, Modifier.weight(1f), label = { Text("Шаг") })
        IconButton({ if (ns.isNotBlank()) sc.launch { d.save(Step(taskId = t0.id, text = ns)); ns = "" } }) { Icon(Icons.Default.Add, null) } }
      Row(verticalAlignment = Alignment.CenterVertically) { Text("Мой день", Modifier.weight(1f))
        Switch(t.myDay != null, { t = t.copy(myDay = if (it) today else null) }) }
      Text("Срок/напоминание: " + (t.due?.let { java.text.DateFormat.getDateTimeInstance().format(it) } ?: "нет"))
      Row { TextButton({ t = t.copy(due = now + 3600000) }) { Text("Сегодня") }; TextButton({ t = t.copy(due = now + day) }) { Text("Завтра") }
        TextButton({ t = t.copy(due = now + 7 * day) }) { Text("Неделя") }; TextButton({ t = t.copy(due = null) }) { Text("Нет") } }
      TextButton({ t = t.copy(repeat = listOf("NONE", "DAILY", "WEEKLY", "MONTHLY").let { it[(it.indexOf(t.repeat) + 1) % 4] }) }) { Text("Повтор: ${t.repeat}") }
      OutlinedTextField(t.note, { t = t.copy(note = it) }, label = { Text("Заметка") }) } })
}

@Composable fun Quests(d: TodoDao) {
  val c = LocalContext.current; val sc = rememberCoroutineScope()
  val qs by d.quests().collectAsState(emptyList()); val its by d.items().collectAsState(emptyList())
  var n by remember { mutableStateOf("") }
  LazyColumn(Modifier.padding(8.dp)) {
    item { Row { OutlinedTextField(n, { n = it }, Modifier.weight(1f), label = { Text("Новый ежедневный квест") })
      IconButton({ if (n.isNotBlank()) sc.launch { d.save(Quest(title = n)); n = "" } }) { Icon(Icons.Default.Add, null) } } }
    items(qs, key = { it.id }) { q -> var m by remember { mutableStateOf("") }
      Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(q.title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
          TextButton({ sc.launch { d.save(q.copy(threshold = maxOf(10, q.threshold - 10))) } }) { Text("−") }
          Text("цель ${q.threshold}%")
          TextButton({ sc.launch { d.save(q.copy(threshold = minOf(100, q.threshold + 10))) } }) { Text("+") }
          IconButton({ sc.launch { d.delItems(q.id); d.delQuest(q.id) } }) { Icon(Icons.Default.Delete, null) } }
        its.filter { it.questId == q.id }.forEach { i -> Row(verticalAlignment = Alignment.CenterVertically) {
          Text("• " + i.title, Modifier.weight(1f)); IconButton({ sc.launch { d.del(i) } }) { Icon(Icons.Default.Close, null) } } }
        Row { OutlinedTextField(m, { m = it }, Modifier.weight(1f), label = { Text("Задача на каждый день") }, singleLine = true)
          IconButton({ if (m.isNotBlank()) sc.launch { d.save(QuestItem(questId = q.id, title = m)); m = ""; ensureToday(c) } }) { Icon(Icons.Default.Add, null) } }
      } } } }
}

@Composable fun Stats(d: TodoDao) {
  val st by d.stats().collectAsState(emptyList()); val qs by d.quests().collectAsState(emptyList())
  val goal = qs.firstOrNull()?.threshold ?: 80; val data = st.takeLast(14)
  val ok = Color(0xFF2E7D32); val bad = Color(0xFFC62828)
  Column(Modifier.padding(16.dp)) {
    Text("Выполнение квестов по дням, % (цель $goal%)", style = MaterialTheme.typography.titleMedium)
    Canvas(Modifier.fillMaxWidth().height(220.dp).padding(vertical = 12.dp)) {
      val w = size.width / maxOf(data.size, 1); val gy = size.height * (1 - goal / 100f)
      drawLine(Color.Gray, Offset(0f, gy), Offset(size.width, gy), 2f)
      data.forEachIndexed { i, s -> val p = s.done * 100f / s.total
        drawRect(if (p >= goal) ok else bad, Offset(i * w + w * 0.15f, size.height * (1 - p / 100f)), Size(w * 0.7f, size.height * p / 100f)) } }
    LazyColumn { items(data.reversed()) { Text("${it.day}: ${it.done * 100 / it.total}% (${it.done}/${it.total})") } }
  }
}
