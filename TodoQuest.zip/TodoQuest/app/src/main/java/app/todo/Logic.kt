package app.todo
import android.app.*
import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.room.withTransaction
import androidx.work.*
import java.time.*
import java.util.concurrent.TimeUnit

val today: String get() = LocalDate.now().toString()
suspend fun refresh(c: Context) = TodoWidget().updateAll(c)

// Создаёт задачи сегодняшнего дня из шаблонов квестов (идемпотентно)
suspend fun ensureToday(c: Context) {
  val d = DB.get(c).dao(); val day = today; val dow = LocalDate.now().dayOfWeek.value - 1
  val have = d.todayKeys(day).map { it.questId to it.title }.toHashSet()   // один запрос вместо запроса на каждую задачу
  val add = ArrayList<Task>()
  for (q in d.questsNow()) if (((q.days shr dow) and 1) == 1) d.itemsOf(q.id).forEachIndexed { n, i ->
    if (have.add(q.id to i.title)) add.add(Task(title = i.title, questId = q.id, day = day, myDay = day, pos = n, goal = i.goal, step = i.step)) }
  if (add.isNotEmpty()) d.saveTasks(add)   // одной транзакцией
  refresh(c)
}
suspend fun put(c: Context, t: Task) {
  val id = DB.get(c).dao().save(t)
  remind(c, if (t.id == 0L) t.copy(id = id) else t); refresh(c)
}
suspend fun toggle(c: Context, t: Task) {
  val nd = !t.done   // у задачи со шкалой выполнение = шкала заполнена целиком, снятие галочки = сброс шкалы
  DB.get(c).dao().save(t.copy(done = nd, progress = if (t.goal > 0) (if (nd) t.goal else 0) else t.progress))
  if (!t.done && t.repeat != "NONE" && t.questId == null) {
    val z = ZonedDateTime.ofInstant(Instant.ofEpochMilli(t.due ?: System.currentTimeMillis()), ZoneId.systemDefault())
    val n = when (t.repeat) { "DAILY" -> z.plusDays(1); "WEEKLY" -> z.plusWeeks(1); else -> z.plusMonths(1) }
    put(c, t.copy(id = 0, done = false, progress = 0, due = n.toInstant().toEpochMilli(), myDay = null))
  }
  refresh(c)
}
/** Шаг по умолчанию для шкалы: 40 → 5, 100 → 20, 10 → 2. */
fun autoStep(goal: Int): Int { val s = goal / 5; return listOf(100, 50, 25, 20, 10, 5, 2, 1).firstOrNull { it <= s } ?: 1 }

/** Прибавить/убавить прогресс шкалы; при заполнении задача выполняется (с повтором, если он задан). */
suspend fun addProgress(c: Context, t: Task, delta: Int) {
  if (t.goal <= 0) return
  val n = (t.progress + delta).coerceIn(0, t.goal)
  if (n >= t.goal && !t.done) toggle(c, t.copy(progress = n))
  else { DB.get(c).dao().save(t.copy(progress = n, done = n >= t.goal)); refresh(c) }
}

// Сохранение порядка одним пакетом (одна транзакция — без «мерцания» списка)
suspend fun reorderTasks(c: Context, list: List<Task>) {
  DB.get(c).dao().saveTasks(list.mapIndexed { n, t -> t.copy(pos = n) }); refresh(c)
}
suspend fun reorderQuests(c: Context, list: List<Quest>) {
  DB.get(c).dao().saveQuests(list.mapIndexed { n, q -> q.copy(pos = n) })
}
// Порядок задач квеста; заодно переставляем уже созданные на сегодня задачи
suspend fun reorderItems(c: Context, q: Quest, list: List<QuestItem>) {
  val db = DB.get(c); val d = db.dao()
  db.withTransaction {
    d.saveItems(list.mapIndexed { n, i -> i.copy(pos = n) })
    list.forEachIndexed { n, i -> d.setPos(q.id, today, i.title, n) }
  }
  refresh(c)
}
class DailyWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
  override suspend fun doWork(): Result { ensureToday(applicationContext); return Result.success() }
}
class RemindWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
  override suspend fun doWork(): Result {
    val nm = applicationContext.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("r", "Напоминания", NotificationManager.IMPORTANCE_DEFAULT))
    nm.notify(inputData.getLong("id", 0).toInt(), Notification.Builder(applicationContext, "r")
      .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(inputData.getString("t")).build())
    return Result.success()
  }
}
fun schedule(c: Context) = WorkManager.getInstance(c).enqueueUniquePeriodicWork(
  "daily", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<DailyWorker>(6, TimeUnit.HOURS).build())
fun remind(c: Context, t: Task) {
  val dl = (t.due ?: return) - System.currentTimeMillis(); if (dl <= 0 || t.done) return
  WorkManager.getInstance(c).enqueueUniqueWork("r${t.id}", ExistingWorkPolicy.REPLACE,
    OneTimeWorkRequestBuilder<RemindWorker>().setInitialDelay(dl, TimeUnit.MILLISECONDS)
      .setInputData(workDataOf("id" to t.id, "t" to t.title)).build())
}
