package app.todo
import android.app.*
import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.*
import java.time.*
import java.util.concurrent.TimeUnit

val today: String get() = LocalDate.now().toString()
suspend fun refresh(c: Context) = TodoWidget().updateAll(c)

// Создаёт задачи сегодняшнего дня из шаблонов квестов (идемпотентно)
suspend fun ensureToday(c: Context) {
  val d = DB.get(c).dao()
  for (q in d.questsNow()) for (i in d.itemsOf(q.id))
    if (d.has(q.id, today, i.title) == 0) d.save(Task(title = i.title, questId = q.id, day = today, myDay = today))
  refresh(c)
}
suspend fun put(c: Context, t: Task) {
  val id = DB.get(c).dao().save(t)
  remind(c, if (t.id == 0L) t.copy(id = id) else t); refresh(c)
}
suspend fun toggle(c: Context, t: Task) {
  DB.get(c).dao().save(t.copy(done = !t.done))
  if (!t.done && t.repeat != "NONE" && t.questId == null) {
    val z = ZonedDateTime.ofInstant(Instant.ofEpochMilli(t.due ?: System.currentTimeMillis()), ZoneId.systemDefault())
    val n = when (t.repeat) { "DAILY" -> z.plusDays(1); "WEEKLY" -> z.plusWeeks(1); else -> z.plusMonths(1) }
    put(c, t.copy(id = 0, done = false, due = n.toInstant().toEpochMilli(), myDay = null))
  }
  refresh(c)
}
class DailyWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
  override suspend fun doWork(): Result { ensureToday(applicationContext); return Result.success() }
}
class RemindWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
  override suspend fun doWork(): Result {
    val nm = applicationContext.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("r", "Напоминания", NotificationManager.IMPORTANCE_DEFAULT))
    nm.notify(inputData.getLong("id", 0).toInt(), Notification.Builder(applicationContext, "r")
      .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(inputData.getString("t")).build())
    return Result.success()
  }
}
fun schedule(c: Context) = WorkManager.getInstance(c).enqueueUniquePeriodicWork(
  "daily", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<DailyWorker>(6, TimeUnit.HOURS).build())
fun remind(c: Context, t: Task) {
  val dl = (t.due ?: return) - System.currentTimeMillis(); if (dl <= 0 || t.done) return
  WorkManager.getInstance(c).enqueueUniqueWork("r${t.id}", ExistingWorkPolicy.REPLACE,
    OneTimeWorkRequestBuilder<RemindWorker>().setInitialDelay(dl, TimeUnit.MILLISECONDS)
      .setInputData(workDataOf("id" to t.id, "t" to t.title)).build())
}
