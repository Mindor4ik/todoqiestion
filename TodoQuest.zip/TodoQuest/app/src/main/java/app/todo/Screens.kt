package app.todo
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Date
import kotlin.math.roundToInt

/* ═════════════════════ ЗАДАЧИ ═════════════════════ */

@Composable fun TaskRow(t: Task, order: Boolean, lifted: Boolean, canUp: Boolean, canDown: Boolean, onMove: (Int) -> Unit, grip: Modifier,
                        onTap: () -> Unit, onTog: () -> Unit, onStar: () -> Unit, onStep: () -> Unit, mod: Modifier = Modifier) {
  val cs = MaterialTheme.colorScheme; val over = t.due != null && !t.done && t.due < System.currentTimeMillis()
  val fade = if (t.done) .55f else 1f
  val star = if (t.important) Color(0xFFFFB300) else cs.outline.copy(alpha = .6f)
  Box(mod.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
    Row(Modifier.fillMaxWidth().liftFx(lifted, 20.dp).glass(RoundedCornerShape(20.dp)).tap(onTap).padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
      verticalAlignment = Alignment.CenterVertically) {
      CheckCircle(t.done, onTog)
      Column(Modifier.weight(1f).padding(end = 6.dp).graphicsLayer { alpha = fade }) {
        Text(t.title, fontWeight = FontWeight.Medium, textDecoration = if (t.done) TextDecoration.LineThrough else null, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (t.goal > 0) Row(Modifier.padding(top = 5.dp), verticalAlignment = Alignment.CenterVertically) {
          Bar(if (t.done) 1f else t.progress.toFloat() / t.goal, Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
          Text("${if (t.done) t.goal else t.progress}/${t.goal}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.primary) }
        if (t.due != null || t.repeat != "NONE" || t.questId != null || t.note.isNotBlank()) Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
          if (t.due != null) Tag(fmt.format(Date(t.due)), if (over) cs.error else cs.primary)
          if (t.repeat != "NONE") Tag("🔁", cs.primary)
          if (t.questId != null) Tag("⚔ квест", Color(0xFFE0457B))
          if (t.note.isNotBlank()) Tag("📝", cs.outline) }
      }
      if (order) MoveControls(canUp, canDown, onMove, grip)
      else if (t.goal > 0 && !t.done) StepBtn(t.step, onStep)
      else IconButton(onStar) { Icon(Icons.Default.Star, null, tint = star) }
    }
  }
}

@Composable fun Tasks(d: TodoDao, all: List<Task>, lists: List<TaskList>) {
  val c = LocalContext.current; val sc = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  var f by remember { mutableStateOf("day") }; var sel by remember { mutableStateOf<Task?>(null) }
  var nl by remember { mutableStateOf("") }
  var q by remember { mutableStateOf("") }; var adding by remember { mutableStateOf(false) }
  var order by remember { mutableStateOf(false) }; var delList by remember { mutableStateOf(false) }
  val day = today
  val base = remember(all, f, q, day) { val lf = f.toLongOrNull()
    all.filter { (when (f) { "day" -> it.myDay == day; "imp" -> it.important; "plan" -> it.due != null; "all" -> true; else -> it.listId == lf }) && it.title.contains(q, true) } }
  val active = remember(base, f, order) { base.filter { !it.done }.let { if (f == "plan" && !order) it.sortedBy { t -> t.due } else it } }
  val done = remember(base) { base.filter { it.done } }; val pct = if (base.isEmpty()) 0 else done.size * 100 / base.size
  val title = when (f) { "day" -> "Мой день"; "imp" -> "Важное"; "plan" -> "Запланировано"; "all" -> "Все задачи"; else -> lists.firstOrNull { it.id.toString() == f }?.name ?: "" }
  val lazy = rememberLazyListState()
  val reorder = rememberReorder<Task>(lazy, { it.id }) { l -> sc.launch { reorderTasks(c, l) } }
  val shown = reorder.items(active)
  BlurWhile(sel != null || adding || delList)
  fun move(i: Int, dx: Int) { val j = i + dx; if (j in active.indices) sc.launch { val l = active.toMutableList(); l.add(j, l.removeAt(i)); reorderTasks(c, l) } }
  fun addTask(t: String, g: Int) { sc.launch { put(c, Task(title = t, listId = f.toLongOrNull(), myDay = if (f == "day") today else null, important = f == "imp", goal = g, step = if (g > 0) autoStep(g) else 1)) } }

  Column(Modifier.fillMaxSize()) {
    // Шапка
    Box(Modifier.padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(accentBrush())
      .drawBehind { drawCircle(Color.White.copy(alpha = .10f), size.height * .9f, Offset(size.width * .95f, -size.height * .15f))
        drawCircle(Color.White.copy(alpha = .07f), size.height * .55f, Offset(size.width * .45f, size.height * 1.15f)) }.padding(18.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
          AnimatedContent(title, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }, label = "ttl") { s ->
            Text(s, style = MaterialTheme.typography.headlineSmall, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) }
          Text("Выполнено ${done.size} из ${base.size}", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .85f))
          Spacer(Modifier.height(10.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostBtn(if (order) "Готово" else "Порядок") { order = !order }
            if (f.toLongOrNull() != null) GhostBtn("Удалить список") { delList = true } }
        }
        ProgressRing(pct, Modifier.size(84.dp), 9.dp, 18)
      }
    }
    GlassField(q, { q = it }, "Поиск", Modifier.fillMaxWidth().padding(horizontal = 14.dp), leading = { Icon(Icons.Default.Search, null) })
    LazyRow(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(listOf("day" to "Мой день", "imp" to "Важное", "plan" to "Запланировано", "all" to "Все") + lists.map { it.id.toString() to it.name }, key = { it.first }) { (k, n) ->
        Pill(f == k, n, { f = k }) }
      item("addlist") { Pill(false, "+ Список", { adding = true }) } }
    LazyColumn(Modifier.weight(1f), state = lazy) {
      if (base.isEmpty()) item("empty") { Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("✨", fontSize = 40.sp); Spacer(Modifier.height(8.dp))
        Text("Пока пусто — добавьте задачу ниже", textAlign = TextAlign.Center, color = cs.onSurface.copy(alpha = .6f)) } }
      itemsIndexed(shown, key = { _, t -> t.id }) { i, t ->
        val drag = reorder.dragKey == t.id
        TaskRow(t, order, drag && reorder.held, i > 0, i < shown.lastIndex, { dx -> move(i, dx) }, reorder.handle(t.id), { sel = t },
          { sc.launch { toggle(c, t) } }, { sc.launch { put(c, t.copy(important = !t.important)) } }, { sc.launch { addProgress(c, t, t.step) } },
          reorder.root(t.id).then(if (drag) Modifier else Modifier.animateItem())) }
      if (done.isNotEmpty() && Prefs.showDone) {
        item("hdr") { Text("Завершённые (${done.size})", Modifier.padding(start = 18.dp, top = 14.dp, bottom = 6.dp), style = MaterialTheme.typography.titleSmall, color = cs.onSurface.copy(alpha = .6f)) }
        items(done, key = { it.id }) { t -> TaskRow(t, false, false, false, false, {}, Modifier, { sel = t }, { sc.launch { toggle(c, t) } }, { sc.launch { put(c, t.copy(important = !t.important)) } }, {}, Modifier.animateItem()) } }
    }
    AddBar { t, g -> addTask(t, g) }
  }
  if (adding) AlertDialog({ adding = false }, title = { Text("Новый список") }, text = { OutlinedTextField(nl, { nl = it }, singleLine = true, shape = RoundedCornerShape(16.dp)) },
    confirmButton = { TextButton({ if (nl.isNotBlank()) sc.launch { f = d.add(TaskList(name = nl)).toString(); nl = "" }; adding = false }) { Text("Создать") } },
    dismissButton = { TextButton({ adding = false }) { Text("Отмена") } })
  if (delList) AlertDialog({ delList = false }, title = { Text("Удалить список?") }, text = { Text("Вместе со списком удалятся все его задачи.") },
    confirmButton = { TextButton({ val id = f.toLongOrNull(); delList = false; if (id != null) sc.launch { d.delListTasks(id); d.delList(id); f = "day"; refresh(c) } }) { Text("Удалить", color = cs.error) } },
    dismissButton = { TextButton({ delList = false }) { Text("Отмена") } })
  sel?.let { Detail(d, it, lists) { sel = null } }
}

fun pick(c: Context, cur: Long?, ok: (Long) -> Unit) {
  val z = Calendar.getInstance().apply { timeInMillis = cur ?: System.currentTimeMillis() }
  android.app.DatePickerDialog(c, { _, y, m, dd ->
    android.app.TimePickerDialog(c, { _, h, mi -> ok(Calendar.getInstance().apply { set(y, m, dd, h, mi, 0) }.timeInMillis) },
      z.get(Calendar.HOUR_OF_DAY), z.get(Calendar.MINUTE), true).show()
  }, z.get(Calendar.YEAR), z.get(Calendar.MONTH), z.get(Calendar.DAY_OF_MONTH)).show()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Detail(d: TodoDao, t0: Task, lists: List<TaskList>, close: () -> Unit) {
  val c = LocalContext.current; val sc = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  var t by remember { mutableStateOf(t0) }; var ns by remember { mutableStateOf("") }
  val steps by d.steps(t0.id).collectAsState(emptyList())
  val fin = { sc.launch {
    if (t.goal > 0 && t.progress >= t.goal && !t0.done) { val s = t.copy(done = false, progress = t.goal); put(c, s); toggle(c, s) }   // заполнили шкалу → выполнено (+повтор)
    else put(c, t.copy(done = if (t.goal > 0) t.progress >= t.goal else t.done))
    close() }; Unit }
  ModalBottomSheet({ fin() }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = cs.surface) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp).navigationBarsPadding().imePadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      OutlinedTextField(t.title, { t = t.copy(title = it) }, Modifier.fillMaxWidth(), label = { Text("Название") }, shape = RoundedCornerShape(16.dp), textStyle = MaterialTheme.typography.titleMedium)
      Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(12.dp)) {
        Label("Шаги")
        steps.forEach { s -> Row(verticalAlignment = Alignment.CenterVertically) {
          CheckCircle(s.done, { sc.launch { d.save(s.copy(done = !s.done)) } }, dia = 22.dp)
          Text(s.text, Modifier.weight(1f), textDecoration = if (s.done) TextDecoration.LineThrough else null, color = if (s.done) cs.outline else cs.onSurface)
          IconButton({ sc.launch { d.del(s) } }) { Icon(Icons.Default.Close, "Удалить шаг", tint = cs.outline) } } }
        Row(verticalAlignment = Alignment.CenterVertically) {
          OutlinedTextField(ns, { ns = it }, Modifier.weight(1f), placeholder = { Text("Новый шаг") }, singleLine = true, shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { if (ns.isNotBlank()) sc.launch { d.save(Step(taskId = t0.id, text = ns)); ns = "" } }))
          IconButton({ if (ns.isNotBlank()) sc.launch { d.save(Step(taskId = t0.id, text = ns)); ns = "" } }) { Icon(Icons.Default.Add, "Добавить шаг") } }
      }
      Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
          Text("Мой день", Modifier.weight(1f)); Switch(t.myDay != null, { t = t.copy(myDay = if (it) today else null) }) }
        HorizontalDivider(color = cs.onSurface.copy(alpha = .08f))
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
          Text("Важное", Modifier.weight(1f)); Switch(t.important, { t = t.copy(important = it) }) }
        HorizontalDivider(color = cs.onSurface.copy(alpha = .08f))
        Row(Modifier.fillMaxWidth().clickable { pick(c, t.due) { t = t.copy(due = it) } }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.DateRange, null, tint = cs.primary); Spacer(Modifier.width(12.dp))
          Text(t.due?.let { fmt.format(Date(it)) } ?: "Срок и напоминание", Modifier.weight(1f))
          if (t.due != null) TextButton({ t = t.copy(due = null) }) { Text("Сбросить") } }
      }
      CounterCard(t) { t = it }
      Column { Label("Повтор")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("NONE" to "Нет", "DAILY" to "Каждый день", "WEEKLY" to "Неделя", "MONTHLY" to "Месяц").forEach { (k, n) -> Pill(t.repeat == k, n, { t = t.copy(repeat = k) }) } } }
      Column { Label("Список")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Pill(t.listId == null, "Без списка", { t = t.copy(listId = null) })
          lists.forEach { l -> Pill(t.listId == l.id, l.name, { t = t.copy(listId = l.id) }) } } }
      OutlinedTextField(t.note, { t = t.copy(note = it) }, Modifier.fillMaxWidth(), label = { Text("Заметка") }, shape = RoundedCornerShape(16.dp), minLines = 2)
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ fin() }, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("Готово") }
        OutlinedButton({ sc.launch { d.del(t0); refresh(c); close() } }, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("Удалить", color = cs.error) } }
    }
  }
}

/* ═════════════════════ КВЕСТЫ ═════════════════════ */

private val dayNames = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

@Composable fun Quests(d: TodoDao, all: List<Task>) {
  val qs by d.quests().collectAsState(emptyList()); val its by d.items().collectAsState(emptyList())
  var editing by remember { mutableStateOf<Long?>(null) }
  AnimatedContent(editing, Modifier.fillMaxSize(), transitionSpec = {
    if (targetState != null) (slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { it / 5 } + fadeIn(tween(260))) togetherWith (slideOutHorizontally(tween(260)) { -it / 8 } + fadeOut(tween(160)))
    else (slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { -it / 8 } + fadeIn(tween(260))) togetherWith (slideOutHorizontally(tween(260)) { it / 5 } + fadeOut(tween(160)))
  }, label = "qe") { id ->
    val q = qs.firstOrNull { it.id == id }
    if (id == null || q == null) QuestList(d, qs, its, all) { editing = it } else QuestEditor(d, q, its) { editing = null }
  }
}

@Composable fun QuestList(d: TodoDao, qs: List<Quest>, its: List<QuestItem>, all: List<Task>, open: (Long) -> Unit) {
  val c = LocalContext.current; val sc = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  var n by remember { mutableStateOf("") }
  val lazy = rememberLazyListState()
  val reorder = rememberReorder<Quest>(lazy, { it.id }) { l -> sc.launch { reorderQuests(c, l) } }
  val shown = reorder.items(qs)
  val day = today
  val byQ = remember(all, day) { all.filter { it.questId != null && it.day == day }.groupBy { it.questId } }
  val tq = remember(byQ) { byQ.values.flatten() }
  val counts = remember(its) { its.groupingBy { it.questId }.eachCount() }
  val tpct = if (tq.isEmpty()) 0 else tq.count { it.done } * 100 / tq.size
  fun add() { if (n.isNotBlank()) { val t = n; n = ""; sc.launch { open(d.save(Quest(title = t, pos = qs.size))) } } }
  fun move(i: Int, dx: Int) { val j = i + dx; if (j in qs.indices) sc.launch { val l = qs.toMutableList(); l.add(j, l.removeAt(i)); reorderQuests(c, l) } }
  LazyColumn(state = lazy, contentPadding = PaddingValues(bottom = 24.dp)) {
    item("hdr") {
      Box(Modifier.padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(accentBrush())
        .drawBehind { drawCircle(Color.White.copy(alpha = .10f), size.height * .9f, Offset(size.width * .95f, -size.height * .15f)) }.padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Column(Modifier.weight(1f)) {
            Text("Ежедневные квесты", style = MaterialTheme.typography.headlineSmall, color = Color.White)
            Text(if (tq.isEmpty()) "Шаблоны задач на каждый день" else "Сегодня ${tq.count { it.done }} из ${tq.size}", color = Color.White.copy(alpha = .85f), style = MaterialTheme.typography.bodyMedium) }
          ProgressRing(tpct, Modifier.size(64.dp), 7.dp, 14) } } }
    item("add") {
      GlassField(n, { n = it }, "Новый квест", Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), onDone = { add() },
        trailing = { IconButton({ add() }) { Icon(Icons.Default.Add, "Создать", tint = cs.primary) } }) }
    if (qs.isEmpty()) item("empty") { Column(Modifier.fillMaxWidth().padding(36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text("⚔", fontSize = 40.sp); Spacer(Modifier.height(8.dp))
      Text("Создайте квест, добавьте в него ежедневные задачи и выберите дни недели.", textAlign = TextAlign.Center, color = cs.onSurface.copy(alpha = .6f)) } }
    itemsIndexed(shown, key = { _, q -> q.id }) { i, q ->
      val drag = reorder.dragKey == q.id
      QuestCard(q, counts[q.id] ?: 0, byQ[q.id] ?: emptyList(), drag && reorder.held, i > 0, i < shown.lastIndex,
        { dx -> move(i, dx) }, reorder.handle(q.id), { open(q.id) }, reorder.root(q.id).then(if (drag) Modifier else Modifier.animateItem())) }
  }
}

@Composable fun QuestCard(q: Quest, count: Int, td: List<Task>, lifted: Boolean, canUp: Boolean, canDown: Boolean, onMove: (Int) -> Unit, grip: Modifier, onOpen: () -> Unit, mod: Modifier) {
  val cs = MaterialTheme.colorScheme; val dn = td.count { it.done }
  Box(mod.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)) {
    Column(Modifier.fillMaxWidth().liftFx(lifted, 24.dp).glass(RoundedCornerShape(24.dp)).tap(onOpen).padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
          Text(q.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
          Text("Задач: $count · цель ${q.threshold}%", style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = .6f)) }
        MoveControls(canUp, canDown, onMove, grip) }
      Column(Modifier.padding(end = 12.dp)) {
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { dayNames.forEachIndexed { i, s -> val on = ((q.days shr i) and 1) == 1
          val bg by animateColorAsState(if (on) cs.primary.copy(alpha = .18f) else cs.onSurface.copy(alpha = .05f), tween(200), label = "dd")
          Text(s, Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(bg).padding(vertical = 5.dp), textAlign = TextAlign.Center, fontSize = 12.sp,
            color = if (on) cs.primary else cs.onSurface.copy(alpha = .4f), fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal) } }
        if (td.isNotEmpty()) { Spacer(Modifier.height(10.dp)); Bar(dn.toFloat() / td.size)
          Text("Сегодня $dn/${td.size}", Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = .6f)) }
      }
    }
  }
}

@Composable fun QuestEditor(d: TodoDao, q: Quest, its: List<QuestItem>, back: () -> Unit) {
  val c = LocalContext.current; val sc = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  val qNow by rememberUpdatedState(q)
  var title by remember(q.id) { mutableStateOf(q.title) }
  var goal by remember(q.id) { mutableFloatStateOf(q.threshold.toFloat()) }
  var m by remember { mutableStateOf("") }; var mg by remember { mutableStateOf("") }; var ren by remember { mutableStateOf<QuestItem?>(null) }; var rt by remember { mutableStateOf("") }
  var rg by remember { mutableStateOf("") }; var rs by remember { mutableStateOf("1") }
  var confirm by remember { mutableStateOf(false) }
  val mine = remember(its, q.id) { its.filter { it.questId == q.id } }
  val lazy = rememberLazyListState()
  val reorder = rememberReorder<QuestItem>(lazy, { it.id }) { l -> sc.launch { reorderItems(c, qNow, l) } }
  val shown = reorder.items(mine)
  BlurWhile(ren != null || confirm)
  // название сохраняется автоматически, чуть позже последнего символа
  LaunchedEffect(title) { if (title.isNotBlank() && title != qNow.title) { delay(500); if (title != qNow.title) d.save(qNow.copy(title = title)) } }
  val leave = { sc.launch { if (title.isNotBlank() && title != qNow.title) d.save(qNow.copy(title = title)); back() }; Unit }
  BackHandler { leave() }
  fun setDays(mask: Int) { sc.launch { d.save(qNow.copy(days = mask)); ensureToday(c) } }
  fun add() { if (m.isNotBlank()) { val t = m; val g = mg.toIntOrNull() ?: 0; m = ""; mg = ""; sc.launch { d.save(QuestItem(questId = q.id, title = t, pos = mine.size, goal = g, step = if (g > 0) autoStep(g) else 1)); ensureToday(c) } } }
  fun move(i: Int, dx: Int) { val j = i + dx; if (j in mine.indices) sc.launch { val l = mine.toMutableList(); l.add(j, l.removeAt(i)); reorderItems(c, qNow, l) } }

  LazyColumn(state = lazy, contentPadding = PaddingValues(bottom = 28.dp)) {
    item("bar") {
      Row(Modifier.padding(start = 6.dp, end = 14.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton({ leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") }
        TextField(title, { title = it }, Modifier.weight(1f), singleLine = true, textStyle = MaterialTheme.typography.titleLarge, placeholder = { Text("Название квеста") },
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), colors = transparentField()) } }
    item("days") {
      Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().glass().padding(16.dp)) {
        Label("Дни недели")
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { dayNames.forEachIndexed { i, s ->
          Pill(((q.days shr i) and 1) == 1, s, { setDays(q.days xor (1 shl i)) }, Modifier.weight(1f), padH = 0.dp, padV = 11.dp) } }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Pill(q.days == 127, "Каждый день", { setDays(127) }, padH = 12.dp, padV = 6.dp)
          Pill(q.days == 31, "Будни", { setDays(31) }, padH = 12.dp, padV = 6.dp)
          Pill(q.days == 96, "Выходные", { setDays(96) }, padH = 12.dp, padV = 6.dp) } } }
    item("goal") {
      Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().glass().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Цель на день", Modifier.weight(1f)); Text("${goal.roundToInt()}%", color = cs.primary, fontWeight = FontWeight.Bold) }
        Slider(goal, { goal = it }, valueRange = 10f..100f, steps = 8, onValueChangeFinished = { sc.launch { d.save(qNow.copy(threshold = goal.roundToInt())) } }) } }
    item("h") { Row(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
      Text("Задачи квеста", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium); Text("${mine.size}", color = cs.onSurface.copy(alpha = .5f)) } }
    if (mine.isEmpty()) item("empty") { Text("Добавьте первую ежедневную задачу ниже", Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center, color = cs.onSurface.copy(alpha = .6f)) }
    itemsIndexed(shown, key = { _, i -> i.id }) { idx, i ->
      val drag = reorder.dragKey == i.id
      Box(reorder.root(i.id).then(if (drag) Modifier else Modifier.animateItem()).fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth().liftFx(drag && reorder.held, 18.dp).glass(RoundedCornerShape(18.dp)).tap { ren = i; rt = i.title; rg = if (i.goal > 0) i.goal.toString() else ""; rs = i.step.toString() }.padding(start = 16.dp, end = 2.dp, top = 2.dp, bottom = 2.dp),
          verticalAlignment = Alignment.CenterVertically) {
          Text("${idx + 1}", Modifier.width(22.dp), color = cs.primary, fontWeight = FontWeight.Bold)
          Text(i.title, Modifier.weight(1f).padding(vertical = 10.dp, horizontal = 4.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
          if (i.goal > 0) Tag("🎯 ${i.goal}", cs.primary)
          MoveControls(idx > 0, idx < shown.lastIndex, { dx -> move(idx, dx) }, reorder.handle(i.id))
          IconButton({ sc.launch { d.delTodayOpen(q.id, today, i.title); d.del(i); refresh(c) } }, Modifier.size(34.dp)) { Icon(Icons.Default.Close, "Удалить задачу", tint = cs.outline, modifier = Modifier.size(20.dp)) }
        } } }
    item("add") {
      Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassField(m, { m = it }, "Задача на каждый день", Modifier.weight(1f), onDone = { add() })
        GlassField(mg, { mg = it.filter(Char::isDigit).take(6) }, "цель", Modifier.width(92.dp), onDone = { add() }, numeric = true)
        IconButton({ add() }) { Icon(Icons.Default.Add, "Добавить", tint = cs.primary) } } }
    item("del") {
      OutlinedButton({ confirm = true }, Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).height(50.dp), shape = RoundedCornerShape(16.dp)) {
        Icon(Icons.Default.Delete, null, tint = cs.error); Spacer(Modifier.width(8.dp)); Text("Удалить квест", color = cs.error) } }
  }
  ren?.let { r -> AlertDialog({ ren = null }, title = { Text("Задача квеста") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
      OutlinedTextField(rt, { rt = it }, singleLine = true, label = { Text("Название") }, shape = RoundedCornerShape(16.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(rg, { rg = it.filter(Char::isDigit).take(6) }, Modifier.weight(1f), singleLine = true, label = { Text("Цель шкалы") }, placeholder = { Text("0 — обычная") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), shape = RoundedCornerShape(16.dp))
        if ((rg.toIntOrNull() ?: 0) > 0) OutlinedTextField(rs, { rs = it.filter(Char::isDigit).take(6) }, Modifier.weight(1f), singleLine = true, label = { Text("Шаг") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), shape = RoundedCornerShape(16.dp)) } } },
    confirmButton = { TextButton({
      val g = rg.toIntOrNull() ?: 0; val st = if (g > 0) (rs.toIntOrNull() ?: autoStep(g)).coerceAtLeast(1) else 1
      if (rt.isNotBlank()) sc.launch {
        if (rt != r.title) d.renameToday(r.questId, today, r.title, rt)
        d.save(r.copy(title = rt, goal = g, step = st)); d.setGoalToday(r.questId, today, rt, g, st); refresh(c) }
      ren = null }) { Text("Сохранить") } },
    dismissButton = { TextButton({ ren = null }) { Text("Отмена") } }) }
  if (confirm) AlertDialog({ confirm = false }, title = { Text("Удалить квест?") }, text = { Text("«${q.title}» и все его задачи будут удалены. Невыполненные задачи на сегодня тоже исчезнут, история статистики сохранится.") },
    confirmButton = { TextButton({ confirm = false; sc.launch { withContext(NonCancellable) {
      d.delTodayAllOpen(q.id, today); d.delItems(q.id); d.delQuest(q.id); refresh(c); back() } } }) { Text("Удалить", color = cs.error) } },
    dismissButton = { TextButton({ confirm = false }) { Text("Отмена") } })
}

@Composable fun StepBtn(step: Int, onClick: () -> Unit) {
  Text("+$step", Modifier.padding(end = 6.dp).pressable(onClick).clip(RoundedCornerShape(18.dp)).background(accentBrush()).padding(horizontal = 14.dp, vertical = 8.dp),
    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
}

/** Настройка шкалы в карточке задачи: цель, шаг и быстрые кнопки прогресса. */
@Composable fun CounterCard(t: Task, onChange: (Task) -> Unit) {
  val cs = MaterialTheme.colorScheme
  var gt by remember { mutableStateOf(if (t.goal > 0) t.goal.toString() else "") }
  var st by remember { mutableStateOf(t.step.toString()) }
  val num = KeyboardOptions(keyboardType = KeyboardType.Number)
  Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 8.dp)) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
      Column(Modifier.weight(1f)) { Text("Шкала"); Text("Например, 40 отжиманий — заполняйте по частям", style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = .6f)) }
      Switch(t.goal > 0, { on -> if (on) { gt = "10"; st = autoStep(10).toString(); onChange(t.copy(goal = 10, step = autoStep(10), progress = 0)) } else { gt = ""; onChange(t.copy(goal = 0, progress = 0, step = 1)) } }) }
    AnimatedVisibility(t.goal > 0) {
      Column(Modifier.padding(bottom = 8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(gt, { v -> gt = v.filter(Char::isDigit).take(6); val g = gt.toIntOrNull() ?: 0; if (g > 0) onChange(t.copy(goal = g, progress = minOf(t.progress, g))) },
            Modifier.weight(1f), singleLine = true, label = { Text("Цель") }, keyboardOptions = num, shape = RoundedCornerShape(16.dp))
          OutlinedTextField(st, { v -> st = v.filter(Char::isDigit).take(6); val s2 = st.toIntOrNull() ?: 0; if (s2 > 0) onChange(t.copy(step = s2)) },
            Modifier.weight(1f), singleLine = true, label = { Text("Шаг") }, keyboardOptions = num, shape = RoundedCornerShape(16.dp)) }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Bar(t.progress.toFloat() / maxOf(1, t.goal), Modifier.weight(1f), 8.dp); Spacer(Modifier.width(10.dp))
          Text("${t.progress}/${t.goal}", color = cs.primary, fontWeight = FontWeight.Bold) }
        Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Pill(false, "−${t.step}", { onChange(t.copy(progress = (t.progress - t.step).coerceAtLeast(0))) })
          Pill(false, "+1", { onChange(t.copy(progress = (t.progress + 1).coerceAtMost(t.goal))) })
          Pill(false, "+${t.step}", { onChange(t.copy(progress = (t.progress + t.step).coerceAtMost(t.goal))) })
          Pill(false, "Заполнить", { onChange(t.copy(progress = t.goal)) })
          Pill(false, "Сброс", { onChange(t.copy(progress = 0)) }) }
      }
    }
  }
}

@Composable fun AddBar(onAdd: (String, Int) -> Unit) {
  val cs = MaterialTheme.colorScheme
  var txt by remember { mutableStateOf("") }; var cnt by remember { mutableStateOf(false) }; var g by remember { mutableStateOf("") }
  val goal = g.toIntOrNull() ?: 0
  val ok = txt.isNotBlank() && (!cnt || goal > 0)
  fun go() { if (ok) { onAdd(txt, if (cnt) goal else 0); txt = "" } }
  Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth().glass(RoundedCornerShape(30.dp), strong = true)) {
    AnimatedVisibility(cnt) {
      Row(Modifier.padding(start = 18.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Цель шкалы (например, 40)", Modifier.weight(1f), color = cs.onSurface.copy(alpha = .7f), fontSize = 14.sp)
        OutlinedTextField(g, { g = it.filter(Char::isDigit).take(6) }, Modifier.width(104.dp), singleLine = true, shape = RoundedCornerShape(14.dp),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) } }
    Row(Modifier.padding(start = 6.dp, end = 6.dp, top = 2.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
      Box(Modifier.size(40.dp).clip(CircleShape).background(if (cnt) cs.primary.copy(alpha = .2f) else Color.Transparent).clickable { cnt = !cnt }, contentAlignment = Alignment.Center) { Text("🎯", fontSize = 18.sp) }
      TextField(txt, { txt = it }, Modifier.weight(1f), placeholder = { Text(if (cnt) "Задача со шкалой" else "Добавить задачу") }, singleLine = true,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { go() }), colors = transparentField())
      val sa by animateFloatAsState(if (ok) 1f else .45f, tween(200), label = "sa")
      Box(Modifier.size(44.dp).graphicsLayer { alpha = sa; val s = .9f + .1f * sa; scaleX = s; scaleY = s }.clip(CircleShape).background(accentBrush())
        .clickable(enabled = ok) { go() }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, "Добавить", tint = Color.White) }
    }
  }
}
