# Glance создаёт ActionCallback по имени класса — без этого правила R8 его удалит и кнопки виджета перестанут работать
-keep class * implements androidx.glance.appwidget.action.ActionCallback { <init>(); }
