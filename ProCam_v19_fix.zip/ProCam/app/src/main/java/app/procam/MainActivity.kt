package app.procam

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Рамка записываемой (активной) области внутри полного кадра при включённой стабилизации: вне рамки — затемнение. */
class EisFrameView(c: Context) : View(c) {
    private var q: FloatArray? = null
    private val density = resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x88000000.toInt(); style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f * density }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA000000.toInt(); style = Paint.Style.STROKE; strokeWidth = 4.5f * density }
    private val quad = Path()
    private val outer = Path()

    fun set(c: FloatArray?) { q = c; invalidate() }

    override fun onDraw(cv: Canvas) {
        val a = q ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        quad.reset()
        quad.moveTo(a[0] * w, a[1] * h)
        quad.lineTo(a[2] * w, a[3] * h)
        quad.lineTo(a[4] * w, a[5] * h)
        quad.lineTo(a[6] * w, a[7] * h)
        quad.close()
        outer.reset()
        outer.fillType = Path.FillType.EVEN_ODD
        outer.addRect(0f, 0f, w, h, Path.Direction.CW)
        outer.addPath(quad)
        cv.drawPath(outer, dim)
        cv.drawPath(quad, shadow)
        cv.drawPath(quad, line)
    }
}

/** Простая гистограмма яркости (64 столбца, корневая шкала). */
class HistogramView(c: Context) : View(c) {
    private var bins = IntArray(64)
    private val p = Paint().apply { color = 0xCCFFFFFF.toInt() }
    private val bg = Paint().apply { color = 0x66000000 }

    fun set(b: IntArray) { bins = b; invalidate() }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val mx = (bins.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val bw = width / 64f
        for (i in 0 until 64) {
            val h = sqrt(bins[i] / mx) * height
            cv.drawRect(i * bw, height - h, (i + 1) * bw, height.toFloat(), p)
        }
    }
}

class MainActivity : Activity(), SurfaceHolder.Callback, CameraEngine.Listener {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val minRailDp = 72                    // dp, минимальная ширина боковых панелей (слева и справа от превью)
    private var railPx = 0                        // px, фактическая ширина панелей: всё, что шире 16:9, отдаём им
    private val tabLut = 2
    private val tabStab = 4
    private val tabCamera = 5
    private var syncStatus = ""
    private val tabNames = listOf("Запись", "Цвет", "LUT", "Монитор", "Стабилизация", "Камера", "Интерфейс", "Обновления", "О приложении")
    /** Порядок и группы в списке разделов: индексы совпадают с tabNames. */
    private val tabGroups = listOf("СЪЁМКА" to listOf(0, 5), "ИЗОБРАЖЕНИЕ" to listOf(1, 2, 4), "ЭКРАН" to listOf(3, 6), "ПРИЛОЖЕНИЕ" to listOf(7, 8))
    private val amber = 0xFFFFFFFF.toInt()

    private lateinit var engine: CameraEngine
    private lateinit var root: FrameLayout
    private lateinit var host: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var gridView: GridView
    private lateinit var eisFrameView: EisFrameView
    private lateinit var levelView: LevelView
    private lateinit var statusHud: TextView
    private lateinit var hud: TextView
    private lateinit var expHud: TextView
    private lateinit var recHud: TextView
    private lateinit var hist: HistogramView
    private lateinit var panel: LinearLayout
    private lateinit var leftRail: LinearLayout     // левая панель: быстрые переключатели
    private lateinit var leftScroll: ScrollView
    private lateinit var side: LinearLayout         // правая панель: объектив, зум, запись, ручные, меню
    private lateinit var recBtn: Button
    private lateinit var zoomSlider: ZoomSlider
    private var zoomPresets: List<Float> = emptyList()
    private var zoomNear = -1
    private var menuBtn: Button? = null
    private var menuAnim: Animator? = null
    private val menuSideDp = 200
    private var recDraw: RecDrawable? = null
    private var recAnim: ValueAnimator? = null
    private var recT = 0f                          // 0 — круг (ожидание), 1 — скруглённый квадрат (запись)
    private val recSizeDp = 76
    private val pauseSizeDp = 48
    private lateinit var lutRibbon: LutRibbon
    private val tabMonitor = 3
    private var lastZoomPush = 0L
    private lateinit var isoBar: SeekBar
    private lateinit var shutBar: SeekBar
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar
    // меню
    private lateinit var menu: FrameLayout
    private lateinit var menuBody: LinearLayout
    private lateinit var menuScroll: ScrollView
    private lateinit var menuTabsBox: LinearLayout
    private lateinit var menuSheet: LinearLayout
    private val tabButtons = ArrayList<Button>()
    private var menuTab = 0

    private val main = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()       // быстрые кнопки
    private val menuRefreshers = ArrayList<() -> Unit>()   // строки текущей вкладки меню
    private var lenses: List<Lens> = emptyList()
    private var shutters: List<Int> = emptyList()
    private var ready = false
    private var recording = false
    private var recStart = 0L
    private var pausedTotal = 0L
    private var pauseSince = 0L
    private var isPaused = false
    private lateinit var pauseBtn: ImageView
    private lateinit var pauseIcon: PauseIcon
    private var gridIdx = 1
    private var guideIdx = 0

    private val lutPicker = 44
    private val maxLutBytes = 40L * 1024 * 1024
    private val prefs by lazy { getSharedPreferences("procam", MODE_PRIVATE) }
    private val lutLib by lazy { LutLibrary(prefs) }
    private val lutCache = LinkedHashMap<String, CubeLut>()   // последние 2 разобранных LUT — переключение мгновенное
    @Volatile private var pendingLut: String? = null

    private val density: Float get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    // Строка состояния: короткий журнал того, что делает приложение (человеческим текстом), в правом нижнем углу.
    private class LogLine(val at: Long, val text: String)
    private val logLines = ArrayList<LogLine>()
    private var logView: TextView? = null
    private val logTick = Runnable { renderLog() }
    private val logTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
    private val logTtlMs = 9000L
    private val logMax = 2

    /** Записать действие приложения в журнал (можно вызывать из любого потока). */
    private fun appLog(msg: String) {
        runOnUiThread {
            logLines.add(LogLine(System.currentTimeMillis(), msg))
            while (logLines.size > logMax) logLines.removeAt(0)
            renderLog()
        }
    }

    private fun renderLog() {
        val v = logView ?: return
        val now = System.currentTimeMillis()
        logLines.removeAll { now - it.at > logTtlMs }
        val show = prefs.getBoolean("status_log", true) && logLines.isNotEmpty()
        v.removeCallbacks(logTick)
        if (!show) { v.visibility = View.GONE; return }
        v.text = logLines.joinToString("\n") { logTime.format(java.util.Date(it.at)) + "  " + it.text }
        v.visibility = View.VISIBLE
        v.postDelayed(logTick, 1000)
    }

    // Собственные всплывающие сообщения приложения (вместо системных Toast): плашка сверху по центру, поверх всего интерфейса.
    private var noteView: TextView? = null
    private val noteHide = Runnable {
        noteView?.animate()?.alpha(0f)?.translationY(dp(6).toFloat())?.setDuration(220)
            ?.withEndAction { noteView?.visibility = View.GONE }?.start()
    }

    private fun showNote(msg: String, ms: Long, error: Boolean = false) {
        runOnUiThread {
            if (!::root.isInitialized) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); return@runOnUiThread }
            val v = noteView ?: TextView(this).apply {
                textSize = 13f
                gravity = Gravity.CENTER
                maxLines = 4
                maxWidth = dp(460)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                elevation = dp(8).toFloat()
                visibility = View.GONE
                isClickable = false
                noteView = this
                root.addView(this, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(66) })
            }
            v.background = GradientDrawable().apply {
                cornerRadius = dp(if (Ui.glass) 22 else 14).toFloat()
                setColor(if (Ui.glass) 0xD91C1C1E.toInt() else 0xF21C1C1E.toInt())
                setStroke(dp(1), if (error) 0xFFFFFFFF.toInt() else if (Ui.glass) 0x3DFFFFFF else amber)
            }
            v.setTextColor(Ui.text)
            v.text = msg
            v.removeCallbacks(noteHide)
            v.animate().cancel()
            v.visibility = View.VISIBLE
            v.alpha = 0f
            v.translationY = dp(8).toFloat()
            v.bringToFront()
            v.animate().alpha(1f).translationY(0f).setDuration(180).start()
            v.postDelayed(noteHide, ms)
        }
    }

    private fun toast(s: String) = showNote(s, 2200)
    private fun toastLong(s: String) = showNote(s, 4500)

    /** Во время записи смены маршрута запрещены: restart() остановил бы запись. */
    private fun idle(block: () -> Unit) {
        if (recording) toast("Сначала остановите запись") else block()
    }

    // ------------------------------------------------------------ LUT: библиотека

    private fun activeLutName(): String = lutLib.active()?.name ?: "нет"

    private fun pickLutFiles() = idle {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, lutPicker)
    }

    @Deprecated("Legacy SAF result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != lutPicker || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        // Без постоянного доступа сохранённый URI после перезапуска приложения уже не откроется.
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        }
        importLuts(uris)
    }

    private fun displayName(u: Uri): String {
        var n: String? = null
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        } catch (e: Exception) { }
        return (n ?: u.lastPathSegment ?: "LUT").removeSuffix(".cube").removeSuffix(".CUBE")
    }

    /** Разбор .cube (LUT 65³ — сотни мс и десятки МБ): только в фоне. */
    private fun parseLut(uri: Uri): CubeLut {
        val len = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        if (len > maxLutBytes) error("файл слишком большой для .cube (${len / 1_000_000} МБ)")
        return contentResolver.openInputStream(uri)?.use { input ->
            CubeLutReader.read(BufferedReader(InputStreamReader(input, Charsets.UTF_8)))
        } ?: error("не удалось открыть файл")
    }

    private fun importLuts(uris: List<Uri>) {
        toast("Читаю LUT: ${uris.size}…")
        Thread({
            val ok = ArrayList<Pair<LutEntry, CubeLut?>>()
            val errors = ArrayList<String>()
            for (u in uris) {
                val name = displayName(u)
                try {
                    val lut = parseLut(u)
                    // Объект LUT оставляем только у первого файла (его можно сразу включить) — остальные не держим в памяти.
                    ok.add(LutEntry(name, u.toString(), lut.size) to (if (ok.isEmpty()) lut else null))
                } catch (e: OutOfMemoryError) {
                    errors.add("$name: недостаточно памяти")
                } catch (e: Exception) {
                    errors.add("$name: ${e.message ?: "неверный .cube"}")
                }
            }
            runOnUiThread { if (!isDestroyed) onLutsImported(ok, errors, uris.size == 1) }
        }, "lut-import").start()
    }

    private fun onLutsImported(ok: List<Pair<LutEntry, CubeLut?>>, errors: List<String>, single: Boolean) {
        ok.forEach { lutLib.add(it.first) }
        if (errors.isNotEmpty()) toastLong("Не загружено:\n" + errors.joinToString("\n"))
        else if (ok.isNotEmpty()) toast("Добавлено LUT: ${ok.size}")
        val first = ok.firstOrNull()
        val lut = first?.second
        if (first != null && lut != null && (single || lutLib.activeUri == null)) {
            cacheLut(first.first.uri, lut)
            applyLut(first.first, lut, true)
        } else {
            refreshAll()
        }
        if (::lutRibbon.isInitialized && lutRibbon.opened) lutRibbon.rebuild()
    }

    private fun cacheLut(uri: String, lut: CubeLut) {
        lutCache[uri] = lut
        while (lutCache.size > 2) lutCache.remove(lutCache.keys.first())
    }

    /** Выбрать LUT из списка (null = без LUT). */
    private fun selectLut(e: LutEntry?, fromUser: Boolean = true, silent: Boolean = false) {
        val routeChange = engine.cfg.lutMode == 2 && ((lutLib.activeUri == null) != (e == null))
        if (recording && routeChange) { toast("Сначала остановите запись"); return }
        if (e == null) {
            pendingLut = null
            lutLib.setActive(null)
            engine.setLut(null)
            engine.lutConfigChanged()
            appLog("LUT выключен")
            refreshAll()
            return
        }
        val cached = lutCache[e.uri]
        if (cached != null) { applyLut(e, cached, fromUser); return }
        pendingLut = e.uri
        appLog("Загружаю LUT «${e.name}»…")
        if (!silent) toast("Загрузка LUT «${e.name}»…")
        Thread({
            var lut: CubeLut? = null
            var err: String? = null
            try {
                lut = parseLut(Uri.parse(e.uri))
            } catch (x: OutOfMemoryError) {
                err = "недостаточно памяти"
            } catch (x: Exception) {
                err = x.message ?: "неверный .cube"
            }
            val result = lut
            val message = err
            runOnUiThread {
                if (isDestroyed || pendingLut != e.uri) return@runOnUiThread   // пользователь уже выбрал другой
                pendingLut = null
                if (result != null) {
                    cacheLut(e.uri, result)
                    applyLut(e, result, fromUser)
                } else {
                    if (lutLib.activeUri == e.uri) lutLib.setActive(null)
                    toastLong("LUT «${e.name}» недоступен: ${message ?: "ошибка"}. Его можно убрать из списка (✕).")
                    refreshAll()
                }
            }
        }, "lut-load").start()
    }

    private fun applyLut(e: LutEntry, lut: CubeLut, fromUser: Boolean) {
        if (e.size == 0) lutLib.add(e.copy(size = lut.size))
        lutLib.setActive(e.uri)
        if (fromUser && engine.cfg.lutMode == 0) { engine.cfg.lutMode = 1; saveLutPrefs() }
        engine.setLut(lut)
        engine.lutConfigChanged()
        appLog("LUT «${e.name}» применён")
        refreshAll()
    }

    private fun deleteLut(e: LutEntry) = idle {
        lutCache.remove(e.uri)
        try { contentResolver.releasePersistableUriPermission(Uri.parse(e.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (x: Exception) { }
        val wasActive = lutLib.activeUri == e.uri
        lutLib.remove(e.uri)
        if (wasActive) { engine.setLut(null); engine.lutConfigChanged() }
        if (::lutRibbon.isInitialized && lutRibbon.opened) lutRibbon.rebuild()
        refreshAll()
    }

    private fun saveLutPrefs() {
        prefs.edit().putInt("lut_mode", engine.cfg.lutMode).putBoolean("lut_in_log", engine.cfg.lutInLog).apply()
    }

    private fun setGrid(i: Int) {
        gridIdx = i.coerceIn(0, Grid.values().size - 1)
        gridView.grid = Grid.values()[gridIdx]
        prefs.edit().putInt("grid", gridIdx).apply()
        appLog("Сетка: ${Grid.values()[gridIdx].label}")
    }

    private fun setGuide(i: Int) {
        guideIdx = i.coerceIn(0, Guide.values().size - 1)
        gridView.guide = Guide.values()[guideIdx]
        prefs.edit().putInt("guide", guideIdx).apply()
        appLog("Рамка: ${Guide.values()[guideIdx].label}")
    }

    private fun setOpenGate(v: Boolean) = idle {
        val cfg = engine.cfg
        if (v && !engine.gateAvailable()) {
            toastLong("Open Gate недоступен: эта камера не отдаёт для видео кадр шире 16:9. Попробуйте другой объектив (кнопка с мм).")
        } else if (cfg.openGate != v) {
            cfg.openGate = v
            prefs.edit().putBoolean("gate", v).apply()
            engine.restart()
        }
    }

    private fun setLogEv(i: Int) {
        engine.cfg.logEv = i.coerceIn(0, 3)
        prefs.edit().putInt("log_ev", engine.cfg.logEv).apply()
        engine.update()
    }

    /** Соотношение сторон кадра → сетка/рамка/тап-фокус считаются по реальному прямоугольнику картинки. */
    private fun applyContentAspect() {
        val s = engine.cfg.size
        gridView.contentAspect = s.width.toFloat() / s.height
    }

    // ------------------------------------------------------------ жизненный цикл

    /** Повороты экрана landscape <-> reverse landscape: превью и тап-фокус должны следовать сразу. */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { if (ready) engine.setRotation(rotationDeg()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Ui.density = resources.displayMetrics.density
        Ui.style = if (prefs.getInt("ui_style", 1) == 1) UiStyle.GLASS else UiStyle.MATERIAL
        buildBase()
        setGrid(prefs.getInt("grid", 1))
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) initEngine()
        else requestPermissions(need, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!ready) initEngine()
        } else {
            showNote("Нужен доступ к камере", 4500, error = true)
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    /** Кнопки громкости — старт/стоп записи (удобно, когда телефон в риге и до экрана не дотянуться). */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && ready) {
            if (event.repeatCount == 0) engine.toggleRecord()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::menu.isInitialized && menuVisible()) closeMenu() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
        if (ready && surface.holder.surface.isValid) startEngine()
        if (::levelView.isInitialized) levelView.resume()
        main.removeCallbacks(statusRunnable)
        statusRunnable.run()
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(statusRunnable)
        if (::levelView.isInitialized) levelView.suspend()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        if (ready) engine.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::lutRibbon.isInitialized) lutRibbon.release()
        if (ready) engine.release()
    }

    // ------------------------------------------------------------ поверхность

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { if (ready) startEngine() }
    override fun surfaceDestroyed(holder: SurfaceHolder) { if (ready) engine.stop() }

    @Suppress("DEPRECATION")
    private fun rotationDeg(): Int {
        return when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    }

    private fun startEngine() { engine.start(surface.holder.surface, rotationDeg()) }

    // ------------------------------------------------------------ UI: каркас

    private fun tv(size: Float, gravity: Int, l: Int, t: Int, r: Int, b: Int): TextView {
        val v = TextView(this)
        v.setTextColor(Color.WHITE)
        v.textSize = size
        v.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        v.setPadding(dp(7), dp(2), dp(7), dp(2))
        v.background = Ui.bg(Ui.Kind.HUD)
        v.visibility = View.GONE        // плашка появляется, только когда есть текст
        v.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { v.visibility = if (e.isNullOrEmpty()) View.GONE else View.VISIBLE }
        })
        host.addView(v, FrameLayout.LayoutParams(WRAP, WRAP, gravity).apply { setMargins(l, t, r, b) })
        return v
    }

    private fun buildBase() {
        root = FrameLayout(this)
        root.setBackgroundColor(Ui.root)
        host = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.setFixedSize(1280, 720)
        surface.holder.addCallback(this)
        host.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH))

        eisFrameView = EisFrameView(this)
        host.addView(eisFrameView, FrameLayout.LayoutParams(MATCH, MATCH))

        gridView = GridView(this)
        host.addView(gridView, FrameLayout.LayoutParams(MATCH, MATCH))
        levelView = LevelView(this)
        levelView.visibility = View.GONE
        host.addView(levelView, FrameLayout.LayoutParams(MATCH, MATCH))

        hist = HistogramView(this)
        host.addView(hist, FrameLayout.LayoutParams(dp(150), dp(52), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(8), 0) })
        hud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(6), 0, 0)
        recHud = tv(14f, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, dp(6), 0, 0)
        expHud = tv(12f, Gravity.BOTTOM or Gravity.END, 0, 0, dp(8), dp(6))
        statusHud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(34), 0, 0)

        // строка состояния: маленький текст в левом нижнем углу превью, сама гаснет через несколько секунд
        logView = TextView(this).apply {
            textSize = 11f
            setTextColor(Ui.text)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            maxWidth = dp(300)
            setLineSpacing(0f, 1.05f)
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            setPadding(dp(4), 0, dp(4), 0)
            visibility = View.GONE
            isClickable = false
        }
        host.addView(logView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(6), 0, 0, dp(6)) })

        // ручные настройки: тонкая полоса вверху превью (внизу — зум), показывается по кнопке «РУЧН.»
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = Ui.bg(Ui.Kind.HUD)
        panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        panel.visibility = View.GONE
        host.addView(panel, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { setMargins(dp(8), dp(8), dp(140), 0) })

        // превью по центру; по бокам — две панели, которые занимают всё, что остаётся от 16:9 (пустых полос нет)
        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))

        // левая панель: кнопки не мельче 44 dp; на очень низком экране панель прокручивается, а не сжимает кнопки
        leftRail = LinearLayout(this)
        leftRail.orientation = LinearLayout.VERTICAL
        leftRail.setPadding(dp(5), dp(4), dp(5), dp(4))
        leftScroll = ScrollView(this)
        leftScroll.isFillViewport = true
        leftScroll.isVerticalScrollBarEnabled = false
        leftScroll.overScrollMode = View.OVER_SCROLL_NEVER
        leftScroll.setBackgroundColor(Ui.dock)
        leftScroll.addView(leftRail, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(leftScroll, FrameLayout.LayoutParams(dp(minRailDp), MATCH, Gravity.START))

        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.setBackgroundColor(Ui.dock)
        side.setPadding(dp(5), dp(4), dp(5), dp(4))
        root.addView(side, FrameLayout.LayoutParams(dp(minRailDp), MATCH, Gravity.END))

        lutRibbon = LutRibbon(
            this,
            entries = { lutLib.items },
            activeUri = { lutLib.activeUri },
            bakeOn = { ::engine.isInitialized && engine.cfg.lutMode == 2 },
            isRecording = { recording },
            inLog = { if (::engine.isInitialized) engine.cfg.lutInLog else true },
            curve = { if (::engine.isInitialized) engine.cfg.curve else Curve.SLOG3 },
            parse = { uri -> try { parseLut(Uri.parse(uri)) } catch (e: Exception) { null } },
            onPick = { e -> selectLut(e, fromUser = true, silent = true) },
            onBake = { v -> setLutBake(v); lutRibbon.refresh() },
            onAdd = { pickLutFiles() },
            onClose = { lutRibbon.close(); renderLog() }
        )
        // лента LUT — временная: открывается по кнопке LUT над нижним краем превью
        root.addView(lutRibbon, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(minRailDp + 8), 0, dp(minRailDp + 8), dp(8))
        })

        buildMenuShell()

        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fit(r - l, b - t) }
        setContentView(root)
    }

    /**
     * Раскладка: превью 16:9 по центру, максимально большое. Что осталось по бокам — две равные панели
     * (левая — быстрые переключатели, правая — управление съёмкой). Меню — боковой лист поверх части превью,
     * правая панель с кнопкой записи остаётся доступной.
     */
    private fun fit(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val minRail = dp(minRailDp)
        var pw = h * 16 / 9
        if (pw > w - 2 * minRail) pw = w - 2 * minRail
        if (pw <= 0) return
        val ph = pw * 9 / 16
        val rail = ((w - pw) / 2).coerceAtLeast(minRail)
        val lp = host.layoutParams as FrameLayout.LayoutParams
        if (lp.width != pw || lp.height != ph) {
            lp.width = pw
            lp.height = ph
            host.layoutParams = lp
        }
        if (rail != railPx) {
            railPx = rail
            val l = leftScroll.layoutParams as FrameLayout.LayoutParams
            l.width = rail; leftScroll.layoutParams = l
            val r = side.layoutParams as FrameLayout.LayoutParams
            r.width = rail; side.layoutParams = r
            val rb = lutRibbon.layoutParams as FrameLayout.LayoutParams
            rb.leftMargin = rail + dp(8); rb.rightMargin = rail + dp(8); lutRibbon.layoutParams = rb
            placeRec()
        }
        // меню — на весь экран; колонка настроек не шире 640 dp, чтобы строки не растягивались на широких экранах
        val bodyW = (w - dp(menuSideDp) - dp(48)).coerceIn(dp(280), dp(640))
        val bl = menuBody.layoutParams as FrameLayout.LayoutParams
        if (bl.width != bodyW) { bl.width = bodyW; menuBody.layoutParams = bl }
    }

    /** Кнопка записи стоит по центру высоты; её центр — на 10 dp внутрь превью от границы правой панели. */
    private fun placeRec() {
        if (!::recBtn.isInitialized) return
        val rail = if (railPx > 0) railPx else dp(minRailDp)
        val lp = recBtn.layoutParams as FrameLayout.LayoutParams
        val rm = rail + dp(10) - dp(recSizeDp) / 2
        if (lp.rightMargin != rm) { lp.rightMargin = rm; recBtn.layoutParams = lp }
        if (::pauseBtn.isInitialized) {
            val pl = pauseBtn.layoutParams as FrameLayout.LayoutParams
            val pm = rm + (dp(recSizeDp) - dp(pauseSizeDp)) / 2
            if (pl.rightMargin != pm) { pl.rightMargin = pm; pauseBtn.layoutParams = pl }
            pauseBtn.translationY = -(dp(recSizeDp) / 2f + dp(10) + dp(pauseSizeDp) / 2f)
        }
    }

    /** Затвор как в камере iPhone: белое кольцо и красная капля; при записи капля «перетекает» в скруглённый квадрат. */
    private fun recDrawable(on: Boolean): android.graphics.drawable.Drawable {
        val d = RecDrawable(density)
        d.color = Ui.rec
        recDraw = d
        recT = if (on) 1f else 0f
        d.t = recT
        return d
    }

    private fun applyRecT(t: Float) { recDraw?.t = t }

    private fun morphRec(on: Boolean) {
        recAnim?.cancel()
        val from = recT
        val to = if (on) 1f else 0f
        if (!animsOn() || recDraw == null) { recT = to; applyRecT(to); return }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 560
        a.interpolator = Spring(6.5f, 11f)
        a.addUpdateListener { recT = from + (to - from) * (it.animatedValue as Float); applyRecT(recT) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) { if (recAnim === a) { recT = to; applyRecT(to) } }
        })
        recAnim = a
        a.start()
    }

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoom(engine.cfg.zoom * d.scaleFactor); return true }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val r = gridView.contentRect()
                if (!r.isEmpty && r.contains(e.x, e.y)) engine.tapFocus((e.x - r.left) / r.width(), (e.y - r.top) / r.height())
                return true
            }
            override fun onLongPress(e: MotionEvent) { engine.clearFocus() }
        })
        host.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) gd.onTouchEvent(ev)
            true
        }
    }

    // ------------------------------------------------------------ UI: быстрые кнопки

    private fun refreshChips() {
        refreshers.toList().forEach { it() }
        menuRefreshers.toList().forEach { it() }
    }

    /** Перерисовать состояние; если открыт список LUT — пересобрать его. */
private fun refreshAll() {
        if (::lutRibbon.isInitialized && lutRibbon.opened) lutRibbon.refresh()
        if (::menu.isInitialized && menuVisible() && menuTab == tabLut) showTab(tabLut, true) else refreshChips()
    }

    private fun styled(b: Button, activeFn: () -> Boolean, textFn: () -> String) {
        b.setAllCaps(false); b.textSize = 11f
        b.minWidth = 0; b.minimumWidth = 0; b.minHeight = 0; b.minimumHeight = 0
        b.setPadding(dp(12), dp(5), dp(12), dp(5))
        b.elevation = dp(if (Ui.glass) 3 else 1).toFloat()
        pressFx(b)
        // refreshChips вызывается часто (зум щипком, слайдеры): трогаем вид только если состояние изменилось
        var lastOn: Boolean? = null
        var lastText: String? = null
        refreshers.add {
            val t = textFn()
            if (t != lastText) { b.text = t; lastText = t }
            val on = activeFn()
            if (on != lastOn) {
                lastOn = on
                b.background = Ui.ripple(Ui.bg(Ui.Kind.CHIP, on))
                b.setTextColor(if (on) Ui.onAccent else Ui.text)
            }
        }
    }

    /** Анимации выключены в системе («Удалить анимацию» / масштаб 0) — тогда всё меняется мгновенно. */
    private fun animsOn(): Boolean = try {
        Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
    } catch (e: Exception) { true }

    private val dropAnims = HashMap<View, ValueAnimator>()

    /**
     * Нажатие как по капле воды: форма сплющивается (шире и ниже, объём сохраняется), на отпускание
     * возвращается пружиной с затухающими колебаниями. Сам клик не перехватывается.
     */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun pressFx(v: View, depth: Float = 0.94f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dropAnims.remove(view)?.cancel()
                    if (animsOn()) view.animate().scaleX(1f + (1f - depth) * 0.9f).scaleY(depth)
                        .setDuration(80).setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (animsOn()) releaseDrop(view)
            }
            false
        }
    }

    private fun releaseDrop(view: View) {
        view.animate().cancel()
        val sx = view.scaleX
        val sy = view.scaleY
        dropAnims.remove(view)?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 420
        a.interpolator = Spring(5.5f, 13f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            view.scaleX = sx + (1f - sx) * f
            view.scaleY = sy + (1f - sy) * f
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (dropAnims[view] === a) { dropAnims.remove(view); view.scaleX = 1f; view.scaleY = 1f }
            }
        })
        dropAnims[view] = a
        a.start()
    }

    private val hiding = HashSet<View>()

    private fun showAnim(v: View, fromX: Float, fromY: Float) {
        hiding.remove(v)
        v.animate().cancel()
        v.visibility = View.VISIBLE
        if (!animsOn()) { v.alpha = 1f; v.translationX = 0f; v.translationY = 0f; return }
        v.alpha = 0f; v.translationX = fromX; v.translationY = fromY
        v.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideAnim(v: View, toX: Float, toY: Float) {
        if (v.visibility != View.VISIBLE) return
        if (!animsOn()) { v.visibility = View.GONE; return }
        hiding.add(v)
        v.animate().cancel()
        v.animate().alpha(0f).translationX(toX).translationY(toY).setDuration(160).setInterpolator(AccelerateInterpolator())
            .withEndAction {
                if (hiding.remove(v)) { v.visibility = View.GONE; v.alpha = 1f; v.translationX = 0f; v.translationY = 0f }
            }.start()
    }

    private fun setPanel(show: Boolean) {
        if (show) { if (panel.visibility != View.VISIBLE || hiding.contains(panel)) showAnim(panel, 0f, -dp(24).toFloat()) }
        else hideAnim(panel, 0f, -dp(24).toFloat())
    }

    /**
     * Кнопка боковой панели: две строки (название / состояние). Высота — по весу, поэтому панель всегда
     * заполнена целиком, без пустых мест, на любом экране. Тап — переключить, долгое нажатие — открыть настройки.
     */
    private fun railBtn(parent: LinearLayout, title: String, state: () -> String, active: () -> Boolean,
                        onLong: (() -> Unit)? = null, weight: Float = 1f, onClick: () -> Unit): Button {
        val b = Button(this)
        styled(b, active) { val st = state(); if (st.isEmpty()) title else title + "\n" + st }
        b.setPadding(dp(2), dp(2), dp(2), dp(2))
        b.textSize = 11f
        b.maxLines = 2
        b.setLineSpacing(0f, 0.95f)
        b.minHeight = dp(44); b.minimumHeight = dp(44)          // цель касания не меньше 44 dp
        b.setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onClick(); refreshChips() }
        if (onLong != null) b.setOnLongClickListener { it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onLong(); refreshChips(); true }
        parent.addView(b, LinearLayout.LayoutParams(MATCH, 0, weight).apply { setMargins(0, dp(2), 0, dp(2)) })
        return b
    }

    private fun zebraIdx(): Int {
        val c = engine.cfg
        return if (!c.zebra) 0 else if (c.zebraLevel < 0.93f) 1 else if (c.zebraLevel < 0.97f) 2 else 3
    }

    private fun setZebra(i: Int) {
        val c = engine.cfg
        c.zebra = i != 0
        if (i == 1) c.zebraLevel = 0.90f else if (i == 2) c.zebraLevel = 0.95f else if (i == 3) c.zebraLevel = 1.0f
        engine.update()
    }

    /** Левая панель: всё, что нужно во время съёмки, под рукой одним тапом. Остальное — в меню с описаниями. */
private fun buildTools() {
        val cfg = engine.cfg
        val r = leftRail
        railBtn(r, "ФОНАРИК", { if (cfg.torch) "вкл" else "выкл" }, { cfg.torch }, { openMenu(tabCamera) }) { cfg.torch = !cfg.torch; engine.update() }
        railBtn(r, "ЗЕБРА", { if (cfg.zebra) "${(cfg.zebraLevel * 100).roundToInt()}%" else "выкл" }, { cfg.zebra }, { openMenu(tabMonitor) }) { setZebra((zebraIdx() + 1) % 4) }
        railBtn(r, "ПИКИНГ", { if (cfg.peaking) "вкл" else "выкл" }, { cfg.peaking }, { openMenu(tabMonitor) }) { cfg.peaking = !cfg.peaking; engine.update() }
        railBtn(r, "СЕТКА", { Grid.values()[gridIdx].label }, { gridIdx != 0 }, { openMenu(tabMonitor) }) { setGrid((gridIdx + 1) % Grid.values().size) }
        railBtn(r, "УРОВЕНЬ", { if (levelView.active) "вкл" else "выкл" }, { levelView.active }, { openMenu(tabMonitor) }) { toggleLevel(!levelView.active) }
        railBtn(r, "LUT", { if (lutLib.activeUri != null && cfg.lutMode != 0) activeLutName().take(9) else "выкл" },
            { lutLib.activeUri != null && cfg.lutMode != 0 }, { openMenu(tabLut) }) { toggleRibbon() }
        railBtn(r, "EIS", { listOf("выкл", "слаб.", "средн.", "сильн.", "макс.")[cfg.eis.coerceIn(0, 4)] }, { cfg.eis > 0 }, { openMenu(tabStab) }) { setEis((cfg.eis + 1) % 5) }
        railBtn(r, "NR", { listOf("выкл", "слаб.", "средн.", "сильн.")[cfg.nrSoft.coerceIn(0, 3)] }, { cfg.nrSoft > 0 }, { openMenu(tabStab) }) { setNrSoft((cfg.nrSoft + 1) % 4) }
        refreshers.add { hist.visibility = if (cfg.hist) View.VISIBLE else View.GONE }
    }

private fun buildSide() {
        val cfg = engine.cfg
        railBtn(side, "КАМЕРА", { lenses.firstOrNull { it.id == cfg.cameraId }?.label ?: "cam" }, { false }, { openMenu(tabCamera) }) {
            idle {
                if (lenses.size > 1) {
                    val i = lenses.indexOfFirst { it.id == cfg.cameraId }
                    cfg.cameraId = lenses[(i + 1) % lenses.size].id
                    cfg.zoom = 1f
                    engine.restart()
                }
            }
        }
        // середина правой панели свободна: сюда заходит кнопка записи
        side.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 2.4f))
        railBtn(side, "РУЧН.", { "" }, { panel.visibility == View.VISIBLE }) {
            if (panel.visibility == View.VISIBLE && !hiding.contains(panel)) setPanel(false)
            else { lutRibbon.close(); setPanel(true) }
        }
        menuBtn = railBtn(side, "МЕНЮ", { "" }, { ::menu.isInitialized && menuVisible() }) {
            if (menuVisible()) closeMenu() else openMenu(menuTab)
        }

        // зум, как в большинстве камер: вертикальный ползунок и пресеты рядом с кнопкой записи
        zoomSlider = ZoomSlider(this).apply {
            setContentDescription("Зум")
            onChange = { z -> setZoomLive(z) }
            onCommit = { engine.update(); refreshChips() }
        }
        zoomSlider.onPreset = { z -> setZoom(z) }
        host.addView(zoomSlider, FrameLayout.LayoutParams(dp(64), MATCH, Gravity.END).apply { setMargins(0, dp(76), dp(58), dp(48)) })

        // кнопка записи — поверх всего, наполовину на превью
        recBtn = Button(this)
        recBtn.text = ""
        recBtn.setPadding(0, 0, 0, 0)
        recBtn.stateListAnimator = null
        recBtn.setContentDescription("Запись")
        recBtn.background = recDrawable(false)
        recBtn.elevation = dp(8).toFloat()
        pressFx(recBtn, 0.9f)
        recBtn.setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); engine.toggleRecord() }
        root.addView(recBtn, FrameLayout.LayoutParams(dp(recSizeDp), dp(recSizeDp), Gravity.END or Gravity.CENTER_VERTICAL))
        pauseIcon = PauseIcon(density)
        pauseBtn = ImageView(this)
        pauseBtn.setImageDrawable(pauseIcon)
        pauseBtn.setContentDescription("Пауза")
        pauseBtn.background = Ui.ripple(GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()); setStroke(dp(1), 0x59FFFFFF)
        })
        pauseBtn.elevation = dp(6).toFloat()
        pauseBtn.visibility = View.GONE
        pressFx(pauseBtn, 0.9f)
        pauseBtn.setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); engine.togglePause() }
        root.addView(pauseBtn, FrameLayout.LayoutParams(dp(pauseSizeDp), dp(pauseSizeDp), Gravity.END or Gravity.CENTER_VERTICAL))
        placeRec()
        recBtn.bringToFront()
    }

    private fun fmtZoom(z: Float): String =
        if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)

    /** Пресеты зума по возможностям камеры — отдаются в сам контрол (кнопки внутри ползунка). */
    private fun rebuildZoomPills(lo: Float, hi: Float) {
        if (!::zoomSlider.isInitialized) return
        val p = listOf(0.5f, 1f, 2f, 3f, 5f, 10f).filter { it >= lo - 0.01f && it <= hi + 0.01f }
        zoomPresets = p
        zoomSlider.setPresets(if (p.size > 1) p else emptyList())
    }

    private fun refreshZoomPills() {
        if (!::zoomSlider.isInitialized || !::engine.isInitialized) return
        zoomSlider.setValue(engine.cfg.zoom)
    }

    private fun toggleRibbon() {
        if (lutRibbon.opened) lutRibbon.close()
        else { setPanel(false); lutRibbon.open() }
        renderLog()
    }

    // ------------------------------------------------------------ UI: меню с описаниями

    private fun menuVisible() = menu.visibility == View.VISIBLE && !hiding.contains(menu)

private fun openMenu(tab: Int) {
        if (!ready) return
        if (::lutRibbon.isInitialized) lutRibbon.close()
        if (menu.visibility != View.VISIBLE || hiding.contains(menu)) openMenuAnimated()
        showTab(tab)
    }

    private fun closeMenu() { closeMenuAnimated() }

    private fun segStyle(b: Button, on: Boolean) {
        b.background = Ui.ripple(Ui.bg(Ui.Kind.BUTTON, on))
        b.setTextColor(if (on) Ui.onAccent else Ui.text)
    }

    private fun flatButton(text: String, size: Float): Button {
        val b = Button(this)
        b.setAllCaps(false)
        b.textSize = size
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.text = text
        pressFx(b)
        return b
    }

    private fun buildMenuShell() {
        menu = FrameLayout(this)
        menu.setBackgroundColor(Ui.menuBg)
        menu.elevation = dp(24).toFloat()          // выше кнопки записи: меню закрывает весь экран
        menu.visibility = View.GONE
        menu.isClickable = true

        menuSheet = LinearLayout(this)
        menuSheet.orientation = LinearLayout.HORIZONTAL
        menu.addView(menuSheet, FrameLayout.LayoutParams(MATCH, MATCH))

        // слева — разделы (как в настройках iOS в альбомной ориентации), внизу главная кнопка «Готово»
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setPadding(dp(16), dp(14), dp(10), dp(14))
        val title = TextView(this)
        title.text = "Настройки"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Ui.text)
        title.setPadding(dp(8), 0, 0, dp(8))
        bar.addView(title)
        val tabsScroll = ScrollView(this)
        tabsScroll.isVerticalScrollBarEnabled = false
        menuTabsBox = LinearLayout(this)
        menuTabsBox.orientation = LinearLayout.VERTICAL
        tabsScroll.addView(menuTabsBox)
        bar.addView(tabsScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        for (i in tabNames.indices) {
            val b = flatButton(tabNames[i], 14f)
            b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            b.setPadding(dp(14), 0, dp(14), 0)
            b.setOnClickListener { showTab(i) }
            tabButtons.add(b)
        }
        for ((gi, g) in tabGroups.withIndex()) {
            val cap = TextView(this)
            cap.text = g.first
            cap.textSize = 11f
            cap.setTypeface(null, Typeface.BOLD)
            cap.setTextColor(Ui.dim)
            cap.letterSpacing = 0.08f
            cap.setPadding(dp(14), if (gi == 0) dp(2) else dp(12), 0, dp(2))
            menuTabsBox.addView(cap)
            for (i in g.second) menuTabsBox.addView(tabButtons[i], LinearLayout.LayoutParams(MATCH, dp(46)).apply { setMargins(0, dp(2), 0, dp(2)) })
        }
        val done = flatButton("Готово", 15f)
        done.setTypeface(null, Typeface.BOLD)
        done.background = Ui.ripple(Ui.bg(Ui.Kind.BUTTON, true))
        done.setTextColor(Ui.onAccent)
        done.setOnClickListener { closeMenu() }
        bar.addView(done, LinearLayout.LayoutParams(MATCH, dp(48)).apply { topMargin = dp(8) })
        menuSheet.addView(bar, LinearLayout.LayoutParams(dp(menuSideDp), MATCH))

        val div = View(this)
        div.setBackgroundColor(0x1FFFFFFF)
        menuSheet.addView(div, LinearLayout.LayoutParams(Math.max(1, dp(1)), MATCH))

        menuScroll = ScrollView(this)
        menuScroll.overScrollMode = View.OVER_SCROLL_NEVER
        menuBody = LinearLayout(this)
        menuBody.orientation = LinearLayout.VERTICAL
        menuBody.setPadding(dp(4), dp(14), dp(4), dp(24))
        menuScroll.addView(menuBody, FrameLayout.LayoutParams(dp(560), WRAP, Gravity.CENTER_HORIZONTAL))
        menuSheet.addView(menuScroll, LinearLayout.LayoutParams(0, MATCH, 1f))

        root.addView(menu, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Центр кнопки «МЕНЮ» в координатах корневого экрана — из неё «капля» меню расходится и в неё же стекает. */
    private fun menuOrigin(): IntArray {
        val b = menuBtn
        if (b == null || b.width == 0) return intArrayOf(root.width - dp(minRailDp) / 2, root.height - dp(40))
        val l = IntArray(2); b.getLocationInWindow(l)
        val r = IntArray(2); root.getLocationInWindow(r)
        return intArrayOf(l[0] - r[0] + b.width / 2, l[1] - r[1] + b.height / 2)
    }

    private fun menuRadius(o: IntArray): Float =
        Math.hypot(Math.max(o[0], root.width - o[0]).toDouble(), Math.max(o[1], root.height - o[1]).toDouble()).toFloat()

    private fun openMenuAnimated() {
        hiding.remove(menu)
        menuAnim?.cancel()
        menuSheet.animate().cancel()
        menu.visibility = View.VISIBLE
        menuSheet.alpha = 1f; menuSheet.scaleX = 1f; menuSheet.scaleY = 1f
        if (!animsOn()) return
        val go = {
            val o = menuOrigin()
            val reveal = ViewAnimationUtils.createCircularReveal(menu, o[0], o[1], dp(24).toFloat(), menuRadius(o))
            reveal.duration = 520
            reveal.interpolator = DecelerateInterpolator(1.8f)
            menuSheet.alpha = 0f; menuSheet.scaleX = 0.92f; menuSheet.scaleY = 0.92f
            menuSheet.animate().alpha(1f).setStartDelay(120).setDuration(260).start()
            val settle = ValueAnimator.ofFloat(0f, 1f)
            settle.duration = 640
            settle.interpolator = Spring(6f, 11f)
            settle.addUpdateListener {
                val sc = 0.92f + 0.08f * (it.animatedValue as Float)
                menuSheet.scaleX = sc; menuSheet.scaleY = sc
            }
            menuAnim = reveal
            reveal.start(); settle.start()
        }
        if (menu.isLaidOut && menu.width > 0) go()
        else menu.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(v: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or2: Int, ob: Int) {
                v.removeOnLayoutChangeListener(this)
                go()
            }
        })
    }

    private fun closeMenuAnimated() {
        if (menu.visibility != View.VISIBLE || hiding.contains(menu)) return
        menuAnim?.cancel()
        if (!animsOn() || !menu.isLaidOut) { menu.visibility = View.GONE; return }
        hiding.add(menu)
        val o = menuOrigin()
        val a = ViewAnimationUtils.createCircularReveal(menu, o[0], o[1], menuRadius(o), dp(24).toFloat())
        a.duration = 360
        a.interpolator = AccelerateInterpolator(1.4f)
        menuSheet.animate().setStartDelay(0).alpha(0f).setDuration(180).start()
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (hiding.remove(menu)) menu.visibility = View.GONE
                menuSheet.alpha = 1f; menuSheet.scaleX = 1f; menuSheet.scaleY = 1f
            }
        })
        menuAnim = a
        a.start()
    }

    private fun showTab(i: Int, keepScroll: Boolean = false) {
        val y = menuScroll.scrollY
        menuTab = i
        tabButtons.forEachIndexed { k, b -> segStyle(b, k == i) }
        menuBody.removeAllViews()
        menuRefreshers.clear()
        val head = TextView(this)
        head.text = tabNames[i]
        head.textSize = 26f
        head.setTypeface(null, Typeface.BOLD)
        head.setTextColor(Ui.text)
        head.setPadding(dp(4), 0, 0, dp(10))
        menuBody.addView(head)
        when (i) {
            0 -> buildVideoTab()
            1 -> buildColorTab()
            2 -> buildLutTab()
            3 -> buildMonitorTab()
            4 -> buildStabTab()
            5 -> buildCameraTab()
            6 -> buildMoreTab()
            7 -> buildUpdatesTab()
            else -> buildAboutTab()
        }
        refreshChips()
        menuScroll.post { menuScroll.scrollTo(0, if (keepScroll) y else 0) }
    }

    /** Карточка: заголовок + описание функции. Возвращает контейнер, куда добавляются элементы управления. */
    private fun card(title: String, desc: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        c.background = Ui.bg(Ui.Kind.PANEL)
        val t = TextView(this)
        t.text = title
        t.textSize = 14f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Ui.text)
        c.addView(t)
        if (desc.isNotEmpty()) {
            val d = TextView(this)
            d.text = desc
            d.textSize = 11.5f
            d.setTextColor(Ui.dim)
            c.addView(d)
        }
        menuBody.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) })
        return c
    }

    /** Строка выбора из нескольких вариантов: все варианты видны сразу, активный подсвечен. */
    private fun seg(
        title: String, desc: String, options: List<String>, selected: () -> Int,
        note: () -> String = { "" }, onPick: (Int) -> Unit
    ) {
        val box = card(title, desc)
        val btns = ArrayList<Button>()
        val perRow = 4                 // длинные списки (разрешения, LOG-кривые) переносятся на следующую строку
        options.chunked(perRow).forEachIndexed { row, chunk ->
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            chunk.forEachIndexed { j, label ->
                val i = row * perRow + j
                val b = flatButton(label, 12f)
                b.setOnClickListener { onPick(i); refreshChips() }
                bar.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(6), dp(2), dp(2)) })
                btns.add(b)
            }
            if (options.size > perRow) repeat(perRow - chunk.size) { bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            box.addView(bar)
        }
        val noteTv = TextView(this)
        noteTv.textSize = 11f
        noteTv.setTextColor(amber)
        box.addView(noteTv)
        menuRefreshers.add {
            val sel = selected()
            btns.forEachIndexed { i, b -> segStyle(b, i == sel) }
            val n = note()
            noteTv.text = n
            noteTv.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun toggle(title: String, desc: String, get: () -> Boolean, note: () -> String = { "" }, set: (Boolean) -> Unit) =
        seg(title, desc, listOf("Выкл", "Вкл"), { if (get()) 1 else 0 }, note) { set(it == 1) }

    private fun saveQuality() {
        val c = engine.cfg
        prefs.edit().putInt("q_preset", c.qualityPreset).putInt("q_mode", c.bitrateMode)
            .putInt("q_kbps", c.bitrateKbps).putFloat("q_gop", c.gopSec)
            .putBoolean("q_b", c.bFrames).putInt("q_audio", c.audioKbps).putInt("bpp_idx", c.bppIdx).apply()
    }

    private fun applyQualityPreset(i: Int) {
        val c = engine.cfg
        c.qualityPreset = i
        when (i) {
            0 -> { c.bppIdx = 0; c.bitrateMode = 0; c.gopSec = 2f; c.bFrames = false }
            1 -> { c.bppIdx = 1; c.bitrateMode = 0; c.gopSec = 1f; c.bFrames = false }
            2 -> { c.bppIdx = 2; c.bitrateMode = 2; c.gopSec = 0.5f; c.bFrames = true }
            else -> { c.bppIdx = 2; c.bitrateMode = 1; c.gopSec = 1f; c.bFrames = true }
        }
        c.bitrateKbps = 0
        saveQuality()
        if (::menu.isInitialized && menuVisible()) showTab(menuTab, true)
        refreshChips()
    }

    private fun estMbps(): Int {
        val c = engine.cfg
        val s = c.size
        val bpp = doubleArrayOf(0.10, 0.15, 0.22)[c.bppIdx.coerceIn(0, 2)] * (if (c.codec == Codec.AVC) 1.5 else 1.0)
        val auto = (s.width.toLong() * s.height * c.fps * bpp).toLong()
        val br = (if (c.bitrateKbps > 0) c.bitrateKbps * 1000L else auto).coerceIn(8_000_000L, Enc.maxBitrate(c.codec.mime).toLong())
        return (br / 1_000_000).toInt()
    }

    private fun buildVideoTab() {
        val cfg = engine.cfg
        val sizes = engine.sizeOptions()
        toggle("Плавный старт записи",
            "В режиме «прямая запись» при старте камера на мгновение пересоздаёт сессию — картинка подвисает. Эта опция ведёт запись через GL (как LUT/EIS/NR): старт без подфриза, но чуть выше нагрев и расход батареи. Действует в SDR и LOG; нативный HLG10 остаётся прямым (там камера сама пишет 10-бит в кодек).",
            { cfg.smoothRec }) { cfg.smoothRec = it; prefs.edit().putBoolean("smooth_rec", it).apply(); idle { engine.restart() } }
        toggle("Open Gate (весь сенсор)",
            "Запись всего кадра сенсора без обрезки до 16:9 (обычно 4:3): шире угол обзора и больше пикселей по вертикали. " +
                "Снимайте «с запасом» и кадрируйте при монтаже в 16:9, 2.39:1 или вертикальное видео — рамки для этого на вкладке «Монитор». " +
                "Файлы крупнее, поддерживает не каждый телефон.",
            { cfg.openGate }, {
                if (engine.caps == null) ""
                else if (!engine.gateAvailable()) "Эта камера не отдаёт для видео кадр шире 16:9 — Open Gate недоступен (попробуйте другой объектив)"
                else if (cfg.openGate) "Пишется весь сенсор: ${sizeLabel(cfg.size)} (${aspectLabel(cfg.size)})"
                else ""
            }) { setOpenGate(it) }
        seg("Разрешение", "Размер кадра записи. Подписи показывают реальные размеры: «4K» — стандартный UHD 3840×2160, остальные нестандартные размеры подписаны цифрами. " +
            "В списке только то, что отдаёт камера и принимает видеокодер вашего телефона.",
            sizes.map { sizeLabel(it) }, { sizes.indexOf(cfg.size) },
            { "${cfg.size.width}×${cfg.size.height} · ${aspectLabel(cfg.size)}" }) { i ->
            idle { cfg.size = sizes[i]; engine.restart() }
        }
        val fpsList = engine.fpsOptions()
        seg("Частота кадров", "24/25 — «киношный» вид, 30 — универсальный вариант, 50/60 — плавное движение и возможность растянуть в слоумо при монтаже. Значения, которые телефон не тянет, скрыты.",
            fpsList.map { "$it" }, { fpsList.indexOf(cfg.fps) }) { i ->
            idle { cfg.fps = fpsList[i]; engine.restart() }
        }
        seg("Кодек", "HEVC (H.265) — примерно вдвое экономнее H.264 при том же качестве и нужен для 10-bit. H.264 — максимальная совместимость с любыми плеерами и редакторами.",
            listOf("HEVC", "H.264"), { cfg.codec.ordinal }) { i ->
            idle { cfg.codec = Codec.values()[i]; engine.restart() }
        }
        seg("Качество (битрейт)", "Чем выше битрейт, тем чище картинка и больше файл. Для цветокоррекции и LOG берите «Высокое».",
            listOf("Низкое", "Среднее", "Высокое"), { cfg.bppIdx }, { "≈ ${estMbps()} Мбит/с для текущих настроек" }) { i -> cfg.bppIdx = i }
        seg("Пресет качества", "Быстрый набор: Эконом — VBR низкий битрейт; Стандарт — сбалансированно; Кино — CQ + короткий GOP + B-кадры для монтажа; Максимум — CBR высокий битрейт.",
            listOf("Эконом", "Стандарт", "Кино", "Максимум"), { cfg.qualityPreset }) { i -> applyQualityPreset(i) }
        seg("Режим битрейта", "VBR — переменный (эффективно), CBR — постоянный (предсказуемый размер/стрим), CQ — постоянное качество (лучше для монтажа, размер плавает). Если кодек телефона режим не поддерживает, пишется VBR.",
            listOf("VBR", "CBR", "CQ"), { cfg.bitrateMode }) { i -> cfg.bitrateMode = i; saveQuality() }
        seg("Битрейт", "Авто — формула от разрешения/fps. Ручной — фиксированный потолок (Мбит/с); выше = чище градиенты и меньше артефактов в движении.",
            listOf("Авто", "20", "40", "60", "80", "120"), { if (cfg.bitrateKbps == 0) 0 else listOf(20, 40, 60, 80, 120).indexOf(cfg.bitrateKbps / 1000).coerceAtLeast(0) + 1 }) { i ->
            cfg.bitrateKbps = if (i == 0) 0 else listOf(20, 40, 60, 80, 120)[i - 1] * 1000; saveQuality()
        }
        seg("GOP (ключевой кадр)", "Короткий GOP — легче монтаж и перемотка, больше размер; длинный — эффективнее сжатие.",
            listOf("0.5с", "1с", "2с"), { when (cfg.gopSec) { 0.5f -> 0; 2f -> 2; else -> 1 } }) { i -> cfg.gopSec = floatArrayOf(0.5f, 1f, 2f)[i]; saveQuality() }
        toggle("B-кадры", "Двустороннее предсказание: лучше сжатие при том же битрейте. Не все кодеки принимают; при отказе пишется без них.", { cfg.bFrames }) { cfg.bFrames = it; saveQuality() }
        seg("Битрейт звука", "Выше = чище речь и атмосфера (кбит/с).", listOf("128", "192", "256", "320"), { listOf(128, 192, 256, 320).indexOf(cfg.audioKbps).coerceAtLeast(0) }) { i -> cfg.audioKbps = listOf(128, 192, 256, 320)[i]; saveQuality() }
        toggle("Звук", "Запись со встроенного микрофона (AAC 192 кбит/с, стерео — если телефон отдаёт).", { cfg.audio }) { cfg.audio = it }
    }

    private fun buildColorTab() {
        val cfg = engine.cfg
        seg("Режим записи", "SDR — обычная картинка Rec.709, готова к просмотру. LOG — плоская картинка с запасом по теням и светам для цветокоррекции. HLG — HDR-запись (BT.2020 + HLG), выглядит правильно на HDR-экранах.",
            listOf("SDR", "LOG", "HLG"), { cfg.mode.ordinal }) { i ->
            idle { cfg.mode = Mode.values()[i]; engine.restart() }
        }
        seg("LOG-кривая", "Какую логарифмическую кривую писать. Выбирайте ту, под которую сделан ваш LUT: S-Log3, V-Log или LogC. Flat — простая универсальная плоская кривая. Работает в режиме LOG.",
            Curve.values().map { it.label }, { cfg.curve.ordinal }) { i -> cfg.curve = Curve.values()[i]; engine.update() }
        seg("Яркость LOG", "Эмулируемый LOG кладёт SDR-картинку в нижние ~60% диапазона, поэтому ролик выглядит тёмным и вялым — так устроены S-Log3, V-Log и LogC. " +
            "«+1»/«+2» поднимают картинку перед кривой (данные не обрезаются). LUT при этом получает «чистую» кривую, его look не меняется. " +
            "0 — точная стандартная кривая. Действует и в режиме «Камера (HW)».",
            listOf("0", "+1 EV", "+2 EV", "+3 EV"), { engine.cfg.logEv },
            { if (cfg.mode != Mode.LOG) "Применяется в режиме LOG" else "" }) { i -> setLogEv(i) }
        seg("Источник LOG", "Шейдер — кривая считается в приложении, работает на любом телефоне, но новых деталей в светах и тенях не добавляет. Камера — телефон сам применяет tone-кривую: картинка реально плоская и деталей больше, но запись идёт напрямую, поэтому LUT в файл запечь нельзя (только превью).",
            listOf("Шейдер (SW)", "Камера (HW)"), { if (cfg.hwLog && engine.caps?.hwLog == true) 1 else 0 },
            { if (engine.caps?.hwLog == true) "" else "Этот телефон не принимает аппаратную tone-кривую — работает шейдер" }) { i ->
            idle {
                if (i == 1 && engine.caps?.hwLog != true) toast("Аппаратная tone-кривая недоступна")
                else { cfg.hwLog = i == 1; engine.restart() }
            }
        }
        seg("Источник HLG", "Нативный — настоящий 10-bit HLG10 от камеры (Android 13+ и поддержка в телефоне). Эмуляция — HLG считается шейдером из обычной SDR-картинки: файл помечен как HLG, но динамического диапазона больше не становится.",
            listOf("Нативный", "Эмуляция"), { if (cfg.emuHlg || engine.caps?.hlg10Native != true) 1 else 0 },
            { if (engine.caps?.hlg10Native == true) "" else "Нативный HLG10 на этом телефоне недоступен — используется эмуляция" }) { i ->
            idle {
                if (i == 0 && engine.caps?.hlg10Native != true) toast("Нативный HLG10 не поддерживается")
                else { cfg.emuHlg = i == 1; engine.restart() }
            }
        }
        toggle("10-bit для эмуляции", "Экспериментально: запись эмулируемых LOG/HLG в 10-bit (только HEVC). Меньше бандинга в градиентах. Если телефон не примет 10-bit, будет 8-bit.", { cfg.tenBitEmu }) { v ->
            idle { cfg.tenBitEmu = v; engine.restart() }
        }
    }

    private fun lutRow(box: LinearLayout, name: String, sub: String, active: Boolean, e: LutEntry?) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val b = flatButton((if (active) "●  " else "○  ") + name + (if (sub.isNotEmpty()) "     $sub" else ""), 13f)
        b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        b.setPadding(dp(12), 0, dp(12), 0)
        segStyle(b, active)
        b.setOnClickListener { selectLut(e) }
        r.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        if (e != null) {
            val x = flatButton("✕", 14f)
            segStyle(x, false)
            x.setOnClickListener { deleteLut(e) }
            r.addView(x, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        box.addView(r)
    }

    /** Что сейчас произойдёт с LUT при записи — простым языком. */
    private fun lutBakeNote(): String {
        val cfg = engine.cfg
        val lut = lutLib.active()
        val noBake = cfg.mode == Mode.HLG || (cfg.mode == Mode.LOG && cfg.hwLog && engine.caps?.hwLog == true)
        return when {
            lut == null -> "Сначала выберите LUT в списке ниже"
            cfg.lutMode != 2 -> "Сейчас LUT «${lut.name}» НЕ записывается в видео"
            noBake -> "В режимах HLG и «LOG: камера (HW)» запечь LUT нельзя — он будет только на экране"
            else -> "Включено: видео запишется сразу с LUT «${lut.name}»"
        }
    }

    /** Применять LUT к видео = режим 2 (запекание); иначе остаётся только показ на экране или ничего. */
    private fun setLutBake(v: Boolean) = idle {
        val cfg = engine.cfg
        cfg.lutMode = if (v) 2 else (if (cfg.lutMode == 0) 0 else 1)
        saveLutPrefs()
        engine.lutConfigChanged()
        if (v && lutLib.activeUri == null) toast("Выберите LUT в списке")
    }

    private fun setLutPreview(v: Boolean) = idle {
        val cfg = engine.cfg
        cfg.lutMode = if (v) (if (cfg.lutMode == 2) 2 else 1) else 0
        saveLutPrefs()
        engine.lutConfigChanged()
    }

    private fun buildLutTab() {
        val cfg = engine.cfg
        toggle("Применять LUT к видео",
            "Вкл — LUT «запекается» в файл: ролик записывается сразу с look-ом LUT, убрать его потом нельзя. " +
                "Выкл — файл пишется без LUT (чистый SDR/LOG), а LUT виден только на экране; наложить его можно при монтаже.",
            { cfg.lutMode == 2 }, { lutBakeNote() }) { setLutBake(it) }

        val box = card("Список LUT",
            "Файлы .cube (3D, размер 2…65). Нажмите на LUT, чтобы выбрать его, ✕ — убрать из списка (сам файл не удаляется). " +
                "Быстро переключать LUT по кругу можно кнопкой «LUT» в нижней полосе.")
        lutRow(box, "Без LUT", "", lutLib.activeUri == null, null)
        for (e in lutLib.items) lutRow(box, e.name, if (e.size > 0) "${e.size}³" else "", e.uri == lutLib.activeUri, e)
        val add = flatButton("+  Добавить файлы .cube", 13f)
        segStyle(add, false)
        add.setOnClickListener { pickLutFiles() }
        box.addView(add, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })

        toggle("Показывать LUT на экране",
            "Включает LUT в превью, чтобы видеть итоговую картинку. На записанный файл это не влияет — за файл отвечает переключатель «Применять LUT к видео».",
            { cfg.lutMode != 0 }, { if (lutLib.activeUri != null && cfg.lutMode == 0) "LUT выбран, но на экране выключен" else "" }) { setLutPreview(it) }
        seg("Вход LUT", "LOG — LUT получает сигнал в выбранной LOG-кривой (для технических LUT вроде «S-Log3 → Rec.709»). Rec.709 — для обычных творческих LUT, рассчитанных на Rec.709.",
            listOf("LOG", "Rec.709"), { if (cfg.lutInLog) 0 else 1 }) { i ->
            idle {
                cfg.lutInLog = i == 0
                saveLutPrefs()
                engine.lutConfigChanged()
            }
        }
    }

    private fun buildMonitorTab() {
        val cfg = engine.cfg
        seg("Сетка", "Направляющие поверх превью (в видео не попадают). Помогают с композицией и ровным горизонтом.",
            Grid.values().map { it.label }, { gridIdx }, { Grid.values()[gridIdx].desc }) { i -> setGrid(i) }
        seg("Рамка кадрирования", "Показывает, какая часть кадра останется после обрезки до выбранного формата (за рамкой экран затемнён). В видео не попадает. Лучше всего вместе с Open Gate.",
            Guide.values().map { it.label }, { guideIdx }, { Guide.values()[guideIdx].desc }) { i -> setGuide(i) }
        toggle("Уровень (горизонт)", "Линия горизонта по датчикам телефона: зелёная — кадр ровный (±1°). Для альбомной съёмки.",
            { levelView.active }, { if (levelView.available) "" else "В этом телефоне нет акселерометра" }) { toggleLevel(it) }
        seg("Зебра", "Штрихует кадр там, где яркость выше порога. Нужна, чтобы не «сжечь» света: 95–100% — уже почти пересвет.",
            listOf("Выкл", "90%", "95%", "100%"), { zebraIdx() }) { i -> setZebra(i) }
        toggle("Focus peaking", "Красным подсвечивает резкие края — помогает точно навести ручной фокус.", { cfg.peaking }) { cfg.peaking = it; engine.update() }
        toggle("False color", "Раскрашивает кадр по яркости: синий и фиолетовый — тёмные тени, зелёный — средние тона (кожа), жёлтый и красный — света и пересвет.", { cfg.falseColor }) { cfg.falseColor = it; engine.update() }
        toggle("Гистограмма", "Распределение яркости в кадре: пик у правого края — пересвет, у левого — провалы в тенях.", { cfg.hist }) { cfg.hist = it; engine.update() }
        seg("Просмотр", "709 — картинка, как она будет выглядеть после коррекции или LUT. LOG — плоская картинка, как она записывается в файл (удобно оценивать экспозицию).",
            listOf("709", "LOG"), { if (cfg.viewLog) 1 else 0 }) { i -> cfg.viewLog = i == 1; engine.update() }
    }

    // ------------------------------------------------------------ шумоподавление и стабилизация

    private fun setNrIsp(v: Int) {
        engine.cfg.nrIsp = v
        prefs.edit().putInt("nr_isp", v).apply()
        engine.update()
    }

    private fun setNrSoft(i: Int) = idle {
        engine.cfg.nrSoft = i.coerceIn(0, 3)
        prefs.edit().putInt("nr_soft", engine.cfg.nrSoft).apply()
        engine.procConfigChanged()
        appLog("Шумоподавление: " + listOf("выкл", "слабое", "среднее", "сильное")[engine.cfg.nrSoft])
    }

    private fun setEis(i: Int) = idle {
        if (i > 0 && !engine.gyroAvailable()) {
            toastLong("В этом телефоне нет гироскопа — стабилизация недоступна")
        } else {
            engine.cfg.eis = i.coerceIn(0, 4)
            prefs.edit().putInt("eis", engine.cfg.eis).apply()
            engine.procConfigChanged()
            appLog("Стабилизация по гироскопу: " + listOf("выкл", "слабая", "средняя", "сильная", "макс.")[engine.cfg.eis])
        }
    }

    private fun setEisHorizon(v: Boolean) = idle {
        engine.cfg.eisHorizon = v
        prefs.edit().putBoolean("eis_horizon", v).apply()
        engine.update()
    }

    private fun setEisFrame(i: Int) {
        engine.cfg.eisFrame = i.coerceIn(0, 2)
        prefs.edit().putInt("eis_frame", engine.cfg.eisFrame).apply()
        engine.update()
    }

    private fun saveEisCal() {
        val sb = StringBuilder()
        for ((id, v) in engine.cfg.eisCal) { if (sb.isNotEmpty()) sb.append(';'); sb.append(id).append(':').append(v.first).append(':').append(v.second) }
        prefs.edit().putString("eis_cal_v2", sb.toString()).apply()
    }

    private fun loadEisCal() {
        val raw = prefs.getString("eis_cal_v2", "") ?: ""
        for (part in raw.split(';')) {
            val f = part.split(':')
            if (f.size == 3) {
                val rot = f[1].toIntOrNull()
                val ms = f[2].toIntOrNull()
                if (rot != null && ms != null) engine.cfg.eisCal[f[0]] = Pair(rot, ms)
            }
        }
    }

    private val eisSyncChoices = listOf(-20, -10, -5, -2, 0, 2, 5, 10, 20)

    private fun setEisSync(ms: Int) {
        engine.cfg.eisSyncMs = ms
        prefs.edit().putInt("eis_sync", ms).apply()
        engine.update()
    }

    private fun buildStabTab() {
        val cfg = engine.cfg
        toggle("Frame Lock (доводка по изображению)",
            "Замкнутый контур: приложение сравнивает предыдущий и текущий стабилизированный кадр и сдвигает окно кадра, удерживая картинку. Гасит остаточную тряску, ошибку синхронизации и межполосное «желе». Намеренные панорамы не трогает (высокочастотный контур).",
            { cfg.eisLock }, { if (cfg.eis == 0) "Включите стабилизацию по гироскопу" else "" }) {
            cfg.eisLock = it; prefs.edit().putBoolean("eis_lock", it).apply(); engine.update()
        }
        val isp = listOf("Авто" to 0, "Выкл" to 1, "Быстрое" to 2, "Высокое" to 3, "Мин." to 4).filter { engine.nrIspAvailable(it.second) }
        seg("Шумоподавление камеры (ISP)",
            "Штатное шумоподавление процессора камеры — работает при любой записи, нагрузки на GPU нет. «Авто» — как решит телефон; «Высокое» чище, но может смазывать мелкие детали; «Выкл» — максимум деталей и зерна (удобно, если шум чистится потом в монтаже). В списке только то, что умеет выбранный объектив.",
            isp.map { it.first }, { isp.indexOfFirst { it.second == cfg.nrIsp } }) { i -> setNrIsp(isp[i].second) }
        seg("Шумоподавление программное",
            "Фильтр в приложении: сглаживает шум внутри кадра, не трогая края, и усредняет его между кадрами там, где ничего не движется. Помогает в темноте и на высоком ISO. Сильное даёт «восковой» вид и лёгкий шлейф за быстрыми объектами. Запись идёт через GL — нагрузка на GPU выше. Лучше всего работает вместе с OIS (вкладка «Камера»).",
            listOf("Выкл", "Слабое", "Среднее", "Сильное"), { cfg.nrSoft },
            { if (cfg.nrSoft > 0 && cfg.mode == Mode.HLG) "Для программной обработки HLG записывается в режиме эмуляции" else "" }) { i -> setNrSoft(i) }
        seg("Стабилизация по гироскопу",
            "Электронная стабилизация по данным гироскопа (как в Gyroflow, но сразу при съёмке): кадр сдвигается и поворачивается так, чтобы убрать тряску рук. Платите кропом: слабая ≈ 7 %, средняя ≈ 15 %, сильная ≈ 25 %, максимальная ≈ 30 % картинки по краям; чем выше уровень, тем плавнее, но тем медленнее камера «догоняет» ваши намеренные движения. Встроенная стабилизация и OIS камеры на это время выключаются. Rolling shutter и искажения объектива не компенсируются.",
            listOf("Выкл", "Слабая", "Средняя", "Сильная", "Максимум"), { cfg.eis },
            {
                if (!engine.gyroAvailable()) "В телефоне нет гироскопа"
                else if (cfg.eis > 0 && engine.caps?.timestampRealtime == false) "Камера не отдаёт метки времени в общей шкале с гироскопом — синхронизация приблизительная, подстройте её ниже"
                else if (cfg.eis > 0 && cfg.mode == Mode.HLG) "Для программной обработки HLG записывается в режиме эмуляции"
                else ""
            }) { i -> setEis(i) }
        seg("Вид стабилизации",
            "Сглаживание — убирает тряску, но наклон кадра сохраняется (камера может «завалиться» вместе с рукой). Блокировка горизонта — кроме тряски выравнивает крен: горизонт остаётся ровным даже при наклоне телефона. Нужен больший кроп (+10 %), иначе в кадр попадут края: поэтому наклон компенсируется только в пределах запаса.",
            listOf("Сглаживание", "Блокировка горизонта"), { if (cfg.eisHorizon) 1 else 0 },
            {
                if (cfg.eisHorizon && !engine.horizonAvailable()) "В телефоне нет акселерометра — горизонт определить нечем"
                else if (cfg.eisHorizon && cfg.eis > 0) "Наклон компенсируется до ≈ " + listOf("", "5°", "7°", "10°", "12°")[cfg.eis.coerceIn(0, 4)] + " (кроп увеличен на 10 %)"
                else if (cfg.eisHorizon) "Включите уровень стабилизации выше"
                else ""
            }) { i -> setEisHorizon(i == 1) }
        seg("Рамка активной области",
            "Когда стабилизация включена, превью показывает весь кадр с камеры, а рамка обозначает часть, которая попадёт в видео (вне рамки затемнено). Статичная — просто показывает величину кропа. Живая — рамка двигается и поворачивается вместе со стабилизацией, так видно, как она работает и когда упирается в край. Выкл — превью показывает итоговую (обрезанную) картинку.",
            listOf("Выкл", "Статичная", "Живая"), { cfg.eisFrame }) { i -> setEisFrame(i) }
        val calBox = card("Автосинхронизация гироскопа",
            "Стабилизация работает только если время кадра и время гироскопа совпадают с точностью нескольких миллисекунд, а оси гироскопа правильно сопоставлены с осями камеры. " +
                "Приложение подбирает это само: сравнивает поворот по гироскопу с реальным сдвигом изображения в кадре. Запускается при включении стабилизации; для надёжного результата подвигайте телефон " +
                "(как при съёмке на ходу), камера должна смотреть на что-то с текстурой — не на гладкую стену и не в темноту.")
        if (syncStatus.isNotEmpty()) {
            val st = TextView(this)
            st.text = syncStatus
            st.textSize = 11f
            st.setTextColor(amber)
            calBox.addView(st)
        }
        val calBtn = flatButton("Откалибровать заново", 13f)
        segStyle(calBtn, false)
        calBtn.setOnClickListener { engine.recalibrate() }
        calBox.addView(calBtn, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
        seg("Синхронизация гироскопа, мс",
            "Ручная подстройка поверх автосинхронизации: сдвиг времени, по которому берутся данные гироскопа для кадра. Нужна, только если после калибровки кадр «дышит» или тряска не уходит. Положительные значения — более поздние данные гироскопа.",
            eisSyncChoices.map { if (it > 0) "+$it" else "$it" }, { eisSyncChoices.indexOf(cfg.eisSyncMs) }) { i -> setEisSync(eisSyncChoices[i]) }
        card("Что важно знать",
            "Лучше всего работает при выдержке не длиннее 1/60 с и достаточном свете: размытие от движения электронная стабилизация не убирает. " +
                "Стабилизация и программное шумоподавление работают в режимах SDR, LOG и эмулируемого HLG; нативный 10-bit HLG10 при их включении не используется. " +
                "Включение и выключение перезапускает камеру, поэтому во время записи недоступно.")
    }

    // ------------------------------------------------------------ о приложении

    private val changelog = listOf(
        "0.19" to listOf(
            "Подфриз при старте записи: причиной было пересоздание сессии камеры в режиме «прямая запись». Новая опция «Плавный старт записи» (включена по умолчанию) ведёт SDR- и LOG-запись через GL — старт без пересоздания сессии",
            "Кнопка паузы над кнопкой записи: во время записи — пауза/продолжить, в файле нет дыры (кадры и звук на паузе не пишутся, продолжение с ключевого кадра)",
            "Кнопка записи: красная капля вернулась; квадрат остановки теперь рисуется самой кнопкой и точно помещается в кольцо",
            "Полоса зума больше не заходит на гистограмму и строку ISO"
        ),
        "0.18" to listOf(
            "Интерфейс в духе Apple Liquid Glass: полупрозрачные панели, светлая кромка и блик сверху, крупные скругления; цветовая схема строго монохромная",
            "Зум одним контролом без фона: кнопки-пресеты внутри ползунка; если повести пальцем по кнопкам, они уступают место ползунку, через пару секунд после отпускания возвращаются",
            "Кнопка записи: квадрат во время записи теперь помещается внутри кольца",
            "Меню разбито на группы (Съёмка, Изображение, Экран, Приложение); «Ещё» заменено отдельными разделами «Интерфейс», «Обновления» и «О приложении»"
        ),
        "0.17" to listOf(
            "Зум по-стандартному: вертикальный ползунок и пресеты рядом с кнопкой записи; активный пресет подсвечивает «капля», которая перетекает между кнопками",
            "Меню на весь экран: слева разделы, справа настройки колонкой до 640 dp, внизу «Готово»; открывается «каплей» из кнопки МЕНЮ и стекает обратно",
            "Анимации-капли: кнопки сплющиваются и возвращаются пружиной, кнопка записи перетекает из круга в квадрат, бегунок зума вытягивается в движении",
            "По рекомендациям Apple HIG: текст не мельче 11, движение короткое и отменяется системным «Удалить анимацию»"
        ),
        "0.16" to listOf(
            "Цели касания не меньше 44 dp и зазоры между кнопками: боковые панели, зум-«пилюли», вкладки и кнопки меню, ручная полоса",
            "Отклик на нажатие: кнопки «вдавливаются», тактильный щелчок; меню, ручная полоса и ползунок зума плавно выезжают",
            "Уважаем системное «Удалить анимацию»: при масштабе анимации 0 всё переключается мгновенно",
            "Быстрее: кнопки перерисовываются только при смене состояния (щипок зума больше не пересоздаёт все фоны)",
            "Левая панель — 8 кнопок (гистограмма в «Мониторе»); на очень низком экране панель прокручивается",
            "Подсказки для TalkBack у кнопки записи и зум-«пилюль»"
        ),
        "0.15" to listOf(
            "Интерфейс в духе камеры iPhone: большая кнопка записи (белое кольцо, красный круг, при записи — квадрат) наполовину заходит на превью",
            "Зум — «пилюли» 0.5 / 1× / 2× внизу превью; долгое нажатие открывает точный ползунок",
            "Новая палитра: чистый чёрный фон, графитовые поверхности, жёлтый акцент и красный для записи; стиль Liquid Glass включён по умолчанию",
            "Ручные настройки переехали на полосу вверху превью"
        ),
        "0.14" to listOf(
            "Новая раскладка: превью по центру ничем не перекрыто, по бокам две панели занимают всё свободное место — пустых полос больше нет",
            "Слева быстрые переключатели: фонарик, зебра, пикинг, гистограмма, сетка, уровень, LUT, EIS, NR (долгое нажатие — настройки)",
            "Справа: объектив, зум на всю высоту, запись, РУЧН. и МЕНЮ",
            "Ручные настройки — одна тонкая полоса внизу превью вместо высокой колонки",
            "Меню стало боковым листом: превью остаётся видно, вкладки — одной строкой; вкладки «Запись», «Камера» и «Ещё» собраны по смыслу",
            "Убраны нижняя полоса и затемняющая панель «Монитор»"
        ),
        "0.13" to listOf(
            "Строка состояния в нижней полосе справа: журнал действий приложения (можно отключить на вкладке «Камера»)",
            "Переключатель «Повернуть превью на 180°» (вкладка «Камера») и диагностика картинки в «О приложении»",
            "Сообщения («LUT применён», ошибки, «Сохранено») теперь показываются плашкой внутри приложения, а не системными тостами Android",
            "Шумоподавление v3: маска движения, временной фильтр с клампом истории по min/max соседей, пространственный фильтр только в зонах движения",
            "Меньше нагрузка: тяжёлые проходы идут в половинном и четвертном разрешении, меньше выборок камеры на пиксель"
        ),
        "0.12" to listOf(
            "Два стиля интерфейса: Material и Liquid Glass (вкладка «Камера»)",
            "Настройки качества видео: пресеты, VBR/CBR/CQ, ручной битрейт, GOP, B-кадры, битрейт звука",
            "Frame Lock: доводка стабилизации по изображению — гасит остаточную тряску и межполосное «желе»"
        ),
        "0.11" to listOf(
            "Интерфейс посовременнее: скруглённые «стеклянные» кнопки, карточки меню, кнопка записи-«затвор»",
            "Ползунок зума стоит левее кнопки записи",
            "Шумоподавление стало заметнее: оценка шума по ISO занижалась, сила теперь зависит от выбранного уровня",
            "Зум: вертикальный логарифмический ползунок с пресетами и магнитом, долгий тап — сброс к 1×, щипок синхронизирован",
            "Нижняя полоса разгружена до 5 кнопок: LUT, EIS, NR, СЕТКА, МОНИТОР",
            "Панель «МОНИТОР»: zebra, peaking, false color, гистограмма, VIEW LOG/709, уровень, рамка",
            "Лента LUT: превью каждого LUT на одной сцене, перелистывание применяет LUT, тап — тоже (во время записи — только просмотр)",
            "Исправлено: кнопка «МЕНЮ» не перекрывается нижней полосой",
            "Иконка приложения (адаптивная, с монохромным вариантом для тем Android 13+)"
        ),
        "0.10" to listOf(
            "Шумоподавление v2: пороги от ISO и яркости, рабочее временное усреднение в тенях, защита от шлейфов",
            "Буферы кадра вдвое легче (RGB10_A2): меньше нагрузка на память и GPU",
            "Стабилизация камеры: три режима — Выкл / OIS / OIS + EIS (OIS помогает программному шумоподавлению)",
            "Новая вкладка «О приложении»"
        ),
        "0.9" to listOf(
            "Стабилизация по гироскопу v2: коррекция rolling shutter по полосам, сглаживание без запаздывания, автоподбор кропа",
            "Учёт смещения нуля гироскопа и гравитации, более точная калибровка синхронизации (старая калибровка сбрасывается)",
            "Рамка активной области учитывает поля превью в Open Gate"
        ),
        "0.8 и ранее" to listOf(
            "Режим Open Gate, сетки и рамки композиции, электронный уровень",
            "Яркость LOG через усиление по EV, LUT (.cube) в превью и в записи",
            "Исправлены поворот и растяжение превью, дублирование разрешений 4K",
            "Программные шумоподавление и стабилизация по гироскопу (первая версия)"
        )
    )

    private fun buildAboutTab() {
        val ver = try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            val code = if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
            "${pi.versionName} (сборка $code)"
        } catch (e: Exception) { "—" }
        card("ProCam", "Версия $ver")
        card("Диагностика картинки", engine.debugInfo())
    }

    private fun buildUpdatesTab() {
        for ((v, items) in changelog) {
            card("Что нового в $v", items.joinToString("\n") { "• $it" })
        }
    }

    private fun buildCameraTab() {
        val cfg = engine.cfg
        toggle("Фонарик", "Постоянный свет вспышки — для тёмных помещений и заброшек. Тот же переключатель — в левой панели съёмки.", { cfg.torch }) { cfg.torch = it; engine.update() }
        if (lenses.size > 1) {
            seg("Объектив", "Основная, широкоугольная, теле. При смене камера перезапускается, зум сбрасывается к 1×. Тот же выбор — кнопка «КАМЕРА» справа.",
                lenses.map { it.label }, { lenses.indexOfFirst { it.id == cfg.cameraId } }) { i ->
                idle { cfg.cameraId = lenses[i].id; cfg.zoom = 1f; engine.restart() }
            }
        }
        seg("Стабилизация камеры",
            "Выкл — со штатива. OIS — оптическая стабилизация линзой: не кропит кадр, не мылит детали и помогает программному шумоподавлению (статичная сцена стоит на месте, усреднение между кадрами работает сильнее). " +
                "OIS + EIS — дополнительно электронная стабилизация процессора: плавнее, но с кропом и лёгким «желе». " +
                "При включённой стабилизации по гироскопу обе выключаются: OIS убирает часть поворота, и гироскопический EIS вычел бы лишнее.",
            listOf("Выкл", "OIS", "OIS + EIS"), { cfg.stabMode },
            { if (cfg.eis > 0) "Сейчас не работает: включена стабилизация по гироскопу" else "" }) { i -> cfg.stabMode = i; engine.update() }
        val manual = card("Ручные настройки", "ISO, выдержка, экспозиция (EV), ручной фокус и баланс белого. Полоса появляется вверху превью; любой ползунок сам переключает параметр в ручной режим. Кнопка «РУЧН.» справа открывает её сразу.")
        val open = flatButton("Показать полосу", 13f)
        segStyle(open, false)
        open.setOnClickListener { closeMenu(); lutRibbon.close(); setPanel(true) }
        manual.addView(open, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
    }

    /** Интерфейс, подсказки и сведения о приложении. */
    private fun buildMoreTab() {
        val cfg = engine.cfg
        seg("Стиль интерфейса",
            "Material — плотные тональные поверхности, чёткая иерархия и ripple. Liquid Glass — полупрозрачные панели поверх живого превью: камера просвечивает сквозь стекло, блик сверху и мягкая тень. Применяется перезапуском экрана.",
            listOf("Material", "Liquid Glass"), { prefs.getInt("ui_style", 1) }) { i ->
            idle { prefs.edit().putInt("ui_style", i).apply(); recreate() }
        }
        toggle("Строка состояния (журнал действий)",
            "Короткие сообщения в левом нижнем углу превью: что сейчас делает приложение (камера, LUT, запись, стабилизация). Исчезают через несколько секунд.",
            { prefs.getBoolean("status_log", true) }) { prefs.edit().putBoolean("status_log", it).apply(); renderLog() }
        toggle("Повернуть превью на 180°",
            "Если изображение на экране вверх ногами — включите. Меняется только картинка на экране, запись не затрагивается.",
            { cfg.previewTurn }) { cfg.previewTurn = it; prefs.edit().putBoolean("prev_turn", it).apply(); engine.update() }
        card("Как устроен экран",
            "Посередине — превью, ничем не перекрытое. Слева — быстрые переключатели: фонарик, зебра, пикинг, сетка, уровень, LUT, EIS, NR (гистограмма — во вкладке «Монитор»); тап переключает, долгое нажатие открывает нужную вкладку меню. " +
                "Справа — объектив, «РУЧН.» (ISO/выдержка/EV/фокус полосой вверху превью) и «МЕНЮ» (боковой лист, превью остаётся видно); большая кнопка записи заходит на превью, как затвор в камере iPhone. " +
                "Зум — кнопки-пресеты рядом с кнопкой записи; если повести пальцем по ним, вместо кнопок включается ползунок. " +
                "Кнопки громкости — старт/стоп записи. Тап по превью — фокус и экспозиция по точке, долгое нажатие — сброс. Щипок — зум.")
    }

    // ------------------------------------------------------------ UI: ручная панель

    private fun addSeek(title: String, row: LinearLayout, onChange: (Int) -> String): SeekBar {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.setTextColor(Ui.text)
        t.textSize = 11f
        t.maxLines = 1
        t.text = title
        val sb = SeekBar(this)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) t.text = "$title  ${onChange(p)}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(t)
        col.addView(sb, LinearLayout.LayoutParams(MATCH, dp(44)))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        return sb
    }

    /** Ручные настройки одной полосой: сверху кнопки режимов, ниже четыре ползунка в ряд. */
    private fun buildPanel() {
        val cfg = engine.cfg
        panel.removeAllViews()
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val sliders = LinearLayout(this)
        sliders.orientation = LinearLayout.HORIZONTAL
        fun pb(text: () -> String, active: () -> Boolean = { false }, onClick: () -> Unit) {
            val b = Button(this)
            styled(b, active, text)
            b.setOnClickListener { onClick(); refreshChips() }
            btns.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        pb({ "EXPOSURE: " + if (cfg.aeManual) "MANUAL" else "AUTO" }, { cfg.aeManual }) { cfg.aeManual = !cfg.aeManual; engine.update() }
        pb({ "SHUTTER 180° (1/${2 * cfg.fps})" }) {
            cfg.expNs = 1_000_000_000L / (2L * cfg.fps)
            cfg.aeManual = true
            engine.update()
            refreshControls()
        }
        pb({ "FOCUS: " + if (cfg.afManual) "MF" else "AF" }, { cfg.afManual }) { cfg.afManual = !cfg.afManual; engine.update() }
        pb({ "WB: " + AWB_PRESETS[cfg.awbIdx].first }) { cfg.awbIdx = (cfg.awbIdx + 1) % AWB_PRESETS.size; engine.update() }

        isoBar = addSeek("ISO", sliders) { p ->
            val r = engine.caps?.isoRange
            if (r == null) "—" else {
                val iso = (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
                cfg.iso = iso; cfg.aeManual = true; engine.update(); refreshChips(); "$iso"
            }
        }
        shutBar = addSeek("SHUTTER", sliders) { p ->
            val d = shutters.getOrNull(p)
            if (d == null) "—" else {
                cfg.expNs = 1_000_000_000L / d; cfg.aeManual = true; engine.update(); refreshChips(); "1/$d"
            }
        }
        evBar = addSeek("EV", sliders) { p ->
            val c = engine.caps
            val r = c?.aeRange
            if (c == null || r == null) "—" else {
                cfg.ev = r.lower + p; engine.update(); "%+.1f".format(cfg.ev * c.aeStep)
            }
        }
        focusBar = addSeek("FOCUS", sliders) { p ->
            val c = engine.caps
            if (c == null || c.minFocus <= 0f) "—" else {
                cfg.focus = c.minFocus * p / 100f; cfg.afManual = true; engine.update(); refreshChips()
                if (cfg.focus < 0.05f) "∞" else "%.0f см".format(100f / cfg.focus)
            }
        }
        panel.addView(btns, LinearLayout.LayoutParams(MATCH, WRAP))
        panel.addView(sliders, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
    }

    /** Подгоняет слайдеры под возможности текущей камеры. */
    private fun refreshControls() {
        val c = engine.caps ?: return
        val cfg = engine.cfg
        if (::zoomSlider.isInitialized) {
            zoomSlider.setRange(c.zoomRange.lower, c.zoomRange.upper)
            zoomSlider.setValue(cfg.zoom)
            rebuildZoomPills(c.zoomRange.lower, c.zoomRange.upper)
        }
        val manual = c.manualSensor && c.isoRange != null && c.expRange != null
        isoBar.isEnabled = manual
        shutBar.isEnabled = manual
        c.isoRange?.let { r ->
            isoBar.max = 100
            val x = cfg.iso.toDouble().coerceIn(r.lower.toDouble(), r.upper.toDouble())
            isoBar.progress = (ln(x / r.lower) / ln(r.upper.toDouble() / r.lower) * 100).roundToInt().coerceIn(0, 100)
        }
        shutters = listOf(24, 25, 30, 48, 50, 60, 96, 100, 120, 125, 240, 250, 500, 1000, 2000, 4000, 8000).filter { d ->
            d >= cfg.fps && (c.expRange?.let { 1_000_000_000L / d in it.lower..it.upper } == true)
        }
        shutBar.max = (shutters.size - 1).coerceAtLeast(0)
        val cur = (1e9 / cfg.expNs).roundToInt()
        shutBar.progress = shutters.indices.minByOrNull { abs(shutters[it] - cur) } ?: 0
        val r = c.aeRange
        evBar.isEnabled = r != null && c.aeStep > 0f
        if (r != null) { evBar.max = r.upper - r.lower; evBar.progress = cfg.ev - r.lower }
        focusBar.isEnabled = c.minFocus > 0f
        focusBar.max = 100
        if (c.minFocus > 0f) focusBar.progress = (cfg.focus / c.minFocus * 100).roundToInt().coerceIn(0, 100)
        refreshChips()
    }




    private fun setZoomLive(z: Float) {
        val c = engine.caps ?: return
        engine.cfg.zoom = z.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
        zoomSlider.setValue(engine.cfg.zoom)
        refreshZoomPills()
        val now = SystemClock.elapsedRealtime()
        if (now - lastZoomPush > 40) { lastZoomPush = now; engine.update() }
    }

    private fun setZoom(z: Float) {
        val c = engine.caps ?: return
        engine.cfg.zoom = z.coerceIn(c.zoomRange.lower, c.zoomRange.upper)
        if (::zoomSlider.isInitialized) zoomSlider.setValueAnimated(engine.cfg.zoom)
        engine.update()
        refreshChips()
    }

    private fun cycleZoom() {
        val c = engine.caps ?: return
        val p = listOf(0.5f, 1f, 2f, 3f, 5f, 10f).filter { it >= c.zoomRange.lower - 0.01f && it <= c.zoomRange.upper + 0.01f }
        if (p.isEmpty()) return
        val cur = engine.cfg.zoom
        setZoom(p.firstOrNull { it > cur + 0.05f } ?: p.first())
    }

    private fun initEngine() {
        engine = CameraEngine(this, this)
        lenses = try { engine.lenses() } catch (e: Exception) { emptyList() }
        engine.cfg.cameraId = (lenses.firstOrNull { it.id == "0" } ?: lenses.firstOrNull())?.id ?: ""
        engine.cfg.lutMode = prefs.getInt("lut_mode", 1).coerceIn(0, 2)
        engine.cfg.lutInLog = prefs.getBoolean("lut_in_log", true)
        engine.cfg.openGate = prefs.getBoolean("gate", false)
        engine.cfg.logEv = prefs.getInt("log_ev", 1).coerceIn(0, 3)
        engine.cfg.nrIsp = prefs.getInt("nr_isp", 0).coerceIn(0, 4)
        engine.cfg.nrSoft = prefs.getInt("nr_soft", 0).coerceIn(0, 3)
        engine.cfg.eis = prefs.getInt("eis", 0).coerceIn(0, 4)
        engine.cfg.eisSyncMs = prefs.getInt("eis_sync", 0).coerceIn(-50, 50)
        engine.cfg.eisHorizon = prefs.getBoolean("eis_horizon", false)
        loadEisCal()
        engine.cfg.qualityPreset = prefs.getInt("q_preset", 1)
        engine.cfg.bppIdx = prefs.getInt("bpp_idx", engine.cfg.bppIdx).coerceIn(0, 2)
        engine.cfg.bitrateMode = prefs.getInt("q_mode", 0).coerceIn(0, 2)
        engine.cfg.bitrateKbps = prefs.getInt("q_kbps", 0)
        engine.cfg.gopSec = prefs.getFloat("q_gop", 1f)
        engine.cfg.bFrames = prefs.getBoolean("q_b", false)
        engine.cfg.audioKbps = prefs.getInt("q_audio", 192)
        engine.cfg.eisLock = prefs.getBoolean("eis_lock", true)
        engine.cfg.previewTurn = prefs.getBoolean("prev_turn", false)
        engine.cfg.smoothRec = prefs.getBoolean("smooth_rec", true)
        engine.cfg.eisFrame = prefs.getInt("eis_frame", 2).coerceIn(0, 2)
        setGuide(prefs.getInt("guide", 0))
        if (prefs.getBoolean("level", false)) toggleLevel(true)
        buildTools()
        buildSide()
        buildPanel()
        setupTouch()
        refreshChips()
        ready = true
        if (surface.holder.surface.isValid) startEngine()
        // Выбранный LUT сохраняется между запусками — его нужно разобрать заново.
        lutLib.active()?.let { selectLut(it, fromUser = false, silent = true) }
    }

    // ------------------------------------------------------------ CameraEngine.Listener

    override fun onInfo(text: String) { hud.text = text }
    override fun onExposure(text: String) { expHud.text = text }
    override fun onHist(bins: IntArray) { hist.set(bins) }
    override fun onError(msg: String) { showNote(msg, 5000, error = true); appLog("Ошибка: " + msg.take(90)) }
    override fun onSaved(path: String) { showNote("Сохранено: $path", 4000); appLog("Видео сохранено") }

    override fun onEisFrame(c: FloatArray?) { eisFrameView.set(c) }

    override fun onSync(msg: String, saved: Boolean) {
        syncStatus = msg
        toastLong(msg)
        appLog("Синхронизация гироскопа: " + msg.take(80))
        if (saved) saveEisCal()
        if (::menu.isInitialized && menuVisible() && menuTab == tabStab) showTab(tabStab, true)
    }

    override fun onReady() {
        appLog("Камера готова: ${engine.cfg.size.width}×${engine.cfg.size.height}, ${engine.cfg.fps} к/с")
        applyContentAspect()
        refreshControls()
        // Список разрешений/fps мог измениться (смена объектива и т.п.) — обновить открытую вкладку.
        if (menuVisible()) showTab(menuTab, true)
    }

    override fun onRecording(on: Boolean) {
        recording = on
        appLog(if (on) "Запись началась" else "Запись остановлена, сохраняю файл…")
        recBtn.setContentDescription(if (on) "Остановить запись" else "Начать запись")
        morphRec(on)
        isPaused = false; pausedTotal = 0L; pauseSince = 0L
        if (::pauseBtn.isInitialized) {
            pauseIcon.play = false
            pauseBtn.setContentDescription("Пауза")
            pauseBtn.visibility = if (on) View.VISIBLE else View.GONE
        }
        if (on) {
            recStart = SystemClock.elapsedRealtime()
            recHud.setTextColor(0xFFFFFFFF.toInt())
            tick()
        } else {
            recHud.text = ""
        }
        statusRunnable.run()
    }

    private fun toggleLevel(on: Boolean) {
        if (on && !levelView.available) { toast("В этом телефоне нет акселерометра"); return }
        levelView.enable(on)
        prefs.edit().putBoolean("level", on).apply()
    }

    // ------------------------------------------------------------ память и размер файла

    private fun fmtDuration(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return if (h > 0) "${h} ч ${m} м" else "${m} м"
    }

    @Suppress("DEPRECATION")
    private fun freeBytes(): Long = try { StatFs(Environment.getExternalStorageDirectory().path).availableBytes } catch (e: Exception) { -1L }

    private val statusRunnable = object : Runnable {
        override fun run() {
            if (::engine.isInitialized && ready) {
                val free = freeBytes()
                val bytesPerSec = estMbps() * 1_000_000L / 8 + 24_000L          // видео + звук
                val sb = StringBuilder()
                if (free >= 0) {
                    sb.append("Память: %.1f ГБ".format(free / 1e9))
                    if (bytesPerSec > 0) sb.append(" · ≈ ").append(fmtDuration(free / bytesPerSec))
                }
                if (recording) {
                    val sec = recElapsedSec()
                    sb.append(" · файл ≈ %.0f МБ".format(sec * bytesPerSec / 1e6))
                }
                statusHud.text = sb.toString()
            }
            main.removeCallbacks(this)
            main.postDelayed(this, 2000)
        }
    }

    override fun onPaused(on: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (on && !isPaused) pauseSince = now
        if (!on && isPaused) pausedTotal += now - pauseSince
        isPaused = on
        pauseIcon.play = on
        pauseBtn.setContentDescription(if (on) "Продолжить" else "Пауза")
        appLog(if (on) "Пауза" else "Запись продолжена")
        recHud.text = recHudText()
    }

    private fun recElapsedSec(): Long {
        val now = SystemClock.elapsedRealtime()
        val extra = if (isPaused) now - pauseSince else 0L
        return ((now - recStart - pausedTotal - extra) / 1000).coerceAtLeast(0)
    }

    private fun recHudText(): String { val s = recElapsedSec(); return (if (isPaused) "❚❚ " else "● ") + "%02d:%02d".format(s / 60, s % 60) }

    private fun tick() {
        main.postDelayed({
            if (recording) {
                recHud.text = recHudText()
                tick()
            }
        }, 500)
    }
}
