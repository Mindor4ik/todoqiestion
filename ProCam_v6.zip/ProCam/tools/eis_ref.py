"""Эталон математики электронной стабилизации по гироскопу (GyroStabilizer.kt) и синтетический тест.
Запуск: python3 eis_ref.py  (нужен numpy)."""
import numpy as np, math

# ---------- кватернионы (w, x, y, z)
def qmul(a, b):
    aw, ax, ay, az = a; bw, bx, by, bz = b
    return np.array([aw*bw-ax*bx-ay*by-az*bz, aw*bx+ax*bw+ay*bz-az*by,
                     aw*by-ax*bz+ay*bw+az*bx, aw*bz+ax*by-ay*bx+az*bw])
def qconj(q): return np.array([q[0], -q[1], -q[2], -q[3]])
def qnorm(q): return q / np.linalg.norm(q)
def from_rotvec(r):
    a = np.linalg.norm(r)
    if a < 1e-12: return qnorm(np.array([1.0, r[0]/2, r[1]/2, r[2]/2]))
    s = math.sin(a/2)/a
    return np.array([math.cos(a/2), r[0]*s, r[1]*s, r[2]*s])
def to_rotvec(q):
    if q[0] < 0: q = -q
    v = q[1:]; n = np.linalg.norm(v)
    if n < 1e-12: return 2*v
    return v/n * 2*math.atan2(n, q[0])
def to_mat(q):
    w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])

# ---------- оси: устройство -> камера (x вправо, y вниз, z вперёд) по SENSOR_ORIENTATION
def dev_to_cam(S):
    return {90: np.array([[0,-1,0],[-1,0,0],[0,0,-1]], float),
            270: np.array([[0,1,0],[1,0,0],[0,0,-1]], float),
            0: np.array([[1,0,0],[0,-1,0],[0,0,-1]], float),
            180: np.array([[-1,0,0],[0,1,0],[0,0,-1]], float)}[S]

def roll_limit(crop, W, H):
    # наибольший крен, при котором повёрнутый кадр (с кропом) ещё целиком внутри исходного
    ratio = max(W, H) / min(W, H)
    a = 0.0
    while a < 0.6 and ratio*math.sin(a+0.002) + math.cos(a+0.002) <= crop:
        a += 0.002
    return a

class Stab:
    def __init__(self, S=90, cap=2048):
        self.M = dev_to_cam(S); self.cap = cap
        self.t = np.zeros(cap); self.qa = np.zeros((cap, 4)); self.qv = np.zeros((cap, 4))
        self.n = 0; self.head = 0
        self.tau = 0.25; self.lim = (0.05, 0.08, 0.1)
        self.wprev = None; self.tprev = None
        self.qA = np.array([1.0, 0, 0, 0]); self.q1 = self.qA.copy(); self.q2 = self.qA.copy()
    def configure(self, tau, f, W, H, crop):
        self.tau = tau
        sx = (W/2)*(1-1/crop); sy = (H/2)*(1-1/crop)
        self.lim = (0.85*math.atan(sy/f), 0.85*math.atan(sx/f), 0.85*roll_limit(crop, W, H))   # x(pitch), y(yaw), z(roll)
    def gyro(self, t, wd):
        wc = self.M @ wd
        if self.tprev is None:
            self.tprev = t; self.wprev = wc; self._push(t); return
        dt = t - self.tprev
        if dt <= 0 or dt > 0.1:
            self.tprev = t; self.wprev = wc; return
        wm = 0.5*(wc + self.wprev)
        self.qA = qnorm(qmul(self.qA, from_rotvec(wm*dt)))
        al = 1 - math.exp(-dt/(self.tau/2))        # два каскада по tau/2: общая задержка ≈ tau
        self.q1 = qnorm(qmul(self.q1, from_rotvec(al*to_rotvec(qmul(qconj(self.q1), self.qA)))))
        self.q2 = qnorm(qmul(self.q2, from_rotvec(al*to_rotvec(qmul(qconj(self.q2), self.q1)))))
        rel = qmul(qconj(self.qA), self.q2)
        r = to_rotvec(rel)
        rc = np.array([max(-self.lim[0], min(self.lim[0], r[0])),
                       max(-self.lim[1], min(self.lim[1], r[1])),
                       max(-self.lim[2], min(self.lim[2], r[2]))])
        if np.any(rc != r):
            self.q2 = qnorm(qmul(self.qA, from_rotvec(rc)))
        self.tprev = t; self.wprev = wc; self._push(t)
    def _push(self, t):
        i = self.head; self.t[i] = t; self.qa[i] = self.qA; self.qv[i] = self.q2
        self.head = (self.head+1) % self.cap; self.n = min(self.n+1, self.cap)
    def rot_at(self, t):
        # выборка упорядочена по времени; бинарный поиск
        idx = [(self.head - self.n + k) % self.cap for k in range(self.n)]
        ts = self.t[idx]
        if t <= ts[0]: k = 0; a = 0.0
        elif t >= ts[-1]: k = self.n-2; a = 1.0
        else:
            k = int(np.searchsorted(ts, t) - 1); a = (t - ts[k])/(ts[k+1]-ts[k])
        i0, i1 = idx[k], idx[k+1]
        qa = qnorm((1-a)*self.qa[i0] + a*self.qa[i1] * (1 if np.dot(self.qa[i0], self.qa[i1]) >= 0 else -1))
        qv = qnorm((1-a)*self.qv[i0] + a*self.qv[i1] * (1 if np.dot(self.qv[i0], self.qv[i1]) >= 0 else -1))
        return to_mat(qmul(qconj(qa), qv))        # R = R_a^T R_v : виртуальная камера -> реальная

# ---------- синтетическая тряска: 4 синусоиды 2–8 Гц по каждой оси + медленная панорама; метрика — «ускорение» точек (px/кадр²)
def mat_to_q(R):
    t = np.trace(R)
    if t > 0:
        s = math.sqrt(t+1)*2; return np.array([s/4, (R[2,1]-R[1,2])/s, (R[0,2]-R[2,0])/s, (R[1,0]-R[0,1])/s])
    i = int(np.argmax(np.diag(R))); j, k = (i+1) % 3, (i+2) % 3
    s = math.sqrt(R[i,i]-R[j,j]-R[k,k]+1)*2
    q = np.zeros(4); q[0] = (R[k,j]-R[j,k])/s; q[1+i] = s/4; q[1+j] = (R[j,i]+R[i,j])/s; q[1+k] = (R[k,i]+R[i,k])/s
    return qnorm(q)

def simulate(S=90, pan_rate=0.25, tau=0.2, amp_scale=1.0, crop=1.15, f=2594.0, W=3840, H=2160, secs=6.0, sync=0.0, flip=False, seed=1):
    rng = np.random.default_rng(seed)
    M = dev_to_cam(S)
    freqs = rng.uniform(2.0, 8.0, size=(3, 4)); amps = amp_scale*rng.uniform(0.002, 0.008, size=(3, 4)); phs = rng.uniform(0, 2*np.pi, size=(3, 4))
    axis = np.array([1.0, 0, 0])     # «вверх» устройства в альбомной позе (S=90/270)
    def R_dev(t):
        shake = np.array([np.sum(amps[i]*np.sin(2*np.pi*freqs[i]*t + phs[i])) for i in range(3)])
        return to_mat(from_rotvec(pan_rate*t*axis)) @ to_mat(from_rotvec(shake))
    st = Stab(S, cap=4096); st.configure(tau, f, W, H, crop)
    for t in np.arange(0, secs, 1/400):
        w = to_rotvec(mat_to_q(R_dev(t-1e-4).T @ R_dev(t+1e-4)))/(2e-4)
        st.gyro(t, -w if flip else w)
    tf = np.arange(1.0, secs-0.5, 1/30.0)
    pts = np.array([[0.0, 0.0, 1.0], [0.25, 0.1, 1.0], [-0.2, -0.12, 1.0], [0.3, -0.15, 1.0]])
    src, out = [], []
    for t in tf:
        Rc = R_dev(t) @ M.T; Rv = st.rot_at(t + sync)
        s_row, o_row = [], []
        for p in pts:
            da = Rc.T @ p
            s_row.append(f*da[:2]/da[2]); dv = Rv.T @ da; o_row.append(f*crop*dv[:2]/dv[2])
        src.append(s_row); out.append(o_row)
    src, out = np.array(src), np.array(out)
    acc = lambda x: float(np.sqrt(np.mean((x[2:] - 2*x[1:-1] + x[:-2])**2)))
    return acc(src), acc(out)

if __name__ == "__main__":
    for S in (90, 270):
        a, b = simulate(S=S); print(f"S={S}: {a:6.2f} -> {b:6.2f}  (подавлено {100*(1-b/a):4.1f} %)")
    a, b = simulate(flip=True); print(f"инвертированный знак гироскопа (должно ухудшать): {a:6.2f} -> {b:6.2f}")
    for e in (0.0, 0.005, 0.010, 0.020, 0.040):
        a, b = simulate(sync=e); print(f"ошибка синхронизации {e*1000:4.0f} мс: {a:6.2f} -> {b:6.2f} ({100*(1-b/a):4.1f} %)")
    for tau in (0.10, 0.20, 0.35):
        a, b = simulate(tau=tau, pan_rate=0.0); print(f"tau={tau:4.2f} (без панорамы): {a:6.2f} -> {b:6.2f} ({100*(1-b/a):4.1f} %)")
