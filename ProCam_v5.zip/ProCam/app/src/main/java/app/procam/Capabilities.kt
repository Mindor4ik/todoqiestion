package app.procam

import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.DynamicRangeProfiles
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.os.Build
import android.util.Range
import android.util.Size
import kotlin.math.abs

const val MIME_HEVC = "video/hevc"
const val MIME_AVC = "video/avc"

data class Lens(val id: String, val label: String, val eq: Int)

/** Подпись разрешения по его реальным размерам (раньше всё с шириной ≥ 3840 называлось «4K», и в списке было два одинаковых). */
fun sizeLabel(s: Size): String = when {
    s.width == 3840 && s.height == 2160 -> "4K"
    s.width == 7680 && s.height == 4320 -> "8K"
    s.width * 9 == s.height * 16 && s.height in intArrayOf(720, 1080, 1440) -> "${s.height}p"
    else -> "${s.width}×${s.height}"
}

/** Соотношение сторон для подсказок: 16:9, 4:3, 3:2 … */
fun aspectLabel(s: Size): String {
    val r = s.width.toDouble() / s.height
    return when {
        abs(r - 16.0 / 9) < 0.02 -> "16:9"
        abs(r - 4.0 / 3) < 0.02 -> "4:3"
        abs(r - 3.0 / 2) < 0.02 -> "3:2"
        abs(r - 1.0) < 0.02 -> "1:1"
        else -> "%.2f:1".format(r)
    }
}

/** Всё, что умеет конкретная камера (по Camera2 characteristics). */
class CamCaps(val id: String, private val ch: CameraCharacteristics) {
    private val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
    private val capSet = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toSet() ?: emptySet()

    val sensorOrientation: Int = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
    val timestampRealtime: Boolean =
        ch.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) == CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
    val fpsRanges: List<Range<Int>> =
        ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: listOf(Range(15, 30))

    val manualSensor = capSet.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
    val isoRange: Range<Int>? = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
    val expRange: Range<Long>? = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    val minFocus: Float = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    val aeStep: Float = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
    val aeRange: Range<Int>? = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
    val activeArray: Rect = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)
    val maxAfRegions: Int = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
    val maxAeRegions: Int = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0

    private val maxDigital: Float = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
    val zoomRange: Range<Float> =
        if (Build.VERSION.SDK_INT >= 30) (ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) ?: Range(1f, maxDigital))
        else Range(1f, maxDigital)

    val awbModes: Set<Int> = ch.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toSet() ?: setOf(CameraMetadata.CONTROL_AWB_MODE_AUTO)
    val afModes: Set<Int> = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.toSet() ?: emptySet()
    val stabModes: Set<Int> = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.toSet() ?: emptySet()
    val oisModes: Set<Int> = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.toSet() ?: emptySet()

    /** Аппаратный LOG через пользовательскую tone-кривую. */
    val maxCurvePoints: Int = ch.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS) ?: 0
    val hwLog: Boolean =
        (ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.contains(CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE) == true) &&
            maxCurvePoints >= 16

    /** Нативный 10-bit HLG10 (Android 13+ и поддержка в HAL). */
    val hlg10Native: Boolean = Build.VERSION.SDK_INT >= 33 &&
        (ch.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)?.supportedProfiles?.contains(DynamicRangeProfiles.HLG10) == true)

    /** Профиль для превью-выхода рядом с HLG10-выходом (STANDARD, если HAL разрешает смешивать). */
    fun previewProfileForHlg(): Long {
        if (Build.VERSION.SDK_INT < 33) return 1L
        val p = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES) ?: return 1L
        return try {
            if (p.getProfileCaptureRequestConstraints(DynamicRangeProfiles.HLG10).contains(DynamicRangeProfiles.STANDARD))
                DynamicRangeProfiles.STANDARD else DynamicRangeProfiles.HLG10
        } catch (e: Exception) {
            DynamicRangeProfiles.HLG10
        }
    }

    private fun is169(s: Size) = s.width * 9 == s.height * 16

    private val recSizes: List<Size> = (map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray<Size>()).toList()
    private val texSizes: List<Size> = (map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray<Size>()).toList()

    val videoSizes: List<Size> = (recSizes.ifEmpty { texSizes })
        .filter { is169(it) && it.width >= 1280 }.distinct().sortedByDescending { it.width }

    /** Аспект всей активной области сенсора (обычно 4:3). */
    val sensorAspect: Double = activeArray.width().toDouble() / activeArray.height()

    /**
     * Open Gate: размеры «весь сенсор» — того же соотношения сторон, что у активной области, и НЕ 16:9
     * (16:9 — это уже обрезка сверху и снизу). Берём список для видео, а если он пуст — список для SurfaceTexture.
     */
    val gateSizes: List<Size> = run {
        fun ok(s: Size) = !is169(s) && s.width > s.height && s.width in 1280..8192 &&
            abs(s.width.toDouble() / s.height - sensorAspect) < 0.02
        val fromRec = recSizes.filter(::ok)
        (if (fromRec.isNotEmpty()) fromRec else texSizes.filter(::ok)).distinct().sortedByDescending { it.width }
    }

    private val previewSizes: List<Size> = texSizes.filter { is169(it) }.sortedBy { it.width }

    fun previewStreamSize(): Size =
        previewSizes.firstOrNull { it.width == 1280 }
            ?: previewSizes.filter { it.width >= 1280 }.minByOrNull { it.width }
            ?: previewSizes.firstOrNull() ?: Size(1280, 720)

    /**
     * Поток превью должен иметь то же соотношение сторон, что и запись. Иначе камера обрежет его по-своему
     * (в Open Gate превью 16:9 показывало бы не весь кадр).
     */
    fun previewStreamSizeFor(rec: Size): Size {
        val ar = rec.width.toDouble() / rec.height
        val same = texSizes.filter { abs(it.width.toDouble() / it.height - ar) < 0.01 }.sortedBy { it.width }
        return same.firstOrNull { it.width >= 1280 } ?: same.lastOrNull() ?: previewStreamSize()
    }

    fun maxFps(size: Size): Int {
        val aeMax = fpsRanges.maxOf { it.upper }
        val dur = try { map.getOutputMinFrameDuration(MediaRecorder::class.java, size) } catch (e: Exception) {
            try { map.getOutputMinFrameDuration(SurfaceTexture::class.java, size) } catch (e2: Exception) { 0L }
        }
        if (dur <= 0L) return aeMax
        return minOf(aeMax, Math.floor(1e9 / dur + 0.01).toInt())
    }

    fun fpsRangeFor(fps: Int): Range<Int> =
        fpsRanges.firstOrNull { it.lower == fps && it.upper == fps }
            ?: fpsRanges.filter { it.upper == fps }.maxByOrNull { it.lower }
            ?: fpsRanges.filter { it.upper > fps && it.lower <= fps }.minByOrNull { it.upper }
            ?: fpsRanges.first()
}

/** Что умеют видеокодеки телефона. */
object Enc {
    // Список кодеков не меняется, пока приложение живо; без кэша каждый вызов supports() строил MediaCodecList заново (десятки мс).
    private val allInfos: Array<MediaCodecInfo> by lazy { MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos }
    private val bestCache = HashMap<String, MediaCodecInfo?>()

    private fun infos(mime: String) = allInfos.filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }

    @Synchronized
    private fun best(mime: String): MediaCodecInfo? = bestCache.getOrPut(mime) {
        val l = infos(mime)
        l.firstOrNull { !it.name.startsWith("OMX.google") && !it.name.startsWith("c2.android") } ?: l.firstOrNull()
    }

    fun bestName(mime: String): String? = best(mime)?.name

    fun supports(mime: String, w: Int, h: Int, fps: Int): Boolean = try {
        best(mime)?.getCapabilitiesForType(mime)?.videoCapabilities?.areSizeAndRateSupported(w, h, fps.toDouble()) == true
    } catch (e: Exception) { false }

    fun hevcMain10(w: Int, h: Int, fps: Int): Boolean = try {
        val caps = best(MIME_HEVC)?.getCapabilitiesForType(MIME_HEVC)
        caps != null && caps.profileLevels.any {
            it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 ||
                it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10
        } && supports(MIME_HEVC, w, h, fps)
    } catch (e: Exception) { false }

    fun maxBitrate(mime: String): Int = try {
        best(mime)?.getCapabilitiesForType(mime)?.videoCapabilities?.bitrateRange?.upper ?: 100_000_000
    } catch (e: Exception) { 100_000_000 }
}
