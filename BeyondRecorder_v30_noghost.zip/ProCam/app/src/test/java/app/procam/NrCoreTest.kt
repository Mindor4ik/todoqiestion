package app.procam

import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.*

class NrCoreTest {
    private val W = 48; private val H = 32
    private fun rms(a: FloatArray, b: FloatArray, skip: (Int) -> Boolean = { false }): Double { var s = 0.0; var n = 0; for (i in a.indices) if (!skip(i)) { s += (a[i] - b[i]).toDouble().pow(2); n++ }; return sqrt(s / max(n, 1)) }
    private fun noisy(clean: FloatArray, sd: Double, rng: Random) = FloatArray(clean.size) { (clean[it] + rng.nextGaussian() * sd).toFloat() }
    private val sigBase = 0.012f

    @Test fun legacyLevelsKeepV25Presets() {
        val p = NrMap.map(NrSettings(level = 3))!!
        assertEquals(0.08f, p.aY, 1e-6f); assertEquals(0.04f, p.aC, 1e-6f); assertEquals(1.0f, p.wSpat, 1e-6f); assertEquals(2.5f, p.rangeK, 1e-6f)
        assertNull(NrMap.map(NrSettings(level = 0)))
    }
    @Test fun advancedStrengthIsMonotonicAndIndependent() {
        val lo = NrMap.map(NrSettings(advanced = true, luma = 0.2f, chroma = 0.9f))!!
        val hi = NrMap.map(NrSettings(advanced = true, luma = 0.8f, chroma = 0.1f))!!
        assertTrue(hi.aY < lo.aY)               // сильнее яркостное
        assertTrue(hi.aC > lo.aC)               // слабее цветовое: независимо
        assertEquals(1f, NrMap.map(NrSettings(advanced = true, luma = 0f, chroma = 0f))!!.aY, 1e-6f)
    }
    @Test fun stagesCanBeDisabledSeparately() {
        val t = NrMap.map(NrSettings(advanced = true, spatial = false, temporal = true, luma = 0.7f))!!
        assertEquals(0f, t.wSpat, 0f); assertTrue(t.aY < 1f)
        val s = NrMap.map(NrSettings(advanced = true, spatial = true, temporal = false, luma = 0.7f))!!
        assertEquals(1f, s.aY, 0f); assertEquals(1f, s.aC, 0f); assertTrue(s.wSpat > 0f)
    }
    @Test fun detailPreservationIsConservative() {
        val a = NrMap.map(NrSettings(advanced = true, detail = 0f))!!; val b = NrMap.map(NrSettings(advanced = true, detail = 1f))!!
        assertTrue(b.k < a.k && b.wSpat < a.wSpat && b.rangeK < a.rangeK)
    }
    @Test fun lowLightStrengthensButCapsSpatialAgainstPlastic() {
        val off = NrMap.map(NrSettings(advanced = true, luma = 0.3f, chroma = 0.3f))!!
        val on = NrMap.map(NrSettings(advanced = true, luma = 0.3f, chroma = 0.3f, lowLight = true, lowLightStrength = 1f))!!
        assertTrue(on.aY < off.aY && on.aC < off.aC && on.sigBoost > 1f)
        assertTrue(on.wSpat <= 0.85f)
        assertNotNull(NrMap.map(NrSettings(level = 0, lowLight = true)))   // Low Light работает и без обычного NR
    }
    @Test fun temporalScaleFollowsProcessingMode() {
        val low = NrMap.map(NrSettings(level = 2, temporalScale = 0.6f))!!; val max = NrMap.map(NrSettings(level = 2, temporalScale = 1.25f))!!
        assertTrue(max.aY < low.aY); assertTrue(max.effectiveFrames() > low.effectiveFrames())
    }
    @Test fun staticSceneNoiseDropsAsTheoryPredicts() {
        val rng = Random(7)
        val clean = FloatArray(W * H) { 0.4f + 0.2f * ((it % W) / W.toFloat()) }
        val p = NrMap.map(NrSettings(advanced = true, luma = 0.8f, detail = 0.5f))!!
        val st = NrRef.State(W, H); var out = FloatArray(0); var raw = FloatArray(0)
        repeat(60) { raw = noisy(clean, 0.02, rng); out = NrRef.step(st, raw, p, sigBase * 1.7f) }
        val before = rms(raw, clean); val after = rms(out, clean)
        val theory = sqrt(p.aY / (2 - p.aY).toDouble())
        assertTrue("шум $before → $after", after < before * theory * 1.8 && after < before * 0.5)
    }
    @Test fun movingEdgeHasNoGhosting() {
        val rng = Random(9)
        val p = NrMap.map(NrSettings(advanced = true, luma = 0.9f, detail = 0.5f))!!
        val st = NrRef.State(W, H)
        fun frame(edge: Int) = FloatArray(W * H) { if (it % W < edge) 0.8f else 0.2f }
        var out = FloatArray(0); var cleanCur = FloatArray(0)
        for (f in 0 until 30) { cleanCur = frame(10 + f); out = NrRef.step(st, noisy(cleanCur, 0.01, rng), p, sigBase * 1.2f) }
        // позади края (свежеоткрытые пиксели: x в [edge-… ]) значение не должно «тянуть» старое: проверяем пятно перед краем (только что стало светлым)
        val x = 38; val y = H / 2
        assertEquals("призрак: ${out[y * W + x]}", cleanCur[y * W + x].toDouble(), out[y * W + x].toDouble(), 0.12)
    }
    @Test fun spatialDetailPreservedMoreWithDetailSetting() {
        // движущаяся текстура высокой частоты: считаем энергию градиента выхода
        fun run(detail: Float): Double {
            val rng = Random(11); val p = NrMap.map(NrSettings(advanced = true, luma = 0.6f, detail = detail))!!
            val st = NrRef.State(W, H); var out = FloatArray(0)
            for (f in 0 until 12) {
                val c = FloatArray(W * H) { val x = it % W + f; (0.5 + 0.25 * sin(x * 1.1)).toFloat() }
                out = NrRef.step(st, noisy(c, 0.01, rng), p, sigBase * 1.2f)
            }
            var e = 0.0; for (y in 0 until H) for (x in 1 until W - 1) { val g = out[y * W + x + 1] - out[y * W + x - 1]; e += g * g }
            return e
        }
        assertTrue(run(1f) >= run(0f) * 0.98)
    }
    @Test fun firstFrameAfterResetPassesThrough() {
        val p = NrMap.map(NrSettings(level = 3))!!; val st = NrRef.State(W, H)
        val cur = FloatArray(W * H) { 0.3f + (it % 7) * 0.01f }
        val o = NrRef.step(st, cur, p, sigBase)
        for (i in cur.indices) assertEquals(cur[i].toDouble(), o[i].toDouble(), 0.03)   // без истории — почти без изменений (только пространственный фильтр)
    }
    @Test fun strengthSlidersAreNeutralAtHalfAndMonotonic() {
        val base = NrMap.map(NrSettings(level = 2))!!
        val neutral = NrMap.map(NrSettings(level = 2, spatialStrength = 0.5f, temporalStrength = 0.5f))!!
        assertEquals(base.aY, neutral.aY, 1e-6f); assertEquals(base.wSpat, neutral.wSpat, 1e-6f); assertEquals(base.k, neutral.k, 1e-6f)
        val off = NrMap.map(NrSettings(level = 2, spatialStrength = 0f, temporalStrength = 0f))!!
        assertEquals(0f, off.wSpat, 1e-6f); assertEquals(1f, off.effectiveFrames(), 1e-3f)
        val strong = NrMap.map(NrSettings(level = 2, spatialStrength = 1f, temporalStrength = 1f))!!
        assertTrue(strong.effectiveFrames() > base.effectiveFrames()); assertTrue(strong.wSpat >= base.wSpat)
    }
}
