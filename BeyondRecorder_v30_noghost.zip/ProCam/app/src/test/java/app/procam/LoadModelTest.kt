package app.procam

import org.junit.Assert.*
import org.junit.Test

class LoadModelTest {
    private val ref = BenchResult(PerfRef.CPU_SINGLE, PerfRef.CPU_MULTI, 8, PerfRef.MEM, PerfRef.GPU, PerfRef.ENC)
    private val cap = Capacity.from(ref, 8000)
    private fun total(i: LoadInput, c: Capacity = cap) = LoadModel.loads(i, c).total

    @Test fun referenceDeviceHasIndex100() { assertEquals(100, ref.index) }
    @Test fun fasterGpuRaisesIndexAndMissingPartsAreExcluded() {
        assertTrue(ref.copy(gpuMpps = PerfRef.GPU * 2).index > 100)
        assertTrue(ref.copy(gpuMpps = PerfRef.GPU / 2).index < 100)
        val noGpu = ref.copy(gpuMpps = null, encMpix = null)
        assertEquals(100, noGpu.index); assertTrue(noGpu.partial)
    }
    @Test fun serializeRoundTrip() {
        val r = ref.copy(gpuNote = "x", device = "A B", soc = "S", gpuName = "G", appVersion = "0.29", atMs = 5, thermalStart = 0, thermalEnd = 2, encMpix = null)
        val b = BenchResult.parse(r.serialize())!!
        assertEquals(r.cpuSingleMops, b.cpuSingleMops, 1e-9); assertNull(b.encMpix); assertEquals("A B", b.device); assertEquals(2, b.thermalEnd); assertEquals(r.index, b.index)
    }
    @Test fun parseRejectsGarbage() { assertNull(BenchResult.parse("")); assertNull(BenchResult.parse("abc")); assertNull(BenchResult.parse("cpuSingle=0\ncpuMulti=1\nmem=1")) }

    @Test fun plain4k30IsLowOnReference() { assertEquals(LoadLevel.LOW, LoadModel.loads(LoadInput(), cap).level) }
    @Test fun heavyConfigIsHigh() {
        val h = LoadInput(fps = 60, nrSoft = 3, eis = 3)
        assertEquals(LoadLevel.HIGH, LoadModel.loads(h, cap).level)
    }
    @Test fun loadGrowsWithFpsResolutionNrEis() {
        val b = LoadInput()
        assertTrue(total(b.copy(fps = 60)) > total(b))
        assertTrue(total(b.copy(w = 7680, h = 4320)) > total(b))
        assertTrue(LoadModel.gpuPasses(b.copy(nrSoft = 1)) < LoadModel.gpuPasses(b.copy(nrSoft = 2)))
        assertTrue(LoadModel.gpuPasses(b.copy(nrSoft = 2)) < LoadModel.gpuPasses(b.copy(nrSoft = 3)))
        assertTrue(LoadModel.gpuPasses(b.copy(eis = 2)) > LoadModel.gpuPasses(b))
        assertTrue(LoadModel.encMpixPerSec(b.copy(hevc = false)) < LoadModel.encMpixPerSec(b))
    }
    @Test fun weakerDeviceMeansHigherLoad() {
        val weak = Capacity.from(ref.copy(gpuMpps = PerfRef.GPU / 4, cpuSingleMops = PerfRef.CPU_SINGLE / 4, encMpix = PerfRef.ENC / 4), 8000)
        val i = LoadInput(nrSoft = 2, eis = 2)
        assertTrue(total(i, weak) > total(i) * 3.5)
        assertEquals(25, ref.copy(gpuMpps = PerfRef.GPU / 4, cpuSingleMops = PerfRef.CPU_SINGLE / 4, encMpix = PerfRef.ENC / 4, cpuMultiMops = PerfRef.CPU_MULTI / 4, memGBs = PerfRef.MEM / 4).index)
    }
    @Test fun noBenchUsesReferenceAndIsFlaggedEstimated() { val c = Capacity.from(null, 8000); assertFalse(c.measured); assertEquals(100, c.index); assertEquals(cap.gpu, c.gpu, 1e-6) }

    @Test fun toggleOffIsGreenOnIsHeavier() {
        val b = LoadInput(fps = 60)
        val l = LoadModel.optionLevels(listOf(b.copy(nrSoft = 0), b.copy(nrSoft = 3)), cap)
        assertEquals(LoadLevel.LOW, l[0].second); assertTrue(l[1].first > l[0].first); assertEquals(LoadLevel.HIGH, l[1].second)
    }
    @Test fun optionLevelsAreMonotoneAndRelativeToCheapest() {
        val b = LoadInput()
        val l = LoadModel.optionLevels(listOf(24, 30, 60, 120, 240).map { b.copy(fps = it) }, cap)
        assertEquals(0.0, l[0].first, 1e-9)
        for (i in 1 until l.size) assertTrue(l[i].first >= l[i - 1].first)
        assertEquals(LoadLevel.HIGH, l.last().second)
    }
    @Test fun thresholds() {
        assertEquals(LoadLevel.LOW, LoadLevel.ofTotal(39.9)); assertEquals(LoadLevel.MID, LoadLevel.ofTotal(40.0)); assertEquals(LoadLevel.HIGH, LoadLevel.ofTotal(75.0))
        assertEquals(LoadLevel.LOW, LoadLevel.ofDelta(4.9)); assertEquals(LoadLevel.MID, LoadLevel.ofDelta(5.0)); assertEquals(LoadLevel.HIGH, LoadLevel.ofDelta(15.0))
    }
    @Test fun opticalFlowCostsCpuAndScalesWithFpsAndMode() {
        val g = LoadInput(eis = 2, gyro = true); val v = g.copy(gyro = false)
        assertTrue(v.visual); assertFalse(g.visual)
        assertTrue(LoadModel.cpuMopsPerSec(v) > LoadModel.cpuMopsPerSec(g))
        assertTrue(LoadModel.cpuMopsPerSec(v.copy(fps = 120)) > LoadModel.cpuMopsPerSec(v) * 3)
        assertTrue(LoadModel.flowMopsPerFrame(v.copy(procMode = 2)) > LoadModel.flowMopsPerFrame(v.copy(procMode = 0)))
        assertTrue(LoadModel.flowMopsPerFrame(v.copy(flowMethod = 2)) > LoadModel.flowMopsPerFrame(v.copy(flowMethod = 1)))
        assertEquals(LoadModel.cpuMopsPerSec(v.copy(srcMode = 1)), LoadModel.cpuMopsPerSec(g), 1e-9)   // явный гироскоп: потока нет
    }
    @Test fun ciKeyMapping() {
        val b = LoadInput()
        assertTrue(LoadModel.withCi(b, "ci_nr_adv", 1).nrAdv); assertEquals(2, LoadModel.withCi(b, "ci_src", 2).srcMode)
        assertEquals(b, LoadModel.withCi(b, "ci_char", 1)); assertEquals(160, LoadModel.withCi(b, "ci_an_w", 3).analysisW)
        assertEquals(b, LoadModel.withCi(b, "ci_an_w", 0))
    }
    @Test fun cpuKernelDeterministicAndMops() {
        assertEquals(CpuKernel.run(1000, 7), CpuKernel.run(1000, 7)); assertNotEquals(CpuKernel.run(1000, 7), CpuKernel.run(1000, 8))
        assertEquals(CpuKernel.OPS_PER_ITER.toDouble(), CpuKernel.mops(1_000_000, 1000), 1e-9); assertEquals(0.0, CpuKernel.mops(5, 0), 0.0)
    }
    @Test fun hotStartIsFlaggedInReport() {
        assertTrue(ref.copy(thermalStart = 3).hotStart); assertFalse(ref.copy(thermalStart = 0).hotStart); assertFalse(ref.copy(thermalStart = null).hotStart)
        assertTrue(BenchReport.text(ref.copy(thermalStart = 3)).contains("разогретом")); assertFalse(BenchReport.text(ref).contains("разогретом"))
    }
    @Test fun redmiNote7LogParsesAndGivesIndex22() {
        val raw = "cpuSingle=1484.70066518847\ncpuMulti=4815.894039735099\ncores=8\nmem=2.9462428097560975\ngpu=203.6685082872928\nenc=104.20506427736656\ngpuNote=\nencNote=\ndur=5593\nthS=3\nthE=3\ndevice=Xiaomi Redmi Note 7\nsoc=QTI SDM660\ngpuName=Adreno (TM) 512\nver=0.29\nat=1\n"
        val r = BenchResult.parse(raw)!!
        assertEquals(22, r.index); assertTrue(r.hotStart)
        // на этом телефоне даже обычный 4K30 через GL — за пределом GPU: модель не должна показывать «низкую»
        assertEquals(LoadLevel.HIGH, LoadModel.loads(LoadInput(), Capacity.from(r, 3500)).level)
    }
    @Test fun reportMentionsUnmeasuredParts() {
        val t = BenchReport.text(ref.copy(gpuMpps = null, gpuNote = "не удалось: x"))
        assertTrue(t.contains("не измерено")); assertTrue(t.contains("Индекс производительности")); assertTrue(BenchReport.text(null).contains("не выполнялся"))
    }
}

class BenchKeysTest {
    @Test fun benchKeysAreDeviceSpecific() {
        val st = MemStore(mapOf("perf29_json" to "cpuSingle=1\n", "perf29_done" to true, "fps" to 60))
        val exp = SettingsPorter.exportAll(st)
        assertFalse(exp.contains("perf29")); assertTrue(exp.contains("fps"))
        assertTrue(SettingsSchema.isPresetExcluded("perf29_json")); assertTrue(SettingsSchema.isResetProtected("perf29_done"))
        assertNull(SettingsCatalog.info("perf29_json")); assertFalse(SettingsCatalog.all.any { it.key.startsWith("perf29_") })
        SettingsManager(st).resetToDefaults()
        assertEquals(true, st.all()["perf29_done"]); assertNotNull(st.all()["perf29_json"])
    }
    @Test fun benchKeysPassValidation() {
        val st = MemStore(mapOf("perf29_json" to "x=1", "perf29_done" to true))
        SettingsManager(st).migrate()
        assertEquals("x=1", st.all()["perf29_json"]); assertEquals(true, st.all()["perf29_done"])
    }
}
