package app.procam

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Полоса с отметками порогов 40 % и 75 %: цвет заливки = уровень нагрузки. Больше 100 % — полная полоса. */
internal class LoadBarView(ctx: Context) : View(ctx) {
    var pct = 0.0; var heightDp = 10
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (heightDp * resources.displayMetrics.density).toInt()) }
    override fun onDraw(c: Canvas) {
        val rad = height / 2f
        p.color = (Ui.dim and 0x00FFFFFF) or 0x33000000; r.set(0f, 0f, width.toFloat(), height.toFloat()); c.drawRoundRect(r, rad, rad, p)
        p.color = LoadLevel.ofTotal(pct).color
        r.set(0f, 0f, (width * (pct / 100.0).coerceIn(0.0, 1.0)).toFloat().coerceAtLeast(if (pct > 0) height.toFloat() else 0f), height.toFloat()); c.drawRoundRect(r, rad, rad, p)
        p.color = Color.argb(150, 255, 255, 255)
        for (t in doubleArrayOf(40.0, 75.0)) { val x = (width * t / 100.0).toFloat(); c.drawRect(x - 1f, 0f, x + 1f, height.toFloat(), p) }
    }
}

/** Полоса нагрузки в меню, цветные метки у настроек, тест производительности при первом входе в камеру, выгрузка результатов. */
internal class LoadUi(private val a: MainActivity) {
    private val main get() = a.main
    private fun dp(v: Int) = a.dp(v)
    @Volatile var benchRunning = false
    private var bench: BenchResult? = BenchResult.parse(a.prefs.getString("perf29_json", ""))
    private var benchObj: Bench? = null
    private var dialog: android.app.AlertDialog? = null
    private val resMon by lazy { ResourceMonitor(a) }
    private val ramTotalMb by lazy { (a.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).let { am -> ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem / (1024 * 1024) } }

    fun result(): BenchResult? = bench
    fun capacity(): Capacity = Capacity.from(bench, ramTotalMb)

    // ------------------------------------------------------------ входные данные модели из текущих настроек

    /** Автобитрейт и ручной битрейт — как в a.estMbps(), но для произвольных размера/fps/кодека. */
    fun mbps(w: Int, h: Int, fps: Int, hevc: Boolean, bppIdx: Int, kbps: Int): Int {
        val bpp = doubleArrayOf(0.10, 0.15, 0.22)[bppIdx.coerceIn(0, 2)] * (if (!hevc) 1.5 else 1.0)
        val br = if (kbps > 0) kbps * 1000L else (w.toLong() * h * fps * bpp).toLong()
        return (br.coerceAtLeast(8_000_000L) / 1_000_000).toInt()
    }

    fun nowInput(): LoadInput {
        val c = a.engine.cfg; val ci = a.ciSettings; val cs = a.colorSettings
        val prof = TemporalManager.profileOf(ci.temporal()); val an = ci.analysis(prof)
        val hevc = c.codec == Codec.HEVC
        return LoadInput(
            w = c.size.width, h = c.size.height, fps = c.fps, hevc = hevc, bitrateMbps = a.estMbps(), bFrames = c.bFrames,
            mode = c.mode.ordinal, hwLog = c.hwLog, lutMode = c.lutMode,
            colorPipe = cs.i("c26_work") != 0 || cs.i("c26_tone") != 0 || cs.i("c26_gamut") != 0 || cs.i("c26_dither") != 0,
            grade = false,
            nrSoft = c.nrSoft, nrAdv = ci.b("ci_nr_adv"), nrSpat = ci.b("ci_nr_spat"), nrTemp = ci.b("ci_nr_temp"),
            nrLuma = ci.f("ci_nr_luma") > 0f, nrChroma = ci.f("ci_nr_chroma") > 0f, nrDetail = ci.f("ci_nr_detail") > 0f, nrMc = ci.b("ci_nr_mc"), lowLight = ci.b("ci_ll"),
            eis = c.eis, gyro = a.engine.gyroAvailable(), srcMode = ci.i("ci_src"), lockOn = c.eisLock, horizon = c.eisHorizon, rs = ci.b("ci_rs"),
            flowMethod = ci.i("ci_flow"), analysisW = an.w, analysisEvery = an.every, procMode = ci.i("ci_proc"),
            smoothRec = c.smoothRec, openGate = c.openGate, audio = c.audio,
            zebra = c.zebra, peaking = c.peaking, falseColor = c.falseColor, hist = c.hist,
            scopes = Integer.bitCount(cs.i("c26_scope_mask")), diag = ci.b("ci_diag")
        )
    }

    // ------------------------------------------------------------ метки у настроек

    fun levels(inputs: List<LoadInput>): List<Pair<Double, LoadLevel>> = try { LoadModel.optionLevels(inputs, capacity()) } catch (e: Exception) { emptyList() }

    fun dotted(label: CharSequence, lv: LoadLevel): CharSequence {
        val s = SpannableString("● $label")
        s.setSpan(ForegroundColorSpan(lv.color), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    fun badge(d: Pair<Double, LoadLevel>): CharSequence {
        val txt = if (d.first < 0.5) "нагрузка: ${d.second.label}" else "нагрузка: ${d.second.label} (≈ +%.0f%% узла)".format(d.first)
        return dotted(txt + if (bench == null) " · без теста производительности" else "", d.second)
    }

    // ------------------------------------------------------------ полоса нагрузки

    private var tv: TextView? = null
    private var tvParts: TextView? = null
    private var tvReal: TextView? = null
    private var barView: LoadBarView? = null
    private val tick = object : Runnable {
        override fun run() {
            if (!a.menuVisible() || tv == null) return
            refreshBar()
            main.postDelayed(this, 1000)
        }
    }

    fun stop() { main.removeCallbacks(tick); tv = null; tvParts = null; tvReal = null; barView = null }

    fun addBar() {
        if (!a.engineReady) return
        val box = a.card("Нагрузка на устройство", "Прогноз для текущих настроек по индексу производительности вашего телефона + реальные показатели сейчас.")
        tv = TextView(a).also { it.textSize = 13f; it.setTypeface(null, Typeface.BOLD); it.setTextColor(Ui.text); it.setPadding(0, dp(6), 0, dp(4)); box.addView(it) }
        barView = LoadBarView(a).also { box.addView(it, LinearLayout.LayoutParams(a.MATCH, a.WRAP)) }
        tvParts = TextView(a).also { it.textSize = 11f; it.setTextColor(Ui.dim); it.typeface = Typeface.MONOSPACE; it.setPadding(0, dp(4), 0, 0); box.addView(it) }
        tvReal = TextView(a).also { it.textSize = 11f; it.setTextColor(Ui.dim); it.setPadding(0, dp(2), 0, 0); box.addView(it) }
        refreshBar()
        main.removeCallbacks(tick)
        main.postDelayed(tick, 1000)
    }

    private fun refreshBar() {
        try {
            val cap = capacity(); val l = LoadModel.loads(nowInput(), cap)
            val lv = l.level
            tv?.text = dotted(if (l.total > 300.0) "перегрузка: нужно ≈ ${Math.round(l.total / 100.0)}× возможностей телефона (узкое место: ${l.bottleneck})" else "≈ %.0f%% · узкое место: %s · %s".format(l.total, l.bottleneck, lv.label), lv)
            barView?.let { it.pct = l.total; it.invalidate() }
            fun pc(v: Double) = if (v > 999.0) ">999%" else "%.0f%%".format(v)
            tvParts?.text = "GPU ${pc(l.gpu)}   CPU ${pc(l.cpu)}   кодек ${pc(l.enc)}   память ${pc(l.mem)}"
            val r = resMon.sample()
            val st = a.engine.recStats()
            tvReal?.text = buildString {
                append("Индекс ${cap.index}" + if (cap.measured) " (${PerfIndex.label(cap.index)})" else " — тест не проходил, оценка по опорному устройству")
                append("\nСейчас: ")
                append(r.cpuProcessPercentOfCore?.let { "CPU приложения %.0f%% ядра".format(it) } ?: "CPU недоступно")
                append(" · RAM свободно ${r.ramAvailMb} МБ · нагрев: ${r.thermalLabel}")
                if (st != null) append(" · потеряно кадров: ${st.droppedVideo}")
            }
        } catch (e: Exception) { tv?.text = "Нагрузка: недоступно" }
    }

    // ------------------------------------------------------------ тест производительности

    /** При первом входе в камеру: тест, если его ещё не проходили и не пропускали. */
    fun maybeFirstRun() {
        if (benchRunning || bench != null || a.prefs.getBoolean("perf29_done", false) || a.prefs.getBoolean("perf29_skip", false)) return
        main.postDelayed({ if (!a.isFinishing && !a.recording) runBench(first = true) }, 1500)
    }

    fun runBench(first: Boolean) {
        if (benchRunning || a.recording) { if (a.recording) a.toast("Остановите запись перед тестом"); return }
        benchRunning = true
        val col = LinearLayout(a); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(12), dp(20), dp(4))
        val msg = TextView(a); msg.text = (if (first) "Первый запуск: измеряем возможности телефона (≈ 10 с), чтобы показывать, насколько каждая настройка его нагружает. Ничего не записывается и не меняется.\n\n" else "Измеряем возможности телефона (≈ 10 с). Превью может на время подвиснуть.\n\n") + "Подготовка…"
        val pb = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal); pb.max = 100
        col.addView(msg); col.addView(pb)
        val b = Bench(a) { stage, f -> main.post { msg.text = msg.text.toString().substringBefore("\n\n") + "\n\n" + stage; pb.progress = (f * 100).toInt() } }
        benchObj = b
        dialog = android.app.AlertDialog.Builder(a).setTitle("Тест производительности").setView(col).setCancelable(false)
            .setNegativeButton("Пропустить") { _, _ -> b.cancelled = true }.show()
        Thread {
            var res: BenchResult? = null; var err: String? = null
            try { res = b.run() } catch (e: InterruptedException) { } catch (e: Throwable) { err = (e.message ?: e.javaClass.simpleName).take(80) }
            main.post { finishBench(res, err, first) }
        }.start()
    }

    private fun finishBench(res: BenchResult?, err: String?, first: Boolean) {
        benchRunning = false; benchObj = null
        try { dialog?.dismiss() } catch (e: Exception) { }
        dialog = null
        if (a.isFinishing) return
        if (res != null) {
            bench = res
            a.prefs.edit().putString("perf29_json", res.serialize()).putBoolean("perf29_done", true).apply()
            a.appLog("Тест производительности: индекс ${res.index}" + if (res.partial) " (часть замеров недоступна)" else "")
            a.toast("Индекс производительности: ${res.index} — ${PerfIndex.label(res.index)}" + if (res.hotStart) ". Телефон был горячий — повторите тест после остывания" else "")
        } else {
            if (first) a.prefs.edit().putBoolean("perf29_skip", true).apply()
            a.toast(if (err != null) "Тест не удался: $err" else "Тест пропущен — его можно запустить в Меню → Настройки → Производительность")
        }
        if (a.menuVisible()) a.showTab(a.menuTab, true)
    }

    fun cancel() { benchObj?.cancelled = true; try { dialog?.dismiss() } catch (e: Exception) { }; dialog = null }

    // ------------------------------------------------------------ выгрузка

    private fun fullText(): String = BenchReport.text(bench) + (bench?.let { "\n--- сырые данные ---\n" + it.serialize() } ?: "")

    fun exportFile(): String? {
        if (bench == null) return null
        val name = "BeyondRecorder_bench_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = a.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
                a.contentResolver.openOutputStream(uri)?.use { it.write(fullText().toByteArray()) } ?: return null
                "Загрузки/$name"
            } else {
                val f = File(a.getExternalFilesDir(null) ?: a.filesDir, name)
                f.writeText(fullText()); f.absolutePath
            }
        } catch (e: Exception) { null }
    }

    fun copyReport() {
        (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Beyond Recorder", fullText()))
        a.toast("Результаты скопированы в буфер обмена")
    }

    fun reportText(): String = BenchReport.text(bench)
}
