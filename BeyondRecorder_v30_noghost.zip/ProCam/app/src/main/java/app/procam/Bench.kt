package app.procam

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES30
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** Тестовый цикл процессора: целочисленная и вещественная арифметика, ~6 операций на итерацию. Чистый Kotlin, проверяется на JVM. */
object CpuKernel {
    const val OPS_PER_ITER = 6
    fun run(iters: Int, seed: Long): Long {
        var x = seed; var f = 1.0
        for (i in 0 until iters) { x = x * 6364136223846793005L + 1442695040888963407L; f = f * 1.0000001 + (x ushr 40).toDouble() * 1e-9 }
        return x xor f.toBits()
    }
    fun mops(iters: Long, ms: Long): Double = if (ms <= 0) 0.0 else iters * OPS_PER_ITER / 1e6 / (ms / 1000.0)
}

/**
 * Тест производительности: CPU (одно ядро и все ядра), память, GPU (опорный шейдер в офскринном контексте), кодек (H.264 1080p через Surface).
 * Каждый этап в try/catch: не удавшийся замер остаётся null и честно отмечается в отчёте. Запускать не из UI-потока.
 */
class Bench(private val ctx: Context, private val onProgress: (String, Float) -> Unit) {
    @Volatile var cancelled = false

    private fun thermal(): Int? = if (Build.VERSION.SDK_INT >= 29) (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus else null

    fun run(): BenchResult {
        val t0 = SystemClock.elapsedRealtime()
        val th0 = thermal()
        onProgress("Процессор, одно ядро", 0.02f)
        val single = cpuSingle(450)
        if (cancelled) throw InterruptedException()
        onProgress("Процессор, все ядра", 0.2f)
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val multi = cpuMulti(cores, 450)
        if (cancelled) throw InterruptedException()
        onProgress("Память", 0.4f)
        val mem = memory(400)
        if (cancelled) throw InterruptedException()
        onProgress("Графический процессор", 0.55f)
        var gpu: Double? = null; var gpuNote = ""; var gpuName = ""
        try { val g = gpuBench(); gpu = g.first; gpuName = g.second } catch (e: Throwable) { gpuNote = "не удалось: " + (e.message ?: e.javaClass.simpleName).take(80) }
        if (cancelled) throw InterruptedException()
        onProgress("Видеокодек", 0.8f)
        var enc: Double? = null; var encNote = ""
        try { enc = encBench() } catch (e: Throwable) { encNote = "не удалось: " + (e.message ?: e.javaClass.simpleName).take(80) }
        onProgress("Готово", 1f)
        return BenchResult(single, multi, cores, mem, gpu, enc, gpuNote, encNote, SystemClock.elapsedRealtime() - t0, th0, thermal(),
            device = "${Build.MANUFACTURER} ${Build.MODEL}", soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE,
            gpuName = gpuName, appVersion = Changelog.entries.first().first, atMs = System.currentTimeMillis())
    }

    private var sink = 0L

    private fun cpuSingle(ms: Long): Double {
        CpuKernel.run(200_000, 1)                                    // прогрев JIT
        var iters = 0L; val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < ms) { sink += CpuKernel.run(300_000, iters); iters += 300_000 }
        return CpuKernel.mops(iters, SystemClock.elapsedRealtime() - t0)
    }

    private fun cpuMulti(n: Int, ms: Long): Double {
        val counts = LongArray(n)
        val t0 = SystemClock.elapsedRealtime()
        val th = (0 until n).map { k -> Thread {
            var it = 0L
            while (SystemClock.elapsedRealtime() - t0 < ms) { CpuKernel.run(300_000, it + k); it += 300_000 }
            counts[k] = it
        }.also { it.start() } }
        th.forEach { it.join() }
        return CpuKernel.mops(counts.sum(), SystemClock.elapsedRealtime() - t0)
    }

    private fun memory(ms: Long): Double {
        val n = 8 * 1024 * 1024                                       // 32 МБ на массив — заведомо больше кэшей
        val a = IntArray(n) { it }; val b = IntArray(n)
        var bytes = 0L; val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < ms) { System.arraycopy(a, 0, b, 0, n); bytes += n * 4L * 2; a[bytes.toInt() and 1023] = b[7] }
        return bytes / 1e9 / ((SystemClock.elapsedRealtime() - t0) / 1000.0)
    }

    // ---------------------------------------------------------------- GPU

    private class Egl(val dpy: EGLDisplay, val ctx: EGLContext, val surf: EGLSurface)

    private fun makeEgl(window: Any?): Egl {
        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw IllegalStateException("EGL init")
        val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        val surfType = if (window == null) EGL14.EGL_PBUFFER_BIT else EGL14.EGL_WINDOW_BIT
        val attr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, 0x40, EGL14.EGL_SURFACE_TYPE, surfType,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_NONE)
        if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0) || n[0] == 0) throw IllegalStateException("EGL config")
        val c = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        val s = if (window == null) EGL14.eglCreatePbufferSurface(dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 16, EGL14.EGL_HEIGHT, 16, EGL14.EGL_NONE), 0)
        else EGL14.eglCreateWindowSurface(dpy, cfgs[0], window, intArrayOf(EGL14.EGL_NONE), 0)
        if (!EGL14.eglMakeCurrent(dpy, s, s, c)) throw IllegalStateException("EGL current")
        return Egl(dpy, c, s)
    }

    private fun freeEgl(e: Egl?) {
        if (e == null) return
        try {
            EGL14.eglMakeCurrent(e.dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(e.dpy, e.surf); EGL14.eglDestroyContext(e.dpy, e.ctx); EGL14.eglTerminate(e.dpy)
        } catch (t: Throwable) { }
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type); GLES30.glShaderSource(s, src); GLES30.glCompileShader(s)
        val ok = IntArray(1); GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { val log = GLES30.glGetShaderInfoLog(s); GLES30.glDeleteShader(s); throw IllegalStateException("shader: " + log.take(60)) }
        return s
    }

    private val VS = "#version 300 es\nlayout(location=0) in vec2 p; out vec2 uv; void main(){ uv = p*0.5+0.5; gl_Position = vec4(p,0.0,1.0); }"
    /** «Опорный проход»: 9 выборок текстуры + арифметика — по весу близок к проходу пространственного шумоподавления. */
    private val FS = "#version 300 es\nprecision mediump float; uniform sampler2D t; uniform float k; in vec2 uv; out vec4 o;\n" +
        "void main(){ vec4 a = vec4(0.0); float d = 1.0/512.0; for(int y=-1;y<=1;y++) for(int x=-1;x<=1;x++){ vec4 c = texture(t, uv + vec2(float(x),float(y))*d);\n" +
        " a += c * (1.0 - 0.1*abs(c.g - 0.5)); } a *= (1.0/9.0); o = vec4(pow(a.rgb, vec3(0.9+k)), 1.0); }"

    private fun gpuBench(): Pair<Double, String> {
        var e: Egl? = null
        try {
            e = makeEgl(null)
            val name = GLES30.glGetString(GLES30.GL_RENDERER) ?: ""
            val W = 1920; val H = 1080                                // 1080p: на быстрых GPU 720p упирается в драйвер, а не в шейдер
            val pr = GLES30.glCreateProgram()
            GLES30.glAttachShader(pr, shader(GLES30.GL_VERTEX_SHADER, VS)); GLES30.glAttachShader(pr, shader(GLES30.GL_FRAGMENT_SHADER, FS))
            GLES30.glLinkProgram(pr); GLES30.glUseProgram(pr)
            val tex = IntArray(2); GLES30.glGenTextures(2, tex, 0)
            for (t in tex) {
                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t)
                GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, W, H, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            }
            val fbo = IntArray(2); GLES30.glGenFramebuffers(2, fbo, 0)
            for (i in 0..1) { GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[i]); GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, tex[i], 0) }
            if (GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) != GLES30.GL_FRAMEBUFFER_COMPLETE) throw IllegalStateException("FBO")
            val quad: FloatBuffer = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)).also { it.position(0) }
            GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, quad)
            GLES30.glViewport(0, 0, W, H)
            GLES30.glUniform1i(GLES30.glGetUniformLocation(pr, "t"), 0)
            fun draw(n: Int) {
                var src = 0
                repeat(n) {
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[1 - src]); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[src])
                    GLES30.glUniform1f(GLES30.glGetUniformLocation(pr, "k"), (it % 7) * 0.001f)
                    GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4); src = 1 - src
                }
                GLES30.glFinish()
            }
            draw(8)                                                   // прогрев: компиляция, частоты
            var frames = 0; val t0 = SystemClock.elapsedRealtime()
            while (SystemClock.elapsedRealtime() - t0 < 1000 && !cancelled) { draw(8); frames += 8 }
            val dt = (SystemClock.elapsedRealtime() - t0) / 1000.0
            if (frames == 0 || dt <= 0) throw IllegalStateException("нет кадров")
            return (W.toDouble() * H * frames / 1e6 / dt) to name
        } finally { freeEgl(e) }
    }

    // ---------------------------------------------------------------- кодек

    private fun encBench(): Double {
        val W = 1920; val H = 1080
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 20_000_000); fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 120); fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var e: Egl? = null
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = codec.createInputSurface()
            codec.start()
            e = makeEgl(surface)
            val info = MediaCodec.BufferInfo()
            var submitted = 0; var done = 0
            val limitFrames = 600; val t0 = SystemClock.elapsedRealtime()
            var tWarm = 0L; var doneWarm = 0                       // старт кодека в скорость не входит: меряем после первых кадров
            val warm = 30
            fun drain() {
                while (true) {
                    val i = codec.dequeueOutputBuffer(info, 0)
                    if (i < 0) break
                    codec.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) { done++; if (done == warm) { tWarm = SystemClock.elapsedRealtime(); doneWarm = done } }
                }
            }
            while (submitted < limitFrames && SystemClock.elapsedRealtime() - t0 < 4000 && !cancelled) {
                val x = (submitted % 30) / 30f
                GLES30.glClearColor(x, 1f - x, 0.5f, 1f)
                // немного движения, чтобы кодек работал не на пустых кадрах
                GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
                GLES30.glViewport(0, 0, W, H)
                GLES30.glScissor((submitted * 37) % (W - 200), (submitted * 23) % (H - 200), 200, 200)
                GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
                GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                android.opengl.EGLExt.eglPresentationTimeANDROID(e.dpy, e.surf, submitted * 8_333_333L)
                EGL14.eglSwapBuffers(e.dpy, e.surf)
                submitted++
                drain()
            }
            codec.signalEndOfInputStream()
            val tEnd = SystemClock.elapsedRealtime() + 1500
            while (SystemClock.elapsedRealtime() < tEnd) {
                val i = codec.dequeueOutputBuffer(info, 10_000)
                if (i >= 0) { codec.releaseOutputBuffer(i, false); if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) { done++; if (done == warm) { tWarm = SystemClock.elapsedRealtime(); doneWarm = done } }; if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break }
            }
            val tEndMs = SystemClock.elapsedRealtime()
            if (tWarm == 0L || done - doneWarm < 20) throw IllegalStateException("мало кадров ($done)")
            return W.toDouble() * H * (done - doneWarm) / 1e6 / ((tEndMs - tWarm) / 1000.0)
        } finally {
            freeEgl(e)
            try { codec.stop() } catch (t: Throwable) { }
            try { codec.release() } catch (t: Throwable) { }
        }
    }
}

/** Текст отчёта для файла и для экрана. */
object BenchReport {
    fun text(r: BenchResult?): String {
        if (r == null) return "Тест производительности ещё не выполнялся. Оценки нагрузки считаются для опорного устройства (индекс 100) и могут не соответствовать вашему телефону."
        fun n(v: Double?, u: String) = if (v == null) "не измерено" else "%.0f %s".format(v, u)
        return buildString {
            appendLine("Beyond Recorder — тест производительности")
            appendLine("Устройство: ${r.device}  ·  SoC: ${r.soc.ifBlank { "—" }}")
            appendLine("Версия приложения: ${r.appVersion}  ·  время теста: ${r.durationMs / 1000.0} с")
            appendLine("Индекс производительности: ${r.index} (${PerfIndex.label(r.index)}; 100 = опорное устройство)" + if (r.partial) "  — посчитан по измеренным узлам" else "")
            appendLine("CPU, одно ядро: ${n(r.cpuSingleMops, "Мопс/с")}")
            appendLine("CPU, ${r.cores} ядер: ${n(r.cpuMultiMops, "Мопс/с")}")
            appendLine("Память (копирование): %.1f ГБ/с".format(r.memGBs))
            appendLine("GPU (${r.gpuName.ifBlank { "—" }}): ${n(r.gpuMpps, "Мпикс·проходов/с")}" + if (r.gpuNote.isNotEmpty()) " (${r.gpuNote})" else "")
            appendLine("Кодек H.264 1080p: ${n(r.encMpix, "Мпикс/с")}" + if (r.encNote.isNotEmpty()) " (${r.encNote})" else "")
            appendLine("Нагрев в начале/конце: ${thermalName(r.thermalStart)} / ${thermalName(r.thermalEnd)}")
            if (r.hotStart) appendLine("⚠ Тест прошёл на уже разогретом телефоне: GPU и кодек занижены из-за троттлинга. Повторите после остывания.")
            appendLine()
            appendLine("Как читать: коэффициенты стоимости настроек — инженерная оценка по структуре обработки, на конкретных телефонах не калибровались. Метки нагрузки — прогноз, а не измерение; реальная нагрузка показана отдельно в полосе (CPU приложения, память, нагрев).")
            appendLine("Тест идёт при работающем превью камеры, поэтому результаты GPU и кодека слегка занижены (запас в безопасную сторону).")
        }
    }
}
