package app.procam

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/** Уровень нагрузки для подписи у настройки: низкая (зелёный), средняя (жёлтый), высокая (красный). */
enum class LoadLevel(val label: String, val color: Int) {
    LOW("низкая", 0xFF3DDC84.toInt()), MID("средняя", 0xFFFFC107.toInt()), HIGH("высокая", 0xFFFF5252.toInt());
    companion object {
        /** Полная нагрузка устройства (% от ёмкости самого загруженного узла). */
        fun ofTotal(pct: Double) = when { pct < 40.0 -> LOW; pct < 75.0 -> MID; else -> HIGH }
        /** Добавка одной настройки (в процентных пунктах ёмкости узла), где она бьёт сильнее всего. */
        fun ofDelta(pct: Double) = when { pct < 5.0 -> LOW; pct < 15.0 -> MID; else -> HIGH }
    }
}

/** Результаты теста производительности. null — этот замер не удалось выполнить на устройстве (в отчёте так и пишется). */
data class BenchResult(
    val cpuSingleMops: Double, val cpuMultiMops: Double, val cores: Int, val memGBs: Double,
    val gpuMpps: Double?, val encMpix: Double?,
    val gpuNote: String = "", val encNote: String = "",
    val durationMs: Long = 0, val thermalStart: Int? = null, val thermalEnd: Int? = null,
    val device: String = "", val soc: String = "", val gpuName: String = "", val appVersion: String = "", val atMs: Long = 0
) {
    val index: Int get() = PerfIndex.compute(this)
    /** Часть узлов не измерена — индекс посчитан по остальным. */
    val partial: Boolean get() = gpuMpps == null || encMpix == null
    /** Статус нагрева «умеренный» (2) и выше в начале теста — телефон уже троттлил. */
    val hotStart: Boolean get() = (thermalStart ?: 0) >= 2

    fun serialize(): String = buildString {
        fun p(k: String, v: Any?) { append(k).append('=').append(v?.toString()?.replace('\n', ' ') ?: "").append('\n') }
        p("cpuSingle", cpuSingleMops); p("cpuMulti", cpuMultiMops); p("cores", cores); p("mem", memGBs); p("gpu", gpuMpps); p("enc", encMpix)
        p("gpuNote", gpuNote); p("encNote", encNote); p("dur", durationMs); p("thS", thermalStart); p("thE", thermalEnd)
        p("device", device); p("soc", soc); p("gpuName", gpuName); p("ver", appVersion); p("at", atMs)
    }

    companion object {
        fun parse(text: String?): BenchResult? {
            if (text.isNullOrBlank()) return null
            val m = HashMap<String, String>()
            for (l in text.lines()) { val i = l.indexOf('='); if (i > 0) m[l.substring(0, i)] = l.substring(i + 1) }
            val cs = m["cpuSingle"]?.toDoubleOrNull() ?: return null
            val cm = m["cpuMulti"]?.toDoubleOrNull() ?: return null
            val mem = m["mem"]?.toDoubleOrNull() ?: return null
            if (cs <= 0 || cm <= 0 || mem <= 0) return null
            return BenchResult(cs, cm, m["cores"]?.toIntOrNull() ?: 1, mem, m["gpu"]?.toDoubleOrNull()?.takeIf { it > 0 }, m["enc"]?.toDoubleOrNull()?.takeIf { it > 0 },
                m["gpuNote"] ?: "", m["encNote"] ?: "", m["dur"]?.toLongOrNull() ?: 0, m["thS"]?.toIntOrNull(), m["thE"]?.toIntOrNull(),
                m["device"] ?: "", m["soc"] ?: "", m["gpuName"] ?: "", m["ver"] ?: "", m["at"]?.toLongOrNull() ?: 0)
        }
    }
}

/** Условные «опорные» значения: индекс 100 = устройство с такими замерами. Это точка отсчёта, а не измеренный телефон. */
object PerfRef {
    const val CPU_SINGLE = 600.0     // Мопс/с одного ядра тестового цикла
    const val CPU_MULTI = 3000.0
    const val MEM = 8.0              // ГБ/с копирования
    const val GPU = 4000.0           // Мпикс·проходов/с (опорный шейдер, 9 выборок)
    const val ENC = 2500.0           // Мпикс/с кодирования H.264 1080p
}

object PerfIndex {
    private val weights = mapOf("gpu" to 0.35, "cs" to 0.20, "cm" to 0.15, "mem" to 0.10, "enc" to 0.20)
    /** Взвешенное геометрическое среднее отношений замеров к опорным ×100; отсутствующие замеры исключаются, веса пересчитываются. */
    fun compute(r: BenchResult): Int {
        val parts = ArrayList<Pair<Double, Double>>()
        parts.add(weights["cs"]!! to r.cpuSingleMops / PerfRef.CPU_SINGLE)
        parts.add(weights["cm"]!! to r.cpuMultiMops / PerfRef.CPU_MULTI)
        parts.add(weights["mem"]!! to r.memGBs / PerfRef.MEM)
        r.gpuMpps?.let { parts.add(weights["gpu"]!! to it / PerfRef.GPU) }
        r.encMpix?.let { parts.add(weights["enc"]!! to it / PerfRef.ENC) }
        val ws = parts.sumOf { it.first }
        var lg = 0.0
        for ((w, v) in parts) lg += (w / ws) * kotlin.math.ln(v.coerceAtLeast(1e-6))
        return (100.0 * kotlin.math.exp(lg)).roundToInt().coerceAtLeast(1)
    }
    fun label(idx: Int) = when { idx < 35 -> "очень скромный"; idx < 70 -> "средний"; idx < 140 -> "хороший"; idx < 250 -> "высокий"; else -> "флагманский" }
}

/** Ёмкость узлов устройства в тех же единицах, что и стоимость настроек. Ёмкость 100 % = безопасная доля пика, а не пик. */
data class Capacity(val gpu: Double, val cpu: Double, val enc: Double, val memMb: Double, val measured: Boolean, val index: Int) {
    companion object {
        const val GPU_USABLE = 0.6; const val CPU_USABLE = 0.5; const val ENC_USABLE = 0.7
        fun from(r: BenchResult?, ramTotalMb: Long): Capacity {
            val mem = max(256.0, ramTotalMb * 0.12)
            if (r == null) return Capacity(PerfRef.GPU * GPU_USABLE, PerfRef.CPU_SINGLE * CPU_USABLE, PerfRef.ENC * ENC_USABLE, mem, false, 100)
            val idx = r.index
            return Capacity(
                (r.gpuMpps ?: PerfRef.GPU * idx / 100.0) * GPU_USABLE, r.cpuSingleMops * CPU_USABLE,
                (r.encMpix ?: PerfRef.ENC * idx / 100.0) * ENC_USABLE, mem, true, idx
            )
        }
    }
}

/** Нагрузка по узлам в % ёмкости. */
data class Loads(val gpu: Double, val cpu: Double, val enc: Double, val mem: Double) {
    val total: Double get() = max(max(gpu, cpu), max(enc, mem))
    val bottleneck: String get() = when (total) { gpu -> "GPU"; cpu -> "CPU"; enc -> "кодек"; else -> "память" }
    val level: LoadLevel get() = LoadLevel.ofTotal(total)
}

/** Всё, от чего зависит нагрузка. Поля называются так же, как соответствующие настройки. */
data class LoadInput(
    val w: Int = 3840, val h: Int = 2160, val fps: Int = 30, val hevc: Boolean = true, val bitrateMbps: Int = 60, val bFrames: Boolean = false,
    /** 0 SDR, 1 LOG (программная кривая), 2 HLG (эмуляция) */
    val mode: Int = 0, val hwLog: Boolean = false,
    /** 0 выкл, 1 монитор, 2 монитор+запись, 3 запись */
    val lutMode: Int = 0, val colorPipe: Boolean = false, val grade: Boolean = false,
    val nrSoft: Int = 0, val nrAdv: Boolean = false, val nrSpat: Boolean = true, val nrTemp: Boolean = true, val nrLuma: Boolean = true, val nrChroma: Boolean = true,
    val nrDetail: Boolean = true, val nrMc: Boolean = false, val lowLight: Boolean = false,
    val eis: Int = 0, val gyro: Boolean = true, val srcMode: Int = 0 /* 0 авто 1 гироскоп 2 поток */, val lockOn: Boolean = true, val horizon: Boolean = false, val rs: Boolean = true,
    val flowMethod: Int = 2, val analysisW: Int = 128, val analysisEvery: Int = 1, val procMode: Int = 1,
    val smoothRec: Boolean = true, val openGate: Boolean = false, val audio: Boolean = true,
    val zebra: Boolean = false, val peaking: Boolean = false, val falseColor: Boolean = false, val hist: Boolean = true, val scopes: Int = 0, val diag: Boolean = false
) {
    /** Оптический поток считается, когда он выбран явно или когда гироскопа нет. */
    val visual: Boolean get() = eis > 0 && (srcMode == 2 || (srcMode == 0 && !gyro))
    val nrOn: Boolean get() = nrSoft > 0 || nrAdv || lowLight
    val glRoute: Boolean get() = smoothRec || lutMode >= 2 || nrOn || eis > 0 || (mode == 1 && !hwLog) || mode == 2 || grade || colorPipe
}

object LoadModel {
    /** Проходов опорного шейдера на кадр (в пикселях размера записи). Коэффициенты — инженерная оценка по структуре шейдеров; на устройствах не калибровались. */
    fun gpuPasses(i: LoadInput): Double {
        var p = 0.05                                        // превью без обработки
        if (i.glRoute) p += 1.0 + 0.5 + 0.25                // кадр в GL + передача кодеку + превью
        if (i.mode == 1 && !i.hwLog) p += 0.35
        if (i.mode == 2) p += 0.45
        if (i.lutMode == 1) p += 0.12
        if (i.lutMode == 2) p += 0.47
        if (i.lutMode == 3) p += 0.35
        if (i.colorPipe) p += 0.3
        if (i.grade) p += 0.4
        if (i.nrAdv) {
            p += 0.6
            if (i.nrSpat) p += 0.9
            if (i.nrTemp) p += 1.0
            if (i.nrLuma || i.nrChroma) p += 0.15
            if (i.nrDetail) p += 0.2
            if (i.nrMc) p += 0.5
        } else if (i.nrSoft > 0) p += when (i.nrSoft) { 1 -> 1.2; 2 -> 1.9; else -> 2.6 }
        if (i.lowLight) p += 0.35
        if (i.eis > 0) { p += 1.0 + 0.05 * i.eis; if (i.rs) p += 0.35; if (i.lockOn) p += 0.1 }
        if (i.visual || i.eis > 0) p += 0.05                // уменьшенный кадр для анализа
        if (i.zebra) p += 0.08
        if (i.peaking) p += 0.15
        if (i.falseColor) p += 0.10
        if (i.hist) p += 0.05
        p += 0.10 * i.scopes
        return p
    }

    /** Мопс/кадр на анализ оптического потока. */
    fun flowMopsPerFrame(i: LoadInput): Double {
        val aw = i.analysisW.coerceAtLeast(16); val ah = (aw * 9 / 16).coerceAtLeast(9)
        val (feats, levels) = when (i.procMode) { 0 -> 60 to 2; 2 -> 160 to 4; else -> 100 to 3 }
        val mk = when (i.flowMethod) { 1 -> 0.7; 2 -> 1.4; else -> 1.0 }      // блоки / фаза / LK
        return (aw * ah * 2.6 + feats * levels * 49.0 * 5 * 6) * mk / 1e6
    }

    fun cpuMopsPerSec(i: LoadInput): Double {
        val f = i.fps.toDouble()
        var m = 0.6 * f + (if (i.audio) 8.0 else 0.0)
        if (i.eis > 0) {
            val every = if (i.visual) 1 else i.analysisEvery.coerceAtLeast(1)       // оптический поток считается на каждом кадре
            m += (if (i.visual) flowMopsPerFrame(i) else 0.02) * f / every
            if (i.lockOn) m += 0.05 * f
            if (i.rs) m += 0.02 * f
        }
        if (i.hist) m += 0.1 * f
        m += 0.2 * i.scopes * f
        if (i.diag) m += 0.05 * f
        return m
    }

    fun encMpixPerSec(i: LoadInput): Double {
        val base = i.w.toDouble() * i.h * i.fps / 1e6
        return base * (if (i.hevc) 1.3 else 1.0) * (if (i.bFrames) 1.2 else 1.0) * (1.0 + 0.15 * i.bitrateMbps / 50.0)
    }

    fun memMb(i: LoadInput): Double {
        val px = i.w.toDouble() * i.h
        var m = px * 1.5 * 10 / 1e6                         // буферы камеры и кодека
        if (i.glRoute) m += px * 4 * 3 / 1e6
        if (i.nrOn) m += px * 8 * 2 / 1e6                   // история временного шума (RGBA16F ×2)
        if (i.eis > 0) m += 12.0
        return m
    }

    fun loads(i: LoadInput, c: Capacity): Loads {
        val gpuMpps = i.w.toDouble() * i.h * i.fps / 1e6 * gpuPasses(i)
        return Loads(gpuMpps / c.gpu * 100.0, cpuMopsPerSec(i) / c.cpu * 100.0, encMpixPerSec(i) / c.enc * 100.0, memMb(i) / c.memMb * 100.0)
    }

    /**
     * Уровни для вариантов одной настройки: добавка варианта — разность нагрузки с самым лёгким вариантом по самому «пострадавшему» узлу.
     * Возвращает пары (добавка в п.п., уровень).
     */
    fun optionLevels(options: List<LoadInput>, c: Capacity): List<Pair<Double, LoadLevel>> {
        if (options.isEmpty()) return emptyList()
        val ls = options.map { loads(it, c) }
        val bg = ls.minOf { it.gpu }; val bc = ls.minOf { it.cpu }; val be = ls.minOf { it.enc }; val bm = ls.minOf { it.mem }
        return ls.map { l ->
            val d = max(max(l.gpu - bg, l.cpu - bc), max(l.enc - be, l.mem - bm))
            d to LoadLevel.ofDelta(d)
        }
    }

    /** Сопоставление ключа настройки Computational Imaging (ci_*) и значения → вариант входных данных. */
    fun withCi(i: LoadInput, key: String, v: Int): LoadInput = when (key) {
        "ci_src" -> i.copy(srcMode = v)
        "ci_nr_adv" -> i.copy(nrAdv = v != 0)
        "ci_nr_spat" -> i.copy(nrSpat = v != 0)
        "ci_nr_temp" -> i.copy(nrTemp = v != 0)
        "ci_nr_luma" -> i.copy(nrLuma = v != 0)
        "ci_nr_chroma" -> i.copy(nrChroma = v != 0)
        "ci_nr_detail" -> i.copy(nrDetail = v != 0)
        "ci_nr_mc" -> i.copy(nrMc = v != 0)
        "ci_ll" -> i.copy(lowLight = v != 0)
        "ci_proc" -> i.copy(procMode = v.coerceIn(0, 2))
        "ci_flow" -> i.copy(flowMethod = v.coerceIn(0, 2))
        "ci_rs" -> i.copy(rs = v != 0)
        "ci_hz_src" -> i
        "ci_diag" -> i.copy(diag = v != 0)
        "ci_an_w" -> if (v <= 0 || v >= CiKeys.AN_W.size) i else i.copy(analysisW = CiKeys.AN_W[v])
        "ci_an_div" -> if (v <= 0) i else i.copy(analysisEvery = v)
        else -> i
    }
}
