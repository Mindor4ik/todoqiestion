package app.procam

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Рамка записываемой (активной) области внутри полного кадра при включённой стабилизации: вне рамки — затемнение. */
class EisFrameView(c: Context) : View(c) {
    private var q: FloatArray? = null
    private val density = resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x88000000.toInt(); style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f * density }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA000000.toInt(); style = Paint.Style.STROKE; strokeWidth = 4.5f * density }
    private val quad = Path()
    private val outer = Path()

    fun set(c: FloatArray?) { q = c; invalidate() }

    override fun onDraw(cv: Canvas) {
        val a = q ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        quad.reset()
        quad.moveTo(a[0] * w, a[1] * h)
        quad.lineTo(a[2] * w, a[3] * h)
        quad.lineTo(a[4] * w, a[5] * h)
        quad.lineTo(a[6] * w, a[7] * h)
        quad.close()
        outer.reset()
        outer.fillType = Path.FillType.EVEN_ODD
        outer.addRect(0f, 0f, w, h, Path.Direction.CW)
        outer.addPath(quad)
        cv.drawPath(outer, dim)
        cv.drawPath(quad, shadow)
        cv.drawPath(quad, line)
    }
}

/** Простая гистограмма яркости (64 столбца, корневая шкала). */
class HistogramView(c: Context) : View(c) {
    private var bins = IntArray(64)
    private val p = Paint().apply { color = 0xCCFFFFFF.toInt() }
    private val bg = Paint().apply { color = 0x66000000 }

    fun set(b: IntArray) { bins = b; invalidate() }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val mx = (bins.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()
        val bw = width / 64f
        for (i in 0 until 64) {
            val h = sqrt(bins[i] / mx) * height
            cv.drawRect(i * bw, height - h, (i + 1) * bw, height.toFloat(), p)
        }
    }
}

class MainActivity : Activity(), SurfaceHolder.Callback, CameraEngine.Listener {

    internal val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    internal val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val minRailDp = 72                    // dp, минимальная ширина боковых панелей (слева и справа от превью)
    private var railPx = 0                        // px, фактическая ширина панелей: всё, что шире 16:9, отдаём им
    private val tabLut = 2
    private val tabStab = 4
    private val tabNr = 15
    internal val subPage = HashMap<Int, Int>()
    private val tabCamera = 5
    internal var syncStatus = ""
    private val tabNames = listOf("Запись", "Цвет", "LUT", "Монитор", "Стабилизация", "Камера", "Интерфейс", "Обновления", "О приложении", "Диагностика", "Настройки", "Управление цветом", "Градация", "Анализ", "Стабилизация 2.0", "NR и обработка", "Уведомления", "Оформление", "Экран камеры", "Поиск настроек")
    /** Порядок и группы в списке разделов: индексы совпадают с tabNames. */
    private val tabGroups = listOf("СЪЁМКА" to listOf(0, 5), "ИЗОБРАЖЕНИЕ" to listOf(1, 11, 12, 4, 15, 2), "ЭКРАН" to listOf(3, 13, 6, 18, 17), "ПРИЛОЖЕНИЕ" to listOf(7, 8, 9, 10, 16, 19))
    internal val amber = 0xFFFFFFFF.toInt()

    internal lateinit var engine: CameraEngine
    internal val engineReady get() = ::engine.isInitialized
    private lateinit var root: FrameLayout
    private lateinit var host: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var gridView: GridView
    private lateinit var eisFrameView: EisFrameView
    internal lateinit var levelView: LevelView
    private lateinit var statusHud: TextView
    private lateinit var hud: TextView
    private lateinit var expHud: TextView
    private lateinit var recHud: TextView
    private lateinit var hist: HistogramView
    private lateinit var panel: LinearLayout
    private lateinit var leftRail: LinearLayout     // левая панель: быстрые переключатели
    private lateinit var leftScroll: ScrollView
    private lateinit var side: LinearLayout         // правая панель: объектив, зум, запись, ручные, меню
    private lateinit var recBtn: Button
    private lateinit var zoomSlider: ZoomSlider
    private lateinit var meterView: AudioMeterView
    private var audioMeter: AudioMeter? = null
    private var resumed = false
    private var zoomAnimator: ValueAnimator? = null
    private var introDone = false
    private val tabColor = 1
    private var zoomPresets: List<Float> = emptyList()
    private var zoomNear = -1
    private var menuBtn: Button? = null
    private var menuAnim: Animator? = null
    private val menuSideDp = 200
    private var recDraw: RecDrawable? = null
    private var recAnim: ValueAnimator? = null
    private var recT = 0f                          // 0 — круг (ожидание), 1 — скруглённый квадрат (запись)
    private val recSizeDp = 76
    private val pauseSizeDp = 48
    internal lateinit var lutRibbon: LutRibbon
    private val tabMonitor = 3
    private var lastZoomPush = 0L
    private lateinit var isoBar: SeekBar
    private lateinit var shutBar: SeekBar
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar
    // меню
    private lateinit var menu: FrameLayout
    private lateinit var menuBody: LinearLayout
    private lateinit var menuScroll: ScrollView
    private lateinit var menuTabsBox: LinearLayout
    private lateinit var menuSheet: LinearLayout
    private val tabButtons = ArrayList<Button>()
    internal var menuTab = 0

    internal val main = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()       // быстрые кнопки
    private val menuRefreshers = ArrayList<() -> Unit>()   // строки текущей вкладки меню
    internal var lenses: List<Lens> = emptyList()
    private var shutters: List<Int> = emptyList()
    private var ready = false
    internal var recording = false
    private var recStart = 0L
    private var pausedTotal = 0L
    private var pauseSince = 0L
    private var isPaused = false
    private lateinit var pauseBtn: ImageView
    private lateinit var pauseIcon: PauseIcon
    internal var gridIdx = 1
    internal var guideIdx = 0

    private val lutPicker = 44
    /** Предел — память приложения, а не произвольное число: файл читается целиком (~2 байта на символ) и затем разбирается. */
    private val maxLutBytes get() = minOf(512L shl 20, Runtime.getRuntime().maxMemory() / 6)
    internal val prefs by lazy { getSharedPreferences("procam", MODE_PRIVATE) }
    internal val settings by lazy { SettingsManager(PrefsStore(prefs)) }
    internal val colorSettings by lazy { ColorSettings(PrefsStore(prefs)) }
    internal val ciSettings by lazy { CiSettings(PrefsStore(prefs)) }
    internal val lutLib by lazy { LutLibrary(prefs) }
    // v0.28: уведомления, раскладка главного экрана, избранное и история настроек
    internal val alerts by lazy { AlertCenter(PrefsStore(prefs)) }
    internal val layouts by lazy { HomeLayoutStore(PrefsStore(prefs)) }
    internal val favorites by lazy { SettingFavorites(PrefsStore(prefs)) }
    internal val history by lazy { SettingHistory(PrefsStore(prefs)) }
    internal val v28 by lazy { V28Tabs(this) }
    private val monMon by lazy { ResourceMonitor(this) }
    private var skipShootingSave = false
    private var prefSnapshot: Map<String, Any?> = emptyMap()
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
        if (key != null) {
            val now = sp.all[key]
            val old = prefSnapshot[key]
            if (old != now && history.tracked(key)) history.record(key, old, now)
            prefSnapshot = HashMap(sp.all)
        }
    }
    private val lutCache = LinkedHashMap<String, CubeLut>()   // последние 2 разобранных LUT — переключение мгновенное
    @Volatile private var pendingLut: String? = null

    private val density: Float get() = resources.displayMetrics.density
    internal fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    // Строка состояния: короткий журнал того, что делает приложение (человеческим текстом), в правом нижнем углу.
    private class LogLine(val at: Long, val text: String)
    private val logLines = ArrayList<LogLine>()
    private var logView: TextView? = null
    private val logTick = Runnable { renderLog() }
    private val logTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
    private val logTtlMs = 9000L
    private val logMax = 2

    /** Записать действие приложения в журнал (можно вызывать из любого потока). */
    internal fun appLog(msg: String) {
        runOnUiThread {
            logLines.add(LogLine(System.currentTimeMillis(), msg))
            while (logLines.size > logMax) logLines.removeAt(0)
            renderLog()
        }
    }

    private fun renderLog() {
        val v = logView ?: return
        val now = System.currentTimeMillis()
        logLines.removeAll { now - it.at > logTtlMs }
        val show = prefs.getBoolean("status_log", true) && logLines.isNotEmpty()
        v.removeCallbacks(logTick)
        if (!show) { v.visibility = View.GONE; return }
        v.text = logLines.joinToString("\n") { logTime.format(java.util.Date(it.at)) + "  " + it.text }
        v.visibility = View.VISIBLE
        v.postDelayed(logTick, 1000)
    }

    // Собственные всплывающие сообщения приложения (вместо системных Toast): плашка сверху по центру, поверх всего интерфейса.
    private var noteView: TextView? = null
    private val noteHide = Runnable {
        noteView?.animate()?.alpha(0f)?.translationY(dp(6).toFloat())?.setStartDelay(0)?.setDuration(220)?.setInterpolator(Ease.exit)
            ?.withEndAction { noteView?.visibility = View.GONE }?.start()
    }

    private fun showNote(msg: String, ms: Long, error: Boolean = false) {
        runOnUiThread {
            if (!::root.isInitialized) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); return@runOnUiThread }
            val v = noteView ?: TextView(this).apply {
                textSize = 13f
                gravity = Gravity.CENTER
                maxLines = 4
                maxWidth = dp(460)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                elevation = dp(8).toFloat()
                visibility = View.GONE
                isClickable = false
                noteView = this
                root.addView(this, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(66) })
            }
            v.background = GradientDrawable().apply {
                if (Ui.m3) {
                    cornerRadius = dp(16).toFloat()
                    setColor(Ui.palette.surfaceContainerHighest)
                    setStroke(dp(if (error) 2 else 1), if (error) Ui.palette.error else Ui.palette.outlineVariant)
                } else {
                    cornerRadius = dp(if (Ui.glass) 22 else 14).toFloat()
                    setColor(if (Ui.glass) 0xD91C1C1E.toInt() else 0xF21C1C1E.toInt())
                    setStroke(dp(1), if (error) 0xFFFFFFFF.toInt() else if (Ui.glass) 0x3DFFFFFF else amber)
                }
            }
            v.setTextColor(if (Ui.m3) Ui.palette.onSurface else Ui.text)
            v.text = msg
            v.removeCallbacks(noteHide)
            v.animate().cancel()
            v.visibility = View.VISIBLE
            v.alpha = 0f
            v.translationY = dp(8).toFloat()
            v.bringToFront()
            v.animate().alpha(1f).translationY(0f).setStartDelay(0).setDuration(280).setInterpolator(Ease.enter).start()
            v.postDelayed(noteHide, ms)
        }
    }

    internal fun toast(s: String) = showNote(s, 2200)
    private fun toastLong(s: String) = showNote(s, 4500)

    /** Во время записи смены маршрута запрещены: restart() остановил бы запись. */
    internal fun idle(block: () -> Unit) {
        if (recording) toast("Сначала остановите запись") else block()
    }

    // ------------------------------------------------------------ LUT: библиотека

    private fun activeLutName(): String = lutLib.active()?.name ?: "нет"

    internal fun pickLutFiles() = idle {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, lutPicker)
    }

    @Deprecated("Legacy SAF result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != lutPicker || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        // Без постоянного доступа сохранённый URI после перезапуска приложения уже не откроется.
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        }
        importLuts(uris)
    }

    private fun displayName(u: Uri): String {
        var n: String? = null
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        } catch (e: Exception) { }
        return (n ?: u.lastPathSegment ?: "LUT").removeSuffix(".cube").removeSuffix(".CUBE")
    }

    /** Разбор .cube (LUT 65³ — сотни мс и десятки МБ): только в фоне. */
    private fun parseLut(uri: Uri): CubeLut {
        val len = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        if (len > maxLutBytes) error("файл (${len / 1_000_000} МБ) не поместится в память приложения при разборе (доступно ≈ ${maxLutBytes / 1_000_000} МБ)")
        return contentResolver.openInputStream(uri)?.use { input ->
            LutEngine.toCube(LutEngine.parse(input.bufferedReader(Charsets.UTF_8).readText()))
        } ?: error("не удалось открыть файл")
    }

    private fun importLuts(uris: List<Uri>) {
        toast("Читаю LUT: ${uris.size}…")
        Thread({
            val ok = ArrayList<Pair<LutEntry, CubeLut?>>()
            val errors = ArrayList<String>()
            for (u in uris) {
                val name = displayName(u)
                try {
                    val lut = parseLut(u)
                    // Объект LUT оставляем только у первого файла (его можно сразу включить) — остальные не держим в памяти.
                    ok.add(LutEntry(name, u.toString(), lut.size) to (if (ok.isEmpty()) lut else null))
                } catch (e: OutOfMemoryError) {
                    errors.add("$name: недостаточно памяти")
                } catch (e: Exception) {
                    errors.add("$name: ${e.message ?: "неверный .cube"}")
                }
            }
            runOnUiThread { if (!isDestroyed) onLutsImported(ok, errors, uris.size == 1) }
        }, "lut-import").start()
    }

    private fun onLutsImported(ok: List<Pair<LutEntry, CubeLut?>>, errors: List<String>, single: Boolean) {
        ok.forEach { lutLib.add(it.first) }
        if (errors.isNotEmpty()) toastLong("Не загружено:\n" + errors.joinToString("\n"))
        else if (ok.isNotEmpty()) toast("Добавлено LUT: ${ok.size}")
        val first = ok.firstOrNull()
        val lut = first?.second
        if (first != null && lut != null && (single || lutLib.activeUri == null)) {
            cacheLut(first.first.uri, lut)
            applyLut(first.first, lut, true)
        } else {
            refreshAll()
        }
        if (::lutRibbon.isInitialized && lutRibbon.opened) lutRibbon.rebuild()
    }

    private fun cacheLut(uri: String, lut: CubeLut) {
        lutCache[uri] = lut
        while (lutCache.size > 2) lutCache.remove(lutCache.keys.first())
    }

    /** Выбрать LUT из списка (null = без LUT). */
    private fun selectLut(e: LutEntry?, fromUser: Boolean = true, silent: Boolean = false) {
        val routeChange = engine.cfg.lutMode in 2..3 && ((lutLib.activeUri == null) != (e == null))
        if (recording && routeChange) { toast("Сначала остановите запись"); return }
        if (e == null) {
            pendingLut = null
            lutLib.setActive(null)
            engine.setLut(null)
            engine.lutConfigChanged()
            appLog("LUT выключен")
            refreshAll()
            return
        }
        val cached = lutCache[e.uri]
        if (cached != null) { applyLut(e, cached, fromUser); return }
        pendingLut = e.uri
        appLog("Загружаю LUT «${e.name}»…")
        if (!silent) toast("Загрузка LUT «${e.name}»…")
        Thread({
            var lut: CubeLut? = null
            var err: String? = null
            try {
                lut = parseLut(Uri.parse(e.uri))
            } catch (x: OutOfMemoryError) {
                err = "недостаточно памяти"
            } catch (x: Exception) {
                err = x.message ?: "неверный .cube"
            }
            val result = lut
            val message = err
            runOnUiThread {
                if (isDestroyed || pendingLut != e.uri) return@runOnUiThread   // пользователь уже выбрал другой
                pendingLut = null
                if (result != null) {
                    cacheLut(e.uri, result)
                    applyLut(e, result, fromUser)
                } else {
                    if (lutLib.activeUri == e.uri) lutLib.setActive(null)
                    toastLong("LUT «${e.name}» недоступен: ${message ?: "ошибка"}. Его можно убрать из списка (✕).")
                    refreshAll()
                }
            }
        }, "lut-load").start()
    }

    private fun applyLut(e: LutEntry, lut: CubeLut, fromUser: Boolean) {
        if (e.size == 0) lutLib.add(e.copy(size = lut.size))
        lutLib.setActive(e.uri)
        if (fromUser && engine.cfg.lutMode == 0) { engine.cfg.lutMode = 1; saveLutPrefs() }
        engine.setLut(lut)
        engine.lutConfigChanged()
        appLog("LUT «${e.name}» применён")
        refreshAll()
    }

    private fun deleteLut(e: LutEntry) = idle {
        lutCache.remove(e.uri)
        try { contentResolver.releasePersistableUriPermission(Uri.parse(e.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (x: Exception) { }
        val wasActive = lutLib.activeUri == e.uri
        lutLib.remove(e.uri)
        if (wasActive) { engine.setLut(null); engine.lutConfigChanged() }
        if (::lutRibbon.isInitialized && lutRibbon.opened) lutRibbon.rebuild()
        refreshAll()
    }

    internal fun saveLutPrefs() {
        prefs.edit().putInt("lut_mode", engine.cfg.lutMode).putBoolean("lut_in_log", engine.cfg.lutInLog).apply()
    }

    internal fun setGrid(i: Int) {
        gridIdx = i.coerceIn(0, Grid.values().size - 1)
        gridView.grid = Grid.values()[gridIdx]
        prefs.edit().putInt("grid", gridIdx).apply()
        appLog("Сетка: ${Grid.values()[gridIdx].label}")
    }

    internal fun setGuide(i: Int) {
        guideIdx = i.coerceIn(0, Guide.values().size - 1)
        gridView.guide = Guide.values()[guideIdx]
        prefs.edit().putInt("guide", guideIdx).apply()
        appLog("Рамка: ${Guide.values()[guideIdx].label}")
    }

    internal fun setOpenGate(v: Boolean) = idle {
        val cfg = engine.cfg
        if (v && !engine.gateAvailable()) {
            toastLong("Open Gate недоступен: эта камера не отдаёт для видео кадр шире 16:9. Попробуйте другой объектив (кнопка с мм).")
        } else if (cfg.openGate != v) {
            cfg.openGate = v
            prefs.edit().putBoolean("gate", v).apply()
            engine.restart()
        }
    }

    internal fun setLogEv(i: Int) {
        engine.cfg.logEv = i.coerceIn(0, 3)
        prefs.edit().putInt("log_ev", engine.cfg.logEv).apply()
        engine.update()
    }

    /** Соотношение сторон кадра → сетка/рамка/тап-фокус считаются по реальному прямоугольнику картинки. */
    private fun applyContentAspect() {
        val s = engine.cfg.size
        gridView.contentAspect = s.width.toFloat() / s.height
    }

    // ------------------------------------------------------------ жизненный цикл

    /** Повороты экрана landscape <-> reverse landscape: превью и тап-фокус должны следовать сразу. */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { if (ready) engine.setRotation(rotationDeg()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Ui.density = resources.displayMetrics.density
        Ui.style = UiStyle.fromPref(settings.resolveUiStyle())   // новая установка — Material 3, прежняя — как была
        applyTheme()
        prefSnapshot = HashMap(prefs.all)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        buildBase()
        setGrid(prefs.getInt("grid", 1))
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) initEngine()
        else requestPermissions(need, 1)
    }

    // ------------------------------------------------------------ v0.28: тема Material 3

    /** Палитра из сохранённых настроек: вариант темы, светлая/тёмная/системная, динамические цвета, свой акцент. */
    private fun applyTheme() {
        val variant = ThemeVariant.values().getOrElse(prefs.getInt("th28_variant", 0)) { ThemeVariant.MATERIAL }
        val seed = prefs.getInt("th28_seed", 0xFF4F8CFF.toInt())
        val sysDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val light = when (prefs.getInt("th28_mode", 0)) { 1 -> true; 2 -> !sysDark; else -> false }
        val flexible = variant == ThemeVariant.MATERIAL || variant == ThemeVariant.CUSTOM   // остальные варианты — только тёмные
        val useLight = light && flexible
        Ui.palette = when {
            prefs.getBoolean("th28_dynamic", false) && Build.VERSION.SDK_INT >= 31 -> Md3.dynamic(systemTonal(), !useLight)
            variant == ThemeVariant.MATERIAL && useLight -> Md3.LIGHT
            variant == ThemeVariant.CUSTOM -> Md3.custom(seed, !useLight)
            else -> Md3.forVariant(variant, seed)
        }
    }

    @android.annotation.TargetApi(31)
    private fun systemTonal(): Tonal {
        fun arr(vararg ids: Int) = IntArray(ids.size) { getColor(ids[it]) }
        return Tonal(
            arr(android.R.color.system_accent1_0, android.R.color.system_accent1_10, android.R.color.system_accent1_50, android.R.color.system_accent1_100,
                android.R.color.system_accent1_200, android.R.color.system_accent1_300, android.R.color.system_accent1_400, android.R.color.system_accent1_500,
                android.R.color.system_accent1_600, android.R.color.system_accent1_700, android.R.color.system_accent1_800, android.R.color.system_accent1_900, android.R.color.system_accent1_1000),
            arr(android.R.color.system_accent2_0, android.R.color.system_accent2_10, android.R.color.system_accent2_50, android.R.color.system_accent2_100,
                android.R.color.system_accent2_200, android.R.color.system_accent2_300, android.R.color.system_accent2_400, android.R.color.system_accent2_500,
                android.R.color.system_accent2_600, android.R.color.system_accent2_700, android.R.color.system_accent2_800, android.R.color.system_accent2_900, android.R.color.system_accent2_1000),
            arr(android.R.color.system_neutral1_0, android.R.color.system_neutral1_10, android.R.color.system_neutral1_50, android.R.color.system_neutral1_100,
                android.R.color.system_neutral1_200, android.R.color.system_neutral1_300, android.R.color.system_neutral1_400, android.R.color.system_neutral1_500,
                android.R.color.system_neutral1_600, android.R.color.system_neutral1_700, android.R.color.system_neutral1_800, android.R.color.system_neutral1_900, android.R.color.system_neutral1_1000),
            arr(android.R.color.system_neutral2_0, android.R.color.system_neutral2_10, android.R.color.system_neutral2_50, android.R.color.system_neutral2_100,
                android.R.color.system_neutral2_200, android.R.color.system_neutral2_300, android.R.color.system_neutral2_400, android.R.color.system_neutral2_500,
                android.R.color.system_neutral2_600, android.R.color.system_neutral2_700, android.R.color.system_neutral2_800, android.R.color.system_neutral2_900, android.R.color.system_neutral2_1000)
        )
    }

    /** Применить уже записанные в хранилище настройки: пересоздание экрана без перезаписи параметров съёмки из памяти (иначе они затёрли бы применённые). */
    internal fun recreateApplyingPrefs() { skipShootingSave = true; recreate() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (!ready) initEngine()
        } else {
            showNote("Нужен доступ к камере", 4500, error = true)
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    /** Кнопки громкости — старт/стоп записи (удобно, когда телефон в риге и до экрана не дотянуться). */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && ready) {
            if (event.repeatCount == 0 && !loadUi.benchRunning) toggleRec()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::menu.isInitialized && menuVisible()) closeMenu() else super.onBackPressed()
    }

    override fun onResume() {
        resumed = true
        startThermalWatch()
        main.postDelayed({ updateMeter() }, 400)
        super.onResume()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
        if (ready && surface.holder.surface.isValid) startEngine()
        if (::levelView.isInitialized) levelView.resume()
        main.removeCallbacks(statusRunnable)
        statusRunnable.run()
        main.removeCallbacks(monitorRunnable)
        main.postDelayed(monitorRunnable, 1500)
    }

    // ------------------------------------------------------------ предупреждение о нагреве (ничего не отключается автоматически)

    private var thermalListener: Any? = null
    private var lastThermalWarn = 0

    private fun startThermalWatch() {
        if (Build.VERSION.SDK_INT < 29 || thermalListener != null) return
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        val l = android.os.PowerManager.OnThermalStatusChangedListener { st -> main.post { onThermal(st) } }
        thermalListener = l
        pm.addThermalStatusListener(l)
    }

    private fun stopThermalWatch() {
        if (Build.VERSION.SDK_INT < 29) return
        val l = thermalListener as? android.os.PowerManager.OnThermalStatusChangedListener ?: return
        (getSystemService(POWER_SERVICE) as android.os.PowerManager).removeThermalStatusListener(l)
        thermalListener = null
    }

    private fun onThermal(st: Int) {
        // Слушатель и мониторинг работают всегда; пользователь решает только, показывать ли сообщение (Меню → Уведомления).
        if (st >= 3 && st > lastThermalWarn) {
            val f = AlertRules.evaluate(MonitorInput(st, null, null, null, null, null, false, null, false, null)) { alerts.threshold(it) }.firstOrNull { it.type == AlertType.OVERHEAT }
            if (f != null) deliver(alerts.post(f.type, f.text, f.severity))
            appLog("Thermal: ${thermalName(st)}")
        }
        lastThermalWarn = if (st >= 3) st else 0
    }

    override fun onPause() {
        stopThermalWatch()
        resumed = false
        stopMeter()
        super.onPause()
        main.removeCallbacks(statusRunnable)
        if (::levelView.isInitialized) levelView.suspend()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        if (ready) { if (!skipShootingSave) settings.saveShooting(engine.cfg); engine.stop() }
        main.removeCallbacks(monitorRunnable)
        alerts.flushIfDirty()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        loadUi.cancel(); loadUi.stop()
        stopMeter()
        super.onDestroy()
        if (::lutRibbon.isInitialized) lutRibbon.release()
        if (ready) engine.release()
    }

    // ------------------------------------------------------------ поверхность

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { if (ready) startEngine() }
    override fun surfaceDestroyed(holder: SurfaceHolder) { if (ready) engine.stop() }

    @Suppress("DEPRECATION")
    private fun rotationDeg(): Int {
        return when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    }

    private fun startEngine() { engine.start(surface.holder.surface, rotationDeg()) }

    // ------------------------------------------------------------ UI: каркас

    private fun tv(size: Float, gravity: Int, l: Int, t: Int, r: Int, b: Int): TextView {
        val v = TextView(this)
        v.setTextColor(Color.WHITE)
        v.textSize = size
        v.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        v.setPadding(dp(7), dp(2), dp(7), dp(2))
        v.background = Ui.bg(Ui.Kind.HUD)
        v.visibility = View.GONE        // плашка появляется, только когда есть текст
        v.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { v.visibility = if (e.isNullOrEmpty()) View.GONE else View.VISIBLE }
        })
        host.addView(v, FrameLayout.LayoutParams(WRAP, WRAP, gravity).apply { setMargins(l, t, r, b) })
        return v
    }

    private fun buildBase() {
        root = FrameLayout(this)
        root.setBackgroundColor(Ui.root)
        host = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.setFixedSize(1280, 720)
        surface.holder.addCallback(this)
        host.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH))

        eisFrameView = EisFrameView(this)
        host.addView(eisFrameView, FrameLayout.LayoutParams(MATCH, MATCH))

        gridView = GridView(this)
        host.addView(gridView, FrameLayout.LayoutParams(MATCH, MATCH))
        levelView = LevelView(this)
        levelView.visibility = View.GONE
        host.addView(levelView, FrameLayout.LayoutParams(MATCH, MATCH))

        ciDiagView = CiDiagView(this)
        ciDiagView.visibility = View.GONE
        host.addView(ciDiagView, FrameLayout.LayoutParams(MATCH, dp(260), Gravity.TOP).apply { setMargins(dp(8), dp(56), dp(8), 0) })
        scopeView = ScopeView(this)
        scopeView.visibility = View.GONE
        host.addView(scopeView, FrameLayout.LayoutParams(MATCH, dp(150), Gravity.BOTTOM).apply { setMargins(dp(70), 0, dp(70), dp(50)) })
        hist = HistogramView(this)
        host.addView(hist, FrameLayout.LayoutParams(dp(150), dp(52), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(8), 0) })
        hud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(6), 0, 0)
        recHud = tv(14f, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, dp(6), 0, 0)
        expHud = tv(12f, Gravity.BOTTOM or Gravity.END, 0, 0, dp(8), dp(6))
        statusHud = tv(11f, Gravity.TOP or Gravity.START, dp(8), dp(34), 0, 0)
        meterView = AudioMeterView(this)
        meterView.visibility = View.GONE
        host.addView(meterView, FrameLayout.LayoutParams(dp(58), MATCH, Gravity.START).apply { setMargins(dp(6), dp(62), 0, dp(46)) })

        // строка состояния: маленький текст в левом нижнем углу превью, сама гаснет через несколько секунд
        logView = TextView(this).apply {
            textSize = 11f
            setTextColor(Ui.onScrim)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            maxWidth = dp(300)
            setLineSpacing(0f, 1.05f)
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            setPadding(dp(4), 0, dp(4), 0)
            visibility = View.GONE
            isClickable = false
        }
        host.addView(logView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(6), 0, 0, dp(6)) })

        // ручные настройки: тонкая полоса вверху превью (внизу — зум), показывается по кнопке «РУЧН.»
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = Ui.bg(Ui.Kind.HUD)
        panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        panel.visibility = View.GONE
        host.addView(panel, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { setMargins(dp(8), dp(8), dp(140), 0) })

        // превью по центру; по бокам — две панели, которые занимают всё, что остаётся от 16:9 (пустых полос нет)
        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))

        // левая панель: кнопки не мельче 44 dp; на очень низком экране панель прокручивается, а не сжимает кнопки
        leftRail = LinearLayout(this)
        leftRail.orientation = LinearLayout.VERTICAL
        leftRail.setPadding(dp(5), dp(4), dp(5), dp(4))
        leftScroll = ScrollView(this)
        leftScroll.isFillViewport = true
        leftScroll.isVerticalScrollBarEnabled = false
        leftScroll.overScrollMode = View.OVER_SCROLL_NEVER
        leftScroll.setBackgroundColor(Ui.dock)
        leftScroll.addView(leftRail, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(leftScroll, FrameLayout.LayoutParams(dp(minRailDp), MATCH, Gravity.START))

        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.setBackgroundColor(Ui.dock)
        side.setPadding(dp(5), dp(4), dp(5), dp(4))
        root.addView(side, FrameLayout.LayoutParams(dp(minRailDp), MATCH, Gravity.END))

        lutRibbon = LutRibbon(
            this,
            entries = { lutLib.items },
            activeUri = { lutLib.activeUri },
            bakeOn = { ::engine.isInitialized && engine.cfg.lutMode in 2..3 },
            isRecording = { recording },
            inLog = { if (::engine.isInitialized) engine.cfg.lutInLog else true },
            curve = { if (::engine.isInitialized) engine.cfg.curve else Curve.FLAT },
            parse = { uri -> try { parseLut(Uri.parse(uri)) } catch (e: Exception) { null } },
            onPick = { e -> selectLut(e, fromUser = true, silent = true) },
            onBake = { v -> setLutBake(v); lutRibbon.refresh() },
            onAdd = { pickLutFiles() },
            onClose = { lutRibbon.close(); renderLog() }
        )
        // лента LUT — временная: открывается по кнопке LUT над нижним краем превью
        root.addView(lutRibbon, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(minRailDp + 8), 0, dp(minRailDp + 8), dp(8))
        })

        buildMenuShell()

        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fit(r - l, b - t) }
        setContentView(root)
    }

    /**
     * Раскладка: превью 16:9 по центру, максимально большое. Что осталось по бокам — две равные панели
     * (левая — быстрые переключатели, правая — управление съёмкой). Меню — боковой лист поверх части превью,
     * правая панель с кнопкой записи остаётся доступной.
     */
    private fun fit(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val minRail = dp(minRailDp)
        var pw = h * 16 / 9
        if (pw > w - 2 * minRail) pw = w - 2 * minRail
        if (pw <= 0) return
        val ph = pw * 9 / 16
        val rail = ((w - pw) / 2).coerceAtLeast(minRail)
        val lp = host.layoutParams as FrameLayout.LayoutParams
        if (lp.width != pw || lp.height != ph) {
            lp.width = pw
            lp.height = ph
            host.layoutParams = lp
        }
        if (rail != railPx) {
            railPx = rail
            val l = leftScroll.layoutParams as FrameLayout.LayoutParams
            l.width = rail; leftScroll.layoutParams = l
            val r = side.layoutParams as FrameLayout.LayoutParams
            r.width = rail; side.layoutParams = r
            val rb = lutRibbon.layoutParams as FrameLayout.LayoutParams
            rb.leftMargin = rail + dp(8); rb.rightMargin = rail + dp(8); lutRibbon.layoutParams = rb
            placeRec()
        }
        // меню — на весь экран; колонка настроек не шире 640 dp, чтобы строки не растягивались на широких экранах
        val bodyW = (w - dp(menuSideDp) - dp(48)).coerceIn(dp(280), dp(640))
        val bl = menuBody.layoutParams as FrameLayout.LayoutParams
        if (bl.width != bodyW) { bl.width = bodyW; menuBody.layoutParams = bl }
    }

    /** Кнопка записи стоит по центру высоты; её центр — на 10 dp внутрь превью от границы правой панели. */
    private var pauseShow = 0f
    private var pauseAnim: ValueAnimator? = null

    /** Кнопка паузы «выезжает» из-под кнопки записи с пружиной и так же уезжает обратно. */
    private fun showPause(on: Boolean) {
        pauseAnim?.cancel()
        val restY = pauseRestY()
        fun render(f: Float) {
            pauseShow = f
            val sc = 0.65f + 0.35f * f
            pauseBtn.alpha = f.coerceIn(0f, 1f)
            pauseBtn.scaleX = sc; pauseBtn.scaleY = sc
            pauseBtn.translationY = restY * f
        }
        if (!animsOn()) {
            render(if (on) 1f else 0f)
            pauseBtn.visibility = if (on) View.VISIBLE else View.GONE
            return
        }
        if (on) pauseBtn.visibility = View.VISIBLE
        val from = if (pauseBtn.visibility == View.VISIBLE) pauseShow else 0f
        val to = if (on) 1f else 0f
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = if (on) 420L else 240L
        a.interpolator = if (on) Ease.enter else Ease.exit
        a.addUpdateListener { render(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) {
                if (cancelled) return
                render(to)
                if (!on) pauseBtn.visibility = View.GONE
            }
        })
        pauseAnim = a
        a.start()
    }

    private fun placeRec() {
        if (!::recBtn.isInitialized) return
        val rail = if (railPx > 0) railPx else dp(minRailDp)
        val lp = recBtn.layoutParams as FrameLayout.LayoutParams
        val rm = rail + dp(10) - dp(recSizeDp) / 2
        if (lp.rightMargin != rm) { lp.rightMargin = rm; recBtn.layoutParams = lp }
        if (::pauseBtn.isInitialized) {
            val pl = pauseBtn.layoutParams as FrameLayout.LayoutParams
            val pm = rm + (dp(recSizeDp) - dp(pauseSizeDp)) / 2
            if (pl.rightMargin != pm) { pl.rightMargin = pm; pauseBtn.layoutParams = pl }
            pauseBtn.translationY = pauseRestY() * pauseShow
        }
    }

    /** Смещение кнопки паузы над записью; если места мало, зазор уменьшается, чтобы не наезжать на верхнюю кнопку правой панели (фонарик). */
    private fun pauseRestY(): Float {
        val half = dp(recSizeDp) / 2f + dp(pauseSizeDp) / 2f
        var gap = dp(10).toFloat()
        if (::side.isInitialized && side.childCount > 0 && root.height > 0) {
            val top = side.getChildAt(0)
            if (top.bottom > 0) {
                val centerY = root.height / 2f
                val free = centerY - half - dp(pauseSizeDp) / 2f - (top.bottom + dp(4)) + dp(0)
                // free = запас между верхом паузы при зазоре 0 и низом фонарика
                gap = gap.coerceAtMost(maxOf(dp(3).toFloat(), free))
            }
        }
        return -(half + gap)
    }

    /** Затвор как в камере iPhone: белое кольцо и красная капля; при записи капля «перетекает» в скруглённый квадрат. */
    private fun recDrawable(on: Boolean): android.graphics.drawable.Drawable {
        val d = RecDrawable(density)
        d.color = Ui.rec
        recDraw = d
        recT = if (on) 1f else 0f
        d.t = recT
        return d
    }

    private fun applyRecT(t: Float) { recDraw?.t = t }

    private fun morphRec(on: Boolean) {
        recAnim?.cancel()
        val from = recT
        val to = if (on) 1f else 0f
        if (!animsOn() || recDraw == null) { recT = to; applyRecT(to); return }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 560
        a.interpolator = Spring(6.5f, 11f)
        a.addUpdateListener { recT = from + (to - from) * (it.animatedValue as Float); applyRecT(recT) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) { if (recAnim === a) { recT = to; applyRecT(to) } }
        })
        recAnim = a
        a.start()
    }

    private fun setupTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoomLive(engine.cfg.zoom * curRel() * d.scaleFactor); return true }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val r = gridView.contentRect()
                if (!r.isEmpty && r.contains(e.x, e.y)) engine.tapFocus((e.x - r.left) / r.width(), (e.y - r.top) / r.height())
                return true
            }
            override fun onLongPress(e: MotionEvent) { engine.clearFocus() }
        })
        host.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) gd.onTouchEvent(ev)
            true
        }
    }

    // ------------------------------------------------------------ UI: быстрые кнопки

    private fun refreshChips() {
        refreshers.toList().forEach { it() }
        menuRefreshers.toList().forEach { it() }
    }

    /** Перерисовать состояние; если открыт список LUT — пересобрать его. */
private fun refreshAll() {
        if (::lutRibbon.isInitialized && lutRibbon.opened) lutRibbon.refresh()
        if (::menu.isInitialized && menuVisible() && menuTab == tabLut) showTab(tabLut, true) else refreshChips()
    }

    private fun styled(b: Button, activeFn: () -> Boolean, textFn: () -> String) {
        b.setAllCaps(false); b.textSize = 11f
        b.minWidth = 0; b.minimumWidth = 0; b.minHeight = 0; b.minimumHeight = 0
        b.setPadding(dp(12), dp(5), dp(12), dp(5))
        b.elevation = dp(if (Ui.glass) 3 else 1).toFloat()
        pressFx(b)
        // refreshChips вызывается часто (зум щипком, слайдеры): трогаем вид только если состояние изменилось
        var lastOn: Boolean? = null
        var lastText: String? = null
        refreshers.add {
            val t = textFn()
            if (t != lastText) { b.text = t; lastText = t }
            val on = activeFn()
            if (on != lastOn) {
                lastOn = on
                b.background = Ui.ripple(Ui.bg(Ui.Kind.CHIP, on))
                b.setTextColor(if (on) Ui.onAccent else Ui.text)
            }
        }
    }

    /** Анимации выключены в системе («Удалить анимацию» / масштаб 0) — тогда всё меняется мгновенно. */
    private fun animsOn(): Boolean = try {
        prefs.getBoolean("anim28", true) && Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
    } catch (e: Exception) { true }

    private val dropAnims = HashMap<View, ValueAnimator>()

    /**
     * Нажатие как по капле воды: форма сплющивается (шире и ниже, объём сохраняется), на отпускание
     * возвращается пружиной с затухающими колебаниями. Сам клик не перехватывается.
     */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun pressFx(v: View, depth: Float = 0.94f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dropAnims.remove(view)?.cancel()
                    if (animsOn()) view.animate().scaleX(depth).scaleY(depth)
                        .setStartDelay(0).setDuration(90).setInterpolator(Ease.enter).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (animsOn()) releaseDrop(view)
            }
            false
        }
    }

    private fun releaseDrop(view: View) {
        view.animate().cancel()
        val sx = view.scaleX
        val sy = view.scaleY
        dropAnims.remove(view)?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 420
        a.interpolator = Spring(5.5f, 13f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            view.scaleX = sx + (1f - sx) * f
            view.scaleY = sy + (1f - sy) * f
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (dropAnims[view] === a) { dropAnims.remove(view); view.scaleX = 1f; view.scaleY = 1f }
            }
        })
        dropAnims[view] = a
        a.start()
    }

    private val hiding = HashSet<View>()

    private fun showAnim(v: View, fromX: Float, fromY: Float) {
        hiding.remove(v)
        v.animate().cancel()
        v.visibility = View.VISIBLE
        if (!animsOn()) { v.alpha = 1f; v.translationX = 0f; v.translationY = 0f; return }
        v.alpha = 0f; v.translationX = fromX; v.translationY = fromY
        v.animate().alpha(1f).translationX(0f).translationY(0f).setStartDelay(0).setDuration(300).setInterpolator(Ease.enter).start()
    }

    private fun hideAnim(v: View, toX: Float, toY: Float) {
        if (v.visibility != View.VISIBLE) return
        if (!animsOn()) { v.visibility = View.GONE; return }
        hiding.add(v)
        v.animate().cancel()
        v.animate().alpha(0f).translationX(toX).translationY(toY).setStartDelay(0).setDuration(200).setInterpolator(Ease.exit)
            .withEndAction {
                if (hiding.remove(v)) { v.visibility = View.GONE; v.alpha = 1f; v.translationX = 0f; v.translationY = 0f }
            }.start()
    }

    internal fun setPanel(show: Boolean) {
        if (show) { if (panel.visibility != View.VISIBLE || hiding.contains(panel)) showAnim(panel, 0f, -dp(10).toFloat()) }
        else hideAnim(panel, 0f, -dp(10).toFloat())
    }

    /**
     * Кнопка боковой панели: две строки (название / состояние). Высота — по весу, поэтому панель всегда
     * заполнена целиком, без пустых мест, на любом экране. Тап — переключить, долгое нажатие — открыть настройки.
     */
    private fun railBtn(parent: LinearLayout, title: String, state: () -> String, active: () -> Boolean,
                        onLong: (() -> Unit)? = null, weight: Float = 1f, onClick: () -> Unit): Button {
        val b = Button(this)
        styled(b, active) { val st = state(); if (st.isEmpty()) title else title + "\n" + st }
        b.setPadding(dp(2), dp(2), dp(2), dp(2))
        b.textSize = 11f
        b.maxLines = 2
        b.setLineSpacing(0f, 0.95f)
        b.minHeight = dp(44); b.minimumHeight = dp(44)          // цель касания не меньше 44 dp
        b.setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onClick(); refreshChips() }
        if (onLong != null) b.setOnLongClickListener { it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onLong(); refreshChips(); true }
        parent.addView(b, LinearLayout.LayoutParams(MATCH, 0, weight).apply { setMargins(0, dp(2), 0, dp(2)) })
        return b
    }

    internal fun zebraIdx(): Int {
        val c = engine.cfg
        return if (!c.zebra) 0 else if (c.zebraLevel < 0.93f) 1 else if (c.zebraLevel < 0.97f) 2 else 3
    }

    internal fun setZebra(i: Int) {
        val c = engine.cfg
        c.zebra = i != 0
        if (i == 1) c.zebraLevel = 0.90f else if (i == 2) c.zebraLevel = 0.95f else if (i == 3) c.zebraLevel = 1.0f
        engine.update()
    }

    /** Левая панель: всё, что нужно во время съёмки, под рукой одним тапом. Остальное — в меню с описаниями. */
    private fun buildTools() {
        val cfg = engine.cfg
        val r = leftRail
        val lay = layouts.active()          // v0.28: состав, порядок и прозрачность левой панели задаёт раскладка («Экран камеры»)
        for (item in lay.visible()) when (item) {
            RailItem.ZEBRA -> railBtn(r, "ЗЕБРА", { if (cfg.zebra) "${(cfg.zebraLevel * 100).roundToInt()}%" else "выкл" }, { cfg.zebra }, { openMenu(tabMonitor) }) { setZebra((zebraIdx() + 1) % 4) }
            RailItem.PEAKING -> railBtn(r, "ПИКИНГ", { if (cfg.peaking) "вкл" else "выкл" }, { cfg.peaking }, { openMenu(tabMonitor) }) { cfg.peaking = !cfg.peaking; engine.update() }
            RailItem.FALSE_COLOR -> railBtn(r, "FALSE COL.", { if (cfg.falseColor) "вкл" else "выкл" }, { cfg.falseColor }, { openMenu(tabMonitor) }) { cfg.falseColor = !cfg.falseColor; engine.update() }
            RailItem.HIST -> railBtn(r, "ГИСТОГР.", { if (cfg.hist) "вкл" else "выкл" }, { cfg.hist }, { openMenu(tabMonitor) }) { cfg.hist = !cfg.hist; engine.update() }
            RailItem.GRID -> railBtn(r, "СЕТКА", { Grid.values()[gridIdx].label }, { gridIdx != 0 }, { openMenu(tabMonitor) }) { setGrid((gridIdx + 1) % Grid.values().size) }
            RailItem.LEVEL -> railBtn(r, "УРОВЕНЬ", { if (levelView.active) "вкл" else "выкл" }, { levelView.active }, { openMenu(tabMonitor) }) { toggleLevel(!levelView.active) }
            RailItem.LOG -> railBtn(r, "LOG", { if (cfg.mode == Mode.LOG) cfg.curve.label else "выкл" }, { cfg.mode == Mode.LOG }, { openMenu(tabColor) }) {
                idle { cfg.mode = if (cfg.mode == Mode.LOG) Mode.SDR else Mode.LOG; engine.restart() }
            }
            RailItem.LUT -> railBtn(r, "LUT", { if (lutLib.activeUri != null && cfg.lutMode != 0) activeLutName().take(9) else "выкл" },
                { lutLib.activeUri != null && cfg.lutMode != 0 }, { openMenu(tabLut) }) { toggleRibbon() }
            RailItem.EIS -> railBtn(r, "EIS", { listOf("выкл", "слаб.", "средн.", "сильн.", "макс.")[cfg.eis.coerceIn(0, 4)] }, { cfg.eis > 0 }, { openMenu(tabStab) }) { setEis((cfg.eis + 1) % 5) }
            RailItem.NR -> railBtn(r, "NR", { listOf("выкл", "слаб.", "средн.", "сильн.")[cfg.nrSoft.coerceIn(0, 3)] }, { cfg.nrSoft > 0 }, { openMenu(tabNr) }) { setNrSoft((cfg.nrSoft + 1) % 4) }
        }
        leftRail.alpha = lay.railOpacity / 100f
        refreshers.add { hist.visibility = if (cfg.hist) View.VISIBLE else View.GONE }
    }

private fun buildSide() {
        val cfg = engine.cfg
        railBtn(side, "ФОНАРИК", { if (cfg.torch) "вкл" else "выкл" }, { cfg.torch }, { openMenu(tabCamera) }) { cfg.torch = !cfg.torch; engine.update() }
        // середина правой панели свободна: сюда заходит кнопка записи
        side.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 2.4f))
        railBtn(side, "РУЧН.", { "" }, { panel.visibility == View.VISIBLE }) {
            if (panel.visibility == View.VISIBLE && !hiding.contains(panel)) setPanel(false)
            else { lutRibbon.close(); setPanel(true) }
        }
        menuBtn = railBtn(side, "МЕНЮ", { "" }, { ::menu.isInitialized && menuVisible() }) {
            if (menuVisible()) closeMenu() else openMenu(menuTab)
        }

        // зум, как в большинстве камер: вертикальный ползунок и пресеты рядом с кнопкой записи
        zoomSlider = ZoomSlider(this).apply {
            setContentDescription("Зум")
            onChange = { z -> setZoomLive(z) }
            onCommit = { engine.update(); refreshChips() }
        }
        zoomSlider.onPreset = { z -> smoothZoomTo(z) }
        host.addView(zoomSlider, FrameLayout.LayoutParams(dp(64), MATCH, Gravity.END).apply { setMargins(0, dp(76), dp(58), dp(48)) })

        // кнопка записи — поверх всего, наполовину на превью
        recBtn = Button(this)
        recBtn.text = ""
        recBtn.setPadding(0, 0, 0, 0)
        recBtn.stateListAnimator = null
        recBtn.setContentDescription("Запись")
        recBtn.background = recDrawable(false)
        recBtn.elevation = dp(8).toFloat()
        pressFx(recBtn, 0.9f)
        recBtn.setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); toggleRec() }
        root.addView(recBtn, FrameLayout.LayoutParams(dp(recSizeDp), dp(recSizeDp), Gravity.END or Gravity.CENTER_VERTICAL))
        pauseIcon = PauseIcon(density)
        pauseBtn = ImageView(this)
        pauseBtn.setImageDrawable(pauseIcon)
        pauseBtn.setContentDescription("Пауза")
        pauseBtn.background = null            // кольцо и фигура рисуются самим PauseIcon — в стиле кнопки записи
        pauseBtn.elevation = dp(6).toFloat()
        pauseBtn.visibility = View.GONE
        pressFx(pauseBtn, 0.9f)
        pauseBtn.setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); engine.togglePause() }
        root.addView(pauseBtn, FrameLayout.LayoutParams(dp(pauseSizeDp), dp(pauseSizeDp), Gravity.END or Gravity.CENTER_VERTICAL))
        placeRec()
        recBtn.bringToFront()
    }

    internal fun fmtZoom(z: Float): String =
        if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)

    /** Пресеты зума по возможностям камеры — отдаются в сам контрол (кнопки внутри ползунка). */
    private fun rebuildZoomPills(lo: Float, hi: Float) {
        if (!::zoomSlider.isInitialized) return
        val p = zoomPresetList(lo, hi)
        zoomPresets = p
        zoomSlider.setPresets(if (p.size > 1) p else emptyList())
    }

    private fun refreshZoomPills() {
        if (!::zoomSlider.isInitialized || !::engine.isInitialized) return
        zoomSlider.setValue(engine.cfg.zoom * curRel())
    }

    /** Кратность текущего объектива относительно основного (0.6 у сверхширокого, 3 у теле). Ползунок и кнопки показывают «общий» зум = кратность × зум камеры. */
    private fun curRel(): Float = lenses.firstOrNull { it.id == engine.cfg.cameraId }?.rel ?: 1f
    private fun curLens(): Lens? = lenses.firstOrNull { it.id == engine.cfg.cameraId }

    /** Какой тыловой объектив лучше всего даёт общий зум g: самый «длинный» из тех, чья кратность не больше g. */
    private fun lensForGlobal(g: Float): Lens? {
        val cur = curLens()
        if (cur == null || cur.front) return cur
        val backs = lenses.filter { !it.front }
        return backs.filter { it.rel <= g + 0.001f && it.zHi * it.rel >= g * 0.97f }.maxByOrNull { it.rel }
            ?: backs.minByOrNull { it.rel }
    }

    private fun toggleRibbon() {
        if (lutRibbon.opened) lutRibbon.close()
        else { setPanel(false); lutRibbon.open() }
        renderLog()
    }

    // ------------------------------------------------------------ UI: меню с описаниями

    internal fun menuVisible() = menu.visibility == View.VISIBLE && !hiding.contains(menu)

private fun openMenu(tab: Int) {
        if (!ready) return
        if (::lutRibbon.isInitialized) lutRibbon.close()
        if (menu.visibility != View.VISIBLE || hiding.contains(menu)) openMenuAnimated()
        showTab(tab)
    }

    internal fun closeMenu() { closeMenuAnimated() }

    internal fun segStyle(b: Button, on: Boolean) {
        b.background = Ui.ripple(Ui.bg(Ui.Kind.BUTTON, on))
        b.setTextColor(if (on) Ui.onAccent else Ui.text)
    }

    internal fun flatButton(text: String, size: Float): Button {
        val b = Button(this)
        b.setAllCaps(false)
        b.textSize = size
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.text = text
        pressFx(b)
        return b
    }

    private fun buildMenuShell() {
        menu = FrameLayout(this)
        menu.setBackgroundColor(Ui.menuBg)
        menu.elevation = dp(24).toFloat()          // выше кнопки записи: меню закрывает весь экран
        menu.visibility = View.GONE
        menu.isClickable = true

        menuSheet = LinearLayout(this)
        menuSheet.orientation = LinearLayout.HORIZONTAL
        menu.addView(menuSheet, FrameLayout.LayoutParams(MATCH, MATCH))

        // слева — разделы (как в настройках iOS в альбомной ориентации), внизу главная кнопка «Готово»
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setPadding(dp(16), dp(14), dp(10), dp(14))
        val title = TextView(this)
        title.text = "Настройки"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Ui.text)
        title.setPadding(dp(8), 0, 0, dp(8))
        bar.addView(title)
        val tabsScroll = ScrollView(this)
        tabsScroll.isVerticalScrollBarEnabled = false
        menuTabsBox = LinearLayout(this)
        menuTabsBox.orientation = LinearLayout.VERTICAL
        tabsScroll.addView(menuTabsBox)
        bar.addView(tabsScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        for (i in tabNames.indices) {
            val b = flatButton(tabNames[i], 14f)
            b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            b.setPadding(dp(14), 0, dp(14), 0)
            b.setOnClickListener { showTab(i) }
            tabButtons.add(b)
        }
        for ((gi, g) in tabGroups.withIndex()) {
            val cap = TextView(this)
            cap.text = g.first
            cap.textSize = 11f
            cap.setTypeface(null, Typeface.BOLD)
            cap.setTextColor(Ui.dim)
            cap.letterSpacing = 0.08f
            cap.setPadding(dp(14), if (gi == 0) dp(2) else dp(12), 0, dp(2))
            menuTabsBox.addView(cap)
            for (i in g.second) menuTabsBox.addView(tabButtons[i], LinearLayout.LayoutParams(MATCH, dp(46)).apply { setMargins(0, dp(2), 0, dp(2)) })
        }
        val done = flatButton("Готово", 15f)
        done.setTypeface(null, Typeface.BOLD)
        done.background = Ui.ripple(Ui.bg(Ui.Kind.BUTTON, true))
        done.setTextColor(Ui.onAccent)
        done.setOnClickListener { closeMenu() }
        bar.addView(done, LinearLayout.LayoutParams(MATCH, dp(48)).apply { topMargin = dp(8) })
        menuSheet.addView(bar, LinearLayout.LayoutParams(dp(menuSideDp), MATCH))

        val div = View(this)
        div.setBackgroundColor(Ui.divider)
        menuSheet.addView(div, LinearLayout.LayoutParams(Math.max(1, dp(1)), MATCH))

        menuScroll = ScrollView(this)
        menuScroll.overScrollMode = View.OVER_SCROLL_NEVER
        menuBody = LinearLayout(this)
        menuBody.orientation = LinearLayout.VERTICAL
        menuBody.setPadding(dp(4), dp(14), dp(4), dp(24))
        menuScroll.addView(menuBody, FrameLayout.LayoutParams(dp(560), WRAP, Gravity.CENTER_HORIZONTAL))
        menuSheet.addView(menuScroll, LinearLayout.LayoutParams(0, MATCH, 1f))

        root.addView(menu, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Центр кнопки «МЕНЮ» в координатах корневого экрана — из неё «капля» меню расходится и в неё же стекает. */
    private fun menuOrigin(): IntArray {
        val b = menuBtn
        if (b == null || b.width == 0) return intArrayOf(root.width - dp(minRailDp) / 2, root.height - dp(40))
        val l = IntArray(2); b.getLocationInWindow(l)
        val r = IntArray(2); root.getLocationInWindow(r)
        return intArrayOf(l[0] - r[0] + b.width / 2, l[1] - r[1] + b.height / 2)
    }

    private fun menuRadius(o: IntArray): Float =
        Math.hypot(Math.max(o[0], root.width - o[0]).toDouble(), Math.max(o[1], root.height - o[1]).toDouble()).toFloat()

    private fun openMenuAnimated() {
        hiding.remove(menu)
        menuAnim?.cancel()
        menuSheet.animate().cancel()
        menu.visibility = View.VISIBLE
        menuSheet.alpha = 1f; menuSheet.scaleX = 1f; menuSheet.scaleY = 1f
        if (!animsOn()) return
        val go = {
            val o = menuOrigin()
            val reveal = ViewAnimationUtils.createCircularReveal(menu, o[0], o[1], dp(24).toFloat(), menuRadius(o))
            reveal.duration = 480
            reveal.interpolator = Ease.standard
            menuSheet.alpha = 0f; menuSheet.scaleX = 0.97f; menuSheet.scaleY = 0.97f
            menuSheet.animate().alpha(1f).setStartDelay(120).setDuration(260).setInterpolator(Ease.enter).start()
            val settle = ValueAnimator.ofFloat(0f, 1f)
            settle.duration = 640
            settle.interpolator = Spring(6f, 11f)
            settle.addUpdateListener {
                val sc = 0.97f + 0.03f * (it.animatedValue as Float)
                menuSheet.scaleX = sc; menuSheet.scaleY = sc
            }
            menuAnim = reveal
            reveal.start(); settle.start()
        }
        if (menu.isLaidOut && menu.width > 0) go()
        else menu.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(v: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or2: Int, ob: Int) {
                v.removeOnLayoutChangeListener(this)
                go()
            }
        })
    }

    private fun closeMenuAnimated() {
        if (menu.visibility != View.VISIBLE || hiding.contains(menu)) return
        menuAnim?.cancel()
        if (!animsOn() || !menu.isLaidOut) { menu.visibility = View.GONE; return }
        hiding.add(menu)
        val o = menuOrigin()
        val a = ViewAnimationUtils.createCircularReveal(menu, o[0], o[1], menuRadius(o), dp(24).toFloat())
        a.duration = 340
        a.interpolator = Ease.exit
        menuSheet.animate().setStartDelay(0).alpha(0f).setDuration(180).start()
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (hiding.remove(menu)) menu.visibility = View.GONE
                menuSheet.alpha = 1f; menuSheet.scaleX = 1f; menuSheet.scaleY = 1f
            }
        })
        menuAnim = a
        a.start()
    }

    internal fun showTab(i: Int, keepScroll: Boolean = false) {
        val y = menuScroll.scrollY
        menuTab = i
        tabButtons.forEachIndexed { k, b -> segStyle(b, k == i) }
        menuBody.removeAllViews()
        secVisible = true; secCur = 0
        menuRefreshers.clear()
        info.stopTick()
        loadUi.stop()
        val head = TextView(this)
        head.text = tabNames[i]
        head.textSize = 26f
        head.setTypeface(null, Typeface.BOLD)
        head.setTextColor(Ui.text)
        head.setPadding(dp(4), 0, 0, dp(10))
        menuBody.addView(head)
        if (i != 7 && i != 8) loadUi.addBar()
        when (i) {
            0 -> buildVideoTab()
            1 -> buildColorTab()
            2 -> buildLutTab()
            3 -> buildMonitorTab()
            5 -> buildCameraTab()
            6 -> buildMoreTab()
            7 -> buildUpdatesTab()
            9 -> buildDiagnosticsTab()
            10 -> buildSettingsTab()
            11 -> colorTabs.buildManagement()
            12 -> colorTabs.buildGrade()
            13 -> colorTabs.buildAnalysis()
            4, 14 -> ciTabs.buildStabilization()
            15 -> ciTabs.buildNr()
            16 -> v28.buildNotifications()
            17 -> v28.buildTheme()
            18 -> v28.buildHome()
            19 -> v28.buildSearch()
            else -> buildAboutTab()
        }
        refreshChips()
        menuScroll.post { menuScroll.scrollTo(0, if (keepScroll) y else 0) }
        menuBody.animate().cancel()
        if (!keepScroll && animsOn()) {
            menuBody.alpha = 0f
            menuBody.translationY = dp(8).toFloat()
            menuBody.animate().alpha(1f).translationY(0f).setStartDelay(0).setDuration(260).setInterpolator(Ease.enter).start()
        } else { menuBody.alpha = 1f; menuBody.translationY = 0f }
    }

    // ------------------------------------------------------------ подразделы вкладок (v0.28)

    private var secVisible = true
    private var secCur = 0

    /** Рисует ряд кнопок подразделов в начале вкладки. Дальше код вкладки отмечает группы настроек вызовами [section]. */
    internal fun subTabs(tab: Int, names: List<String>) {
        secVisible = true
        secCur = (subPage[tab] ?: 0).coerceIn(0, names.size - 1)
        val box = card("Подраздел: ${names[secCur]}", "")
        for (chunk in names.withIndex().chunked(3)) {
            val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL
            for ((i, n) in chunk) {
                val b = flatButton(n, 12f); segStyle(b, i == secCur)
                b.setOnClickListener { subPage[tab] = i; showTab(tab, false) }
                r.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(1)) })
            }
            box.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    /** Всё, что создаётся после этого вызова, относится к подразделу [i]. */
    internal fun section(i: Int) { secVisible = (i == secCur) }

    /** Карточка: заголовок + описание функции. Возвращает контейнер, куда добавляются элементы управления. */
    internal fun card(title: String, desc: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        c.background = Ui.bg(Ui.Kind.PANEL)
        val t = TextView(this)
        t.text = title
        t.textSize = 14f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Ui.text)
        c.addView(t)
        if (desc.isNotEmpty()) {
            val d = TextView(this)
            d.text = desc
            d.textSize = 11.5f
            d.setTextColor(Ui.dim)
            c.addView(d)
        }
        // v0.28: карточка из невыбранного подраздела создаётся, но на экран не добавляется (код вкладки остаётся прежним)
        if (secVisible) menuBody.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) })
        return c
    }

    /** Строка выбора из нескольких вариантов: все варианты видны сразу, активный подсвечен. */
    internal fun seg(
        title: String, desc: String, options: List<String>, selected: () -> Int,
        note: () -> String = { "" }, load: ((Int) -> LoadInput)? = null, onPick: (Int) -> Unit
    ) {
        val box = card(title, desc)
        val btns = ArrayList<Button>()
        val perRow = 4                 // длинные списки (разрешения, LOG-кривые) переносятся на следующую строку
        options.chunked(perRow).forEachIndexed { row, chunk ->
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            chunk.forEachIndexed { j, label ->
                val i = row * perRow + j
                val b = flatButton(label, 12f)
                b.setOnClickListener { onPick(i); refreshChips() }
                bar.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(6), dp(2), dp(2)) })
                btns.add(b)
            }
            if (options.size > perRow) repeat(perRow - chunk.size) { bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            box.addView(bar)
        }
        val noteTv = TextView(this)
        noteTv.textSize = 11f
        noteTv.setTextColor(amber)
        box.addView(noteTv)
        val loadTv = if (load != null) TextView(this).also { it.textSize = 11f; it.setPadding(0, dp(2), 0, 0); box.addView(it) } else null
        menuRefreshers.add {
            val sel = selected()
            btns.forEachIndexed { i, b -> segStyle(b, i == sel) }
            if (load != null && loadTv != null) {
                val lv = try { loadUi.levels(options.indices.map { load(it) }) } catch (e: Exception) { emptyList() }
                if (lv.size == options.size) {
                    btns.forEachIndexed { i, b -> b.text = loadUi.dotted(options[i], lv[i].second) }
                    loadTv.text = loadUi.badge(lv[sel.coerceIn(0, lv.size - 1)])
                }
            }
            val n = note()
            noteTv.text = n
            noteTv.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    /** Выпадающий список: кнопка с текущим значением, по тапу — стеклянный список с прокруткой. */
    internal fun drop(
        title: String, desc: String, options: List<String>, selected: () -> Int,
        note: () -> String = { "" }, load: ((Int) -> LoadInput)? = null, onPick: (Int) -> Unit
    ) {
        val box = card(title, desc)
        val btn = flatButton("", 14f)
        btn.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        btn.setPadding(dp(14), 0, dp(14), 0)
        box.addView(btn, LinearLayout.LayoutParams(MATCH, dp(46)).apply { topMargin = dp(6) })
        val noteTv = TextView(this)
        noteTv.textSize = 11f
        noteTv.setTextColor(amber)
        box.addView(noteTv)
        val loadTv = if (load != null) TextView(this).also { it.textSize = 11f; it.setPadding(0, dp(2), 0, 0); box.addView(it) } else null
        fun levelsNow(): List<Pair<Double, LoadLevel>> = if (load == null) emptyList() else try { loadUi.levels(options.indices.map { load(it) }) } catch (e: Exception) { emptyList() }
        btn.setOnClickListener {
            val lv = levelsNow()
            val shown: List<CharSequence> = if (lv.size == options.size) options.indices.map { loadUi.dotted(options[it], lv[it].second) } else options
            showDropdown(btn, shown, selected()) { i -> onPick(i); refreshChips() }
        }
        menuRefreshers.add {
            val sel = selected()
            val lv = levelsNow()
            if (lv.size == options.size && loadTv != null) { loadTv.text = loadUi.badge(lv[sel.coerceIn(0, lv.size - 1)]) }
            btn.text = (options.getOrNull(sel) ?: "—") + "    ▾"
            segStyle(btn, false)
            val n = note()
            noteTv.text = n
            noteTv.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun showDropdown(anchor: View, options: List<CharSequence>, sel: Int, onPick: (Int) -> Unit) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(6), dp(6), dp(6), dp(6))
        val sv = ScrollView(this)
        sv.addView(col)
        sv.background = Ui.bg(Ui.Kind.MENU)
        sv.elevation = dp(12).toFloat()
        val pw = android.widget.PopupWindow(sv, anchor.width, WRAP, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        var selRow: View? = null
        options.forEachIndexed { i, label ->
            val b = flatButton(label.toString(), 14f)
            b.text = label
            b.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            b.setPadding(dp(12), 0, dp(12), 0)
            segStyle(b, i == sel)
            if (i == sel) selRow = b
            b.setOnClickListener { pw.dismiss(); onPick(i) }
            col.addView(b, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(0, dp(1), 0, dp(1)) })
        }
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val screenH = resources.displayMetrics.heightPixels
        val below = screenH - (loc[1] + anchor.height) - dp(8)
        val above = loc[1] - dp(8)
        val want = options.size * dp(46) + dp(12)
        val showBelow = below >= minOf(want, dp(220)) || below >= above
        val h = minOf(want, if (showBelow) below else above).coerceAtLeast(dp(120))
        pw.height = h
        if (showBelow) pw.showAtLocation(anchor, Gravity.TOP or Gravity.START, loc[0], loc[1] + anchor.height + dp(4))
        else pw.showAtLocation(anchor, Gravity.TOP or Gravity.START, loc[0], loc[1] - h - dp(4))
        selRow?.let { r -> sv.post { sv.scrollTo(0, (r.top - dp(60)).coerceAtLeast(0)) } }
    }

    internal fun toggle(title: String, desc: String, get: () -> Boolean, note: () -> String = { "" }, load: ((Boolean) -> LoadInput)? = null, set: (Boolean) -> Unit) =
        seg(title, desc, listOf("Выкл", "Вкл"), { if (get()) 1 else 0 }, note, load?.let { f -> { i: Int -> f(i == 1) } }) { set(it == 1) }

    internal fun saveQuality() {
        val c = engine.cfg
        prefs.edit().putInt("q_preset", c.qualityPreset).putInt("q_mode", c.bitrateMode)
            .putInt("q_kbps", c.bitrateKbps).putFloat("q_gop", c.gopSec)
            .putBoolean("q_b", c.bFrames).putInt("q_audio", c.audioKbps).putInt("bpp_idx", c.bppIdx).apply()
    }

    internal fun applyQualityPreset(i: Int) {
        val c = engine.cfg
        c.qualityPreset = i
        when (i) {
            0 -> { c.bppIdx = 0; c.bitrateMode = 0; c.gopSec = 2f; c.bFrames = false }
            1 -> { c.bppIdx = 1; c.bitrateMode = 0; c.gopSec = 1f; c.bFrames = false }
            2 -> { c.bppIdx = 2; c.bitrateMode = 2; c.gopSec = 0.5f; c.bFrames = true }
            else -> { c.bppIdx = 2; c.bitrateMode = 1; c.gopSec = 1f; c.bFrames = true }
        }
        c.bitrateKbps = 0
        saveQuality()
        if (::menu.isInitialized && menuVisible()) showTab(menuTab, true)
        refreshChips()
    }

    internal fun estMbps(): Int {
        val c = engine.cfg
        val s = c.size
        val bpp = doubleArrayOf(0.10, 0.15, 0.22)[c.bppIdx.coerceIn(0, 2)] * (if (c.codec == Codec.AVC) 1.5 else 1.0)
        val auto = (s.width.toLong() * s.height * c.fps * bpp).toLong()
        val br = (if (c.bitrateKbps > 0) c.bitrateKbps * 1000L else auto).coerceIn(8_000_000L, Enc.maxBitrate(c.codec.mime).toLong())
        return (br / 1_000_000).toInt()
    }

    private fun buildVideoTab() = tabs.buildVideoTab()

    private fun buildColorTab() = tabs.buildColorTab()
    internal val loadUi by lazy { LoadUi(this) }
    private val colorTabs by lazy { ColorTabs(this) }
    private val ciTabs by lazy { CiTabs(this) }
    private lateinit var ciDiagView: CiDiagView
    private lateinit var scopeView: ScopeView
    /** Показать/скрыть оверлей приборов по маске c26_scope_mask. */
    internal fun updateScopes() {
        val mk = colorSettings.i("c26_scope_mask")
        scopeView.mask = mk
        scopeView.visibility = if (mk != 0) View.VISIBLE else View.GONE
        if (::engine.isInitialized) engine.update()
    }

    internal fun lutRow(box: LinearLayout, name: String, sub: String, active: Boolean, e: LutEntry?) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val b = flatButton((if (active) "●  " else "○  ") + name + (if (sub.isNotEmpty()) "     $sub" else ""), 13f)
        b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        b.setPadding(dp(12), 0, dp(12), 0)
        segStyle(b, active)
        b.setOnClickListener { selectLut(e) }
        r.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        if (e != null) {
            val x = flatButton("✕", 14f)
            segStyle(x, false)
            x.setOnClickListener { deleteLut(e) }
            r.addView(x, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        box.addView(r)
    }

    /** Что сейчас произойдёт с LUT при записи — простым языком. */
    internal fun lutBakeNote(): String {
        val cfg = engine.cfg
        val lut = lutLib.active()
        val noBake = cfg.mode == Mode.HLG || (cfg.mode == Mode.LOG && cfg.hwLog && engine.caps?.hwLog == true)
        return when {
            lut == null -> "Сначала выберите LUT в списке ниже"
            cfg.lutMode !in 2..3 -> "Сейчас LUT «${lut.name}» НЕ записывается в видео"
            noBake -> "В режимах HLG и «LOG: камера (HW)» запечь LUT нельзя — он будет только на экране"
            else -> "Включено: видео запишется сразу с LUT «${lut.name}»"
        }
    }

    /** Применять LUT к видео = режим 2 (запекание); иначе остаётся только показ на экране или ничего. */
    internal fun setLutBake(v: Boolean) = idle {
        val cfg = engine.cfg
        val view = cfg.lutMode in 1..2
        cfg.lutMode = if (v) (if (view) 2 else 3) else (if (view) 1 else 0)
        saveLutPrefs()
        engine.lutConfigChanged()
        if (v && lutLib.activeUri == null) toast("Выберите LUT в списке")
    }

    internal fun setLutPreview(v: Boolean) = idle {
        val cfg = engine.cfg
        val bake = cfg.lutMode in 2..3
        cfg.lutMode = if (v) (if (bake) 2 else 1) else (if (bake) 3 else 0)
        saveLutPrefs()
        engine.lutConfigChanged()
    }

    private fun buildLutTab() = tabs.buildLutTab()

    private fun buildMonitorTab() = tabs.buildMonitorTab()

    // ------------------------------------------------------------ шумоподавление и стабилизация

    internal fun setNrIsp(v: Int) {
        engine.cfg.nrIsp = v
        prefs.edit().putInt("nr_isp", v).apply()
        engine.update()
    }

    internal fun setAntiband(v: Int) {
        engine.cfg.antiband = v.coerceIn(0, 3)
        prefs.edit().putInt("antiband", engine.cfg.antiband).apply()
        engine.update()
    }

    internal fun setNrSoft(i: Int) = idle {
        engine.cfg.nrSoft = i.coerceIn(0, 3)
        prefs.edit().putInt("nr_soft", engine.cfg.nrSoft).apply()
        engine.procConfigChanged()
        appLog("Шумоподавление: " + listOf("выкл", "слабое", "среднее", "сильное")[engine.cfg.nrSoft])
    }

    internal fun setEis(i: Int) = idle {
        if (i > 0 && !engine.gyroAvailable() && ciSettings.i("ci_src") == 1) {
            toastLong("Выбран источник «Гироскоп», а его в телефоне нет — выберите «Авто» или «Оптический поток»")
        } else {
            engine.cfg.eis = i.coerceIn(0, 4)
            prefs.edit().putInt("eis", engine.cfg.eis).apply()
            engine.procConfigChanged()
            appLog("Стабилизация: " + listOf("выкл", "слабая", "средняя", "сильная", "макс.")[engine.cfg.eis] + (if (engine.cfg.eis > 0 && !engine.gyroAvailable()) " (по оптическому потоку)" else ""))
        }
    }

    internal fun setEisHorizon(v: Boolean) = idle {
        engine.cfg.eisHorizon = v
        prefs.edit().putBoolean("eis_horizon", v).apply()
        engine.update()
    }

    internal fun setEisFrame(i: Int) {
        engine.cfg.eisFrame = i.coerceIn(0, 2)
        prefs.edit().putInt("eis_frame", engine.cfg.eisFrame).apply()
        engine.update()
    }

    private fun saveEisCal() {
        val sb = StringBuilder()
        for ((id, v) in engine.cfg.eisCal) { if (sb.isNotEmpty()) sb.append(';'); sb.append(id).append(':').append(v.first).append(':').append(v.second) }
        prefs.edit().putString("eis_cal_v2", sb.toString()).apply()
    }

    private fun loadEisCal() {
        val raw = prefs.getString("eis_cal_v2", "") ?: ""
        for (part in raw.split(';')) {
            val f = part.split(':')
            if (f.size == 3) {
                val rot = f[1].toIntOrNull()
                val ms = f[2].toIntOrNull()
                if (rot != null && ms != null) engine.cfg.eisCal[f[0]] = Pair(rot, ms)
            }
        }
    }

    internal val eisSyncChoices = listOf(-20, -10, -5, -2, 0, 2, 5, 10, 20)

    internal fun setEisSync(ms: Int) {
        engine.cfg.eisSyncMs = ms
        prefs.edit().putInt("eis_sync", ms).apply()
        engine.update()
    }


    // ------------------------------------------------------------ о приложении



    private fun buildAboutTab() {
        val ver = try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            val code = if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
            "${pi.versionName} (сборка $code)"
        } catch (e: Exception) { "—" }
        card("Beyond Recorder", "Версия $ver")
        card("Диагностика картинки", engine.debugInfo())
    }


    // Вкладки «Диагностика» и «Настройки» вынесены в InfoTabs.kt
    internal val tabs by lazy { MenuTabs(this) }
    internal val info by lazy { InfoTabs(this) }
    private fun buildDiagnosticsTab() = info.buildDiagnosticsTab()
    private fun buildSettingsTab() = info.buildSettingsTab()


    private fun buildUpdatesTab() {
        for ((v, items) in Changelog.entries) {
            card("Что нового в $v", items.joinToString("\n") { "• $it" })
        }
    }

    private fun buildCameraTab() = tabs.buildCameraTab()

    /** Интерфейс, подсказки и сведения о приложении. */
    private fun buildMoreTab() {
        val cfg = engine.cfg
        seg("Стиль интерфейса",
            "Material 3 — стандартный стиль с v0.28: цветовые роли, тональные поверхности, темы и динамические цвета (раздел «Оформление»). Material — прежний плотный стиль. Liquid Glass — полупрозрачные панели поверх живого превью: камера просвечивает сквозь стекло, блик сверху и мягкая тень. Применяется перезапуском экрана.",
            listOf("Material", "Liquid Glass", "Material 3"), { prefs.getInt("ui_style", 2) }) { i ->
            idle { prefs.edit().putInt("ui_style", i).apply(); recreate() }
        }
        toggle("Строка состояния (журнал действий)",
            "Короткие сообщения в левом нижнем углу превью: что сейчас делает приложение (камера, LUT, запись, стабилизация). Исчезают через несколько секунд.",
            { prefs.getBoolean("status_log", true) }) { prefs.edit().putBoolean("status_log", it).apply(); renderLog() }
        toggle("Повернуть превью на 180°",
            "Если изображение на экране вверх ногами — включите. Меняется только картинка на экране, запись не затрагивается.",
            { cfg.previewTurn }) { cfg.previewTurn = it; prefs.edit().putBoolean("prev_turn", it).apply(); engine.update() }
        card("Как устроен экран",
            "Посередине — превью, ничем не перекрытое. Слева — быстрые переключатели: фонарик, зебра, пикинг, сетка, уровень, LUT, EIS, NR (гистограмма — во вкладке «Монитор»); тап переключает, долгое нажатие открывает нужную вкладку меню. " +
                "Справа — объектив, «РУЧН.» (ISO/выдержка/EV/фокус полосой вверху превью) и «МЕНЮ» (боковой лист, превью остаётся видно); большая кнопка записи заходит на превью, как затвор в камере iPhone. " +
                "Зум — кнопки-пресеты рядом с кнопкой записи; если повести пальцем по ним, вместо кнопок включается ползунок. " +
                "Кнопки громкости — старт/стоп записи. Тап по превью — фокус и экспозиция по точке, долгое нажатие — сброс. Щипок — зум.")
    }

    // ------------------------------------------------------------ UI: ручная панель

    private fun addSeek(title: String, row: LinearLayout, onChange: (Int) -> String): SeekBar {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.setTextColor(Ui.text)
        t.textSize = 11f
        t.maxLines = 1
        t.text = title
        val sb = SeekBar(this)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) t.text = "$title  ${onChange(p)}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(t)
        col.addView(sb, LinearLayout.LayoutParams(MATCH, dp(44)))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        return sb
    }

    /** Ручные настройки одной полосой: сверху кнопки режимов, ниже четыре ползунка в ряд. */
    private fun buildPanel() {
        val cfg = engine.cfg
        panel.removeAllViews()
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val sliders = LinearLayout(this)
        sliders.orientation = LinearLayout.HORIZONTAL
        fun pb(text: () -> String, active: () -> Boolean = { false }, onClick: () -> Unit) {
            val b = Button(this)
            styled(b, active, text)
            b.setOnClickListener { onClick(); refreshChips() }
            btns.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        pb({ "EXPOSURE: " + if (cfg.aeManual) "MANUAL" else "AUTO" }, { cfg.aeManual }) { cfg.aeManual = !cfg.aeManual; engine.update() }
        pb({ "SHUTTER 180° (1/${2 * cfg.fps})" }) {
            cfg.expNs = 1_000_000_000L / (2L * cfg.fps)
            cfg.aeManual = true
            engine.update()
            refreshControls()
        }
        pb({ "FOCUS: " + if (cfg.afManual) "MF" else "AF" }, { cfg.afManual }) { cfg.afManual = !cfg.afManual; engine.update() }
        pb({ "WB: " + AWB_PRESETS[cfg.awbIdx].first }) { cfg.awbIdx = (cfg.awbIdx + 1) % AWB_PRESETS.size; engine.update() }

        isoBar = addSeek("ISO", sliders) { p ->
            val r = engine.caps?.isoRange
            if (r == null) "—" else {
                val iso = (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
                cfg.iso = iso; cfg.aeManual = true; engine.update(); refreshChips(); "$iso"
            }
        }
        shutBar = addSeek("SHUTTER", sliders) { p ->
            val d = shutters.getOrNull(p)
            if (d == null) "—" else {
                cfg.expNs = 1_000_000_000L / d; cfg.aeManual = true; engine.update(); refreshChips(); "1/$d"
            }
        }
        evBar = addSeek("EV", sliders) { p ->
            val c = engine.caps
            val r = c?.aeRange
            if (c == null || r == null) "—" else {
                cfg.ev = r.lower + p; engine.update(); "%+.1f".format(cfg.ev * c.aeStep)
            }
        }
        focusBar = addSeek("FOCUS", sliders) { p ->
            val c = engine.caps
            if (c == null || c.minFocus <= 0f) "—" else {
                cfg.focus = c.minFocus * p / 100f; cfg.afManual = true; engine.update(); refreshChips()
                if (cfg.focus < 0.05f) "∞" else "%.0f см".format(100f / cfg.focus)
            }
        }
        panel.addView(btns, LinearLayout.LayoutParams(MATCH, WRAP))
        panel.addView(sliders, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
    }

    /** Подгоняет слайдеры под возможности текущей камеры. */
    internal fun refreshControls() {
        val c = engine.caps ?: return
        val cfg = engine.cfg
        if (::zoomSlider.isInitialized) {
            val hi = zoomHi(c)
            val rel = curRel()
            if (cfg.zoom > hi) { cfg.zoom = hi; engine.update() }
            if (cfg.zoom < c.zoomRange.lower) { cfg.zoom = c.zoomRange.lower; engine.update() }
            zoomSlider.setHwLimit(c.zoomRange.upper * rel)
            // общий диапазон: у отдельных объективов — от самого широкого до зум-предела
            val back = lenses.filter { !it.front }
            val multi = !(curLens()?.front ?: false) && back.size > 1
            val gLo = if (multi) minOf(c.zoomRange.lower * rel, back.minOf { it.zLo * it.rel }) else c.zoomRange.lower * rel
            val gHi = if (multi) maxOf(hi * rel, zoomCap()) else hi * rel
            zoomSlider.setRange(gLo, gHi)
            zoomSlider.setValue(cfg.zoom * rel)
            rebuildZoomPills(gLo, gHi)
        }
        val manual = c.manualSensor && c.isoRange != null && c.expRange != null
        isoBar.isEnabled = manual
        shutBar.isEnabled = manual
        c.isoRange?.let { r ->
            isoBar.max = 100
            val x = cfg.iso.toDouble().coerceIn(r.lower.toDouble(), r.upper.toDouble())
            isoBar.progress = (ln(x / r.lower) / ln(r.upper.toDouble() / r.lower) * 100).roundToInt().coerceIn(0, 100)
        }
        shutters = listOf(24, 25, 30, 48, 50, 60, 96, 100, 120, 125, 240, 250, 500, 1000, 2000, 4000, 8000).filter { d ->
            d >= cfg.fps && (c.expRange?.let { 1_000_000_000L / d in it.lower..it.upper } == true)
        }
        shutBar.max = (shutters.size - 1).coerceAtLeast(0)
        val cur = (1e9 / cfg.expNs).roundToInt()
        shutBar.progress = shutters.indices.minByOrNull { abs(shutters[it] - cur) } ?: 0
        val r = c.aeRange
        evBar.isEnabled = r != null && c.aeStep > 0f
        if (r != null) { evBar.max = r.upper - r.lower; evBar.progress = cfg.ev - r.lower }
        focusBar.isEnabled = c.minFocus > 0f
        focusBar.max = 100
        if (c.minFocus > 0f) focusBar.progress = (cfg.focus / c.minFocus * 100).roundToInt().coerceIn(0, 100)
        refreshChips()
    }




    /** Верхний предел зума из настроек (10× по умолчанию, до 100×). Выше аппаратного максимума камеры движок зум не наращивает — там жёлтый «!». */
    internal fun zoomCap(): Float = prefs.getInt("zoom_max", 10).coerceIn(10, 100).toFloat()
    private fun zoomHi(c: CamCaps): Float = (zoomCap() / curRel()).coerceAtLeast(c.zoomRange.lower)

    /** Ровно пять кнопок зума: края диапазона и три «круглых» значения между ними, равномерно по логарифмической шкале. */
    private fun zoomPresetList(lo: Float, hi: Float): List<Float> {
        val backs = lenses.filter { !it.front }
        val cur = curLens()
        if (cur != null && !cur.front && backs.size > 1) {
            // отдельные объективы: кнопки — кратности самих объективов (0.6×, 1×, 3× …) и «круглые» значения между ними
            val out = ArrayList<Float>()
            for (l in backs) if (l.rel >= lo - 0.01f && out.none { abs(it - l.rel) < 0.01f }) out.add(l.rel)
            for (n in floatArrayOf(1f, 2f, 3f, 5f, 10f)) {
                if (n < lo - 0.01f || n > hi + 0.01f) continue
                if (out.none { abs(ln(it / n)) < 0.18f }) out.add(n)
            }
            val r = out.filter { it <= hi + 0.01f }.sorted().toMutableList()
            while (r.size > 6) {   // слишком много — выкидываем «круглое», что не объектив
                val drop = r.filter { v -> backs.none { abs(it.rel - v) < 0.01f } }.firstOrNull() ?: break
                r.remove(drop)
            }
            if (r.size >= 2) return r
        }
        return zoomPresetListPlain(lo, hi)
    }

    private fun zoomPresetListPlain(lo: Float, hi: Float): List<Float> {
        val first = (Math.ceil(lo * 10.0 - 0.001) / 10.0).toFloat()
        val last = (Math.floor(hi * 10.0 + 0.001) / 10.0).toFloat()
        if (last <= first + 0.05f) return listOf(first)
        val nice = listOf(0.5f, 0.6f, 0.7f, 0.8f, 1f, 1.5f, 2f, 3f, 4f, 5f, 8f, 10f, 15f, 20f, 30f, 50f, 100f)
        val out = ArrayList<Float>()
        out.add(first)
        for (q in floatArrayOf(0.25f, 0.5f, 0.75f)) {
            val target = first * Math.pow((last / first).toDouble(), q.toDouble()).toFloat()
            val cand = nice.filter { it > first + 0.05f && it < last - 0.05f && out.none { o -> abs(o - it) < 0.01f } }
                .minByOrNull { abs(ln(it / target)) }
            out.add(cand ?: (Math.round(target * 10f) / 10f))
        }
        out.add(last)
        val res = out.distinct().sorted().toMutableList()
        // очень узкий диапазон: добираем до пяти равномерно по шкале
        var guard = 0
        while (res.size < 5 && guard++ < 8) {
            var bi = 0
            var bg = 0f
            for (i in 0 until res.size - 1) { val g = ln(res[i + 1] / res[i]); if (g > bg) { bg = g; bi = i } }
            val mid = (Math.round(Math.sqrt((res[bi] * res[bi + 1]).toDouble()).toFloat() * 100f) / 100f)
            if (mid <= res[bi] + 0.005f || mid >= res[bi + 1] - 0.005f) break
            res.add(bi + 1, mid)
        }
        return res
    }

    /**
     * Плавный зум к значению (тап по кнопке): камера и ползунок едут вместе по логарифмической шкале,
     * мягкий старт и мягкая остановка; чем дальше цель, тем дольше ход (0.3–1.1 с). Щипок или тяга ползунка прерывают его.
     */
    private fun smoothZoomTo(target: Float) {
        val c = engine.caps ?: return
        val rel = curRel()
        val tl = lensForGlobal(target)
        if (tl != null && tl.id != engine.cfg.cameraId && engine.canSwitchLive()) { switchLens(tl, target); return }
        val hi = zoomHi(c)
        val to = (target / rel).coerceIn(c.zoomRange.lower, hi)
        val from = engine.cfg.zoom
        zoomAnimator?.cancel()
        zoomAnimator = null
        if (!animsOn() || abs(ln(to / from)) < 0.01f) { setZoom(to * rel); return }
        val lf = ln(from.toDouble())
        val lt = ln(to.toDouble())
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = (320 + 320 * Math.min(2.5, Math.abs(lt - lf))).toLong()
        a.interpolator = Ease.standard
        a.addUpdateListener {
            val z = Math.exp(lf + (lt - lf) * (it.animatedValue as Float)).toFloat()
            engine.cfg.zoom = z.coerceIn(c.zoomRange.lower, hi)
            zoomSlider.setValue(engine.cfg.zoom * rel)
            val now = SystemClock.elapsedRealtime()
            if (now - lastZoomPush > 33) { lastZoomPush = now; engine.update() }
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) {
                if (cancelled) return
                if (zoomAnimator === a) zoomAnimator = null
                engine.cfg.zoom = to
                zoomSlider.setValue(to * rel)
                engine.update()
                refreshChips()
            }
        })
        zoomAnimator = a
        a.start()
    }

    /** Переключение на другой объектив с сохранением общего зума g (камера перезапускается; запись на GL-маршруте продолжается). */
    private fun switchLens(l: Lens, g: Float) {
        zoomAnimator?.cancel(); zoomAnimator = null
        lastLensSwitch = SystemClock.elapsedRealtime()
        engine.switchLens(l.id, (g / l.rel).coerceIn(l.zLo, maxOf(l.zLo, zoomCap() / l.rel)))
    }

    private var lastLensSwitch = 0L

    /** z — общий зум (кратность объектива × зум камеры). */
    private fun setZoomLive(z: Float) {
        zoomAnimator?.cancel(); zoomAnimator = null
        val c = engine.caps ?: return
        // протяжка через границу объективов: до 2.99× — кроп основного, с 3× — телеобъектив (и наоборот)
        val tl = lensForGlobal(z)
        val now0 = SystemClock.elapsedRealtime()
        if (tl != null && tl.id != engine.cfg.cameraId && now0 - lastLensSwitch > 1200 && engine.canSwitchLive()) {
            switchLens(tl, z)
            return
        }
        val rel = curRel()
        engine.cfg.zoom = (z / rel).coerceIn(c.zoomRange.lower, zoomHi(c))
        zoomSlider.setValue(engine.cfg.zoom * rel)
        refreshZoomPills()
        val now = SystemClock.elapsedRealtime()
        if (now - lastZoomPush > 40) { lastZoomPush = now; engine.update() }
    }

    private fun setZoom(z: Float, allowSwitch: Boolean = true) {
        zoomAnimator?.cancel(); zoomAnimator = null
        val c = engine.caps ?: return
        val rel = curRel()
        engine.cfg.zoom = (z / rel).coerceIn(c.zoomRange.lower, zoomHi(c))
        if (::zoomSlider.isInitialized) zoomSlider.setValue(engine.cfg.zoom * rel)
        engine.update()
        refreshChips()
    }

    private fun cycleZoom() {
        val c = engine.caps ?: return
        val rel = curRel()
        val p = zoomPresetList(c.zoomRange.lower * rel, zoomHi(c) * rel)
        if (p.isEmpty()) return
        val cur = engine.cfg.zoom * rel
        smoothZoomTo(p.firstOrNull { it > cur + 0.05f } ?: p.first())
    }

    private fun initEngine() {
        engine = CameraEngine(this, this)
        engine.colors = colorSettings
        engine.ci = ciSettings
        engine.onCiDiag = { d -> main.post { ciDiagView.visibility = if (ciSettings.b("ci_diag")) View.VISIBLE else View.GONE; ciDiagView.set(d) } }
        engine.onScopePixels = { p, w, h -> main.post { scopeView.set(p, w, h) } }
        updateScopes()
        val migLog = settings.migrate()      // версия схемы, проверка значений; пользовательские настройки не теряются
        lenses = try { engine.lenses() } catch (e: Exception) { emptyList() }
        engine.cfg.cameraId = (lenses.firstOrNull { it.id == "0" } ?: lenses.firstOrNull())?.id ?: ""
        engine.cfg.lutMode = prefs.getInt("lut_mode", 1).coerceIn(0, 3)
        engine.cfg.lutInLog = prefs.getBoolean("lut_in_log", true)
        engine.cfg.openGate = prefs.getBoolean("gate", false)
        engine.cfg.logEv = prefs.getInt("log_ev", 1).coerceIn(0, 3)
        engine.cfg.nrIsp = prefs.getInt("nr_isp", 0).coerceIn(0, 4)
        engine.cfg.antiband = prefs.getInt("antiband", 0).coerceIn(0, 3)
        engine.cfg.nrSoft = prefs.getInt("nr_soft", 0).coerceIn(0, 3)
        engine.cfg.eis = prefs.getInt("eis", 0).coerceIn(0, 4)
        engine.cfg.eisSyncMs = prefs.getInt("eis_sync", 0).coerceIn(-50, 50)
        engine.cfg.eisHorizon = prefs.getBoolean("eis_horizon", false)
        loadEisCal()
        engine.cfg.qualityPreset = prefs.getInt("q_preset", 1)
        engine.cfg.bppIdx = prefs.getInt("bpp_idx", engine.cfg.bppIdx).coerceIn(0, 4)
        engine.cfg.bitrateMode = prefs.getInt("q_mode", 0).coerceIn(0, 2)
        engine.cfg.bitrateKbps = prefs.getInt("q_kbps", 0)
        engine.cfg.gopSec = prefs.getFloat("q_gop", 1f)
        engine.cfg.bFrames = prefs.getBoolean("q_b", false)
        engine.cfg.audioKbps = prefs.getInt("q_audio", 192)
        engine.cfg.eisLock = prefs.getBoolean("eis_lock", true)
        engine.cfg.previewTurn = prefs.getBoolean("prev_turn", false)
        for (l in lenses) engine.cfg.lensFlip[l.id] = prefs.getBoolean("lens_flip_${l.id}", false)
        engine.cfg.smoothRec = prefs.getBoolean("smooth_rec", true)
        settings.loadShooting(engine.cfg, lenses.map { it.id })
        info.loadPerfMode()
        engine.cfg.eisFrame = prefs.getInt("eis_frame", 2).coerceIn(0, 2)
        setGuide(prefs.getInt("guide", 0))
        if (prefs.getBoolean("level", false)) toggleLevel(true)
        buildTools()
        buildSide()
        buildPanel()
        setupTouch()
        refreshChips()
        ready = true
        loadUi.maybeFirstRun()
        migLog.forEach { appLog(it) }
        updateMeter()
        root.post { playIntro() }
        if (surface.holder.surface.isValid) startEngine()
        // Выбранный LUT сохраняется между запусками — его нужно разобрать заново.
        lutLib.active()?.let { selectLut(it, fromUser = false, silent = true) }
    }

    // ------------------------------------------------------------ CameraEngine.Listener

    override fun onInfo(text: String) { hud.text = text }
    override fun onExposure(text: String) { expHud.text = text }
    override fun onHist(bins: IntArray) { hist.set(bins) }
    override fun onError(msg: String) {
        val t = AlertClassifier.classify(msg)
        val d = alerts.post(t, msg, key = t.name + ":" + msg.replace(Regex("[0-9]+"), "#").take(80))   // разные сообщения одного типа не склеиваются
        if (d == null) appLog("Ошибка: " + msg.take(90)) else deliver(d)
    }
    override fun onSaved(path: String) { showNote("Сохранено: $path", 4000); appLog("Видео сохранено") }

    override fun onEisFrame(c: FloatArray?) { eisFrameView.set(c) }

    override fun onSync(msg: String, saved: Boolean) {
        syncStatus = msg
        toastLong(msg)
        appLog("Синхронизация гироскопа: " + msg.take(80))
        if (saved) saveEisCal()
        if (::menu.isInitialized && menuVisible() && menuTab == tabStab) showTab(tabStab, true)
    }

    override fun onReady() {
        appLog("Камера готова: ${engine.cfg.size.width}×${engine.cfg.size.height}, ${engine.cfg.fps} к/с")
        applyContentAspect()
        refreshControls()
        // Список разрешений/fps мог измениться (смена объектива и т.п.) — обновить открытую вкладку.
        if (menuVisible()) showTab(menuTab, true)
    }

    override fun onRecording(on: Boolean) {
        recording = on
        appLog(if (on) "Запись началась" else "Запись остановлена, сохраняю файл…")
        recBtn.setContentDescription(if (on) "Остановить запись" else "Начать запись")
        morphRec(on)
        if (on) updateMeter() else main.postDelayed({ updateMeter() }, 900)
        isPaused = false; pausedTotal = 0L; pauseSince = 0L
        if (::pauseBtn.isInitialized) {
            pauseIcon.reset()
            pauseBtn.setContentDescription("Пауза")
            showPause(on)
        }
        if (on) {
            recStart = SystemClock.elapsedRealtime()
            recHud.setTextColor(0xFFFFFFFF.toInt())
            tick()
        } else {
            recHud.text = ""
        }
        statusRunnable.run()
    }

    private fun toggleRec() {
        if (!recording) stopMeter()          // микрофон нужен рекордеру: слушатель шкал уступает
        engine.toggleRecord()
    }

    private fun meterWanted(): Boolean = ::engine.isInitialized && engine.cfg.audio && prefs.getBoolean("audio_meter", true)
    private fun micGranted(): Boolean = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Шкалы звука видны, если звук включён. Без записи уровни берёт отдельный слушатель, во время записи — сам рекордер. */
    internal fun updateMeter() {
        if (!::meterView.isInitialized) return
        val want = meterWanted() && micGranted()
        meterView.visibility = if (want) View.VISIBLE else View.GONE
        if (want && resumed && ready && !recording) {
            if (audioMeter?.running != true) {
                val m = AudioMeter { l, r -> meterView.post { meterView.set(l, r) } }
                audioMeter = if (m.start()) m else null
            }
        } else stopMeter()
    }

    private fun stopMeter() { audioMeter?.stop(); audioMeter = null }

    override fun onAudioLevel(l: Float, r: Float) { if (::meterView.isInitialized) meterView.set(l, r) }

    /** Первый показ: боковые панели выплывают от краёв, остальное проявляется. Без перелёта: всё заканчивается ровно на своих местах. */
    private fun playIntro() {
        if (introDone) return
        introDone = true
        if (!animsOn()) return
        val shift = dp(minRailDp) * 0.4f
        fun fly(v: View, dx: Float, dy: Float, delay: Long) {
            v.animate().cancel()
            v.alpha = 0f; v.translationX = dx; v.translationY = dy
            v.animate().alpha(1f).translationX(0f).translationY(0f).setStartDelay(delay).setDuration(480)
                .setInterpolator(Ease.enter).withEndAction { v.animate().setStartDelay(0) }.start()
        }
        fly(leftScroll, -shift, 0f, 0)
        fly(side, shift, 0f, 70)
        if (::zoomSlider.isInitialized) fly(zoomSlider, dp(10).toFloat(), 0f, 160)
        for (v in listOf<View>(recBtn, hud, statusHud, expHud, hist, meterView)) fly(v, 0f, 0f, 120)
    }

    internal fun toggleLevel(on: Boolean) {
        if (on && !levelView.available) { toast("В этом телефоне нет акселерометра"); return }
        levelView.enable(on)
        prefs.edit().putBoolean("level", on).apply()
    }

    // ------------------------------------------------------------ память и размер файла

    private fun fmtDuration(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return if (h > 0) "${h} ч ${m} м" else "${m} м"
    }

    @Suppress("DEPRECATION")
    private val LOW_STORAGE_STOP_BYTES = 200_000_000L
    private fun freeBytes(): Long = try { StatFs(Environment.getExternalStorageDirectory().path).availableBytes } catch (e: Exception) { -1L }

    // ------------------------------------------------------------ v0.28: мониторинг и показ уведомлений

    private fun monitorIntervalMs(): Long = (prefs.getInt("perf28_mon", 2000)).coerceIn(500, 60_000).toLong()

    private val monitorRunnable = object : Runnable {
        override fun run() {
            try { monitorTick() } catch (e: Exception) { appLog("Мониторинг: " + (e.message ?: e.javaClass.simpleName).take(60)) }
            main.removeCallbacks(this)
            main.postDelayed(this, monitorIntervalMs())
        }
    }

    /** Реальные показатели → список проблем → центр уведомлений. Идёт независимо от того, включены ли сообщения. */
    private fun monitorTick() {
        if (!ready || !::engine.isInitialized) return
        val r = monMon.sample()
        val st = engine.recStats()
        val drop = if (recording && st != null) { val tot = st.videoFrames + st.droppedVideo; if (tot > 200) st.droppedVideo * 100f / tot else null } else null
        val free = freeBytes()
        val input = MonitorInput(r.thermalStatus, r.thermalHeadroom, r.batteryTempC, r.cpuProcessPercentOfCore, r.gpuLoad,
            r.ramAvailMb, r.lowMemory, if (free >= 0) free / 1_000_000 else null, recording, drop)
        for (f in AlertRules.evaluate(input) { alerts.threshold(it) }) deliver(alerts.post(f.type, f.text, f.severity))
        alerts.flushIfDirty()
    }

    /** Показ: плашка поверх превью или строка состояния; звук и вибрация — не во время записи со звуком (иначе попадут в файл). */
    internal fun deliver(d: AlertDelivery?) {
        if (d == null || !d.banner) return
        val e = d.entry
        val prefix = when (e.severity) { Severity.CRITICAL -> "❗ "; Severity.WARNING -> "⚠ "; else -> "" }
        if (d.overPreview) showNote(prefix + e.text, if (e.severity == Severity.CRITICAL) 6000L else 4500L, error = e.severity == Severity.CRITICAL)
        else appLog(e.text.take(90))
        val quiet = recording && ::engine.isInitialized && engine.cfg.audio
        if (quiet) return
        if (d.vibrate) try {
            @Suppress("DEPRECATION") val vib = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            vib?.vibrate(android.os.VibrationEffect.createOneShot(90, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (ex: Exception) { }
        if (d.sound) try {
            val tg = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 60)
            tg.startTone(android.media.ToneGenerator.TONE_PROP_PROMPT, 150)
            main.postDelayed({ tg.release() }, 400)
        } catch (ex: Exception) { }
    }

    private val statusRunnable = object : Runnable {
        override fun run() {
            if (::engine.isInitialized && ready) {
                val free = freeBytes()
                val bytesPerSec = estMbps() * 1_000_000L / 8 + 24_000L          // видео + звук
                val sb = StringBuilder()
                if (free >= 0) {
                    sb.append("Память: %.1f ГБ".format(free / 1e9))
                    if (bytesPerSec > 0) sb.append(" · ≈ ").append(fmtDuration(free / bytesPerSec))
                }
                // Защита файла: когда места почти нет, запись завершается штатно (файл корректно закрывается), а не обрывается ошибкой записи.
                if (recording && free in 0 until LOW_STORAGE_STOP_BYTES) {
                    // защита файла работает всегда; пользователь решает только, показывать ли сообщение
                    appLog("Память почти закончилась (${free / 1_000_000} МБ): запись остановлена, файл сохранён")
                    deliver(alerts.post(AlertType.STORAGE_FULL, "Память почти закончилась — запись остановлена, файл сохранён", Severity.CRITICAL, key = "stop"))
                    engine.toggleRecord()
                }
                if (recording) {
                    val sec = recElapsedSec()
                    sb.append(" · файл ≈ %.0f МБ".format(sec * bytesPerSec / 1e6))
                }
                statusHud.text = sb.toString()
            }
            main.removeCallbacks(this)
            main.postDelayed(this, 2000)
        }
    }

    override fun onPaused(on: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (on && !isPaused) pauseSince = now
        if (!on && isPaused) pausedTotal += now - pauseSince
        isPaused = on
        pauseIcon.play = on
        pauseBtn.setContentDescription(if (on) "Продолжить" else "Пауза")
        appLog(if (on) "Пауза" else "Запись продолжена")
        recHud.text = recHudText()
    }

    private fun recElapsedSec(): Long {
        val now = SystemClock.elapsedRealtime()
        val extra = if (isPaused) now - pauseSince else 0L
        return ((now - recStart - pausedTotal - extra) / 1000).coerceAtLeast(0)
    }

    private fun recHudText(): String { val s = recElapsedSec(); return (if (isPaused) "❚❚ " else "● ") + "%02d:%02d".format(s / 60, s % 60) }

    private fun tick() {
        main.postDelayed({
            if (recording) {
                recHud.text = recHudText()
                tick()
            }
        }, 500)
    }
}
