package app.procam

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Настройки шумоподавления NR 4.0 (то, что выбрал пользователь). */
class NrSettings(
    /** Быстрые уровни v0.25–v0.26: 0 выкл, 1..3. Работают, пока advanced = false. */
    val level: Int = 0,
    val advanced: Boolean = false,
    val spatial: Boolean = true,
    val temporal: Boolean = true,
    val luma: Float = 0.6f,
    val chroma: Float = 0.6f,
    /** Сохранение деталей 0..1: консервативнее считает движение и слабее фильтрует пространственно. */
    val detail: Float = 0.5f,
    val lowLight: Boolean = false,
    val lowLightStrength: Float = 0.6f,
    /** Множитель глубины временного накопления из профиля обработки (Low Latency < Balanced < Maximum Quality). */
    val temporalScale: Float = 1f,
    /** Общая сила пространственного сглаживания 0..1: 0.5 — как раньше, 0 — пространственный этап выключен, 1 — вдвое сильнее. */
    val spatialStrength: Float = 0.5f,
    /** Общая сила временного накопления 0..1: 0.5 — как раньше, 0 — без накопления, 1 — глубина накопления возводится в квадрат (вдвое больше кадров). */
    val temporalStrength: Float = 0.5f
)

/** Параметры, которые получает шейдер NR v3/4 (те же униформы, что и раньше, плюс переключатели этапов). */
class NrShaderParams(val aY: Float, val aC: Float, val k: Float, val wSpat: Float, val rangeK: Float, val sigBoost: Float, val spatialOn: Boolean, val temporalOn: Boolean) {
    /** Эффективное число усредняемых кадров для статичных областей (рекурсивный фильтр: N = (2−a)/a). */
    fun effectiveFrames(): Float = (2f - aY) / aY
}

object NrMap {
    private val LEVELS = arrayOf(floatArrayOf(0.30f, 0.15f, 2.5f, 0.6f, 2.0f), floatArrayOf(0.15f, 0.07f, 2.5f, 0.8f, 2.0f), floatArrayOf(0.08f, 0.04f, 2.5f, 1.0f, 2.5f))

    /** null — шумоподавление выключено (ни один этап не нужен). */
    fun map(s: NrSettings): NrShaderParams? {
        val lowOn = s.lowLight
        if (!s.advanced && s.level <= 0 && !lowOn) return null
        var aY: Float; var aC: Float; var k: Float; var w: Float; var rk: Float
        var boost = 1f
        if (!s.advanced && s.level > 0) {
            val l = LEVELS[(s.level - 1).coerceIn(0, 2)]
            aY = l[0]; aC = l[1]; k = l[2]; w = l[3]; rk = l[4]
        } else {
            val ly = if (s.advanced) s.luma else 0f
            val ch = if (s.advanced) s.chroma else 0f
            aY = 0.04f.pow(ly.coerceIn(0f, 1f)); aC = 0.02f.pow(ch.coerceIn(0f, 1f))
            k = 2.5f; w = 0.8f; rk = 2.0f
            if (s.advanced) { val d = s.detail.coerceIn(0f, 1f); k = 2.5f - 1.2f * d; w *= (1f - 0.6f * d); rk = 2.0f - 1.0f * d }
        }
        if (lowOn) {
            val ll = s.lowLightStrength.coerceIn(0f, 1f)
            // подавление яркостного и цветового шума усиливается, но не ниже уже выбранного; защита от пластика — потолок на пространственный вес
            aY = min(aY, 0.04f.pow(0.4f + 0.5f * ll)); aC = min(aC, 0.02f.pow(0.6f + 0.4f * ll))
            boost = 1f + ll
            k = min(k, 2.2f)
            w = min(max(w, 0.5f + 0.35f * ll), 0.85f)
        }
        // слайдеры «сила»: действуют поверх любого режима (быстрые уровни, расширенные, Low Light)
        val ss = s.spatialStrength.coerceIn(0f, 1f); val ts = s.temporalStrength.coerceIn(0f, 1f)
        w = (w * ss * 2f).coerceIn(0f, 1f); rk *= (0.5f + ss)
        // глубже ≈50 кадров слайдер накопление не доводит (aY ≥ 0.04): иначе на движении остаются шлейфы
        aY = max(aY.pow(2f * ts), min(aY, 0.04f)); aC = max(aC.pow(2f * ts), min(aC, 0.02f)); k *= (0.75f + 0.5f * ts)
        aY = aY.pow(s.temporalScale.coerceIn(0.3f, 2f)).coerceIn(0.02f, 1f)
        aC = aC.pow(s.temporalScale.coerceIn(0.3f, 2f)).coerceIn(0.01f, 1f)
        return NrShaderParams(
            aY = if (s.temporal) aY else 1f, aC = if (s.temporal) aC else 1f,
            k = k, wSpat = if (s.spatial) w else 0f, rangeK = rk, sigBoost = boost, spatialOn = s.spatial, temporalOn = s.temporal
        )
    }
}

/** Эталон (CPU) формул шейдеров NR: маска движения, пространственный билатеральный 3×3, временной рекурсивный. Работает по яркости. */
object NrRef {
    /** σ шума яркости от уровня: sqrt(a·y + b), нормировано на σ при y=0.5 — как в таблице шейдера; здесь простой профиль для тестов. */
    fun sigma(y: Float, base: Float) = base * kotlin.math.sqrt(0.35f + 1.3f * y.coerceIn(0f, 1f))

    class State(val w: Int, val h: Int) {
        var hist = FloatArray(w * h); var prevL = FloatArray(w * h); var mask = FloatArray(w * h); var have = false
    }

    /** Один шаг. cur — текущая яркость. Возвращает выход (и обновляет состояние). */
    fun step(st: State, cur: FloatArray, p: NrShaderParams, sigBase: Float): FloatArray {
        val w = st.w; val h = st.h
        val out = FloatArray(w * h)
        val newMask = FloatArray(w * h)
        val sigScale = max(sigBase, 1e-4f)
        // маска движения (как FS_MASK): по яркости, усреднённой по 2×2 (шум ÷2), порог k·σ сравнивается с разностью усреднённых кадров (σ·0.71)
        val avg = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val x1 = min(x + 1, w - 1); val y1 = min(y + 1, h - 1)
            avg[y * w + x] = (cur[y * w + x] + cur[y * w + x1] + cur[y1 * w + x] + cur[y1 * w + x1]) * 0.25f
        }
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val l = avg[i]
            val sig = max(sigma(l, sigScale) * p.sigBoost, 1e-4f)
            val m = if (st.have) ((kotlin.math.abs(l - st.prevL[i]) / (p.k * sig)) - 1f).coerceIn(0f, 1f) else 1f
            var pm = if (st.have) st.mask[i] else 1f
            if (st.have) {
                if (x + 1 < w) pm = max(pm, st.mask[i + 1]); if (x > 0) pm = max(pm, st.mask[i - 1])
                if (y + 1 < h) pm = max(pm, st.mask[i + w]); if (y > 0) pm = max(pm, st.mask[i - w])
            }
            newMask[i] = max(m, pm * 0.80f)
        }
        // пространственный фильтр только в зонах движения (как FS_SPAT)
        val spat = FloatArray(w * h) { cur[it] }
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (newMask[i] < 0.02f) continue
            val y0 = cur[i]
            val sr = max(p.rangeK * sigma(y0, sigScale) * p.sigBoost * 0.5f, 1e-4f)
            val inv2r = 1f / (2f * sr * sr)
            var acc = y0; var wt = 1f
            for (j in -1..1) for (ii in -1..1) {
                if (ii == 0 && j == 0) continue
                val xx = (x + ii).coerceIn(0, w - 1); val yy = (y + j).coerceIn(0, h - 1)
                val s = cur[yy * w + xx]
                val ws = if (ii != 0 && j != 0) 0.13534f else 0.60653f
                val ww = ws * exp(-(s - y0) * (s - y0) * inv2r)
                acc += s * ww; wt += ww
            }
            spat[i] = acc / wt
        }
        // временной фильтр с клампом истории (как FS_TEMP, по 2×2-min/max заменён окном 3×3)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val yc = cur[i]
            var yh = if (st.have) st.hist[i] else yc
            var mn = yc; var mx = yc
            for (j in -1..1) for (ii in -1..1) { val v = cur[(y + j).coerceIn(0, h - 1) * w + (x + ii).coerceIn(0, w - 1)]; mn = min(mn, v); mx = max(mx, v) }
            val pad = p.k * max(sigma(yc, sigScale) * p.sigBoost, 1e-4f)
            yh = yh.coerceIn(mn - pad, mx + pad)
            val m = newMask[i]
            val ay = if (st.have) (p.aY + (1f - p.aY) * m) else 1f
            var yt = yh + ay * (yc - yh)
            if (m > 0.02f) yt += (spat[i] - yt) * (m * p.wSpat)
            out[i] = yt
        }
        st.prevL = avg; st.mask = newMask; st.hist = out.copyOf(); st.have = true
        return out
    }
}
