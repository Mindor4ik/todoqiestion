package app.procam

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Глобальный сдвиг изображения между двумя маленькими кадрами яркости (проекции по строкам и столбцам + взаимная корреляция).
 * Результат — сдвиг содержимого в пикселях маленького кадра (x вправо, y вниз): содержимое A в точке p оказывается в B в точке p + d.
 * Эталон: tools/calib.py (_profile_shift).
 */
object MotionProbe {
    /** @return [dx, dy, уверенность 0..1] или null (пик на границе поиска / нет текстуры). */
    fun shift(a: FloatArray, b: FloatArray, w: Int, h: Int, r: Int = 10): DoubleArray? {
        val ax = DoubleArray(w)
        val bx = DoubleArray(w)
        val ay = DoubleArray(h)
        val by = DoubleArray(h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val va = a[y * w + x].toDouble()
                val vb = b[y * w + x].toDouble()
                ax[x] += va; ay[y] += va
                bx[x] += vb; by[y] += vb
            }
        }
        val rx = profileShift(ax, bx, r) ?: return null
        val ry = profileShift(ay, by, r) ?: return null
        return doubleArrayOf(rx[0], ry[0], min(rx[1], ry[1]))
    }

    /** Убираем среднее и медленные изменения (скользящее среднее 9, нули за краями), затем окно Ханна. */
    private fun prep(x: DoubleArray): DoubleArray {
        val n = x.size
        var m = 0.0
        for (v in x) m += v
        m /= n
        val c = DoubleArray(n) { x[it] - m }
        val out = DoubleArray(n)
        for (i in 0 until n) {
            var s = 0.0
            for (j in (i - 4)..(i + 4)) if (j in 0 until n) s += c[j]
            out[i] = (c[i] - s / 9.0) * (0.5 - 0.5 * cos(2.0 * PI * i / max(n - 1, 1)))
        }
        return out
    }

    private fun profileShift(a0: DoubleArray, b0: DoubleArray, r: Int): DoubleArray? {
        val a = prep(a0)
        val b = prep(b0)
        val n = a.size
        val cs = DoubleArray(2 * r + 1)
        for (s in -r..r) {
            var c = 0.0
            if (s >= 0) { for (i in 0 until n - s) c += a[i] * b[i + s] }
            else { for (i in -s until n) c += a[i] * b[i + s] }
            cs[s + r] = c
        }
        var bi = 0
        for (i in 1 until cs.size) if (cs[i] > cs[bi]) bi = i
        if (bi == 0 || bi == cs.size - 1) return null
        val den = cs[bi - 1] - 2 * cs[bi] + cs[bi + 1]
        val sub = if (den != 0.0) 0.5 * (cs[bi - 1] - cs[bi + 1]) / den else 0.0
        var na = 0.0
        var nb = 0.0
        for (i in 0 until n) { na += a[i] * a[i]; nb += b[i] * b[i] }
        return doubleArrayOf((bi - r) + sub, cs[bi] / (sqrt(na) * sqrt(nb) + 1e-9))
    }
}
