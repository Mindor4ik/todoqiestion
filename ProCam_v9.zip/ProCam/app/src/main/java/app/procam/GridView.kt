package app.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Сетка-композиция поверх превью. В запись не попадает. */
enum class Grid(val label: String, val desc: String) {
    OFF("Выкл", "Сетка выключена."),
    THIRDS("3×3", "Правило третей: ставьте главный объект на пересечения линий, горизонт — на одну из горизонталей."),
    GRID4("4×4", "Мелкая сетка: удобно выравнивать горизонт и вертикали зданий."),
    PHI("Золотое", "Золотое сечение (1 : 1,618) — линии ближе к центру, чем в правиле третей; мягкая композиция."),
    CROSS("Крест", "Центральный крест — для симметричных кадров и точного центрирования."),
    DIAG("Диагонали", "Сетка 3×3 и диагонали кадра — для динамичных композиций и ведущих линий.")
}

/** Рамка итогового кадра внутри снятого (главное применение — Open Gate: снимаете весь сенсор, кадрируете при монтаже). */
enum class Guide(val label: String, val ratio: Float, val desc: String) {
    OFF("Выкл", 0f, "Рамка выключена."),
    R169("16:9", 16f / 9f, "Стандарт YouTube, ТВ и мониторов."),
    R239("2.39:1", 2.39f, "Кинематографичный широкий формат (анаморфот)."),
    R185("1.85:1", 1.85f, "Широкоэкранное кино."),
    R916("9:16", 9f / 16f, "Вертикальное видео: Reels, Shorts, TikTok."),
    R11("1:1", 1f, "Квадрат для ленты соцсетей.")
}

class GridView(c: Context) : View(c) {
    var grid: Grid = Grid.OFF
        set(v) { field = v; invalidate() }
    var guide: Guide = Guide.OFF
        set(v) { field = v; invalidate() }
    /** Соотношение сторон реального кадра внутри вида (превью вписано по центру, по бокам могут быть поля). */
    var contentAspect: Float = 16f / 9f
        set(v) { field = v; invalidate() }

    private val px = resources.displayMetrics.density
    private val light = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3FFFFFF.toInt(); strokeWidth = 1.5f * px }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000; strokeWidth = 1.5f * px }
    private val shade = Paint().apply { color = 0x99000000.toInt() }
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFB300.toInt(); strokeWidth = 2f * px; style = Paint.Style.STROKE
    }

    /** Прямоугольник кадра в координатах вида. */
    fun contentRect(): RectF {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return RectF()
        var cw = w
        var ch = h
        if (w / h > contentAspect) cw = h * contentAspect else ch = w / contentAspect
        val l = (w - cw) / 2f
        val t = (h - ch) / 2f
        return RectF(l, t, l + cw, t + ch)
    }

    private fun line(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        cv.drawLine(x1 + px, y1 + px, x2 + px, y2 + px, dark)   // тень, чтобы линии читались на светлом
        cv.drawLine(x1, y1, x2, y2, light)
    }

    private fun vertical(cv: Canvas, r: RectF, fr: FloatArray) { for (f in fr) line(cv, r.left + r.width() * f, r.top, r.left + r.width() * f, r.bottom) }
    private fun horizontal(cv: Canvas, r: RectF, fr: FloatArray) { for (f in fr) line(cv, r.left, r.top + r.height() * f, r.right, r.top + r.height() * f) }

    override fun onDraw(cv: Canvas) {
        val r = contentRect()
        if (r.isEmpty) return

        if (guide != Guide.OFF) {
            // Рамка нужного формата по центру кадра; всё за её пределами затемняем.
            val gw: Float
            val gh: Float
            if (guide.ratio >= r.width() / r.height()) { gw = r.width(); gh = gw / guide.ratio } else { gh = r.height(); gw = gh * guide.ratio }
            val g = RectF(r.centerX() - gw / 2, r.centerY() - gh / 2, r.centerX() + gw / 2, r.centerY() + gh / 2)
            cv.drawRect(r.left, r.top, r.right, g.top, shade)
            cv.drawRect(r.left, g.bottom, r.right, r.bottom, shade)
            cv.drawRect(r.left, g.top, g.left, g.bottom, shade)
            cv.drawRect(g.right, g.top, r.right, g.bottom, shade)
            cv.drawRect(g, frame)
        }

        if (grid == Grid.OFF) return
        val thirds = floatArrayOf(1f / 3f, 2f / 3f)
        when (grid) {
            Grid.THIRDS -> { vertical(cv, r, thirds); horizontal(cv, r, thirds) }
            Grid.GRID4 -> { val q = floatArrayOf(0.25f, 0.5f, 0.75f); vertical(cv, r, q); horizontal(cv, r, q) }
            Grid.PHI -> { val p = floatArrayOf(0.381966f, 0.618034f); vertical(cv, r, p); horizontal(cv, r, p) }
            Grid.CROSS -> { vertical(cv, r, floatArrayOf(0.5f)); horizontal(cv, r, floatArrayOf(0.5f)) }
            Grid.DIAG -> {
                vertical(cv, r, thirds); horizontal(cv, r, thirds)
                line(cv, r.left, r.top, r.right, r.bottom); line(cv, r.left, r.bottom, r.right, r.top)
            }
            else -> {}
        }
    }
}
