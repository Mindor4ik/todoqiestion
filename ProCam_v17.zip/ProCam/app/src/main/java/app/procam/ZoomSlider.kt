package app.procam

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Вертикальный ползунок зума (логарифмическая шкала). Тянуть — плавный зум,
 * отпускание рядом с пресетом — магнит, долгий тап — сброс к 1×.
 */
class ZoomSlider(ctx: Context) : View(ctx) {
    var onChange: ((Float) -> Unit)? = null   // во время тяги (можно дросселировать)
    var onCommit: (() -> Unit)? = null        // палец отпущен

    private var lower = 1f
    private var upper = 10f
    private var value = 1f
    private val px = resources.displayMetrics.density
    private fun dp(v: Float) = v * px

    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3A3C.toInt() }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFD60A.toInt() }
    private val thumbP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val thumbRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD60A.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(2f)
    }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E8E93.toInt(); strokeWidth = dp(1.2f) }
    private val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFAEAEB2.toInt(); textSize = dp(11f) }
    private val valueP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD60A.toInt(); textSize = dp(12f); textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()
    private var dragging = false

    private val gesture = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onLongPress(e: MotionEvent) {
            val target = 1f.coerceIn(lower, upper)
            value = target
            onChange?.invoke(value)
            onCommit?.invoke()
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            invalidate()
        }
    })

    fun setRange(l: Float, u: Float) {
        lower = l.coerceAtLeast(0.1f)
        upper = u.coerceAtLeast(lower + 0.01f)
        value = value.coerceIn(lower, upper)
        invalidate()
    }

    fun setValue(v: Float) {
        anim?.cancel()
        squash = 0f
        value = v.coerceIn(lower, upper)
        invalidate()
    }

    private var anim: ValueAnimator? = null
    private var squash = 0f

    /** Плавный переезд ползунка (тап по пресету): бегунок тянется, как капля, и оседает с перелётом. */
    fun setValueAnimated(v: Float) {
        val target = v.coerceIn(lower, upper)
        anim?.cancel()
        val t0 = zoomToT(value)
        val t1 = zoomToT(target)
        if (dragging || abs(t1 - t0) < 0.002f || !animationsEnabled()) { value = target; squash = 0f; invalidate(); return }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 520
        a.interpolator = Spring(7f, 10f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            value = tToZoom(t0 + (t1 - t0) * f)
            squash = sin(Math.PI * it.animatedFraction.coerceIn(0f, 1f)).toFloat() * abs(t1 - t0).coerceAtMost(0.5f) * 2f
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) { squash = 0f; invalidate() }
        })
        anim = a
        a.start()
    }

    private fun animationsEnabled(): Boolean = try {
        android.provider.Settings.Global.getFloat(context.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
    } catch (e: Exception) { true }

    private fun presets(): List<Float> {
        val base = listOf(0.5f, 0.6f, 0.7f, 1f, 1.5f, 2f, 3f, 5f, 7f, 10f, 15f, 20f, 30f)
        val out = ArrayList<Float>()
        out.add(lower)
        for (p in base) if (p > lower + 0.02f && p < upper - 0.02f) out.add(p)
        out.add(upper)
        return out
    }

    private fun fmt(z: Float): String {
        val s = if (z >= 10f || abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString()
        else "%.1f".format(z)
        return "$s×"
    }

    private fun topPad() = dp(22f)
    private fun botPad() = dp(12f)
    private fun trackX() = width - dp(20f)
    private fun usable() = (height - topPad() - botPad()).coerceAtLeast(dp(40f))
    private fun zoomToT(z: Float) = (ln((z / lower).toDouble()) / ln((upper / lower).toDouble())).toFloat().coerceIn(0f, 1f)
    private fun tToZoom(t: Float) = lower * (upper / lower).pow(t.coerceIn(0f, 1f))
    private fun yFor(z: Float) = topPad() + (1f - zoomToT(z)) * usable()

    override fun onDraw(cv: Canvas) {
        val x = trackX()
        val tw = dp(5f)
        val y0 = topPad(); val y1 = height - botPad()
        rect.set(x - tw / 2, y0, x + tw / 2, y1)
        cv.drawRoundRect(rect, tw / 2, tw / 2, trackP)
        val ty = yFor(value)
        rect.set(x - tw / 2, ty, x + tw / 2, y1)
        cv.drawRoundRect(rect, tw / 2, tw / 2, fillP)
        for (p in presets()) {
            val y = yFor(p)
            cv.drawLine(x - dp(9f), y, x - dp(4f), y, tickP)
            labelP.textAlign = Paint.Align.RIGHT
            cv.drawText(fmt(p), x - dp(11f), y + dp(3f), labelP)
        }
        // бегунок-капля: при движении вытягивается по вертикали и сужается по горизонтали
        val rx = dp(9f) * (1f - 0.2f * squash)
        val ry = dp(9f) * (1f + 0.55f * squash)
        rect.set(x - rx, ty - ry, x + rx, ty + ry)
        cv.drawOval(rect, thumbP)
        cv.drawOval(rect, thumbRing)
        cv.drawText(fmt(value), width / 2f, dp(14f), valueP)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (upper - lower < 0.02f) return false
        gesture.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                applyY(e.y, false)
            }
            MotionEvent.ACTION_MOVE -> if (dragging) applyY(e.y, false)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    applyY(e.y, true)
                    dragging = false
                    onCommit?.invoke()
                    performClick()
                }
            }
        }
        return true
    }

    private fun applyY(y: Float, snap: Boolean) {
        var t = 1f - (y - topPad()) / usable()
        t = t.coerceIn(0f, 1f)
        var z = tToZoom(t)
        if (snap) {
            val tp = zoomToT(z)
            val near = presets().minByOrNull { abs(zoomToT(it) - tp) }
            if (near != null && abs(zoomToT(near) - tp) < 0.045f) {
                z = near
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
        }
        z = z.coerceIn(lower, upper)
        if (abs(z - value) > 0.0005f) {
            value = z
            onChange?.invoke(z)
            invalidate()
        }
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
