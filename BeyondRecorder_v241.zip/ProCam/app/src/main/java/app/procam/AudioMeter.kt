package app.procam

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/**
 * Лёгкий слушатель микрофона только для шкал уровня (в файл ничего не пишет).
 * Работает, пока нет записи: во время записи уровни отдаёт сам рекордер, чтобы не открывать микрофон дважды.
 */
class AudioMeter(private val onLevel: (Float, Float) -> Unit) {
    @Volatile private var run = false
    private var th: Thread? = null
    val running get() = run

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (run) return true
        val rate = 48000
        for ((chCfg, n) in listOf(AudioFormat.CHANNEL_IN_STEREO to 2, AudioFormat.CHANNEL_IN_MONO to 1)) {
            val min = AudioRecord.getMinBufferSize(rate, chCfg, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) continue
            for (src in listOf(MediaRecorder.AudioSource.CAMCORDER, MediaRecorder.AudioSource.MIC)) {
                val r = try { AudioRecord(src, rate, chCfg, AudioFormat.ENCODING_PCM_16BIT, min * 2) } catch (e: Exception) { null } ?: continue
                if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); continue }
                try { r.startRecording() } catch (e: Exception) { r.release(); continue }
                if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) { r.release(); continue }
                run = true
                val t = Thread({ loop(r, n) }, "procam-meter")
                t.isDaemon = true
                th = t
                t.start()
                return true
            }
        }
        return false
    }

    private fun loop(r: AudioRecord, ch: Int) {
        val buf = ShortArray(1024 * ch)               // ≈ 21 мс
        try {
            while (run) {
                val n = r.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                var l = 0
                var rr = 0
                var i = 0
                while (i + ch <= n) {
                    val a = Math.abs(buf[i].toInt())
                    if (a > l) l = a
                    if (ch == 2) { val b = Math.abs(buf[i + 1].toInt()); if (b > rr) rr = b }
                    i += ch
                }
                if (ch == 1) rr = l
                onLevel(l / 32768f, rr / 32768f)
            }
        } catch (e: Exception) {
        } finally {
            try { r.stop() } catch (e: Exception) {}
            r.release()
        }
    }

    /** Останавливает и ждёт, пока микрофон освободится (до 250 мс), чтобы рекордер мог сразу его открыть. */
    fun stop() {
        run = false
        val t = th
        th = null
        try { t?.join(250) } catch (e: Exception) {}
    }
}
