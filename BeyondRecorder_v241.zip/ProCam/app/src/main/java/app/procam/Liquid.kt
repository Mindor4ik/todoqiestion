package app.procam

import android.animation.TimeInterpolator
import android.view.animation.PathInterpolator

/**
 * Мягкая «пружина» 0 → 1 БЕЗ перелёта (критическое затухание): плавный разгон и мягкая остановка,
 * ничто не выходит за свои границы. Параметры оставлены для совместимости: чем больше damping, тем быстрее оседает.
 */
class Spring(private val damping: Float = 6.5f, @Suppress("unused") private val freq: Float = 11f) : TimeInterpolator {
    private val k = damping.coerceAtLeast(5f) * 1.35f
    private val norm = 1.0 - (1.0 + k) * Math.exp(-k.toDouble())
    override fun getInterpolation(t: Float): Float {
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f
        val x = k * t
        return ((1.0 - (1.0 + x) * Math.exp(-x.toDouble())) / norm).toFloat()
    }
}

/** Кривые движения интерфейса: появление — мягкое торможение, уход — мягкий разгон, переезды — плавно с обеих сторон. */
object Ease {
    val enter: TimeInterpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
    val exit: TimeInterpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
    val standard: TimeInterpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
}
