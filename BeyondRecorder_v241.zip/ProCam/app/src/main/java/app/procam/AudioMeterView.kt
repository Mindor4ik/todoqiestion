package app.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.TypedValue
import android.view.View

/**
 * Две вертикальные шкалы уровня — левый и правый канал (пик, дБFS от −60 до 0), сегментами.
 * Быстрая атака, плавный спад, удержание пика, верхний сегмент — индикатор перегрузки. Монохромно, без подложки.
 */
class AudioMeterView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private val disp = FloatArray(2)          // показываемый уровень, доля шкалы 0..1
    private val hold = FloatArray(2)
    private val holdAt = LongArray(2)
    private val clipUntil = LongArray(2)
    private var last = 0L
    private val segs = 24
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xE6FFFFFF.toInt(); textSize = sp(11f); textAlign = Paint.Align.CENTER
        setShadowLayer(dp(3f), 0f, dp(1f), 0x99000000.toInt())
    }
    private val rect = RectF()

    init { contentDescription = "Уровень звука, левый и правый канал" }

    private fun frac(p: Float): Float =
        if (p <= 0.001f) 0f else ((20.0 * Math.log10(p.toDouble()) + 60.0) / 60.0).toFloat().coerceIn(0f, 1f)

    /** Пики последнего блока звука, 0..1 (линейно). */
    fun set(l: Float, r: Float) {
        val now = SystemClock.uptimeMillis()
        push(0, l, now); push(1, r, now)
        postInvalidateOnAnimation()
    }

    private fun push(i: Int, p: Float, now: Long) {
        val f = frac(p)
        if (f > disp[i]) disp[i] = f
        if (f >= hold[i]) { hold[i] = f; holdAt[i] = now }
        if (p >= 0.97f) clipUntil[i] = now + 1500
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0f else ((now - last) / 1000f).coerceIn(0f, 0.2f)
        last = now
        var moving = false
        for (i in 0..1) {
            disp[i] = (disp[i] - 0.55f * dt).coerceAtLeast(0f)               // плавный спад ≈ 33 дБ/с
            if (now - holdAt[i] > 1200) hold[i] = (hold[i] - 0.4f * dt).coerceAtLeast(0f)
            if (disp[i] > 0.002f || hold[i] > 0.002f || now < clipUntil[i]) moving = true
        }
        val w = width.toFloat()
        val y0 = dp(6f)
        val y1 = height - dp(22f)
        if (y1 - y0 < dp(40f)) return
        val bw = dp(9f)
        val gap = dp(4f)
        val x0 = w - 2 * bw - gap - dp(4f)
        val segH = (y1 - y0) / segs
        val sh = segH - dp(1.5f)

        // деления шкалы
        txt.textAlign = Paint.Align.RIGHT
        for ((db, label) in listOf(0 to "0", -12 to "−12", -24 to "−24", -48 to "−48")) {
            val f = (db + 60) / 60f
            val y = y1 - f * (y1 - y0)
            cv.drawText(label, x0 - dp(5f), y + dp(4f), txt)
        }
        txt.textAlign = Paint.Align.CENTER

        for (ch in 0..1) {
            val x = x0 + ch * (bw + gap)
            val lit = (disp[ch] * (segs - 1)).toInt()                      // сколько обычных сегментов горит
            for (s in 0 until segs) {
                val yTop = y1 - (s + 1) * segH
                val on = if (s == segs - 1) now < clipUntil[ch] else s < lit
                paint.color = if (on) (if (s >= segs - 5) 0xFFFFFFFF.toInt() else 0xD9FFFFFF.toInt()) else 0x26FFFFFF
                rect.set(x, yTop, x + bw, yTop + sh)
                cv.drawRoundRect(rect, dp(1.5f), dp(1.5f), paint)
            }
            if (hold[ch] > 0.01f) {                                         // удержание пика
                val y = y1 - hold[ch] * (y1 - y0)
                paint.color = 0xFFFFFFFF.toInt()
                rect.set(x - dp(1.5f), y - dp(1f), x + bw + dp(1.5f), y + dp(1f))
                cv.drawRect(rect, paint)
            }
            cv.drawText(if (ch == 0) "L" else "R", x + bw / 2f, height - dp(6f), txt)
        }
        if (moving) postInvalidateOnAnimation()
    }
}
