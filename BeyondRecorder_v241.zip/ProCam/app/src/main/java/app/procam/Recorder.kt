package app.procam

import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

enum class ColorTag { BT709, LOG, HLG }

data class RecConfig(
    val w: Int, val h: Int, val fps: Int,
    val mime: String, val bitrate: Int,
    val tenBit: Boolean, val tag: ColorTag,
    val audio: Boolean, val hint: Int,
    val realtimeTs: Boolean,
    val bitrateMode: Int = 0, val gopSec: Float = 1f, val bFrames: Boolean = false, val audioKbps: Int = 192
)

/**
 * Видео: MediaCodec (HEVC/AVC, при необходимости Main10) с входной Surface.
 * Звук: AudioRecord -> AAC. Мультиплексор: MediaMuxer (MP4).
 */
class Recorder(private val ctx: Context, private val c: RecConfig) {
    companion object { private const val TAG = "ProCamRec"; private const val RATE = 48000 }

    var inputSurface: Surface? = null; private set
    val width: Int get() = c.w
    val height: Int get() = c.h
    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private var arec: AudioRecord? = null
    private var aCh = 2
    private var muxer: MediaMuxer? = null
    private var hub: MuxerHub? = null
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    @Volatile private var audioRun = false
    @Volatile private var stopping = false
    @Volatile private var vTrack = -1
    @Volatile private var aTrack = -1

    /** Сообщение о проблеме видеокодека; fatal = запись надо остановить. Вызывается не из UI-потока. */
    var onVideoIssue: ((String, Boolean) -> Unit)? = null

    /** Пики последнего блока звука (левый, правый), 0..1 линейно. Вызывается из потока звука. */
    var onLevel: ((Float, Float) -> Unit)? = null
    @Volatile var paused = false; private set
    @Volatile private var awaitKey = false

    /** Пауза: кадры и звук не пишутся, при продолжении ждём ключевой кадр, таймстампы сдвигаются без дыры. */
    fun setPaused(p: Boolean) {
        if (p == paused) return
        if (p) { paused = true; return }
        hub?.markResume()
        awaitKey = true
        try { venc?.setParameters(android.os.Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }) } catch (e: Exception) { }
        paused = false
    }
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var file: File? = null
    private var displayName = ""

    fun prepare() {
        venc = createVideoEncoder()
        inputSurface = venc!!.createInputSurface()
        if (c.audio) setupAudio()
        openOutput()
        muxer!!.setOrientationHint(c.hint)
        hub = MuxerHub(muxer!!, if (aenc != null) 2 else 1, c.realtimeTs)
    }

    fun start() {
        venc!!.start()
        vThread = Thread({ drainVideo() }, "rec-video").also { it.start() }
        val ae = aenc
        val ar = arec
        if (ae != null && ar != null) {
            ae.start()
            ar.startRecording()
            audioRun = true
            aThread = Thread({ audioLoop() }, "rec-audio").also { it.start() }
        }
    }

    /** Блокирующий вызов, запускать не из UI-потока. Возвращает путь/имя файла или null. */
    fun finish(): String? {
        stopping = true
        audioRun = false
        try { aThread?.join(2500) } catch (e: Exception) { }
        try { venc?.signalEndOfInputStream() } catch (e: Exception) { Log.w(TAG, "EOS: ${e.message}") }
        try { vThread?.join(5000) } catch (e: Exception) { }
        var ok = false
        try { venc?.stop() } catch (e: Exception) { }
        try { venc?.release() } catch (e: Exception) { }
        try { aenc?.stop() } catch (e: Exception) { }
        try { aenc?.release() } catch (e: Exception) { }
        try { arec?.stop() } catch (e: Exception) { }
        try { arec?.release() } catch (e: Exception) { }
        try { muxer?.stop(); ok = true } catch (e: Exception) { Log.w(TAG, "muxer.stop: ${e.message}") }
        try { muxer?.release() } catch (e: Exception) { }
        try { pfd?.close() } catch (e: Exception) { }
        val summary = if (ok) (hub?.summary(vTrack, aTrack) ?: "") else ""
        val path = finalizeOutput(ok)
        return if (path != null && summary.isNotEmpty()) "$path\n$summary" else path
    }

    fun abort() {
        audioRun = false
        try { venc?.release() } catch (e: Exception) { }
        try { aenc?.release() } catch (e: Exception) { }
        try { arec?.release() } catch (e: Exception) { }
        try { muxer?.release() } catch (e: Exception) { }
        try { pfd?.close() } catch (e: Exception) { }
        finalizeOutput(false)
    }

    // ------------------------------------------------------------- video

    /** Режим битрейта из настроек; если кодек телефона его не поддерживает — VBR. */
    private fun bitrateModeFor(mode: Int): Int {
        val want = when (mode) {
            1 -> MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
            2 -> MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CQ
            else -> return MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
        }
        return try {
            val e = MediaCodec.createEncoderByType(c.mime)
            val ok = try { e.codecInfo.getCapabilitiesForType(c.mime).encoderCapabilities.isBitrateModeSupported(want) } finally { e.release() }
            if (ok) want else MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
        } catch (x: Exception) { MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR }
    }

    private fun videoFormat(extras: Boolean): MediaFormat {
        val f = MediaFormat.createVideoFormat(c.mime, c.w, c.h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        f.setInteger(MediaFormat.KEY_BIT_RATE, c.bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, c.fps)
        if (c.gopSec == Math.round(c.gopSec).toFloat()) f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, Math.round(c.gopSec).coerceAtLeast(1))
        else f.setFloat(MediaFormat.KEY_I_FRAME_INTERVAL, c.gopSec)
        f.setInteger(MediaFormat.KEY_BITRATE_MODE, bitrateModeFor(c.bitrateMode))
        if (c.tenBit && c.mime == MIME_HEVC) {
            f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10)
        }
        if (c.tag == ColorTag.HLG) {
            f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT2020)
            f.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_HLG)
        } else {
            f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
        }
        f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        if (extras) {
            f.setInteger(MediaFormat.KEY_OPERATING_RATE, c.fps)
            f.setInteger(MediaFormat.KEY_PRIORITY, 0)
            if (Build.VERSION.SDK_INT >= 29) f.setInteger(MediaFormat.KEY_MAX_B_FRAMES, if (c.bFrames) 2 else 0)
        }
        return f
    }

    private fun createVideoEncoder(): MediaCodec {
        var last: Exception? = null
        for (extras in listOf(true, false)) {
            val name = Enc.bestName(c.mime)
            val codec = if (name != null) MediaCodec.createByCodecName(name) else MediaCodec.createEncoderByType(c.mime)
            try {
                codec.configure(videoFormat(extras), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                return codec
            } catch (e: Exception) {
                last = e
                codec.release()
            }
        }
        throw last ?: IllegalStateException("encoder")
    }

    private fun drainVideo() {
        val e = venc ?: return
        val h = hub ?: return
        val info = MediaCodec.BufferInfo()
        var track = -1
        var lastOut = SystemClock.uptimeMillis()
        var warned = false
        while (true) {
            var i = -1
            try {
                i = e.dequeueOutputBuffer(info, 10_000)
            } catch (ex: Exception) {
                // Раньше это молча обрывало видеодорожку: звук шёл дальше, а видео «замирало» на последнем кадре.
                Log.e(TAG, "dequeueOutputBuffer", ex)
                if (!stopping) onVideoIssue?.invoke("кодек остановился: ${ex.message}", true)
                break
            }
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = h.addTrack(e.outputFormat)
                vTrack = track
            } else if (i >= 0) {
                lastOut = SystemClock.uptimeMillis()
                warned = false
                val buf = e.getOutputBuffer(i)
                var failed: String? = null
                try {
                    var skip = paused
                    if (!skip && awaitKey) {
                        if ((info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0) awaitKey = false else skip = true
                    }
                    if (!skip && buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && track >= 0) {
                        h.write(track, buf, info)
                    }
                } catch (ex: Exception) {
                    failed = ex.message ?: ex.javaClass.simpleName
                }
                try { e.releaseOutputBuffer(i, false) } catch (ex: Exception) { }
                if (failed != null) {
                    Log.e(TAG, "write sample: $failed")
                    onVideoIssue?.invoke("ошибка записи кадра: $failed", true)
                    break
                }
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
            } else if (!stopping && !warned && SystemClock.uptimeMillis() - lastOut > 5000) {
                warned = true
                onVideoIssue?.invoke("кодек уже 5 с не получает кадры (камера или GL перестали их подавать)", false)
            }
        }
    }

    // ------------------------------------------------------------- audio

    private fun setupAudio() {
        for (chCfg in listOf(AudioFormat.CHANNEL_IN_STEREO to 2, AudioFormat.CHANNEL_IN_MONO to 1)) {
            val min = AudioRecord.getMinBufferSize(RATE, chCfg.first, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) continue
            for (src in listOf(MediaRecorder.AudioSource.CAMCORDER, MediaRecorder.AudioSource.MIC)) {
                val r = try {
                    AudioRecord(src, RATE, chCfg.first, AudioFormat.ENCODING_PCM_16BIT, min * 4)
                } catch (e: Exception) { null } ?: continue
                if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); continue }
                arec = r
                aCh = chCfg.second
                val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, aCh)
                f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                f.setInteger(MediaFormat.KEY_BIT_RATE, c.audioKbps * 1000)
                f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                aenc = enc
                return
            }
        }
    }

    private fun audioLoop() {
        val rec = arec ?: return
        val enc = aenc ?: return
        val h = hub ?: return
        val info = MediaCodec.BufferInfo()
        val buf = ByteArray(4096 * aCh)
        val bpf = 2 * aCh
        var track = -1
        var total = 0L
        var baseUs = -1L

        fun drain(): Boolean {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, 0)
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = h.addTrack(enc.outputFormat)
                    aTrack = track
                } else if (i >= 0) {
                    val ob = enc.getOutputBuffer(i)
                    if (!paused && ob != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && track >= 0) {
                        h.write(track, ob, info)
                    }
                    enc.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                } else {
                    return false
                }
            }
        }

        try {
            while (audioRun) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break          // ошибка AudioRecord: выходим к EOS, а не крутимся в холостом цикле
                if (n == 0) continue
                onLevel?.let { cb ->
                    var pl = 0
                    var pr = 0
                    var i = 0
                    while (i + bpf <= n) {
                        val a = Math.abs((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 255))
                        if (a > pl) pl = a
                        if (aCh == 2) {
                            val b = Math.abs((buf[i + 3].toInt() shl 8) or (buf[i + 2].toInt() and 255))
                            if (b > pr) pr = b
                        }
                        i += bpf
                    }
                    if (aCh == 1) pr = pl
                    cb(pl / 32768f, pr / 32768f)
                }
                val frames = n / bpf
                if (baseUs < 0) baseUs = SystemClock.elapsedRealtimeNanos() / 1000 - frames * 1_000_000L / RATE
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear()
                    ib.put(buf, 0, n)
                    enc.queueInputBuffer(idx, 0, n, baseUs + total * 1_000_000L / RATE, 0)
                    total += frames
                }
                drain()
            }
            var idx = enc.dequeueInputBuffer(100_000)
            if (idx >= 0) {
                enc.queueInputBuffer(idx, 0, 0, baseUs.coerceAtLeast(0) + total * 1_000_000L / RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            val t0 = SystemClock.uptimeMillis()
            while (!drain() && SystemClock.uptimeMillis() - t0 < 2000) Thread.sleep(5)
        } catch (e: Exception) {
            Log.w(TAG, "audioLoop: ${e.message}")
        }
    }

    // ------------------------------------------------------------- output

    private fun openOutput() {
        displayName = "BEYOND_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Beyond Recorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val u = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("MediaStore insert")
            uri = u
            pfd = ctx.contentResolver.openFileDescriptor(u, "rw") ?: throw IllegalStateException("openFileDescriptor")
            muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
            dir.mkdirs()
            val f = File(dir, displayName)
            file = f
            muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        }
    }

    private fun finalizeOutput(ok: Boolean): String? {
        val u = uri
        if (u != null) {
            return try {
                if (ok) {
                    ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                    "Movies/Beyond Recorder/$displayName"
                } else {
                    ctx.contentResolver.delete(u, null, null); null
                }
            } catch (e: Exception) { null }
        }
        val f = file ?: return null
        return if (ok) f.absolutePath else { f.delete(); null }
    }
}

/**
 * Склейка видео/аудио дорожек. Стартует, когда готовы все дорожки; до этого сэмплы буферизуются.
 * Общая точка отсчёта времени = самый ранний сэмпл среди всего, что накопилось к моменту старта
 * (раньше брался «кто первый пришёл», и ранние кадры/звук получали одинаковое время 0).
 */
private class MuxerHub(private val muxer: MediaMuxer, private val expected: Int, private val common: Boolean) {
    private class Pending(val track: Int, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

    private var added = 0
    private var started = false
    private var base = -1L
    private val bases = LongArray(4) { -1L }
    private val pending = ArrayList<Pending>()
    private val counts = IntArray(4)
    private val lastPts = LongArray(4)
    private val shift = LongArray(4)
    private val lastRaw = LongArray(4) { -1L }
    private val lastStep = LongArray(4) { 20_000L }
    private val gapNext = BooleanArray(4)

    /** Продолжение после паузы: у каждой дорожки первый следующий сэмпл «приклеивается» к предыдущему. */
    @Synchronized
    fun markResume() { for (i in 0..3) gapNext[i] = true }

    @Synchronized
    fun addTrack(f: MediaFormat): Int {
        val t = muxer.addTrack(f)
        added++
        if (added >= expected) {
            muxer.start()
            started = true
            if (common) base = pending.minOfOrNull { it.info.presentationTimeUs } ?: -1L
            for (p in pending) emit(p.track, p.data, p.info)
            pending.clear()
        }
        return t
    }

    @Synchronized
    fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (started) {
            emit(track, buf, info)
        } else {
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            val copy = ByteBuffer.allocate(info.size)
            copy.put(buf)
            copy.flip()
            val ni = MediaCodec.BufferInfo()
            ni.set(0, info.size, info.presentationTimeUs, info.flags)   // время пока «сырое»
            pending.add(Pending(track, copy, ni))
        }
    }

    private fun emit(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        val raw = info.presentationTimeUs
        val b: Long
        if (common) {
            if (base < 0) base = raw
            b = base
        } else {
            if (bases[track] < 0) bases[track] = raw
            b = bases[track]
        }
        if (track in 0..3) {
            if (gapNext[track] && lastRaw[track] >= 0) {
                shift[track] += (raw - lastRaw[track] - lastStep[track]).coerceAtLeast(0L)
            }
            gapNext[track] = false
            if (lastRaw[track] >= 0 && raw > lastRaw[track]) lastStep[track] = (raw - lastRaw[track]).coerceIn(1_000L, 200_000L)
            lastRaw[track] = raw
        }
        val pts = max(0L, raw - b - (if (track in 0..3) shift[track] else 0L))
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        val ni = MediaCodec.BufferInfo()
        ni.set(info.offset, info.size, pts, info.flags)
        muxer.writeSampleData(track, buf, ni)
        if (track in 0..3) {
            counts[track]++
            if (pts > lastPts[track]) lastPts[track] = pts
        }
    }

    /** Итог для диагностики: сколько реально записано видео и звука. */
    @Synchronized
    fun summary(v: Int, a: Int): String {
        val sb = StringBuilder()
        var vs = -1.0
        var asec = -1.0
        if (v in 0..3 && counts[v] > 0) {
            vs = lastPts[v] / 1e6
            sb.append("видео: ${counts[v]} кадр., ${"%.1f".format(vs)} с")
        }
        if (a in 0..3 && counts[a] > 0) {
            asec = lastPts[a] / 1e6
            if (sb.isNotEmpty()) sb.append("; ")
            sb.append("звук: ${"%.1f".format(asec)} с")
        }
        if (vs >= 0 && asec >= 0 && asec - vs > 1.0) {
            sb.append("\n⚠ видео оборвалось раньше звука на ${"%.1f".format(asec - vs)} с")
        }
        return sb.toString()
    }
}
