package app.procam

import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Вкладки Color Science 2.0: «Управление цветом», «Градация», «Анализ». Все значения идут через ColorSettings (схема настроек v3). */
internal class ColorTabs(private val a: MainActivity) {
    private val cs get() = a.colorSettings
    private fun dp(v: Int) = a.dp(v)
    private fun apply() { a.engine.update() }
    private fun put(k: String, v: Any) { cs.set(k, v); apply() }
    private fun fmt(v: Float) = if (kotlin.math.abs(v) >= 100f) "%.0f".format(v) else "%.3f".format(v).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    /** Строка «название — ползунок — число»: значение можно задать и вводом с клавиатуры (в пределах допустимого). */
    private fun num(box: LinearLayout, label: String, key: String) {
        val r = ColorKeys.rules[key] as Rule.FloatR
        val row = LinearLayout(a); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(a); t.text = label; t.textSize = 12f; t.setTextColor(Ui.text)
        row.addView(t, LinearLayout.LayoutParams(dp(110), a.WRAP))
        val sb = SeekBar(a); sb.max = 1000
        val ed = EditText(a); ed.textSize = 12f; ed.setTextColor(Ui.text); ed.setSingleLine()
        ed.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        ed.imeOptions = EditorInfo.IME_ACTION_DONE
        fun show() { val v = cs.f(key); sb.progress = ((v - r.min) / (r.max - r.min) * 1000).toInt().coerceIn(0, 1000); ed.setText(fmt(v)) }
        show()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { val v = r.min + (r.max - r.min) * p / 1000f; ed.setText(fmt(v)); put(key, v) } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        ed.setOnEditorActionListener { _, _, _ ->
            ed.text.toString().replace(',', '.').toFloatOrNull()?.let { put(key, it) }
            show(); false
        }
        row.addView(sb, LinearLayout.LayoutParams(0, a.WRAP, 1f))
        row.addView(ed, LinearLayout.LayoutParams(dp(78), a.WRAP))
        box.addView(row)
    }

    /** Список из N чисел через запятую (узлы кривой, полосы тона). */
    private fun csv(box: LinearLayout, label: String, key: String) {
        val row = LinearLayout(a); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(a); t.text = label; t.textSize = 12f; t.setTextColor(Ui.text)
        row.addView(t, LinearLayout.LayoutParams(dp(110), a.WRAP))
        val ed = EditText(a); ed.textSize = 12f; ed.setTextColor(Ui.text); ed.setSingleLine(); ed.setText(cs.s(key))
        ed.setOnEditorActionListener { _, _, _ -> put(key, ed.text.toString().trim()); ed.setText(cs.s(key)); false }
        row.addView(ed, LinearLayout.LayoutParams(0, a.WRAP, 1f))
        box.addView(row)
    }

    private fun resetBtn(box: LinearLayout, text: String, keys: Collection<String>) {
        val b = a.flatButton(text, 13f); a.segStyle(b, false)
        b.setOnClickListener { cs.reset(keys); apply(); a.showTab(a.menuTab, true) }
        box.addView(b, LinearLayout.LayoutParams(a.MATCH, dp(40)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
    }

    private fun ib(k: String, opts: List<String>, title: String, desc: String) =
        a.seg(title, desc, opts, { cs.i(k) }) { put(k, it); a.showTab(a.menuTab, true) }

    private fun tg(k: String, title: String, desc: String) = a.toggle(title, desc, { cs.b(k) }) { put(k, it) }

    fun buildManagement() {
        a.section(0)
        a.subTabs(Tabs.COLORMGMT, listOf("Пространства и тон", "Этапы цепочки", "LOG и HLG", "Профили цвета"))
        ib("c26_work", listOf("Rec.709", "Rec.2020", "P3", "ACES AP1"), "Рабочее цветовое пространство",
            "Цвета градации считаются в линейном свете в этих основных цветах. Камера отдаёт Rec.709; другое пространство — это пересчёт примарей, а не новые данные сенсора.")
        ib("c26_sdr_in", listOf("sRGB", "Gamma 2.4", "Gamma 2.2", "BT.709"), "Передаточная функция входа (SDR)", "Как трактовать код, пришедший из камеры. Не пересчитывает запись «как есть», пока всё остальное выключено.")
        ib("c26_sdr_out", listOf("sRGB", "Gamma 2.4", "Gamma 2.2", "BT.709"), "Передаточная функция выхода (SDR)", "Кодирование итоговой SDR-картинки в записи и на мониторе.")
        ib("c26_tone", listOf("Выкл", "Reinhard", "Filmic", "Hable"), "Тон-мэппинг", "Сжимает значения выше белого (HDR/HLG → SDR или перегруз градацией). Выкл — жёсткое ограничение.")
        val box = a.card("Тон-мэппинг: белая точка", "")
        num(box, "Белая точка", "c26_tone_w")
        ib("c26_gamut", listOf("Обрезка", "Сжатие насыщ."), "Gamut mapping", "Что делать с цветами вне охвата выхода: обрезать по каналам или сжать насыщенность с сохранением яркости.")
        a.section(1)
        val st = a.card("Этапы цепочки", "Каждый этап можно отключить отдельно — например, чтобы найти, что меняет картинку.")
        a.toggle("Баланс белого", "", { cs.b("c26_en_wb") }) { put("c26_en_wb", it) }
        a.toggle("Градация", "", { cs.b("c26_en_grade") }) { put("c26_en_grade", it) }
        a.toggle("Тон-мэппинг", "", { cs.b("c26_en_tone") }) { put("c26_en_tone", it) }
        a.toggle("LUT", "", { cs.b("c26_en_lut") }) { put("c26_en_lut", it) }
        a.toggle("До / После (монитор)", "Временно показывает картинку без градации, тон-мэппинга и LUT. В файл это не попадает и не сохраняется.",
            { cs.bypass }) { cs.bypass = it; apply() }
        a.section(2)
        val lg = a.card("LOG / HLG", "Аппаратный LOG записывается как есть. Ниже — программные параметры. HLG-превью, HLG-запись и обработка — разные вещи: белый HLG задаёт, куда ложится диффузный белый SDR.")
        num(lg, "Белый HLG", "c26_hlg_white")
        a.toggle("Своя LOG-кривая", "Параметрическая: out = c·log10(a·x + 1) + d (x — линейный свет). Только программный LOG; не заменяет аппаратный и не восстанавливает обрезанные света.",
            { cs.b("c26_custom_log") }) { put("c26_custom_log", it); a.showTab(a.menuTab, true) }
        if (cs.b("c26_custom_log")) { num(lg, "a", "c26_cl_a"); num(lg, "b", "c26_cl_b"); num(lg, "c", "c26_cl_c"); num(lg, "d", "c26_cl_d") }
        a.toggle("Rec.2020 для SDR/LOG-записи", "Сохраняется как настройка; метаданные файла для SDR/LOG пока остаются Rec.709 (HLG пишется как BT.2020).", { cs.b("c26_rec2020") }) { put("c26_rec2020", it) }
        ib("c26_dither", listOf("Выкл", "Слабый", "Сильный"), "Дизеринг", "Шум ±½ кода перед 8-bit квантованием: гасит бандинг в градиентах. Выкл — как раньше.")
        a.section(3)
        val pr = a.card("Профили цвета", "Готовые наборы настроек. Свои наборы — через пресеты на вкладке «Настройки».")
        for ((name, kv) in profiles) {
            val b = a.flatButton(name, 13f); a.segStyle(b, false)
            b.setOnClickListener { cs.reset(ColorKeys.rules.keys); for ((k, v) in kv) cs.set(k, v); apply(); a.toast("Профиль: $name"); a.showTab(a.menuTab, true) }
            pr.addView(b, LinearLayout.LayoutParams(a.MATCH, dp(40)).apply { setMargins(dp(2), dp(4), dp(2), dp(2)) })
        }
        resetBtn(pr, "Сбросить весь цвет", ColorKeys.rules.keys)
    }

    private val profiles: List<Pair<String, Map<String, Any>>> = listOf(
        "Rec.709 (по умолчанию)" to emptyMap(),
        "Rec.709 Gamma 2.4" to mapOf("c26_sdr_in" to 1, "c26_sdr_out" to 1),
        "Rec.2020 рабочее" to mapOf("c26_work" to 1),
        "Display P3 рабочее" to mapOf("c26_work" to 2),
        "HLG → SDR (Filmic)" to mapOf("c26_tone" to 2, "c26_gamut" to 1)
    )

    fun buildGrade() {
        a.section(0)
        a.subTabs(Tabs.GRADE, listOf("Экспозиция, тон, цвет", "Lift / Gamma / Gain", "Кривые", "Split toning"))
        val b = a.card("Экспозиция и баланс белого", "Применяется до тон-мэппинга, в линейном свете. Превью и запись используют одну формулу.")
        num(b, "Экспозиция, EV", "c26_ev"); num(b, "Температура, K", "c26_kelvin"); num(b, "Тинт", "c26_tint")
        val t = a.card("Тон", "")
        num(t, "Контраст", "c26_contrast"); num(t, "Света", "c26_hi"); num(t, "Тени", "c26_sh"); num(t, "Белое", "c26_wh"); num(t, "Чёрное", "c26_bl")
        val c = a.card("Цвет", "")
        num(c, "Насыщенность", "c26_sat"); num(c, "Vibrance", "c26_vib"); num(c, "Оттенок, °", "c26_hue")
        a.section(1)
        val w = a.card("Lift / Gamma / Gain", "m — общий, R/G/B — по каналам.")
        for (s in listOf("m", "r", "g", "b")) num(w, "Lift $s", "c26_lift_$s")
        for (s in listOf("m", "r", "g", "b")) num(w, "Gamma $s", "c26_gamma_$s")
        for (s in listOf("m", "r", "g", "b")) num(w, "Gain $s", "c26_gain_$s")
        a.section(2)
        val cv = a.card("Кривые", "5 узлов (вход 0, .25, .5, .75, 1) → значение выхода, через запятую. Общая и по каналам.")
        csv(cv, "Яркость", "c26_cv_m"); csv(cv, "R", "c26_cv_r"); csv(cv, "G", "c26_cv_g"); csv(cv, "B", "c26_cv_b")
        val hb = a.card("Hue vs Hue / Sat / Lum", "6 полос (красный, жёлтый, зелёный, голубой, синий, пурпур): сдвиг оттенка (°), насыщенность и яркость.")
        csv(hb, "Hue →", "c26_hb_shift"); csv(hb, "Sat", "c26_hb_sat"); csv(hb, "Lum", "c26_hb_lum")
        a.section(3)
        val sp = a.card("Split toning", "Оттенок и сила для теней и светов, баланс сдвигает границу.")
        num(sp, "Тени: оттенок", "c26_sp_sh_hue"); num(sp, "Тени: сила", "c26_sp_sh_amt"); num(sp, "Света: оттенок", "c26_sp_hi_hue"); num(sp, "Света: сила", "c26_sp_hi_amt"); num(sp, "Баланс", "c26_sp_bal")
        resetBtn(sp, "Сбросить градацию", ColorKeys.rules.keys.filter { it.startsWith("c26_") && it !in listOf("c26_work", "c26_sdr_in", "c26_sdr_out", "c26_tone", "c26_tone_w", "c26_gamut", "c26_rec2020", "c26_hlg_white", "c26_custom_log", "c26_lut_interp", "c26_lut_io", "c26_lut_mix", "c26_dither") && !it.startsWith("c26_en_") && !it.startsWith("c26_cl_") && !it.startsWith("c26_scope") && !it.startsWith("c26_fc") && !it.startsWith("c26_z") })
    }

    fun buildAnalysis() {
        a.subTabs(Tabs.ANALYSIS, listOf("Приборы", "False color", "Зебра"))
        val cfg = a.engine.cfg
        a.section(0)
        val m = a.card("Приборы", "Считаются по реальным пикселям кадра мониторинга (после всей цветовой цепочки). Можно включить несколько сразу.")
        for ((bit, name) in listOf(1 to "Waveform", 2 to "RGB Parade", 4 to "Vectorscope", 8 to "Гистограмма RGB + Y"))
            a.toggle(name, "", { cs.i("c26_scope_mask") and bit != 0 }) { put("c26_scope_mask", if (it) cs.i("c26_scope_mask") or bit else cs.i("c26_scope_mask") and bit.inv()); a.updateScopes() }
        ib("c26_scope_res", listOf("128×72", "192×108", "256×144", "384×216", "512×288"), "Разрешение анализа", "Больше — точнее, но каждое чтение кадра с GPU дороже.")
        val hzs = listOf(1, 2, 6, 15, 30)
        a.seg("Частота обновления", "Анализов в секунду (во время записи не чаще 2 раз в секунду, чтобы не рвать кадры кодера).",
            hzs.map { "$it Гц" }, { hzs.indexOfFirst { it >= cs.i("c26_scope_hz") }.let { if (it < 0) hzs.size - 1 else it } }) { put("c26_scope_hz", hzs[it]) }
        a.section(1)
        ib("c26_fc_map", listOf("Стандарт", "Спектр", "Кожа", "Свои диапазоны"), "Карта false color", "Окраска по яркости монитора.")
        if (cs.i("c26_fc_map") == 3) {
            val fc = a.card("Свои диапазоны false color", "Три диапазона яркости (0…1): синий, зелёный, красный.")
            for (n in 1..3) { num(fc, "От $n", "c26_fc_l$n"); num(fc, "До $n", "c26_fc_h$n") }
        }
        a.toggle("False color", "", { cfg.falseColor }) { cfg.falseColor = it; apply() }
        a.section(2)
        val z = a.card("Зебра", "Две независимые зебры: по светам и по теням.")
        a.toggle("Зебра по светам", "Порог — на вкладке «Монитор» (90 / 95 / 100 %).", { cfg.zebra }) { cfg.zebra = it; apply() }
        a.toggle("Зебра по теням", "", { cs.b("c26_zlo_on") }) { put("c26_zlo_on", it) }
        num(z, "Порог теней", "c26_zlo_level"); num(z, "Интенсивность", "c26_z_alpha")
    }
}
