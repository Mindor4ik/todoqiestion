package app.procam

import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Вкладки Computational Imaging v0.27: «Стабилизация 2.0» и «NR и обработка». Каждая настройка связана с реальным алгоритмом. */
internal class CiTabs(private val a: MainActivity) {
    private val ci get() = a.ciSettings
    private val cfg get() = a.engine.cfg
    private fun dp(v: Int) = a.dp(v)
    private fun apply(route: Boolean = false) { if (route) a.engine.procConfigChanged() else a.engine.update() }
    private fun put(k: String, v: Any, route: Boolean = false) { ci.set(k, v); apply(route) }
    private fun fmt(v: Float) = if (kotlin.math.abs(v) >= 100f) "%.0f".format(v) else "%.3f".format(v).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    private fun num(box: LinearLayout, label: String, key: String, route: Boolean = false) {
        val r = CiKeys.rules[key] as Rule.FloatR
        val row = LinearLayout(a); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(a); t.text = label; t.textSize = 12f; t.setTextColor(Ui.text)
        row.addView(t, LinearLayout.LayoutParams(dp(120), a.WRAP))
        val sb = SeekBar(a); sb.max = 1000
        val ed = EditText(a); ed.textSize = 12f; ed.setTextColor(Ui.text); ed.setSingleLine()
        ed.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        ed.imeOptions = EditorInfo.IME_ACTION_DONE
        fun show() { val v = ci.f(key); sb.progress = ((v - r.min) / (r.max - r.min) * 1000).toInt().coerceIn(0, 1000); ed.setText(fmt(v)) }
        show()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { val v = r.min + (r.max - r.min) * p / 1000f; ed.setText(fmt(v)); put(key, v, route) } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        ed.setOnEditorActionListener { _, _, _ -> ed.text.toString().replace(',', '.').toFloatOrNull()?.let { put(key, it, route) }; show(); false }
        row.addView(sb, LinearLayout.LayoutParams(0, a.WRAP, 1f))
        row.addView(ed, LinearLayout.LayoutParams(dp(78), a.WRAP))
        box.addView(row)
    }

    private fun ib(k: String, opts: List<String>, title: String, desc: String, route: Boolean = false, note: () -> String = { "" }) =
        a.seg(title, desc, opts, { ci.i(k) }, note) { put(k, it, route); a.showTab(a.menuTab, true) }
    private fun tg(k: String, title: String, desc: String, route: Boolean = false) = a.toggle(title, desc, { ci.b(k) }) { put(k, it, route); a.showTab(a.menuTab, true) }

    private fun note(box: LinearLayout, text: String) {
        val t = TextView(a); t.text = text; t.textSize = 11f; t.setTextColor(a.amber); box.addView(t)
    }

    /** Подразделы внутри большой вкладки: выбранный запоминается на время работы приложения. Возвращает номер выбранного. */
    private fun subTabs(tab: Int, names: List<String>): Int {
        val cur = (a.subPage[tab] ?: 0).coerceIn(0, names.size - 1)
        val box = a.card("Подраздел: ${names[cur]}", "В этой вкладке много настроек, поэтому они разложены по подразделам.")
        for (chunk in names.withIndex().chunked(3)) {
            val r = LinearLayout(a); r.orientation = LinearLayout.HORIZONTAL
            for ((i, n) in chunk) {
                val b = a.flatButton(n, 12f); a.segStyle(b, i == cur)
                b.setOnClickListener { a.subPage[tab] = i; a.showTab(tab, false) }
                r.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(1)) })
            }
            box.addView(r, LinearLayout.LayoutParams(a.MATCH, a.WRAP))
        }
        return cur
    }

    fun buildStabilization() {
        val gyroOk = a.engine.gyroAvailable()
        val sub = subTabs(Tabs.STAB, listOf("Уровень и вид", "Источник и сила", "Кроп", "Frame Lock", "Rolling shutter и горизонт", "Синхронизация"))
        if (sub == 0) {
            a.seg("Стабилизация по гироскопу",
                "Электронная стабилизация по данным гироскопа (как в Gyroflow, но сразу при съёмке): кадр сдвигается и поворачивается так, чтобы убрать тряску рук. Платите кропом: слабая ≈ 7 %, средняя ≈ 15 %, сильная ≈ 25 %, максимальная ≈ 30 % картинки по краям; чем выше уровень, тем плавнее, но тем медленнее камера «догоняет» ваши намеренные движения. Встроенная стабилизация и OIS камеры на это время выключаются. Rolling shutter компенсируется по времени считывания, которое отдаёт камера (если отдаёт); искажения объектива не компенсируются. Точные настройки, оптический поток и динамический кроп — на вкладке «Стабилизация 2.0».",
                listOf("Выкл", "Слабая", "Средняя", "Сильная", "Максимум"), { cfg.eis },
                {
                    if (!a.engine.gyroAvailable()) "Гироскопа нет: стабилизация пойдёт по оптическому потоку (подробности — подраздел «Источник и сила»)"
                    else if (cfg.eis > 0 && a.engine.caps?.timestampRealtime == false) "Камера не отдаёт метки времени в общей шкале с гироскопом — синхронизация приблизительная, подстройте её ниже"
                    else if (cfg.eis > 0 && cfg.mode == Mode.HLG) "Для программной обработки HLG записывается в режиме эмуляции"
                    else ""
                }) { i -> a.setEis(i) }
            a.seg("Вид стабилизации",
                "Сглаживание — убирает тряску, но наклон кадра сохраняется (камера может «завалиться» вместе с рукой). Блокировка горизонта — кроме тряски выравнивает крен: горизонт остаётся ровным даже при наклоне телефона. Нужен больший кроп (+10 %), иначе в кадр попадут края: поэтому наклон компенсируется только в пределах запаса.",
                listOf("Сглаживание", "Блокировка горизонта"), { if (cfg.eisHorizon) 1 else 0 },
                {
                    if (cfg.eisHorizon && !a.engine.horizonAvailable()) "В телефоне нет акселерометра — горизонт определить нечем"
                    else if (cfg.eisHorizon && cfg.eis > 0) "Наклон компенсируется до ≈ " + listOf("", "5°", "7°", "10°", "12°")[cfg.eis.coerceIn(0, 4)] + " (кроп увеличен на 10 %)"
                    else if (cfg.eisHorizon) "Включите уровень стабилизации выше"
                    else ""
                }) { i -> a.setEisHorizon(i == 1) }
            a.seg("Рамка активной области",
                "Когда стабилизация включена, превью показывает весь кадр с камеры, а рамка обозначает часть, которая попадёт в видео (вне рамки затемнено). Статичная — просто показывает величину кропа. Живая — рамка двигается и поворачивается вместе со стабилизацией, так видно, как она работает и когда упирается в край. Выкл — превью показывает итоговую (обрезанную) картинку.",
                listOf("Выкл", "Статичная", "Живая"), { cfg.eisFrame }) { i -> a.setEisFrame(i) }
            a.card("Что важно знать",
                "Лучше всего работает при выдержке не длиннее 1/60 с и достаточном свете: размытие от движения электронная стабилизация не убирает. " +
                    "Стабилизация и программное шумоподавление работают в режимах SDR, LOG и эмулируемого HLG; нативный 10-bit HLG10 при их включении не используется. " +
                    "Включение и выключение перезапускает камеру, поэтому во время записи недоступно.")
    val rc = a.card("Сброс", "Возвращает точные настройки стабилизации (источник, сила, кроп, Frame Lock, rolling shutter, горизонт) к значениям по умолчанию. Уровень стабилизации не меняется.")
    val rb = a.flatButton("Сбросить точные настройки стабилизации", 13f); a.segStyle(rb, false)
    rb.setOnClickListener { ci.reset(CiKeys.rules.keys.filter { it.startsWith("ci_") && !it.startsWith("ci_nr") && !it.startsWith("ci_ll") && it != "ci_proc" && it != "ci_an_w" && it != "ci_an_div" && it != "ci_diag" }); apply(true); a.showTab(a.menuTab, true) }
    rc.addView(rb, LinearLayout.LayoutParams(a.MATCH, dp(40)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
        }
        if (sub == 1) {
            ib("ci_src", listOf("Авто", "Гироскоп", "Оптический поток"), "Источник движения",
                "Авто: гироскоп, если он есть и отдаёт данные, иначе оптический поток. Гироскоп точнее и почти не грузит процессор. Оптический поток работает на любом телефоне, но грузит CPU и хуже на однотонных сценах и при сильных рывках. Встроенная стабилизация и OIS на это время выключаются.",
                route = true, note = { if (!gyroOk) "В этом телефоне нет гироскопа — будет оптический поток" else "" })
            val st = a.card("Сила и характер", "Сила < 1 — частичная коррекция; > 1 — длиннее окно сглаживания (медленнее реагирует на ваши движения). Характер: слева — естественное движение, справа — максимально устойчивая картинка.")
            num(st, "Сила", "ci_strength"); num(st, "Характер", "ci_char")
            tg("ci_adapt", "Адаптивное окно", "Окно сглаживания сжимается при намеренном движении (поворот, ходьба) и растягивается в покое: меньше лага и меньше лишнего кропа при панораме.")
            tg("ci_jump", "Защита от скачков", "Ограничивает резкое изменение коррекции за кадр. Для оптического потока включена всегда: его оценки иногда ошибаются.")
        }
        if (sub == 2) {
            val cr = a.card("Адаптивный кроп", "Кроп — цена стабилизации. «Максимальный кроп» — ваш потолок; −1 = по выбранному уровню. Динамический кроп меняет масштаб по необходимости: растёт быстро, возвращается медленно.")
            num(cr, "Макс. кроп, %", "ci_maxcrop")
            tg("ci_dyncrop", "Динамический кроп", "Пустые края не появляются в любом режиме, кроме «растянуть края».")
            ib("ci_border", listOf("Ограничить коррекцию", "Растянуть края", "Увеличить кроп"), "Обработка границ",
                "Что делать, когда запаса кадра не хватает. «Ограничить» — коррекция урезается, чёрных краёв нет. «Растянуть края» — коррекция полная, но края картинки размазываются (заметно при сильных рывках). «Увеличить кроп» — масштаб растёт выше максимума (до ×4), работает вместе с динамическим кропом; потерю площади видно в диагностике.")
        }
        if (sub == 3) {
            val fl = a.card("Frame Lock", "Замкнутый контур: измеряет остаточную тряску уже стабилизированной картинки и убирает её (в т. ч. «желе»). Намеренные панорамы не трогает. Включается переключателем ниже.")
            a.toggle("Frame Lock", "", { cfg.eisLock }) { cfg.eisLock = it; a.prefs.edit().putBoolean("eis_lock", it).apply(); a.engine.update() }
            num(fl, "Сила", "ci_lock_str"); num(fl, "Плавность", "ci_lock_smooth")
            ib("ci_lock_flow", FlowMethod.values().map { it.label }, "Метод измерения остатка", "Проекции — быстрые и работают как в v0.25 (только сдвиг и сдвиг по третям кадра). Lucas-Kanade и block matching + RANSAC дают сдвиг, поворот и масштаб, отделяют движущиеся объекты, но тяжелее.")
            ib("ci_flow", FlowMethod.values().map { it.label }, "Метод оптического потока", "Для источника «оптический поток», измерения rolling shutter и горизонта по изображению. Проекции дают только сдвиг: для стабилизации по изображению берите Lucas-Kanade или block matching. Переключайте для сравнения.")
        }
        if (sub == 4) {
            val rs = a.card("Rolling shutter", "Коррекция «желе» и наклона вертикалей по времени считывания матрицы. Это время отдаёт Camera2 (если отдаёт); иначе задайте своё или измерьте по изображению.")
            tg("ci_rs", "Компенсация rolling shutter", "")
            num(rs, "Сила, ×", "ci_rs_str"); num(rs, "Своё время, мс", "ci_rs_skew")
            tg("ci_rs_meas", "Измерить время считывания", "Оценивает skew по сдвигам верха и низа кадра при ускорениях камеры (дрожание, резкие движения). Нужны десятки секунд движения. Результат — оценка с надёжностью, а не паспортное значение.", route = false)
            val m = a.engine.rsMeasured()
            if (m != null && ci.b("ci_rs_meas")) {
                val best = if (m.first != null && m.third > 0.5) m.first else if (m.second != null && m.third > 0.5) m.second else null
                note(rs, if (best != null) "Оценка: %.1f мс (надёжность %.0f%%)".format(best, m.third * 100) else "Данных пока недостаточно: подвигайте камерой")
                if (best != null) {
                    val b = a.flatButton("Применить %.1f мс как своё время".format(best), 13f); a.segStyle(b, false)
                    b.setOnClickListener { put("ci_rs_skew", best.toFloat()); a.showTab(a.menuTab, true) }
                    rs.addView(b, LinearLayout.LayoutParams(a.MATCH, dp(40)).apply { setMargins(dp(2), dp(6), dp(2), dp(2)) })
                }
            }
            val hz = a.card("Horizon Lock", "Выравнивание горизонта независимо от силы стабилизации. Источник: акселерометр (измерение) или анализ изображения (оценка по вертикалям и горизонталям сцены; не работает в природе без прямых линий).")
            ib("ci_hz_src", listOf("Авто", "Акселерометр", "Изображение"), "Источник горизонта", "")
            num(hz, "Интенсивность", "ci_hz_str"); num(hz, "Поправка, °", "ci_hz_trim")
            note(hz, if (a.engine.horizonAvailable()) "Акселерометр доступен" else "Акселерометра нет — горизонт только по изображению (оценка)")
        }
        if (sub == 5) {
            val calBox = a.card("Автосинхронизация гироскопа",
                "Стабилизация работает только если время кадра и время гироскопа совпадают с точностью нескольких миллисекунд, а оси гироскопа правильно сопоставлены с осями камеры. " +
                    "Приложение подбирает это само: сравнивает поворот по гироскопу с реальным сдвигом изображения в кадре. Запускается при включении стабилизации; для надёжного результата подвигайте телефон " +
                    "(как при съёмке на ходу), камера должна смотреть на что-то с текстурой — не на гладкую стену и не в темноту.")
            if (a.syncStatus.isNotEmpty()) {
                val st = TextView(a)
                st.text = a.syncStatus
                st.textSize = 11f
                st.setTextColor(a.amber)
                calBox.addView(st)
            }
            val calBtn = a.flatButton("Откалибровать заново", 13f)
            a.segStyle(calBtn, false)
            calBtn.setOnClickListener { a.engine.recalibrate() }
            calBox.addView(calBtn, LinearLayout.LayoutParams(a.MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
            a.seg("Синхронизация гироскопа, мс",
                "Ручная подстройка поверх автосинхронизации: сдвиг времени, по которому берутся данные гироскопа для кадра. Нужна, только если после калибровки кадр «дышит» или тряска не уходит. Положительные значения — более поздние данные гироскопа.",
                a.eisSyncChoices.map { if (it > 0) "+$it" else "$it" }, { a.eisSyncChoices.indexOf(cfg.eisSyncMs) }) { i -> a.setEisSync(a.eisSyncChoices[i]) }
        }
    }

    fun buildNr() {
        val sub = subTabs(Tabs.NR, listOf("Шумоподавление", "Low Light", "Режим обработки", "Диагностика"))
        if (sub == 0) {
            val nr = a.card("Шумоподавление 4.0", "Работает до цвета и LUT, прямо на кадре с камеры: порядок «стабилизация → шумоподавление → цвет → LUT» не нарушается, LOG/HLG и HDR не затрагиваются.")
            val isp = listOf("Авто" to 0, "Выкл" to 1, "Быстрое" to 2, "Высокое" to 3, "Мин." to 4).filter { a.engine.nrIspAvailable(it.second) }
            a.seg("Шумоподавление камеры (ISP)",
                "Штатное шумоподавление процессора камеры — работает при любой записи, нагрузки на GPU нет. «Авто» — как решит телефон; «Высокое» чище, но может смазывать мелкие детали; «Выкл» — максимум деталей и зерна (удобно, если шум чистится потом в монтаже). В списке только то, что умеет выбранный объектив.",
                isp.map { it.first }, { isp.indexOfFirst { it.second == cfg.nrIsp } }) { i -> a.setNrIsp(isp[i].second) }
    a.seg("Быстрый уровень", "Как в v0.25–0.26. Это же значение переключает кнопка NR на панели инструментов. Работает, пока не включены «Расширенные настройки».",
        listOf("Выкл", "Слабое", "Среднее", "Сильное"), { cfg.nrSoft }, { if (ci.b("ci_nr_adv")) "Включены расширенные настройки: быстрый уровень больше не определяет шумоподавление (см. ниже)" else "" }) { i -> a.setNrSoft(i) }
            tg("ci_nr_adv", "Расширенные настройки", "Раздельное управление этапами и силой. Включает шумоподавление независимо от быстрого уровня.", route = true)
            if (ci.b("ci_nr_adv")) {
                tg("ci_nr_spat", "Пространственный этап", "Билатеральный фильтр 3×3 только там, где есть движение: края сохраняются.")
                tg("ci_nr_temp", "Временной этап", "Рекурсивное накопление по кадрам с маской движения и ограничением истории (нет «призраков»).")
                num(nr, "Яркостный шум", "ci_nr_luma"); num(nr, "Цветовой шум", "ci_nr_chroma"); num(nr, "Сохранение деталей", "ci_nr_detail")
            }
            tg("ci_nr_mc", "Компенсация движения истории (экспериментально)", "Сдвигает историю на измеренное глобальное движение кадра (по результатам Frame Lock). Не проверено на устройствах; при ошибке знака сдвига эффект NR просто слабее. Выключено по умолчанию.")
            val np = NrMap.map(ci.nr(cfg.nrSoft, TemporalManager.profileOf(ci.temporal())))
            note(nr, if (np != null) "Накопление на статике ≈ %.0f кадров, пространственный вес %.2f, порог движения %.1fσ".format(np.effectiveFrames(), np.wSpat, np.k) else "Шумоподавление выключено")
        }
        if (sub == 1) {
            val ll = a.card("Low Light", "Отдельный режим для тёмных сцен: сильнее и яркостный, и цветовой шум, шумовая модель ожидает больше шума, пространственный вес ограничен (нет «пластика»). Яркость НЕ поднимается и чувствительность сенсора не растёт — подавляется шум, а не добавляются детали. На движущихся объектах деталей будет меньше; это видно на картинке и в диагностике.")
            tg("ci_ll", "Low Light", "Работает и при выключенном обычном NR.", route = true)
            num(ll, "Сила", "ci_ll_str")
            note(ll, "Многокадровое накопление здесь рекурсивное: без дополнительной задержки видео, но на быстром движении оно сбрасывается маской.")
        }
        if (sub == 2) {
            val pf = a.card("Режим обработки и производительность", "Режимы меняют алгоритмы анализа и глубину накопления, а НЕ разрешение, FPS и битрейт записи. Ничего не отключается автоматически: если телефон не тянет, кадры могут теряться — смотрите «потеряно кадров» в диагностике и снижайте режим или частоту анализа сами.")
            ib("ci_proc", listOf("Low Latency", "Balanced", "Maximum Quality"), "Режим", "Low Latency: меньше точек и итераций, анализ через кадр, короче накопление. Balanced: баланс. Maximum Quality: больше точек и пирамида глубже, шире окно «в будущее» гироскопа, глубже накопление NR — выше нагрузка и нагрев.")
            ib("ci_an_w", listOf("Из режима", "96 px", "128 px", "160 px", "192 px"), "Разрешение анализа", "Ширина кадра для оптического потока и горизонта. Больше — точнее, но дороже (CPU и чтение кадра с GPU).")
            ib("ci_an_div", listOf("Из режима", "Каждый кадр", "Каждый 2-й", "Каждый 3-й", "Каждый 4-й", "5-й", "6-й", "7-й", "8-й"), "Частота анализа", "Для источника «оптический поток» анализ каждый кадр обязателен; редкий анализ относится к измерению rolling shutter и горизонту по изображению.")
        }
        if (sub == 3) {
            val dg = a.card("Диагностика и сравнение", "Оверлей на экране камеры: векторы потока, траектория коррекции, кроп, задержка, FPS, потеря кадров. «Задержка» — время обработки кадра в приложении (CPU + ожидание GPU при чтении кадра), а не полная нагрузка GPU.")
            tg("ci_diag", "Показывать диагностику", "")
            a.toggle("До / После (превью)", "Превью показывает исходный кадр камеры без стабилизации и шумоподавления. В файл не влияет, не сохраняется.", { ci.compare }) { ci.compare = it; apply() }
            val rb = a.flatButton("Сбросить NR и обработку", 13f); a.segStyle(rb, false)
            rb.setOnClickListener { ci.reset(CiKeys.rules.keys.filter { it.startsWith("ci_nr") || it.startsWith("ci_ll") || it == "ci_proc" || it == "ci_an_w" || it == "ci_an_div" || it == "ci_diag" }); apply(true); a.showTab(a.menuTab, true) }
            dg.addView(rb, LinearLayout.LayoutParams(a.MATCH, dp(40)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
        }
    }
}
