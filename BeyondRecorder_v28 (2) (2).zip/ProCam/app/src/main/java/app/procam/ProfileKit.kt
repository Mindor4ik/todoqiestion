package app.procam

/** Разделы меню: индексы совпадают с MainActivity.tabNames. Один источник правды для поиска, профилей и переходов. */
object Tabs {
    const val RECORD = 0; const val COLOR = 1; const val LUT = 2; const val MONITOR = 3; const val STAB = 4; const val CAMERA = 5
    const val INTERFACE = 6; const val UPDATES = 7; const val ABOUT = 8; const val DIAG = 9; const val SETTINGS = 10
    const val COLORMGMT = 11; const val GRADE = 12; const val ANALYSIS = 13; const val STAB2 = 14; const val NR = 15
    const val NOTIF = 16; const val THEME = 17; const val HOME = 18; const val SEARCH = 19
}

enum class SettingCategory(val label: String) {
    CAMERA("Camera"), IMAGE("Image"), COLOR("Color"), RECORDING("Recording"), AUDIO("Audio"), STABILIZATION("Stabilization"),
    PROCESSING("Processing"), INTERFACE("Interface"), PERFORMANCE("Performance"), STORAGE("Storage"),
    NOTIFICATIONS("Notifications"), DIAGNOSTICS("Diagnostics"), ADVANCED("Advanced")
}

class SettingInfo(val key: String, val title: String, val about: String, val category: SettingCategory, val tab: Int, val effect: String = "")

/** Каталог настроек для поиска: человеческое название, описание, практический эффект, раздел меню, где живёт настоящий элемент управления. */
object SettingsCatalog {
    private fun s(k: String, t: String, a: String, c: SettingCategory, tab: Int, e: String = "") = SettingInfo(k, t, a, c, tab, e)

    private val manual: List<SettingInfo> = listOf(
        s("rec_w", "Разрешение записи", "Ширина кадра видео; пара с высотой.", SettingCategory.RECORDING, Tabs.RECORD, "Больше кадр — больше нагрузка и размер файла"),
        s("rec_h", "Высота кадра записи", "Высота кадра видео.", SettingCategory.RECORDING, Tabs.RECORD),
        s("fps", "Частота кадров", "Кадров в секунду. Значок ⚠ в меню — телефон не заявляет такую частоту для этого размера.", SettingCategory.RECORDING, Tabs.RECORD, "Больше fps — больше нагрузка и нагрев"),
        s("codec", "Кодек", "HEVC (H.265) или AVC (H.264).", SettingCategory.RECORDING, Tabs.RECORD, "HEVC чище при том же битрейте"),
        s("q_preset", "Пресет качества", "Набор битрейта и GOP.", SettingCategory.RECORDING, Tabs.RECORD),
        s("bpp_idx", "Качество (бит на пиксель)", "Битрейт считается от размера кадра и fps.", SettingCategory.RECORDING, Tabs.RECORD, "Выше — меньше артефактов, больше файл"),
        s("q_mode", "Режим битрейта", "VBR / CBR / CQ.", SettingCategory.RECORDING, Tabs.RECORD),
        s("q_kbps", "Битрейт вручную", "кбит/с; 0 — автоматически.", SettingCategory.RECORDING, Tabs.RECORD),
        s("q_gop", "Интервал ключевых кадров (GOP)", "Секунды между ключевыми кадрами.", SettingCategory.RECORDING, Tabs.RECORD),
        s("q_b", "B-кадры", "Включить B-кадры кодека.", SettingCategory.RECORDING, Tabs.RECORD),
        s("q_audio", "Битрейт звука", "кбит/с AAC.", SettingCategory.AUDIO, Tabs.RECORD),
        s("smooth_rec", "Плавный старт записи", "Запись через GL без пересоздания сессии камеры.", SettingCategory.RECORDING, Tabs.CAMERA),
        s("audio_on", "Запись звука", "Включить микрофон.", SettingCategory.AUDIO, Tabs.RECORD),
        s("audio_meter", "Шкалы звука", "L/R, пик в дБ, удержание.", SettingCategory.AUDIO, Tabs.MONITOR),
        s("mode", "Режим SDR / LOG / HLG", "Тип записываемой кривой.", SettingCategory.COLOR, Tabs.COLOR),
        s("curve", "LOG-кривая", "Flat, S-Log3, V-Log, LogC.", SettingCategory.COLOR, Tabs.COLOR),
        s("log_ev", "Яркость LOG", "Усиление по EV для программного LOG.", SettingCategory.COLOR, Tabs.COLOR),
        s("lut_mode", "Режим LUT", "Где применяется LUT: превью, запись или оба.", SettingCategory.COLOR, Tabs.LUT),
        s("lut_in_log", "LUT ожидает LOG", "Применять LUT к LOG-сигналу.", SettingCategory.COLOR, Tabs.LUT),
        s("view_log", "Просмотр LOG / 709", "Показывать превью без цветовой коррекции.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("zebra", "Зебра", "Подсветка пересвета.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("zebra_level", "Уровень зебры", "Порог яркости зебры.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("peaking", "Focus peaking", "Подсветка резких краёв.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("false_color", "False color", "Ложные цвета экспозиции.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("hist", "Гистограмма", "Показывать гистограмму на превью.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("grid", "Сетка композиции", "Тип сетки.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("guide", "Рамка композиции", "Соотношение сторон рамки.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("level", "Электронный уровень", "Горизонт по датчикам.", SettingCategory.IMAGE, Tabs.MONITOR),
        s("gate", "Open Gate", "Весь сенсор, если камера отдаёт кадр шире 16:9.", SettingCategory.CAMERA, Tabs.CAMERA),
        s("prev_turn", "Повернуть превью на 180°", "Меняется только картинка на экране.", SettingCategory.CAMERA, Tabs.INTERFACE),
        s("stab_mode", "Стабилизация камеры (OIS)", "Выкл / OIS / OIS + EIS.", SettingCategory.STABILIZATION, Tabs.STAB),
        s("eis", "Электронная стабилизация", "Сила EIS по гироскопу или оптическому потоку.", SettingCategory.STABILIZATION, Tabs.STAB, "Кадр немного кропается"),
        s("eis_sync", "Сдвиг синхронизации гироскопа", "Миллисекунды; калибруется в «Стабилизации».", SettingCategory.STABILIZATION, Tabs.STAB),
        s("eis_horizon", "Выравнивание горизонта", "Horizon Lock.", SettingCategory.STABILIZATION, Tabs.STAB),
        s("eis_lock", "Frame Lock", "Доводка по изображению.", SettingCategory.STABILIZATION, Tabs.STAB),
        s("eis_frame", "Рамка стабилизации", "Показ области кропа.", SettingCategory.STABILIZATION, Tabs.STAB),
        s("nr_isp", "Шумоподавление камеры (ISP)", "Уровень шумоподавления самой камеры.", SettingCategory.PROCESSING, Tabs.NR),
        s("nr_soft", "Программное шумоподавление", "NR на GPU.", SettingCategory.PROCESSING, Tabs.NR, "Нагружает GPU на каждом кадре"),
        s("ui_style", "Стиль интерфейса", "Material 3, Material или Liquid Glass.", SettingCategory.INTERFACE, Tabs.THEME),
        s("th28_variant", "Тема оформления", "Material, AMOLED, Minimal, Professional, Cinema, Custom.", SettingCategory.INTERFACE, Tabs.THEME),
        s("th28_mode", "Светлая / тёмная тема", "Для Material и Custom; остальные темы тёмные.", SettingCategory.INTERFACE, Tabs.THEME),
        s("th28_dynamic", "Динамические цвета (Material You)", "Цвета из обоев, Android 12+.", SettingCategory.INTERFACE, Tabs.THEME),
        s("th28_seed", "Свой акцентный цвет", "Для темы Custom.", SettingCategory.INTERFACE, Tabs.THEME),
        s("anim28", "Анимации интерфейса", "Выкл — всё переключается мгновенно. Системное «Удалить анимацию» учитывается всегда.", SettingCategory.INTERFACE, Tabs.THEME),
        s("status_log", "Строка состояния", "Журнал действий на превью.", SettingCategory.INTERFACE, Tabs.INTERFACE),
        s("zoom_max", "Максимальный зум", "Предел цифрового зума.", SettingCategory.CAMERA, Tabs.INTERFACE),
        s("perf_mode", "Режим оптимизации", "Performance / Balanced / Quality: только предложения, применяются по вашему согласию.", SettingCategory.PERFORMANCE, Tabs.DIAG),
        s("perf28_mon", "Период мониторинга, мс", "Как часто проверяются температура, память, нагрузка и пороги уведомлений.", SettingCategory.PERFORMANCE, Tabs.NOTIF),
        s(HomeLayouts.ACTIVE, "Раскладка главного экрана", "Какие кнопки быстрого доступа слева, их порядок и прозрачность.", SettingCategory.INTERFACE, Tabs.HOME),
        s(AlertKeys.RETENTION_DAYS, "Срок хранения истории уведомлений, дней", "0 — бессрочно.", SettingCategory.NOTIFICATIONS, Tabs.NOTIF)
    )

    /** Остальные ключи схемы (цветовой конвейер, вычислительная обработка, уведомления) получают записи автоматически. */
    val all: List<SettingInfo> by lazy {
        val known = manual.map { it.key }.toHashSet()
        val auto = ArrayList<SettingInfo>()
        for (k in SettingsSchema.rules.keys) {
            if (k in known) continue
            when {
                k.startsWith("c26_") -> auto.add(SettingInfo(k, "Цвет: $k", "Параметр цветового конвейера (Color Science 2.0).", SettingCategory.COLOR, Tabs.COLORMGMT))
                k.startsWith("ci_") -> auto.add(SettingInfo(k, "Обработка: $k", "Параметр стабилизации, шумоподавления или режима обработки.",
                    if (k.startsWith("ci_nr") || k.startsWith("ci_ll") || k == "ci_proc" || k.startsWith("ci_an") || k == "ci_diag") SettingCategory.PROCESSING else SettingCategory.STABILIZATION,
                    if (k.startsWith("ci_nr") || k.startsWith("ci_ll") || k == "ci_proc" || k.startsWith("ci_an") || k == "ci_diag") Tabs.NR else Tabs.STAB))
                k.startsWith("n28.") -> {
                    val t = AlertType.values().firstOrNull { k.startsWith("n28.${it.name}.") }
                    if (t != null) auto.add(SettingInfo(k, "Уведомление «${t.title}»: ${k.substringAfterLast('.')}", t.about, SettingCategory.NOTIFICATIONS, Tabs.NOTIF))
                }
                else -> auto.add(SettingInfo(k, k, "Параметр приложения.", SettingCategory.ADVANCED, Tabs.SETTINGS))
            }
        }
        manual + auto
    }

    private val byKey: Map<String, SettingInfo> by lazy { all.associateBy { it.key } }
    fun info(key: String): SettingInfo? = byKey[key]

    fun rangeText(key: String): String = when (val r = SettingsSchema.rules[key]) {
        is Rule.IntR -> "${r.min}…${r.max} (по умолчанию ${r.default})"
        is Rule.FloatR -> "${r.min}…${r.max} (по умолчанию ${r.default})"
        is Rule.BoolR -> "вкл / выкл (по умолчанию ${if (r.default) "вкл" else "выкл"})"
        is Rule.TextR -> (r.allowed?.joinToString(" / ") ?: "любой текст") + " (по умолчанию ${r.default})"
        null -> "не ограничено"
    }

    fun valueText(key: String, store: KeyValueStore): String {
        val v = store.all()[key]
        if (v != null) return v.toString().take(60)
        val r = SettingsSchema.rules[key] ?: return "не задано"
        return "${r.default} (по умолчанию)"
    }

    /** Поиск по всем словам запроса (каждое должно встретиться). Совпадение в названии выше, чем в описании. Пустой запрос — пусто. */
    fun search(query: String): List<SettingInfo> {
        val toks = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (toks.isEmpty()) return emptyList()
        return all.mapNotNull { e ->
            val t = e.title.lowercase(); val a = e.about.lowercase(); val k = e.key.lowercase(); val c = e.category.label.lowercase(); val ef = e.effect.lowercase()
            var score = 0
            for (w in toks) {
                score += when {
                    t.contains(w) -> 3
                    k.contains(w) || c.contains(w) -> 2
                    a.contains(w) || ef.contains(w) -> 1
                    else -> return@mapNotNull null
                }
            }
            e to score
        }.sortedByDescending { it.second }.map { it.first }
    }
}

/** Избранные настройки. */
class SettingFavorites(private val store: KeyValueStore) {
    companion object { const val KEY = "s28.fav" }
    fun get(): List<String> = (store.all()[KEY] as? String)?.split(',')?.filter { it.isNotEmpty() && SettingsCatalog.info(it) != null } ?: emptyList()
    fun isFav(k: String) = k in get()
    fun toggle(k: String): Boolean {
        if (SettingsCatalog.info(k) == null) return false
        val cur = get().toMutableList()
        val now = if (k in cur) { cur.remove(k); false } else { cur.add(k); true }
        store.commit(mapOf(KEY to cur.joinToString(",")))
        return now
    }
}

/** История изменений настроек: что, когда и с какого значения на какое. Ведётся по слушателю хранилища (см. MainActivity). */
class SettingHistory(private val store: KeyValueStore) {
    companion object { const val KEY = "s28.hist"; const val MAX = 200 }
    class Row(val atMs: Long, val key: String, val old: String, val new: String)

    private fun fmt(v: Any?): String = v?.toString()?.replace("\t", " ")?.replace("\n", " ")?.take(80) ?: "—"

    /** Какие ключи достойны записи: параметры схемы (без служебных и без самой истории). */
    fun tracked(k: String): Boolean = SettingsCatalog.info(k) != null && k != AlertKeys.HISTORY && !k.endsWith(".seen") && !k.startsWith("s28.") && !k.startsWith("b28")

    fun record(key: String, old: Any?, new: Any?, nowMs: Long = System.currentTimeMillis()) {
        if (!tracked(key) || old == new) return
        val rows = rows().toMutableList()
        rows.add(Row(nowMs, key, fmt(old), fmt(new)))
        while (rows.size > MAX) rows.removeAt(0)
        store.commit(mapOf(KEY to rows.joinToString("\n") { "${it.atMs}\t${Codec28.esc(it.key)}\t${Codec28.esc(it.old)}\t${Codec28.esc(it.new)}" }))
    }

    fun rows(): List<Row> {
        val raw = store.all()[KEY] as? String ?: return emptyList()
        val out = ArrayList<Row>()
        for (l in raw.split('\n')) {
            val p = l.split('\t'); if (p.size < 4) continue
            val t = p[0].toLongOrNull() ?: continue
            out.add(Row(t, Codec28.unesc(p[1]), Codec28.unesc(p[2]), Codec28.unesc(p[3])))
        }
        return out
    }

    fun newestFirst(): List<Row> = rows().asReversed()
    fun clear() { store.commit(emptyMap(), setOf(KEY)) }
}

/** Экспорт и импорт настроек с проверкой: формат, контрольная сумма, диапазоны. Файл применяется целиком или не применяется. */
object SettingsPorter {
    const val KIND_ALL = "settings"
    const val KIND_UI = "ui"
    const val KIND_PRESET = "preset"
    const val KIND_BACKUP = "backup"
    const val BACKUP_KEY = "b28.backup"

    private fun portable(k: String) = (SettingsSchema.rules.containsKey(k) || k == HomeLayouts.ACTIVE || k == SettingFavorites.KEY) && k != "camera_id"

    fun exportAll(store: KeyValueStore, kind: String = KIND_ALL): String =
        Codec28.pack(kind, store.all().filter { portable(it.key) && it.value != null })

    class Report(val applied: Int, val rejected: List<String>, val fatal: String?)

    /** Разбирает и проверяет текст. Если заголовок, сумма или формат неверны — ничего не меняется. */
    fun importAll(store: KeyValueStore, text: String, kind: String = KIND_ALL): Report {
        val u = Codec28.unpack(kind, text)
        if (u.error != null) return Report(0, emptyList(), u.error)
        val ok = LinkedHashMap<String, Any?>(); val bad = ArrayList<String>()
        for ((k, v) in u.values) {
            val r = SettingsSchema.rules[k]
            when {
                r != null -> if (r.ok(v)) ok[k] = v else bad.add("«$k»: значение $v вне допустимого")
                k == HomeLayouts.ACTIVE -> if (v is String && HomeLayouts.decode(v).layout != null) ok[k] = v else bad.add("«$k»: раскладка повреждена")
                k == SettingFavorites.KEY -> if (v is String) ok[k] = v else bad.add("«$k»: неверный тип")
                else -> bad.add("«$k»: неизвестный ключ")
            }
        }
        if (ok.isNotEmpty()) store.commit(ok)
        return Report(ok.size, bad, null)
    }

    /** Резервная копия перед миграцией схемы: при сбое можно вернуть прежние значения. */
    fun backup(store: KeyValueStore) { store.commit(mapOf(BACKUP_KEY to exportAll(store, KIND_BACKUP))) }
    fun hasBackup(store: KeyValueStore) = (store.all()[BACKUP_KEY] as? String)?.isNotEmpty() == true
    fun restoreBackup(store: KeyValueStore): Report {
        val raw = store.all()[BACKUP_KEY] as? String ?: return Report(0, emptyList(), "резервной копии нет")
        return importAll(store, raw, KIND_BACKUP)
    }

    // ---- пресеты съёмки («Camera Profiles»): обмен между устройствами тем же проверяемым контейнером
    fun exportPreset(store: KeyValueStore, name: String): String? {
        val raw = store.all()[SettingsSchema.PRESET_PREFIX + name] as? String ?: return null
        return Codec28.pack(KIND_PRESET, mapOf("name" to name, "data" to raw))
    }

    fun importPreset(store: KeyValueStore, text: String): Pair<String?, String?> {
        val u = Codec28.unpack(KIND_PRESET, text)
        if (u.error != null) return null to u.error
        val name = (u.values["name"] as? String)?.let { HomeLayouts.cleanName(it) }?.takeIf { it.isNotEmpty() } ?: return null to "в файле нет имени пресета"
        val data = u.values["data"] as? String ?: return null to "в файле нет данных пресета"
        for (line in data.split('\n')) {
            if (line.isEmpty()) continue
            val p = line.split('\t')
            if (p.size < 3) return null to "повреждённая строка пресета"
            val v = Codec28.parse(p[1], Codec28.unesc(p[2])) ?: return null to "значение «${Codec28.unesc(p[0])}» не разобрано"
            val r = SettingsSchema.rules[Codec28.unesc(p[0])]
            if (r != null && !r.ok(v)) return null to "значение «${Codec28.unesc(p[0])}» вне допустимого"
        }
        store.commit(mapOf(SettingsSchema.PRESET_PREFIX + name to data))
        return name to null
    }
}

/**
 * Профили интерфейса («UI Profiles»): внешний вид, тема, раскладка. Переключение пишет ТОЛЬКО ключи из [KEYS]:
 * параметры записи, цвета и обработка не затрагиваются по построению (проверяется юнит-тестом).
 */
object UiProfiles {
    val KEYS = setOf("ui_style", "th28_variant", "th28_mode", "th28_dynamic", "th28_seed", "anim28", HomeLayouts.ACTIVE)
    const val PREFIX = "p28.ui."

    class Profile(val name: String, val about: String, val values: Map<String, Any>)

    private fun p(name: String, about: String, variant: ThemeVariant, layout: HomeLayout) = Profile(name, about, linkedMapOf(
        "ui_style" to 2, "th28_variant" to variant.ordinal, "th28_mode" to 0, "th28_dynamic" to false, HomeLayouts.ACTIVE to HomeLayouts.encode(layout)))

    val BUILT_IN: List<Profile> = listOf(
        p("Default Material", "Material 3, стандартная палитра, привычная левая панель из восьми кнопок", ThemeVariant.MATERIAL, HomeLayouts.DEFAULT),
        p("Compact", "Material 3 и короткая левая панель: зебра, LOG, LUT; панель чуть прозрачнее", ThemeVariant.MATERIAL, HomeLayouts.MINIMAL.copy(name = "Compact", railOpacity = 85)),
        p("Professional", "Холодная палитра с высоким контрастом, все инструменты экспозиции на левой панели", ThemeVariant.PROFESSIONAL, HomeLayouts.PROFESSIONAL),
        p("Minimal", "Монохром и три кнопки: ничего лишнего вокруг кадра", ThemeVariant.MINIMAL, HomeLayouts.MINIMAL),
        p("Cinema", "Чёрный фон и янтарный акцент, сетка, уровень, зебра, LOG, LUT, EIS", ThemeVariant.CINEMA, HomeLayouts.CINEMA)
    )

    fun customNames(store: KeyValueStore): List<String> = store.all().keys.filter { it.startsWith(PREFIX) }.map { it.removePrefix(PREFIX) }.sorted()

    /** Применить встроенный профиль. Возвращает записанные ключи (для проверки и для сообщения пользователю). */
    fun apply(store: KeyValueStore, prof: Profile): Set<String> {
        val edits = prof.values.filterKeys { it in KEYS }
        store.commit(edits)
        return edits.keys
    }

    fun applyCustom(store: KeyValueStore, name: String): Boolean {
        val raw = store.all()[PREFIX + name] as? String ?: return false
        val u = Codec28.unpack(KIND_UI_INNER, raw)
        if (u.error != null) return false
        val edits = LinkedHashMap<String, Any?>()
        for ((k, v) in u.values) {
            if (k !in KEYS) continue
            val r = SettingsSchema.rules[k]
            if (r != null && !r.ok(v)) continue
            if (k == HomeLayouts.ACTIVE && !(v is String && HomeLayouts.decode(v).layout != null)) continue
            edits[k] = v
        }
        store.commit(edits)
        return true
    }

    private const val KIND_UI_INNER = "uiprofile"

    fun saveCurrent(store: KeyValueStore, name: String): String? {
        val n = HomeLayouts.cleanName(name); if (n.isEmpty()) return null
        val cur = store.all().filter { it.key in KEYS && it.value != null }
        store.commit(mapOf(PREFIX + n to Codec28.pack(KIND_UI_INNER, cur))); return n
    }

    fun duplicate(store: KeyValueStore, from: String, to: String): Boolean {
        val raw = store.all()[PREFIX + from] as? String ?: return false
        val n = HomeLayouts.cleanName(to); if (n.isEmpty()) return false
        store.commit(mapOf(PREFIX + n to raw)); return true
    }

    fun rename(store: KeyValueStore, from: String, to: String): Boolean {
        if (!duplicate(store, from, to)) return false
        if (HomeLayouts.cleanName(to) != from) store.commit(emptyMap(), setOf(PREFIX + from))
        return true
    }

    fun delete(store: KeyValueStore, name: String) { store.commit(emptyMap(), setOf(PREFIX + name)) }
    fun export(store: KeyValueStore, name: String): String? = (store.all()[PREFIX + name] as? String)?.let { Codec28.pack(SettingsPorter.KIND_UI, mapOf("name" to name, "data" to it)) }

    fun importProfile(store: KeyValueStore, text: String): Pair<String?, String?> {
        val u = Codec28.unpack(SettingsPorter.KIND_UI, text)
        if (u.error != null) return null to u.error
        val name = (u.values["name"] as? String)?.let { HomeLayouts.cleanName(it) }?.takeIf { it.isNotEmpty() } ?: return null to "в файле нет имени профиля"
        val data = u.values["data"] as? String ?: return null to "в файле нет данных профиля"
        val inner = Codec28.unpack(KIND_UI_INNER, data)
        if (inner.error != null) return null to inner.error
        store.commit(mapOf(PREFIX + name to data)); return name to null
    }
}
