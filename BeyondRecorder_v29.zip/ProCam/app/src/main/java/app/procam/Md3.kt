package app.procam

/**
 * Дизайн-токены Material Design 3: цветовые роли, типографика, отступы, формы, возвышение, движение, состояния.
 * Всё здесь — чистые данные и формулы (без android.*), поэтому проверяется юнит-тестами, включая контраст WCAG.
 * Единственный потребитель — [Ui]; экраны не должны хранить собственных цветов и размеров.
 */
class Md3Palette(
    val primary: Int, val onPrimary: Int, val primaryContainer: Int, val onPrimaryContainer: Int,
    val secondary: Int, val onSecondary: Int, val secondaryContainer: Int, val onSecondaryContainer: Int,
    val surface: Int, val onSurface: Int, val surfaceVariant: Int, val onSurfaceVariant: Int,
    val surfaceContainerLow: Int, val surfaceContainer: Int, val surfaceContainerHigh: Int, val surfaceContainerHighest: Int,
    val outline: Int, val outlineVariant: Int,
    val error: Int, val onError: Int, val errorContainer: Int, val onErrorContainer: Int,
    val record: Int,
    val dark: Boolean
)

/** Тональные цвета системы (Material You) для динамической палитры. Заполняется из android.R.color.system_* на Android 12+. */
class Tonal(val a1: IntArray, val a2: IntArray, val n1: IntArray, val n2: IntArray) {
    companion object {
        /** Индексы: 0, 10, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000 */
        const val T0 = 0; const val T10 = 1; const val T50 = 2; const val T100 = 3; const val T200 = 4; const val T300 = 5
        const val T400 = 6; const val T500 = 7; const val T600 = 8; const val T700 = 9; const val T800 = 10; const val T900 = 11; const val T1000 = 12
        const val SIZE = 13
    }
}

enum class ThemeVariant(val label: String, val about: String) {
    MATERIAL("Material", "Стандартная палитра Material 3: тёмная, спокойный синий акцент"),
    AMOLED("AMOLED", "Чисто чёрные поверхности: экономит заряд на OLED и не светит в тёмной сцене"),
    MINIMAL("Minimal", "Монохром без цветного акцента: ничего не отвлекает от кадра"),
    PROFESSIONAL("Professional", "Холодная нейтральная палитра с повышенным контрастом"),
    CINEMA("Cinema", "Чёрный с тёплым янтарным акцентом, как рабочие мониторы кинокамер"),
    CUSTOM("Custom", "Акцентный цвет по вашему выбору, остальное рассчитывается автоматически")
}

object Md3 {
    // ------------------------------------------------------------ палитры

    private val ERR_DARK = intArrayOf(0xFFF2B8B5.toInt(), 0xFF601410.toInt(), 0xFF8C1D18.toInt(), 0xFFF9DEDC.toInt())
    private val ERR_LIGHT = intArrayOf(0xFFB3261E.toInt(), 0xFFFFFFFF.toInt(), 0xFFF9DEDC.toInt(), 0xFF410E0B.toInt())
    private const val REC = 0xFFFF3B30.toInt()

    val DARK = Md3Palette(
        primary = 0xFFA8C7FA.toInt(), onPrimary = 0xFF062E6F.toInt(), primaryContainer = 0xFF0842A0.toInt(), onPrimaryContainer = 0xFFD3E3FD.toInt(),
        secondary = 0xFFC2C7CF.toInt(), onSecondary = 0xFF2B3138.toInt(), secondaryContainer = 0xFF3D4349.toInt(), onSecondaryContainer = 0xFFDEE3EB.toInt(),
        surface = 0xFF131314.toInt(), onSurface = 0xFFE3E3E3.toInt(), surfaceVariant = 0xFF444746.toInt(), onSurfaceVariant = 0xFFC4C7C5.toInt(),
        surfaceContainerLow = 0xFF1B1B1C.toInt(), surfaceContainer = 0xFF1E1F20.toInt(), surfaceContainerHigh = 0xFF282A2C.toInt(), surfaceContainerHighest = 0xFF333537.toInt(),
        outline = 0xFF8E918F.toInt(), outlineVariant = 0xFF444746.toInt(),
        error = ERR_DARK[0], onError = ERR_DARK[1], errorContainer = ERR_DARK[2], onErrorContainer = ERR_DARK[3],
        record = REC, dark = true
    )

    val LIGHT = Md3Palette(
        primary = 0xFF0B57D0.toInt(), onPrimary = 0xFFFFFFFF.toInt(), primaryContainer = 0xFFD3E3FD.toInt(), onPrimaryContainer = 0xFF041E49.toInt(),
        secondary = 0xFF535A63.toInt(), onSecondary = 0xFFFFFFFF.toInt(), secondaryContainer = 0xFFDEE3EB.toInt(), onSecondaryContainer = 0xFF191F26.toInt(),
        surface = 0xFFF8F9FA.toInt(), onSurface = 0xFF1F1F1F.toInt(), surfaceVariant = 0xFFE1E3E1.toInt(), onSurfaceVariant = 0xFF444746.toInt(),
        surfaceContainerLow = 0xFFF1F3F4.toInt(), surfaceContainer = 0xFFECEEF0.toInt(), surfaceContainerHigh = 0xFFE6E8EA.toInt(), surfaceContainerHighest = 0xFFE0E2E4.toInt(),
        outline = 0xFF6F7270.toInt(), outlineVariant = 0xFFC4C7C5.toInt(),
        error = ERR_LIGHT[0], onError = ERR_LIGHT[1], errorContainer = ERR_LIGHT[2], onErrorContainer = ERR_LIGHT[3],
        record = REC, dark = false
    )

    val AMOLED = Md3Palette(
        primary = DARK.primary, onPrimary = DARK.onPrimary, primaryContainer = DARK.primaryContainer, onPrimaryContainer = DARK.onPrimaryContainer,
        secondary = DARK.secondary, onSecondary = DARK.onSecondary, secondaryContainer = 0xFF2A2F35.toInt(), onSecondaryContainer = DARK.onSecondaryContainer,
        surface = 0xFF000000.toInt(), onSurface = 0xFFE9E9E9.toInt(), surfaceVariant = 0xFF2A2B2B.toInt(), onSurfaceVariant = 0xFFC4C7C5.toInt(),
        surfaceContainerLow = 0xFF080808.toInt(), surfaceContainer = 0xFF101011.toInt(), surfaceContainerHigh = 0xFF1A1B1C.toInt(), surfaceContainerHighest = 0xFF242526.toInt(),
        outline = 0xFF8E918F.toInt(), outlineVariant = 0xFF3A3C3B.toInt(),
        error = ERR_DARK[0], onError = ERR_DARK[1], errorContainer = ERR_DARK[2], onErrorContainer = ERR_DARK[3],
        record = REC, dark = true
    )

    val MINIMAL = Md3Palette(
        primary = 0xFFE6E6E6.toInt(), onPrimary = 0xFF1A1A1A.toInt(), primaryContainer = 0xFF3A3A3A.toInt(), onPrimaryContainer = 0xFFF0F0F0.toInt(),
        secondary = 0xFFBDBDBD.toInt(), onSecondary = 0xFF1A1A1A.toInt(), secondaryContainer = 0xFF303030.toInt(), onSecondaryContainer = 0xFFE0E0E0.toInt(),
        surface = 0xFF0B0B0B.toInt(), onSurface = 0xFFEDEDED.toInt(), surfaceVariant = 0xFF333333.toInt(), onSurfaceVariant = 0xFFC2C2C2.toInt(),
        surfaceContainerLow = 0xFF121212.toInt(), surfaceContainer = 0xFF171717.toInt(), surfaceContainerHigh = 0xFF202020.toInt(), surfaceContainerHighest = 0xFF2A2A2A.toInt(),
        outline = 0xFF8C8C8C.toInt(), outlineVariant = 0xFF3A3A3A.toInt(),
        error = ERR_DARK[0], onError = ERR_DARK[1], errorContainer = ERR_DARK[2], onErrorContainer = ERR_DARK[3],
        record = REC, dark = true
    )

    val PROFESSIONAL = Md3Palette(
        primary = 0xFF9ECBFF.toInt(), onPrimary = 0xFF00315C.toInt(), primaryContainer = 0xFF004880.toInt(), onPrimaryContainer = 0xFFD1E4FF.toInt(),
        secondary = 0xFFB9C8DA.toInt(), onSecondary = 0xFF233240.toInt(), secondaryContainer = 0xFF3A4857.toInt(), onSecondaryContainer = 0xFFD5E4F7.toInt(),
        surface = 0xFF0F1114.toInt(), onSurface = 0xFFF1F1F4.toInt(), surfaceVariant = 0xFF3F4650.toInt(), onSurfaceVariant = 0xFFC6CDD6.toInt(),
        surfaceContainerLow = 0xFF161A1E.toInt(), surfaceContainer = 0xFF1B2025.toInt(), surfaceContainerHigh = 0xFF252B31.toInt(), surfaceContainerHighest = 0xFF30373E.toInt(),
        outline = 0xFF909AA5.toInt(), outlineVariant = 0xFF3F4650.toInt(),
        error = ERR_DARK[0], onError = ERR_DARK[1], errorContainer = ERR_DARK[2], onErrorContainer = ERR_DARK[3],
        record = REC, dark = true
    )

    val CINEMA = Md3Palette(
        primary = 0xFFFFB950.toInt(), onPrimary = 0xFF442B00.toInt(), primaryContainer = 0xFF633F00.toInt(), onPrimaryContainer = 0xFFFFDDB1.toInt(),
        secondary = 0xFFDBC3A1.toInt(), onSecondary = 0xFF3D2E15.toInt(), secondaryContainer = 0xFF54442A.toInt(), onSecondaryContainer = 0xFFF8DFBB.toInt(),
        surface = 0xFF050505.toInt(), onSurface = 0xFFEAE6E0.toInt(), surfaceVariant = 0xFF383430.toInt(), onSurfaceVariant = 0xFFCEC6BC.toInt(),
        surfaceContainerLow = 0xFF0D0C0B.toInt(), surfaceContainer = 0xFF151311.toInt(), surfaceContainerHigh = 0xFF201D1A.toInt(), surfaceContainerHighest = 0xFF2B2824.toInt(),
        outline = 0xFF978F85.toInt(), outlineVariant = 0xFF3F3A34.toInt(),
        error = ERR_DARK[0], onError = ERR_DARK[1], errorContainer = ERR_DARK[2], onErrorContainer = ERR_DARK[3],
        record = REC, dark = true
    )

    /** Все статические палитры, для тестов и для выбора. */
    val ALL: Map<String, Md3Palette> = linkedMapOf("DARK" to DARK, "LIGHT" to LIGHT, "AMOLED" to AMOLED, "MINIMAL" to MINIMAL, "PROFESSIONAL" to PROFESSIONAL, "CINEMA" to CINEMA)

    // ------------------------------------------------------------ динамические цвета и Custom

    /** Material You: акцент и нейтрали берутся из обоев/системы (Android 12+). Тональные индексы выбраны по схеме M3 (тёмная: 200/800/700/100). */
    fun dynamic(t: Tonal, dark: Boolean): Md3Palette {
        val e = if (dark) ERR_DARK else ERR_LIGHT
        return if (dark) Md3Palette(
            primary = t.a1[Tonal.T200], onPrimary = t.a1[Tonal.T800], primaryContainer = t.a1[Tonal.T700], onPrimaryContainer = t.a1[Tonal.T100],
            secondary = t.a2[Tonal.T200], onSecondary = t.a2[Tonal.T800], secondaryContainer = t.a2[Tonal.T700], onSecondaryContainer = t.a2[Tonal.T100],
            surface = t.n1[Tonal.T900], onSurface = t.n1[Tonal.T100], surfaceVariant = t.n2[Tonal.T700], onSurfaceVariant = t.n2[Tonal.T200],
            surfaceContainerLow = mix(t.n1[Tonal.T900], t.n1[Tonal.T800], 0.35f), surfaceContainer = mix(t.n1[Tonal.T900], t.n1[Tonal.T800], 0.6f),
            surfaceContainerHigh = t.n1[Tonal.T800], surfaceContainerHighest = mix(t.n1[Tonal.T800], t.n1[Tonal.T700], 0.6f),
            outline = t.n2[Tonal.T400], outlineVariant = t.n2[Tonal.T700],
            error = e[0], onError = e[1], errorContainer = e[2], onErrorContainer = e[3], record = REC, dark = true
        ) else Md3Palette(
            primary = t.a1[Tonal.T600], onPrimary = t.a1[Tonal.T0], primaryContainer = t.a1[Tonal.T100], onPrimaryContainer = t.a1[Tonal.T900],
            secondary = t.a2[Tonal.T600], onSecondary = t.a2[Tonal.T0], secondaryContainer = t.a2[Tonal.T100], onSecondaryContainer = t.a2[Tonal.T900],
            surface = t.n1[Tonal.T10], onSurface = t.n1[Tonal.T900], surfaceVariant = t.n2[Tonal.T100], onSurfaceVariant = t.n2[Tonal.T700],
            surfaceContainerLow = mix(t.n1[Tonal.T10], t.n1[Tonal.T50], 0.4f), surfaceContainer = mix(t.n1[Tonal.T10], t.n1[Tonal.T50], 0.8f),
            surfaceContainerHigh = t.n1[Tonal.T50], surfaceContainerHighest = mix(t.n1[Tonal.T50], t.n1[Tonal.T100], 0.5f),
            outline = t.n2[Tonal.T500], outlineVariant = t.n2[Tonal.T200],
            error = e[0], onError = e[1], errorContainer = e[2], onErrorContainer = e[3], record = REC, dark = false
        )
    }

    /**
     * Своя палитра по одному цвету: оттенок и насыщенность берутся у [seed]. Светлота каждой пары «цвет / текст на нём» подгоняется
     * [fit] так, чтобы контраст был не ниже 4.8:1 при любом оттенке (жёлтый и зелёный при одинаковой светлоте HSL гораздо ярче синего).
     * Проверка: юнит-тест перебирает оттенки; при выборе цвета пользователем контраст не нарушается.
     */
    fun custom(seed: Int, dark: Boolean = true): Md3Palette {
        val hsl = toHsl(seed)
        val s = hsl[1].coerceIn(0.25f, 0.9f)
        val h = hsl[0]
        fun c(l: Float, sat: Float = s) = fromHsl(h, sat.coerceIn(0f, 1f), l)
        val base = if (dark) DARK else LIGHT
        if (dark) {
            val surface = c(0.07f, 0.08f); val sc = c(0.12f, 0.08f); val sch = c(0.16f, 0.08f); val schh = c(0.20f, 0.08f)
            val p0 = c(0.80f); val onP = fit(c(0.16f), p0); val p = fit(p0, sc)
            val onPc = c(0.90f); val pc = fit(c(0.30f), onPc)
            val sec = c(0.78f, s * 0.4f); val onSec = fit(c(0.16f, s * 0.4f), sec)
            val onSc = c(0.90f, s * 0.4f); val sc2 = fit(c(0.28f, s * 0.35f), onSc)
            return Md3Palette(
                primary = p, onPrimary = onP, primaryContainer = pc, onPrimaryContainer = onPc,
                secondary = sec, onSecondary = onSec, secondaryContainer = sc2, onSecondaryContainer = onSc,
                surface = surface, onSurface = fit(c(0.90f, 0.05f), schh), surfaceVariant = c(0.26f, 0.08f), onSurfaceVariant = fit(c(0.78f, 0.06f), sch),
                surfaceContainerLow = c(0.10f, 0.08f), surfaceContainer = sc, surfaceContainerHigh = sch, surfaceContainerHighest = schh,
                outline = fit(c(0.58f, 0.06f), surface, 3.2), outlineVariant = c(0.26f, 0.08f),
                error = base.error, onError = base.onError, errorContainer = base.errorContainer, onErrorContainer = base.onErrorContainer, record = REC, dark = true
            )
        }
        val surface = c(0.97f, 0.12f); val sc = c(0.93f, 0.10f); val sch = c(0.91f, 0.10f); val schh = c(0.89f, 0.10f)
        val onP = c(0.99f, 0.20f); val p = fit(fit(c(0.36f), onP), sc)
        val pc = c(0.90f); val onPc = fit(c(0.12f), pc)
        val onSec = c(0.99f, 0.10f); val sec = fit(c(0.38f, s * 0.4f), onSec)
        val sc2 = c(0.90f, s * 0.35f); val onSc = fit(c(0.13f, s * 0.4f), sc2)
        return Md3Palette(
            primary = p, onPrimary = onP, primaryContainer = pc, onPrimaryContainer = onPc,
            secondary = sec, onSecondary = onSec, secondaryContainer = sc2, onSecondaryContainer = onSc,
            surface = surface, onSurface = fit(c(0.11f, 0.05f), schh), surfaceVariant = c(0.89f, 0.08f), onSurfaceVariant = fit(c(0.28f, 0.06f), sch),
            surfaceContainerLow = c(0.95f, 0.10f), surfaceContainer = sc, surfaceContainerHigh = sch, surfaceContainerHighest = schh,
            outline = fit(c(0.42f, 0.06f), surface, 3.2), outlineVariant = c(0.78f, 0.08f),
            error = base.error, onError = base.onError, errorContainer = base.errorContainer, onErrorContainer = base.onErrorContainer, record = REC, dark = false
        )
    }

    /** Сдвигает светлоту [c] (оттенок и насыщенность сохраняются), пока контраст с [against] не станет не ниже [min]; крайний случай — чёрный или белый. */
    fun fit(c: Int, against: Int, min: Double = 4.8): Int {
        if (contrast(c, against) >= min) return c
        val hsl = toHsl(c)
        var lighten = luminance(c) >= luminance(against)
        // v0.29: если в выбранную сторону целевого контраста не достичь даже белым/чёрным (фон — средне-серый), идём в другую сторону
        if (contrast(if (lighten) 0xFFFFFFFF.toInt() else 0xFF000000.toInt(), against) < min) lighten = !lighten
        var l = hsl[2]
        for (i in 0 until 100) {
            l += if (lighten) 0.01f else -0.01f
            if (l > 1f || l < 0f) break
            val n = fromHsl(hsl[0], hsl[1], l)
            if (contrast(n, against) >= min) return n
        }
        return if (lighten) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
    }

    fun forVariant(v: ThemeVariant, seed: Int): Md3Palette = when (v) {
        ThemeVariant.MATERIAL -> DARK; ThemeVariant.AMOLED -> AMOLED; ThemeVariant.MINIMAL -> MINIMAL
        ThemeVariant.PROFESSIONAL -> PROFESSIONAL; ThemeVariant.CINEMA -> CINEMA; ThemeVariant.CUSTOM -> custom(seed, true)
    }

    // ------------------------------------------------------------ цветовая математика

    fun mix(a: Int, b: Int, f: Float): Int {
        val t = f.coerceIn(0f, 1f)
        fun ch(s: Int) = (((a shr s) and 255) + ((((b shr s) and 255) - ((a shr s) and 255)) * t)).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    private fun lin(c: Int): Double { val s = c / 255.0; return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4) }
    fun luminance(c: Int): Double = 0.2126 * lin((c shr 16) and 255) + 0.7152 * lin((c shr 8) and 255) + 0.0722 * lin(c and 255)

    /** Контраст WCAG 2.x: от 1 до 21. Текст — от 4.5, крупные элементы и обводки — от 3. */
    fun contrast(a: Int, b: Int): Double {
        val la = luminance(a); val lb = luminance(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }

    /** [h 0..360, s 0..1, l 0..1] */
    fun toHsl(c: Int): FloatArray {
        val r = ((c shr 16) and 255) / 255f; val g = ((c shr 8) and 255) / 255f; val b = (c and 255) / 255f
        val mx = maxOf(r, maxOf(g, b)); val mn = minOf(r, minOf(g, b))
        val l = (mx + mn) / 2f
        if (mx == mn) return floatArrayOf(0f, 0f, l)
        val d = mx - mn
        val s = if (l > 0.5f) d / (2f - mx - mn) else d / (mx + mn)
        val h = when (mx) { r -> ((g - b) / d + (if (g < b) 6f else 0f)); g -> (b - r) / d + 2f; else -> (r - g) / d + 4f } * 60f
        return floatArrayOf(h, s, l)
    }

    fun fromHsl(h: Float, s: Float, l: Float): Int {
        val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
        val p = 2f * l - q
        fun k(t0: Float): Float {
            var t = t0; if (t < 0f) t += 1f; if (t > 1f) t -= 1f
            return when { t < 1f / 6f -> p + (q - p) * 6f * t; t < 0.5f -> q; t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f; else -> p }
        }
        val hh = (((h % 360f) + 360f) % 360f) / 360f
        fun b8(v: Float) = Math.round(v.coerceIn(0f, 1f) * 255f)
        return (0xFF shl 24) or (b8(k(hh + 1f / 3f)) shl 16) or (b8(k(hh)) shl 8) or b8(k(hh - 1f / 3f))
    }

    // ------------------------------------------------------------ типографика, отступы, формы, возвышение, движение, состояния

    /** Размеры в sp. Не мельче 11 sp: как и в прежних версиях, мелкий текст на превью нечитаем. */
    object Type { const val TITLE_LARGE = 22f; const val TITLE_MEDIUM = 16f; const val BODY_LARGE = 16f; const val BODY_MEDIUM = 14f
        const val LABEL_LARGE = 14f; const val LABEL_MEDIUM = 12f; const val LABEL_SMALL = 11f }

    /** Отступы, dp (сетка 4). */
    object Space { const val XS = 4; const val S = 8; const val M = 12; const val L = 16; const val XL = 24; const val XXL = 32 }

    /** Радиусы скруглений, dp. */
    object Shape { const val XS = 4f; const val S = 8f; const val M = 12f; const val L = 16f; const val XL = 28f; const val FULL = 999f }

    /** Возвышение, dp (уровни 0–5 из M3). */
    object Elevation { val LEVELS = floatArrayOf(0f, 1f, 3f, 6f, 8f, 12f) }

    /** Длительности движения, мс. «Эмфазизированные» кривые лежат в [Ease]. */
    object Motion { const val SHORT = 120L; const val MEDIUM = 240L; const val LONG = 360L }

    /** Прозрачности состояний компонентов (M3 state layers). */
    object State { const val HOVER = 0.08f; const val FOCUS = 0.10f; const val PRESSED = 0.10f; const val DRAGGED = 0.16f; const val DISABLED = 0.38f }

    /** Границы контраста: текст — 4.5, графика — 3. */
    const val TEXT_CONTRAST = 4.5
    const val UI_CONTRAST = 3.0

    /** Пары «цвет текста / цвет под ним», которые обязаны давать контраст текста; используются тестом. */
    fun textPairs(p: Md3Palette): List<Triple<String, Int, Int>> = listOf(
        Triple("onSurface/surface", p.onSurface, p.surface), Triple("onSurface/surfaceContainer", p.onSurface, p.surfaceContainer),
        Triple("onSurface/surfaceContainerHigh", p.onSurface, p.surfaceContainerHigh), Triple("onSurface/surfaceContainerHighest", p.onSurface, p.surfaceContainerHighest),
        Triple("onSurfaceVariant/surfaceContainer", p.onSurfaceVariant, p.surfaceContainer), Triple("onSurfaceVariant/surfaceContainerHigh", p.onSurfaceVariant, p.surfaceContainerHigh),
        Triple("onSurfaceVariant/surface", p.onSurfaceVariant, p.surface),
        Triple("onPrimary/primary", p.onPrimary, p.primary), Triple("onPrimaryContainer/primaryContainer", p.onPrimaryContainer, p.primaryContainer),
        Triple("onSecondary/secondary", p.onSecondary, p.secondary), Triple("onSecondaryContainer/secondaryContainer", p.onSecondaryContainer, p.secondaryContainer),
        Triple("onError/error", p.onError, p.error), Triple("onErrorContainer/errorContainer", p.onErrorContainer, p.errorContainer),
        Triple("primary/surfaceContainer", p.primary, p.surfaceContainer)
    )
}
