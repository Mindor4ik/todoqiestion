package app.procam

import android.content.SharedPreferences
import android.util.Size

/** Хранилище ключ-значение: на устройстве — SharedPreferences, в тестах — память. */
interface KeyValueStore {
    fun all(): Map<String, Any?>
    /** Атомарно: записать [edits] и удалить [removes]. */
    fun commit(edits: Map<String, Any?>, removes: Set<String> = emptySet())
}

class PrefsStore(private val sp: SharedPreferences) : KeyValueStore {
    override fun all(): Map<String, Any?> = sp.all
    override fun commit(edits: Map<String, Any?>, removes: Set<String>) {
        val e = sp.edit()
        for (k in removes) e.remove(k)
        for ((k, v) in edits) when (v) {
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is Long -> e.putLong(k, v)
            is Float -> e.putFloat(k, v)
            is String -> e.putString(k, v)
            else -> {}
        }
        e.apply()
    }
}

class MemStore(initial: Map<String, Any?> = emptyMap()) : KeyValueStore {
    private val m = LinkedHashMap<String, Any?>(initial)
    override fun all(): Map<String, Any?> = LinkedHashMap(m)
    override fun commit(edits: Map<String, Any?>, removes: Set<String>) { removes.forEach { m.remove(it) }; m.putAll(edits) }
}

/** Правило допустимых значений. Границы — только там, где есть техническая причина (формат, размер поля, физика). */
sealed class Rule {
    abstract fun ok(v: Any?): Boolean
    abstract val default: Any
    class IntR(val min: Int, val max: Int, override val default: Int) : Rule() { override fun ok(v: Any?) = v is Int && v in min..max }
    class FloatR(val min: Float, val max: Float, override val default: Float) : Rule() {
        override fun ok(v: Any?) = v is Float && !v.isNaN() && v in min..max
    }
    class BoolR(override val default: Boolean) : Rule() { override fun ok(v: Any?) = v is Boolean }
    class TextR(override val default: String, val allowed: Set<String>? = null) : Rule() {
        override fun ok(v: Any?) = v is String && (allowed == null || v in allowed)
    }
}

object SettingsSchema {
    /** История: 5 — v0.28 (Material 3 по умолчанию для новых установок, ключи th28_*, n28.* уведомлений, l28.* раскладки, s28.* избранное/история); 4 — v0.27; 3 — v0.26 (Color Science 2.0: ключи c26_*, lut_mode 0…3); 0 — до версионирования (v0.1–v0.24); 2 — v0.25 (схема, миграции, пресеты, сохранение параметров съёмки). */
    const val VERSION = 5
    const val KEY_VERSION = "schema"
    const val PRESET_PREFIX = "preset."

    /** Ключи, которые не входят в пресеты: служебные и привязанные к конкретному телефону. */
    fun isPresetExcluded(k: String) = k == KEY_VERSION || k.startsWith(PRESET_PREFIX) || k == "eis_cal_v2" || k == "camera_id" ||
        // v0.28: пресет съёмки не трогает интерфейс, уведомления, раскладки, профили, историю и резервные копии (и наоборот)
        k.startsWith("n28.") || k.startsWith("l28.") || k.startsWith("p28.") || k.startsWith("s28.") || k.startsWith("b28") || k.startsWith("th28_") ||
        k == "ui_style" || k == "anim28" || k == "perf28_mon" || k.startsWith("perf29_")

    /** Что «Сброс настроек» не стирает: пресеты, калибровки, версия схемы, история, резервная копия, пользовательские профили и раскладки. */
    fun isResetProtected(k: String) = k.startsWith(PRESET_PREFIX) || k == KEY_VERSION || k == "eis_cal_v2" ||
        k == AlertKeys.HISTORY || k.startsWith("p28.") || k.startsWith(HomeLayouts.CUSTOM_PREFIX) || k.startsWith("s28.") || k.startsWith("b28") || k.startsWith("perf29_")

    val rules: Map<String, Rule> = linkedMapOf(
        // уже существовавшие
        "lut_mode" to Rule.IntR(0, 3, 1), "lut_in_log" to Rule.BoolR(true), "gate" to Rule.BoolR(false),
        "log_ev" to Rule.IntR(0, 3, 1), "nr_isp" to Rule.IntR(0, 4, 0), "nr_soft" to Rule.IntR(0, 3, 0),
        "eis" to Rule.IntR(0, 4, 0), "eis_sync" to Rule.IntR(-50, 50, 0), "eis_horizon" to Rule.BoolR(false),
        "eis_lock" to Rule.BoolR(true), "eis_frame" to Rule.IntR(0, 2, 2),
        "q_preset" to Rule.IntR(0, 3, 1), "bpp_idx" to Rule.IntR(0, 4, 1), "q_mode" to Rule.IntR(0, 2, 0),
        "q_kbps" to Rule.IntR(0, 2_000_000, 0),          // 0 = авто; потолок — 2 Гбит/с, дальше поле кодека не имеет смысла
        "q_gop" to Rule.FloatR(0.04f, 30f, 1f), "q_b" to Rule.BoolR(false), "q_audio" to Rule.IntR(8, 1024, 192),
        "prev_turn" to Rule.BoolR(false), "smooth_rec" to Rule.BoolR(true),
        "ui_style" to Rule.IntR(0, 2, 2), "zoom_max" to Rule.IntR(2, 1000, 30), "grid" to Rule.IntR(0, 20, 1), "guide" to Rule.IntR(0, 20, 0),
        "level" to Rule.BoolR(false), "audio_meter" to Rule.BoolR(true), "status_log" to Rule.BoolR(true),
        // параметры съёмки: до v0.25 после перезапуска сбрасывались
        "rec_w" to Rule.IntR(16, 16384, 3840), "rec_h" to Rule.IntR(16, 16384, 2160), "fps" to Rule.IntR(1, 1000, 30),
        "codec" to Rule.TextR("HEVC", setOf("HEVC", "AVC")), "mode" to Rule.TextR("SDR", setOf("SDR", "LOG", "HLG")),
        "curve" to Rule.TextR("FLAT", setOf("FLAT", "SLOG3", "VLOG", "LOGC")),
        "audio_on" to Rule.BoolR(true), "stab_mode" to Rule.IntR(0, 2, 2),
        "zebra" to Rule.BoolR(false), "zebra_level" to Rule.FloatR(0.3f, 1f, 0.95f), "peaking" to Rule.BoolR(false),
        "false_color" to Rule.BoolR(false), "hist" to Rule.BoolR(true), "view_log" to Rule.BoolR(false),
        "perf_mode" to Rule.IntR(0, 2, 1),
        // v0.28: оформление, анимации, период мониторинга
        "th28_variant" to Rule.IntR(0, 5, 0), "th28_mode" to Rule.IntR(0, 2, 0), "th28_dynamic" to Rule.BoolR(false),
        "th28_seed" to Rule.IntR(Int.MIN_VALUE, Int.MAX_VALUE, 0xFF4F8CFF.toInt()), "anim28" to Rule.BoolR(true),
        "perf28_mon" to Rule.IntR(500, 60_000, 2000),
        // v0.29: результаты теста производительности (свойство конкретного телефона: не входят ни в пресеты, ни в экспорт, ни в сброс)
        "perf29_json" to Rule.TextR(""), "perf29_done" to Rule.BoolR(false), "perf29_skip" to Rule.BoolR(false)
    ) + ColorKeys.rules + CiKeys.rules + AlertKeys.rules
}

/** Центральное управление настройками: миграция, проверка значений, сброс, пользовательские пресеты. */
class SettingsManager(private val store: KeyValueStore) {

    /** Версия схемы, записанная в хранилище (0 — настройки до версионирования). */
    fun storedVersion(): Int = (store.all()[SettingsSchema.KEY_VERSION] as? Int) ?: 0

    /**
     * Приводит хранилище к текущей схеме. Пользовательские значения не удаляются: исправляются только
     * значения, которые невозможно применить (неверный тип / вне допустимого диапазона) — они заменяются значением по умолчанию.
     * Возвращает человекочитаемый журнал изменений.
     */
    fun migrate(): List<String> {
        val log = ArrayList<String>()
        val from = storedVersion()
        if (from > SettingsSchema.VERSION) {
            log.add("Настройки сохранены более новой версией приложения (схема $from) — оставлены без изменений")
            return log
        }
        if (from < 2) {
            // v0 → v2: до этой версии bpp_idx ограничивался 0..2 при чтении, поэтому старые значения валидны;
            // параметры съёмки (разрешение, fps, кодек, режим, кривая) появляются в хранилище впервые.
            log.add("Схема настроек: $from → 2 (ваши значения сохранены)")
        }
        if (from in 1..2) log.add("Схема настроек: $from → 3 (добавлены параметры управления цветом; все ваши значения сохранены)")
        if (from < SettingsSchema.VERSION && store.all().isNotEmpty()) {
            // v0.28: перед изменением схемы остаётся резервная копия прежних значений (Меню → Настройки → «Восстановить»)
            SettingsPorter.backup(store)
            log.add("Схема настроек: $from → ${SettingsSchema.VERSION} (Material 3, уведомления, профили; ваши значения сохранены, резервная копия создана)")
        }
        resolveUiStyle()
        log.addAll(sanitize())
        store.commit(mapOf(SettingsSchema.KEY_VERSION to SettingsSchema.VERSION))
        return log
    }

    /**
     * Стиль интерфейса. Новая установка (пустое хранилище) получает Material 3; уже работавшее приложение остаётся в прежнем стиле
     * (раньше по умолчанию был Liquid Glass) — выбор фиксируется в хранилище, чтобы не «переехать» при следующем запуске.
     */
    fun resolveUiStyle(): Int {
        val all = store.all()
        val v = all["ui_style"]
        if (v is Int && v in 0..2) return v
        val pick = if (all.isEmpty()) 2 else 1
        store.commit(mapOf("ui_style" to pick))
        return pick
    }

    /** Заменяет невозможные значения значением по умолчанию. */
    fun sanitize(): List<String> {
        val log = ArrayList<String>()
        val all = store.all()
        val fix = LinkedHashMap<String, Any?>()
        for ((k, r) in SettingsSchema.rules) {
            if (!all.containsKey(k)) continue
            val v = all[k]
            if (!r.ok(v)) {
                fix[k] = r.default
                log.add("«$k»: значение $v невозможно применить — возвращено ${r.default}")
            }
        }
        if (fix.isNotEmpty()) store.commit(fix)
        return log
    }

    /** Сброс: удаляет все параметры, кроме пресетов, калибровок и служебных ключей. */
    fun resetToDefaults() {
        val rm = store.all().keys.filter { !SettingsSchema.isResetProtected(it) }.toSet()
        store.commit(emptyMap(), rm)
    }

    // ---------------------------------------------------------------- пресеты

    fun presetNames(): List<String> = store.all().keys.filter { it.startsWith(SettingsSchema.PRESET_PREFIX) }
        .map { it.removePrefix(SettingsSchema.PRESET_PREFIX) }.sorted()

    private fun cleanName(n: String) = n.trim().replace(Regex("[\\r\\n\\t]"), " ").take(40)

    /** Сохранить текущие настройки как пресет. Возвращает имя или null, если имя пустое. */
    fun savePreset(name: String): String? {
        val n = cleanName(name)
        if (n.isEmpty()) return null
        val sb = StringBuilder()
        for ((k, v) in store.all()) {
            if (SettingsSchema.isPresetExcluded(k) || v == null) continue
            val t = when (v) { is Boolean -> "b"; is Int -> "i"; is Long -> "l"; is Float -> "f"; is String -> "s"; else -> continue }
            sb.append(esc(k)).append('\t').append(t).append('\t').append(esc(v.toString())).append('\n')
        }
        store.commit(mapOf(SettingsSchema.PRESET_PREFIX + n to sb.toString()))
        return n
    }

    /** Применить пресет: перезаписывает значения из пресета, затем проверяет их. Возвращает число применённых ключей, -1 — пресета нет. */
    fun applyPreset(name: String): Int {
        val raw = store.all()[SettingsSchema.PRESET_PREFIX + name] as? String ?: return -1
        val edits = LinkedHashMap<String, Any?>()
        for (line in raw.split('\n')) {
            if (line.isEmpty()) continue
            val p = line.split('\t')
            if (p.size < 3) continue
            val k = unesc(p[0]); val s = unesc(p[2])
            val v: Any? = try {
                when (p[1]) { "b" -> s.toBooleanStrict(); "i" -> s.toInt(); "l" -> s.toLong(); "f" -> s.toFloat(); "s" -> s; else -> null }
            } catch (e: Exception) { null }
            if (v != null && !SettingsSchema.isPresetExcluded(k)) edits[k] = v
        }
        store.commit(edits)
        sanitize()
        return edits.size
    }

    /** Применить набор изменений (например, принятый совет оптимизации) с проверкой значений. */
    fun applyChanges(changes: Map<String, Any>) { store.commit(changes); sanitize() }

    fun deletePreset(name: String) { store.commit(emptyMap(), setOf(SettingsSchema.PRESET_PREFIX + name)) }

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t")
    private fun unesc(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 'n' -> sb.append('\n'); 't' -> sb.append('\t'); else -> sb.append(s[i + 1]) }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- параметры съёмки <-> Cfg

    /** Сохраняет параметры съёмки, которые раньше не переживали перезапуск. */
    fun saveShooting(c: Cfg) {
        store.commit(linkedMapOf(
            "rec_w" to c.size.width, "rec_h" to c.size.height, "fps" to c.fps,
            "codec" to c.codec.name, "mode" to c.mode.name, "curve" to c.curve.name,
            "audio_on" to c.audio, "stab_mode" to c.stabMode,
            "zebra" to c.zebra, "zebra_level" to c.zebraLevel, "peaking" to c.peaking,
            "false_color" to c.falseColor, "hist" to c.hist, "view_log" to c.viewLog,
            "camera_id" to c.cameraId
        ))
    }

    /** Загружает параметры съёмки; отсутствующие остаются по умолчанию. Недопустимые значения engine.normalize() заменит и сообщит. */
    fun loadShooting(c: Cfg, knownCameraIds: Collection<String>) {
        val a = store.all()
        fun <T> get(k: String, d: T): T {
            val r = SettingsSchema.rules[k]
            val v = a[k]
            @Suppress("UNCHECKED_CAST")
            return if (v != null && r != null && r.ok(v)) v as T else d
        }
        val w = get("rec_w", c.size.width); val h = get("rec_h", c.size.height)
        if (a.containsKey("rec_w") && a.containsKey("rec_h")) c.size = Size(w, h)
        c.fps = get("fps", c.fps)
        c.codec = Codec.values().firstOrNull { it.name == get("codec", c.codec.name) } ?: c.codec
        c.mode = Mode.values().firstOrNull { it.name == get("mode", c.mode.name) } ?: c.mode
        c.curve = Curve.values().firstOrNull { it.name == get("curve", c.curve.name) } ?: c.curve
        c.audio = get("audio_on", c.audio)
        c.stabMode = get("stab_mode", c.stabMode)
        c.zebra = get("zebra", c.zebra); c.zebraLevel = get("zebra_level", c.zebraLevel)
        c.peaking = get("peaking", c.peaking); c.falseColor = get("false_color", c.falseColor)
        c.hist = get("hist", c.hist); c.viewLog = get("view_log", c.viewLog)
        (a["camera_id"] as? String)?.takeIf { it in knownCameraIds }?.let { c.cameraId = it }
    }
}
