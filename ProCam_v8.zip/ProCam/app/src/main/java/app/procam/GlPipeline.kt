package app.procam

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max

/** Параметры шейдера. out: 0 = без обработки, 1 = LOG, 2 = HLG (только для кодера). */
data class GlParams(
    val out: Int = 0,
    val curve: Int = 1,
    val inLog: Boolean = false,      // камера уже отдаёт LOG (аппаратная кривая)
    val inHlg: Boolean = false,      // превью-выход камеры в HLG10
    val viewLog: Boolean = false,    // монитор показывает плоскую LOG-картинку
    val zebra: Boolean = false,
    val zebraLevel: Float = 0.95f,
    val peaking: Boolean = false,
    val falseColor: Boolean = false,
    val hist: Boolean = true,
    val sensorRot: Int = 90,         // SENSOR_ORIENTATION камеры
    val dispRot: Int = 90,           // поворот дисплея (0/90/180/270)
    val lutView: Boolean = false,    // применять LUT в превью (проход 1 и скоуп)
    val lutRec: Boolean = false,     // запекать LUT в запись (проход 0, только GL-маршрут)
    val lutInLog: Boolean = true,    // вход LUT: выбранная LOG-кривая (true) или Rec.709 gamma (false)
    val lutMix: Float = 1f,
    val logGain: Float = 1f,         // 2^EV: предусиление перед LOG-кривой (яркость LOG)
    val eis: Boolean = false,        // электронная стабилизация по гироскопу (проход «до всего»)
    val eisCrop: Float = 1f,         // кроп-запас (1.15 = 15 %)
    val eisFocal: Float = 0f,        // фокусное расстояние, пиксели кадра
    val nr: Int = 0,                 // программное шумоподавление: 0 выкл, 1..3 сила
    val eisFrame: Int = 0            // рамка активной области: 0 выкл, 1 статичная, 2 живая (превью показывает весь кадр)
)

/**
 * Камера -> SurfaceTexture (OES) -> шейдер -> [окно превью] и (опционально) [входная поверхность кодека].
 * Здесь же эмуляция LOG/HLG для телефонов без нативной поддержки и все мониторные ассисты.
 */
class GlPipeline(private val onHistogram: (IntArray) -> Unit) {
    companion object {
        private const val TAG = "ProCamGL"
        const val SW = 128
        const val SH = 72

        private const val VS = """#version 300 es
uniform mat4 uTexMat;
uniform int uRot;   // поворот картинки по часовой стрелке, четверти оборота (0..3)
out vec2 vUv;
void main() {
  vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
  vec2 q = p;
  if (uRot == 1) q = vec2(p.y, -p.x);
  else if (uRot == 2) q = -p;
  else if (uRot == 3) q = vec2(-p.y, p.x);
  gl_Position = vec4(q, 0.0, 1.0);
  vUv = (uTexMat * vec4(p * 0.5 + 0.5, 0.0, 1.0)).xy;
}
"""

        private const val FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp sampler3D;   // в GLSL ES 3.00 у sampler3D НЕТ точности по умолчанию — без этой строки шейдер не соберётся
uniform samplerExternalOES uTex;
uniform sampler3D uLut;
uniform int uLutEnabled;     // LUT включён в текущем проходе
uniform int uLutInLog;       // 1: вход LUT — LOG-кривая uCurve, 0: Rec.709 gamma
uniform float uLutMix;
uniform float uLogGain;      // предусиление сцены перед LOG-кривой
uniform float uLutSize;
uniform vec3 uLutMin;        // DOMAIN_MIN
uniform vec3 uLutScale;      // 1 / (DOMAIN_MAX - DOMAIN_MIN)
uniform int uPass;      // 0 = запись, 1 = превью, 2 = скоуп (гистограмма)
uniform int uOut;       // 0 sdr, 1 log, 2 hlg
uniform int uCurve;     // 0 flat, 1 slog3, 2 vlog, 3 logc
uniform int uInLog;
uniform int uInHlg;
uniform int uViewLog;
uniform int uZebra;
uniform float uZebraLevel;
uniform int uPeak;
uniform int uFalse;
uniform vec2 uTexel;
in vec2 vUv;
out vec4 oColor;

const float L10 = 0.30103;      // log10(2)
const float HLG_WHITE = 0.265;  // сцена-линейный уровень SDR-белого (~203 нит) в HLG
const mat3 TO2020 = mat3(0.6274039, 0.0690973, 0.0163914,
                         0.3292830, 0.9195404, 0.0880133,
                         0.0433131, 0.0113623, 0.8955953);
const mat3 TO709 = mat3(1.6604910, -0.1245505, -0.0181508,
                        -0.5876411, 1.1328999, -0.1005789,
                        -0.0728499, -0.0083494, 1.1187297);

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 srgbDec(vec3 v) { return mix(v / 12.92, pow((v + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), v)); }
vec3 srgbEnc(vec3 l) { l = clamp(l, 0.0, 1.0); return mix(l * 12.92, 1.055 * pow(l, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), l)); }

float logEncC(int c, float x) {
  x = max(x, 0.0);
  if (c == 1) return x >= 0.01125 ? (420.0 + log2((x + 0.01) / 0.19) * L10 * 261.5) / 1023.0
                                  : (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0;
  if (c == 2) return x < 0.01 ? 5.6 * x + 0.125 : 0.241514 * log2(x + 0.00873) * L10 + 0.598206;
  if (c == 3) return x > 0.010591 ? 0.247190 * log2(5.555556 * x + 0.052272) * L10 + 0.385537
                                  : 5.367655 * x + 0.092809;
  return log2(1.0 + 31.0 * x) / 5.0;
}
float logDecC(int c, float y) {
  y = clamp(y, 0.0, 1.0);
  if (c == 1) { float v = y * 1023.0; return v >= 171.2102946929 ? pow(10.0, (v - 420.0) / 261.5) * 0.19 - 0.01
                                                                 : (v - 95.0) * 0.01125 / (171.2102946929 - 95.0); }
  if (c == 2) return y < 0.181 ? (y - 0.125) / 5.6 : pow(10.0, (y - 0.598206) / 0.241514) - 0.00873;
  if (c == 3) return y > 0.149658 ? (pow(10.0, (y - 0.385537) / 0.247190) - 0.052272) / 5.555556
                                  : (y - 0.092809) / 5.367655;
  return (exp2(5.0 * y) - 1.0) / 31.0;
}
// logEnc0 — «чистая» кривая (так её ждут технические LUT); logEnc/logDec — с яркостью LOG (то, что пишется в файл и камеру).
vec3 logEnc0(vec3 l) { return vec3(logEncC(uCurve, l.r), logEncC(uCurve, l.g), logEncC(uCurve, l.b)); }
vec3 logEnc(vec3 l) { return logEnc0(l * uLogGain); }
vec3 logDec(vec3 v) { return vec3(logDecC(uCurve, v.r), logDecC(uCurve, v.g), logDecC(uCurve, v.b)) / uLogGain; }

float hlgOetf(float e) {
  e = clamp(e, 0.0, 1.0);
  return e <= 1.0 / 12.0 ? sqrt(3.0 * e) : 0.17883277 * log(max(12.0 * e - 0.28466892, 1e-6)) + 0.55991073;
}
float hlgInv(float v) {
  v = clamp(v, 0.0, 1.0);
  return v <= 0.5 ? v * v / 3.0 : (exp((v - 0.55991073) / 0.17883277) + 0.28466892) / 12.0;
}

vec3 falseColor(float y) {
  if (y < 0.03) return vec3(0.4, 0.0, 0.6);
  if (y < 0.10) return vec3(0.0, 0.25, 0.95);
  if (y > 0.97) return vec3(1.0, 0.0, 0.0);
  if (y > 0.90) return vec3(1.0, 0.9, 0.0);
  if (y > 0.55 && y < 0.62) return vec3(1.0, 0.55, 0.7);
  if (y > 0.38 && y < 0.48) return vec3(0.0, 0.75, 0.2);
  return vec3(y);
}

vec3 applyLut(vec3 c) {
  vec3 n = clamp((c - uLutMin) * uLutScale, 0.0, 1.0);
  vec3 uv = n * ((uLutSize - 1.0) / uLutSize) + vec3(0.5 / uLutSize);   // центры текселей
  return texture(uLut, uv).rgb;
}

void main() {
  vec3 src = clamp(texture(uTex, vUv).rgb, 0.0, 1.0);
  if (uPass == 0) {
    vec3 lin = srgbDec(src);
    vec3 c = src;
    if (uOut == 1) {
      c = logEnc(lin);
    } else if (uOut == 2) {
      vec3 e = TO2020 * lin * HLG_WHITE;
      c = vec3(hlgOetf(e.r), hlgOetf(e.g), hlgOetf(e.b));
    }
    if (uLutEnabled == 1) {
      vec3 li = (uLutInLog == 1) ? logEnc0(lin) : srgbEnc(lin);
      c = mix(c, applyLut(li), clamp(uLutMix, 0.0, 1.0));
    }
    oColor = vec4(c, 1.0);
    return;
  }
  vec3 lin;
  if (uInLog == 1) {
    lin = logDec(src);
  } else if (uInHlg == 1) {
    vec3 e = vec3(hlgInv(src.r), hlgInv(src.g), hlgInv(src.b)) / HLG_WHITE;
    lin = clamp(TO709 * e, 0.0, 1.0);
  } else {
    lin = srgbDec(src);
  }
  vec3 v = srgbEnc(lin);
  if (uViewLog == 1) v = (uInLog == 1) ? src : logEnc(lin);
  if (uLutEnabled == 1) {
    // Вход LUT один и тот же для превью и записи: LOG-кривая (или 709). Не зависит от режима VIEW.
    vec3 li = (uLutInLog == 1) ? logEnc0(lin) : srgbEnc(lin);
    v = mix(v, applyLut(li), clamp(uLutMix, 0.0, 1.0));
  }
  if (uPass == 1) {
    float y = lum(v);
    if (uFalse == 1) v = falseColor(y);
    if (uPeak == 1) {
      float gx = lum(texture(uTex, vUv + vec2(uTexel.x, 0.0)).rgb) - lum(texture(uTex, vUv - vec2(uTexel.x, 0.0)).rgb);
      float gy = lum(texture(uTex, vUv + vec2(0.0, uTexel.y)).rgb) - lum(texture(uTex, vUv - vec2(0.0, uTexel.y)).rgb);
      if (abs(gx) + abs(gy) > 0.18) v = vec3(1.0, 0.15, 0.15);
    }
    if (uZebra == 1 && y >= uZebraLevel) {
      if (fract((gl_FragCoord.x + gl_FragCoord.y) / 14.0) > 0.5) v = vec3(0.0);
    }
  }
  oColor = vec4(v, 1.0);
}
"""
    }

    private val VS_FRONT = """#version 300 es
uniform int uRot;
out vec2 vQ;
void main() {
  vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
  vec2 q = p;
  if (uRot == 1) q = vec2(p.y, -p.x);
  else if (uRot == 2) q = -p;
  else if (uRot == 3) q = vec2(-p.y, p.x);
  gl_Position = vec4(q, 0.0, 1.0);
  vQ = q;
}
"""

    /**
     * Проход «до всего»: камера (OES) -> [EIS-варп] -> [шумоподавление] -> текстура кадра в ориентации сенсора
     * (ровно то, что без него получает кодер в проходе 0). Дальше обычный шейдер читает уже эту текстуру.
     */
    private val FS_FRONT = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp int;           // иначе uRot (общий с вершинным шейдером) получает разную точность и программа не линкуется
precision highp sampler2D;
uniform samplerExternalOES uTex;
uniform sampler2D uPrev;    // предыдущий обработанный кадр (временное шумоподавление)
uniform mat4 uTexMat;
uniform int uRot;
uniform int uEis;
uniform mat3 uEisR;         // поворот из виртуальной камеры в реальную
uniform vec2 uEisA;         // (W/2, H/2) / (f * crop): выходные клип-координаты -> нормализованные лучи
uniform vec2 uEisB;         // f / (W/2, H/2): нормализованные лучи -> клип-координаты источника
uniform int uNr;            // 0 выкл, 1..3
uniform int uHavePrev;
uniform vec2 uStep;         // один тексель исходного кадра
in vec2 vQ;
out vec4 oColor;

const vec2 K[8] = vec2[8](vec2(1.0, 0.0), vec2(-1.0, 0.0), vec2(0.0, 1.0), vec2(0.0, -1.0),
                          vec2(0.7071, 0.7071), vec2(-0.7071, 0.7071), vec2(0.7071, -0.7071), vec2(-0.7071, -0.7071));

vec2 rotInv(vec2 q) {
  if (uRot == 1) return vec2(-q.y, q.x);
  if (uRot == 2) return -q;
  if (uRot == 3) return vec2(q.y, -q.x);
  return q;
}
vec2 srcUv(vec2 q) { return (uTexMat * vec4(rotInv(q) * 0.5 + 0.5, 0.0, 1.0)).xy; }

void main() {
  vec2 q = vQ;
  if (uEis == 1) {
    vec3 d = vec3(q.x * uEisA.x, -q.y * uEisA.y, 1.0);   // клип (y вверх) -> луч виртуальной камеры (y вниз)
    vec3 s = uEisR * d;                                    // тот же луч в реальной камере
    if (s.z < 0.05) { oColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
    q = vec2(s.x / s.z * uEisB.x, -(s.y / s.z) * uEisB.y);
  }
  vec2 uv = srcUv(q);
  vec3 c = texture(uTex, uv).rgb;
  if (uNr > 0) {
    // пространственный билатеральный фильтр (сохраняет края): 4 соседа на слабом уровне, 8 — на остальных
    float sig = (uNr == 1) ? 0.035 : ((uNr == 2) ? 0.060 : 0.095);
    float inv2 = 1.0 / (2.0 * sig * sig);
    vec2 st = uStep * ((uNr == 3) ? 1.6 : 1.2);
    int taps = (uNr == 1) ? 4 : 8;
    vec3 acc = c;
    float wsum = 1.0;
    for (int i = 0; i < taps; i++) {
      vec3 n = texture(uTex, uv + K[i] * st).rgb;
      vec3 dd = n - c;
      float w = exp(-dot(dd, dd) * inv2);
      acc += n * w;
      wsum += w;
    }
    c = acc / wsum;
    // временной фильтр: подмешиваем прошлый кадр там, где разница мала (движение отсекает подмешивание)
    if (uHavePrev == 1) {
      vec3 pv = texture(uPrev, vQ * 0.5 + 0.5).rgb;
      float diff = length(c - pv);
      float t0 = 0.03 + 0.01 * float(uNr);
      float t1 = 0.10 + 0.04 * float(uNr);
      float wmax = (uNr == 1) ? 0.45 : ((uNr == 2) ? 0.65 : 0.80);
      c = mix(c, pv, wmax * (1.0 - smoothstep(t0, t1, diff)));
    }
  }
  oColor = vec4(c, 1.0);
}
"""

    /** Проба для автосинхронизации: яркость исходного (нестабилизированного) кадра в уменьшенном виде, ориентация сенсора. */
    private val FS_PROBE = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp int;
uniform samplerExternalOES uTex;
uniform mat4 uTexMat;
uniform int uRot;
uniform vec2 uPix;          // один пиксель проб-кадра в клип-координатах
in vec2 vQ;
out vec4 oColor;

vec2 rotInv(vec2 q) {
  if (uRot == 1) return vec2(-q.y, q.x);
  if (uRot == 2) return -q;
  if (uRot == 3) return vec2(q.y, -q.x);
  return q;
}
vec2 srcUv(vec2 q) { return (uTexMat * vec4(rotInv(q) * 0.5 + 0.5, 0.0, 1.0)).xy; }

void main() {
  float s = 0.0;
  for (int j = -2; j <= 2; j++) {
    for (int i = -2; i <= 2; i++) {
      vec3 c = texture(uTex, srcUv(vQ + vec2(float(i), float(j)) * 0.2 * uPix)).rgb;
      s += dot(c, vec3(0.299, 0.587, 0.114));
    }
  }
  s /= 25.0;
  oColor = vec4(s, s, s, 1.0);
}
"""

    /** Основной шейдер для чтения из обычной 2D-текстуры (результат прохода «до всего»); сам FS не меняется. */
    private val FS_2D: String = FS
        .replace("#extension GL_OES_EGL_image_external_essl3 : require\n", "")
        .replace("uniform samplerExternalOES uTex;", "uniform sampler2D uTex;")
        .replace("precision highp sampler3D;", "precision highp sampler3D;\nprecision highp sampler2D;")

    private val thread = HandlerThread("procam-gl").also { it.start() }
    private val handler = Handler(thread.looper)
    @Volatile var params = GlParams()

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var prevSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var encSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var prevW = 1
    private var prevH = 1
    private var encW = 1
    private var encH = 1
    private var st: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private var tex = 0
    private var lutTex = 0
    private var lutSize = 0                                   // только GL-поток
    private var lutMin = floatArrayOf(0f, 0f, 0f)
    private var lutScale = floatArrayOf(1f, 1f, 1f)
    @Volatile private var lutSource: CubeLut? = null          // последний запрошенный LUT (мог прийти до создания GL)
    private var prog = 0
    private var scopeTex = 0
    private var fbo = 0
    private val tm = FloatArray(16)
    private val locs = HashMap<String, Int>()
    private var texel = floatArrayOf(0f, 0f)
    private var lastScope = 0L
    private var encFails = 0

    /** Гироскопический стабилизатор (задаётся движком). */
    @Volatile var stabilizer: GyroStabilizer? = null

    /** Сообщение пользователю из GL-потока (например, программная обработка отключена). */
    var onNotice: ((String) -> Unit)? = null

    /** Углы рамки активной области в долях окна превью (x0,y0 … x3,y3); null — убрать рамку. Вызывается из GL-потока. */
    var onEisFrame: ((FloatArray?) -> Unit)? = null
    private var frameShown = false

    private var srcW = 1
    private var srcH = 1
    private var curProg = 0
    private var progF = 0
    private var prog2D = 0
    private val fTex = IntArray(2)
    private val fFbo = IntArray(2)
    private var fReady = false
    private var frontFailed = false
    private var fIdx = 0
    private var havePrev = false
    private var useFront = false
    private val eisR = FloatArray(9)

    // проба для автосинхронизации
    private var progP = 0
    private var pFbo = 0
    private var pTex = 0
    private val pW = 128
    private var pH = 72
    private var probeBuf: java.nio.ByteBuffer? = null
    private var prevLuma: FloatArray? = null
    private var prevLumaTs = 0L
    private var probeSkip = 0
    private var probeCount = 0
    private var probeFailed = false
    private val ident4 = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    @Volatile private var contentAspect = 16f / 9f   // соотношение сторон кадра (в Open Gate 4:3): превью вписывается без растяжения

    /** Вызывается из GL-потока, если поверхность кодека перестала принимать кадры во время записи. */
    var onEncoderError: (() -> Unit)? = null
    private val px = ByteBuffer.allocateDirect(SW * SH * 4)

    /** Запускается в GL-потоке. ready(поверхность для камеры, активен ли 10-bit, ошибка). */
    fun start(preview: Surface, camW: Int, camH: Int, wantTenBit: Boolean, ready: (Surface?, Boolean, String?) -> Unit) {
        handler.post {
            try {
                var ten = false
                var created = false
                for (t in if (wantTenBit) listOf(true, false) else listOf(false)) {
                    try {
                        initEgl(t)
                        prevSurf = EGL14.eglCreateWindowSurface(dpy, cfg, preview, intArrayOf(EGL14.EGL_NONE), 0)
                        if (prevSurf == EGL14.EGL_NO_SURFACE) throw RuntimeException("eglCreateWindowSurface")
                        if (!EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)) throw RuntimeException("eglMakeCurrent")
                        ten = t
                        created = true
                        break
                    } catch (e: Exception) {
                        Log.w(TAG, "EGL init (10-bit=$t) failed: ${e.message}")
                        releaseEgl()
                    }
                }
                if (!created) throw RuntimeException("не удалось создать EGL")
                EGL14.eglSwapInterval(dpy, 0)
                val sz = IntArray(1)
                EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_WIDTH, sz, 0); prevW = sz[0]
                EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_HEIGHT, sz, 0); prevH = sz[0]
                initGl()
                try { uploadLut(lutSource) } catch (e: Exception) { Log.w(TAG, "LUT upload: ${e.message}") }
                contentAspect = camW.toFloat() / camH
                srcW = camW
                srcH = camH
                val k = max(1f, camW / 1280f)
                texel = floatArrayOf(k / camW, k / camH)
                val s = SurfaceTexture(tex)
                s.setDefaultBufferSize(camW, camH)
                s.setOnFrameAvailableListener({ drawFrame() }, handler)
                st = s
                camSurface = Surface(s)
                ready(camSurface, ten, null)
            } catch (e: Throwable) {
                Log.e(TAG, "start failed", e)
                ready(null, false, e.message)
            }
        }
    }

    fun startEncoding(surface: Surface, w: Int, h: Int) {
        handler.post {
            try {
                encSurf = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
                encW = w
                encH = h
                encFails = 0
                if (encSurf != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)
                    EGL14.eglSwapInterval(dpy, 0)
                    EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                }
            } catch (e: Exception) {
                Log.e(TAG, "startEncoding", e)
                encSurf = EGL14.EGL_NO_SURFACE
            }
        }
    }

    fun stopEncoding(done: () -> Unit) {
        handler.post {
            if (encSurf != EGL14.EGL_NO_SURFACE && dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                EGL14.eglDestroySurface(dpy, encSurf)
            }
            encSurf = EGL14.EGL_NO_SURFACE
            done()
        }
    }

    fun stop() {
        handler.post {
            try {
                st?.setOnFrameAvailableListener(null)
                st?.release(); st = null
                camSurface?.release(); camSurface = null
                releaseEgl()
            } catch (e: Exception) {
                Log.w(TAG, "stop", e)
            }
            thread.quitSafely()
        }
    }

    // ---------------------------------------------------------------- EGL / GL

    private fun initEgl(tenBit: Boolean) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw RuntimeException("eglInitialize")
        cfg = chooseConfig(tenBit)
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        if (ctx == EGL14.EGL_NO_CONTEXT) throw RuntimeException("eglCreateContext (нужен GLES 3.0)")
    }

    private fun chooseConfig(tenBit: Boolean): EGLConfig {
        val bits = if (tenBit) 10 else 8
        val alpha = if (tenBit) 2 else 8
        for (recordable in listOf(true, false)) {
            val a = ArrayList<Int>()
            a.addAll(listOf(EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR))
            a.addAll(listOf(EGL14.EGL_RED_SIZE, bits, EGL14.EGL_GREEN_SIZE, bits, EGL14.EGL_BLUE_SIZE, bits, EGL14.EGL_ALPHA_SIZE, alpha))
            if (recordable) a.addAll(listOf(0x3142, 1)) // EGL_RECORDABLE_ANDROID
            a.add(EGL14.EGL_NONE)
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (EGL14.eglChooseConfig(dpy, a.toIntArray(), 0, cfgs, 0, 1, n, 0) && n[0] > 0 && cfgs[0] != null) return cfgs[0]!!
        }
        throw RuntimeException("нет подходящего EGLConfig (10-bit=$tenBit)")
    }

    private fun releaseEgl() {
        if (dpy != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (encSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, encSurf)
            if (prevSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, prevSurf)
            if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(dpy)
        }
        dpy = EGL14.EGL_NO_DISPLAY; ctx = EGL14.EGL_NO_CONTEXT
        prevSurf = EGL14.EGL_NO_SURFACE; encSurf = EGL14.EGL_NO_SURFACE
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            throw RuntimeException("шейдер: $log")
        }
        return s
    }

    private fun initGl() {
        val vs = compile(GLES30.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, FS)
        prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: ${GLES30.glGetProgramInfoLog(prog)}")
        locs.clear()

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        tex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, tex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glGenTextures(1, t, 0)
        scopeTex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, scopeTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SW, SH, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, scopeTex, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    /**
     * Загрузка .cube в 3D-текстуру (порядок данных как в файле: R быстрее всего).
     * Можно вызывать из любого потока и в любой момент: если GL ещё не создан, LUT подхватит start().
     */
    fun setLut(lut: CubeLut?, done: (String?) -> Unit = {}) {
        lutSource = lut
        handler.post {
            if (dpy == EGL14.EGL_NO_DISPLAY) { done(null); return@post }   // start() загрузит lutSource сам
            try {
                uploadLut(lut)
                done(null)
            } catch (e: Exception) {
                Log.w(TAG, "setLut", e)
                done(e.message ?: "LUT upload error")
            }
        }
    }

    /** Только в GL-потоке с текущим контекстом. При ошибке LUT отключается, а не остаётся «наполовину». */
    private fun uploadLut(lut: CubeLut?) {
        if (lutTex != 0) { GLES30.glDeleteTextures(1, intArrayOf(lutTex), 0); lutTex = 0 }
        lutSize = 0
        if (lut == null) return
        val n = lut.size
        require(n in 2..CubeLutReader.MAX_SIZE && lut.data.size == n * n * n * 3) { "неверные размеры LUT" }

        val fb = ByteBuffer.allocateDirect(lut.data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(lut.data)
        fb.position(0)

        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        val id = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, id)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
        var guard = 0
        while (GLES30.glGetError() != GLES30.GL_NO_ERROR && ++guard < 16) { /* сбросить старые ошибки */ }
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_RGB16F, n, n, n, 0, GLES30.GL_RGB, GLES30.GL_FLOAT, fb)
        val err = GLES30.glGetError()
        if (err != GLES30.GL_NO_ERROR) {
            GLES30.glDeleteTextures(1, ids, 0)
            throw RuntimeException("glTexImage3D: 0x" + Integer.toHexString(err))
        }
        lutTex = id
        lutSize = n
        lutMin = lut.domainMin.copyOf()
        lutScale = FloatArray(3) { 1f / (lut.domainMax[it] - lut.domainMin[it]) }
    }

    private fun loc(name: String) = locs.getOrPut("$curProg/$name") { GLES30.glGetUniformLocation(curProg, name) }

    private fun b(v: Boolean) = if (v) 1 else 0

    /** Матрица SurfaceTexture уже содержит поворот на 90/270 (камера отдаёт кадр, довёрнутый на ориентацию сенсора). */
    private var tmRot = false

    /**
     * Поворот по часовой (в четвертях) для прохода.
     * Превью: кадр «сырого» сенсора нужно повернуть на (S - D); если матрица уже довернула его на S, остаётся -D.
     * Кодер: ему нужен сырой кадр сенсора (метка поворота в MP4 = S - D), поэтому поворот матрицы отменяем.
     */
    private fun rotQuarter(p: GlParams, pass: Int, tmr: Boolean = tmRot): Int {
        val s = p.sensorRot
        val cw = when (pass) {
            0 -> if (tmr) 360 - s else 0
            1 -> s - p.dispRot - (if (tmr) s else 0)
            else -> 0
        }
        return (((cw % 360) + 360) % 360) / 90
    }

    private fun draw(p: GlParams, pass: Int) {
        val use2d = useFront && prog2D != 0 && fReady && !(pass == 1 && p.eis && p.eisFrame > 0)
        curProg = if (use2d) prog2D else prog
        GLES30.glUseProgram(curProg)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        if (use2d) GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fTex[fIdx])
        else GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, lutTex)
        GLES30.glUniform1i(loc("uLut"), 1)
        val lutOn = lutTex != 0 && lutSize > 0 && (if (pass == 0) p.lutRec else p.lutView)
        GLES30.glUniform1i(loc("uLutEnabled"), if (lutOn) 1 else 0)
        GLES30.glUniform1i(loc("uLutInLog"), b(p.lutInLog))
        GLES30.glUniform1f(loc("uLutSize"), max(1, lutSize).toFloat())
        GLES30.glUniform1f(loc("uLutMix"), p.lutMix)
        GLES30.glUniform1f(loc("uLogGain"), p.logGain)
        GLES30.glUniform3f(loc("uLutMin"), lutMin[0], lutMin[1], lutMin[2])
        GLES30.glUniform3f(loc("uLutScale"), lutScale[0], lutScale[1], lutScale[2])
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, if (use2d) ident4 else tm, 0)
        GLES30.glUniform1i(loc("uRot"), rotQuarter(p, pass, tmRot && !use2d))
        GLES30.glUniform1i(loc("uPass"), pass)
        GLES30.glUniform1i(loc("uOut"), p.out)
        GLES30.glUniform1i(loc("uCurve"), p.curve)
        GLES30.glUniform1i(loc("uInLog"), b(p.inLog))
        GLES30.glUniform1i(loc("uInHlg"), b(p.inHlg))
        GLES30.glUniform1i(loc("uViewLog"), b(p.viewLog))
        GLES30.glUniform1i(loc("uZebra"), b(p.zebra))
        GLES30.glUniform1f(loc("uZebraLevel"), p.zebraLevel)
        GLES30.glUniform1i(loc("uPeak"), b(p.peaking))
        GLES30.glUniform1i(loc("uFalse"), b(p.falseColor))
        GLES30.glUniform2f(loc("uTexel"), texel[0], texel[1])
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun drawFrame() {
        val s = st ?: return
        if (dpy == EGL14.EGL_NO_DISPLAY) return
        try {
            s.updateTexImage()
            s.getTransformMatrix(tm)
            tmRot = Math.abs(tm[1]) > Math.abs(tm[0])
            val ts = s.timestamp
            val p = params

            // Проход «до всего» (EIS / шумоподавление). Если ничего не включено или он сломался — всё работает как раньше.
            var front = false
            if (!frontFailed && ((p.eis && stabilizer != null) || p.nr > 0)) {
                front = try {
                    frontPass(p, ts, stabilizer)
                } catch (e: Exception) {
                    Log.e(TAG, "frontPass", e)
                    frontFailed = true
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                    onNotice?.invoke("Шумоподавление/стабилизация отключены: ${e.message}")
                    false
                }
            }
            useFront = front
            if (!front || p.nr == 0) havePrev = false

            // Автосинхронизация гироскопа с видео: пока идёт калибровка, на каждом втором кадре снимаем уменьшенную яркость.
            val cal = stabilizer
            if (cal != null && cal.calibrating && p.eis && !probeFailed) {
                if (SystemClock.elapsedRealtime() - cal.calStartMs > 25_000L) {
                    prevLuma = null
                    cal.failCalibration()
                } else if (++probeSkip >= 2) {
                    probeSkip = 0
                    try {
                        runProbe(p, ts, cal)
                    } catch (e: Exception) {
                        Log.w(TAG, "probe: ${e.message}")
                        probeFailed = true
                        onNotice?.invoke("Автосинхронизация гироскопа недоступна: ${e.message}")
                        cal.failCalibration()
                    }
                }
            } else {
                prevLuma = null
            }
            if (frameShown && !(front && p.eis && p.eisFrame > 0)) {
                frameShown = false
                onEisFrame?.invoke(null)
            }

            if (encSurf != EGL14.EGL_NO_SURFACE) {
                EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)
                GLES30.glViewport(0, 0, encW, encH)
                draw(p, 0)
                EGLExt.eglPresentationTimeANDROID(dpy, encSurf, ts)
                if (!EGL14.eglSwapBuffers(dpy, encSurf)) {
                    // Раньше эта ошибка глоталась: превью живое, а видео в файле обрывалось.
                    if (++encFails == 20) onEncoderError?.invoke()
                } else {
                    encFails = 0
                }
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
            }

            // Буфер превью фиксирован (16:9). Кадр другого формата вписываем по центру, поля — чёрные (не растягиваем).
            GLES30.glViewport(0, 0, prevW, prevH)
            GLES30.glClearColor(0f, 0f, 0f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
            var vw = prevW
            var vh = prevH
            if (prevW.toFloat() / prevH > contentAspect) vw = (prevH * contentAspect).toInt().coerceAtLeast(1)
            else vh = (prevW / contentAspect).toInt().coerceAtLeast(1)
            GLES30.glViewport((prevW - vw) / 2, (prevH - vh) / 2, vw, vh)
            draw(p, 1)
            EGL14.eglSwapBuffers(dpy, prevSurf)

            if (p.hist) {
                val now = SystemClock.uptimeMillis()
                // Скоуп читает пиксели с GPU синхронно — во время записи делаем это реже, чтобы не рвать кадры кодера.
                val every = if (encSurf != EGL14.EGL_NO_SURFACE) 500L else 160L
                if (now - lastScope > every) {
                    lastScope = now
                    scope(p)
                }
            }
            if (front) {
                fIdx = 1 - fIdx           // следующий кадр пишем в другую текстуру, эта станет «предыдущим»
                havePrev = p.nr > 0
            }
        } catch (e: Exception) {
            Log.w(TAG, "drawFrame: ${e.message}")
        }
    }

    private fun linkProgram(vs: Int, fs: Int): Int {
        val pr = GLES30.glCreateProgram()
        GLES30.glAttachShader(pr, vs)
        GLES30.glAttachShader(pr, fs)
        GLES30.glLinkProgram(pr)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(pr, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: ${GLES30.glGetProgramInfoLog(pr)}")
        return pr
    }

    /** Две текстуры кадра (ping-pong) в ориентации сенсора: RGBA16F, если устройство умеет рендерить в неё, иначе RGBA8. */
    private fun makeFrontTargets(): Boolean {
        for (half in listOf(true, false)) {
            var guard = 0
            while (GLES30.glGetError() != GLES30.GL_NO_ERROR && ++guard < 16) { /* сбросить старые ошибки */ }
            GLES30.glGenTextures(2, fTex, 0)
            GLES30.glGenFramebuffers(2, fFbo, 0)
            var ok = true
            for (i in 0..1) {
                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fTex[i])
                if (half) GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA16F, srcW, srcH, 0, GLES30.GL_RGBA, GLES30.GL_HALF_FLOAT, null)
                else GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, srcW, srcH, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fFbo[i])
                GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, fTex[i], 0)
                if (GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) != GLES30.GL_FRAMEBUFFER_COMPLETE) ok = false
            }
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            if (ok && GLES30.glGetError() == GLES30.GL_NO_ERROR) return true
            GLES30.glDeleteFramebuffers(2, fFbo, 0)
            GLES30.glDeleteTextures(2, fTex, 0)
        }
        return false
    }

    private fun ensureFront(): Boolean {
        if (fReady) return true
        if (frontFailed) return false
        try {
            if (srcW.toLong() * srcH > 16_000_000L) throw RuntimeException("кадр ${srcW}×$srcH слишком велик для программной обработки")
            progF = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_FRONT), compile(GLES30.GL_FRAGMENT_SHADER, FS_FRONT))
            prog2D = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS_2D))
            if (!makeFrontTargets()) throw RuntimeException("не удалось создать буферы кадра")
            fReady = true
            return true
        } catch (e: Exception) {
            frontFailed = true
            Log.e(TAG, "front init failed", e)
            onNotice?.invoke("Шумоподавление/стабилизация отключены: ${e.message}")
            return false
        }
    }

    /**
     * Границы записываемого кадра внутри полного исходного кадра: углы выходного прямоугольника через ту же гомографию,
     * что и в шейдере, затем поворот в ориентацию экрана. r == null — статичная рамка (без стабилизации).
     */
    private fun publishFrame(p: GlParams, r: FloatArray?) {
        val cb = onEisFrame ?: return
        val f = p.eisFocal
        val cr = max(p.eisCrop, 1f)
        val ax = (srcW / 2f) / (f * cr)
        val ay = (srcH / 2f) / (f * cr)
        val bx = f / (srcW / 2f)
        val by = f / (srcH / 2f)
        val rot = rotQuarter(p, 1, false)
        val cx = floatArrayOf(-1f, 1f, 1f, -1f)
        val cy = floatArrayOf(-1f, -1f, 1f, 1f)
        val out = FloatArray(8)
        for (k in 0..3) {
            var dx = cx[k] * ax
            var dy = -cy[k] * ay
            var dz = 1f
            if (r != null) {
                val sx = r[0] * dx + r[3] * dy + r[6] * dz     // r — по столбцам: (строка i, столбец j) = r[j * 3 + i]
                val sy = r[1] * dx + r[4] * dy + r[7] * dz
                val sz = r[2] * dx + r[5] * dy + r[8] * dz
                dx = sx; dy = sy; dz = sz
            }
            if (dz < 0.05f) dz = 0.05f
            val qx = dx / dz * bx
            val qy = -(dy / dz) * by
            var ex = qx
            var ey = qy
            when (rot) {          // как вершинный поворот основного шейдера
                1 -> { ex = qy; ey = -qx }
                2 -> { ex = -qx; ey = -qy }
                3 -> { ex = -qy; ey = qx }
            }
            out[k * 2] = (ex + 1f) / 2f
            out[k * 2 + 1] = (1f - ey) / 2f
        }
        cb(out)
        frameShown = true
    }

    private fun ensureProbe(): Boolean {
        if (progP != 0) return true
        pH = Math.round(pW.toDouble() * srcH / srcW).toInt().coerceIn(16, 128)
        val pr = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_FRONT), compile(GLES30.GL_FRAGMENT_SHADER, FS_PROBE))
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        pTex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, pTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, pW, pH, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        pFbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, pFbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, pTex, 0)
        val ok = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        if (!ok) throw RuntimeException("буфер пробы не создан")
        probeBuf = java.nio.ByteBuffer.allocateDirect(pW * pH * 4)
        progP = pr
        return true
    }

    private fun runProbe(p: GlParams, ts: Long, stab: GyroStabilizer) {
        ensureProbe()
        val buf = probeBuf ?: return
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, pFbo)
        GLES30.glViewport(0, 0, pW, pH)
        curProg = progP
        GLES30.glUseProgram(progP)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, tm, 0)
        GLES30.glUniform1i(loc("uRot"), rotQuarter(p, 0))
        GLES30.glUniform2f(loc("uPix"), 2f / pW, 2f / pH)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        buf.clear()
        GLES30.glReadPixels(0, 0, pW, pH, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)

        // glReadPixels отдаёт строки снизу вверх; для оценки сдвига нужно y вниз (как в модели камеры)
        val luma = FloatArray(pW * pH)
        for (y in 0 until pH) {
            val row = (pH - 1 - y) * pW * 4
            for (x in 0 until pW) luma[y * pW + x] = (buf.get(row + x * 4).toInt() and 255) / 255f
        }
        val prev = prevLuma
        if (prev != null) {
            val r = MotionProbe.shift(prev, luma, pW, pH)
            if (r != null && r[2] > 0.3) stab.addMotion(prevLumaTs, ts, r[0], r[1])
        }
        prevLuma = luma
        prevLumaTs = ts
        if (++probeCount % 20 == 0) stab.requestCalibrate(p.eisFocal.toDouble() * pW / srcW)
    }

    private fun frontPass(p: GlParams, ts: Long, stab: GyroStabilizer?): Boolean {
        if (!ensureFront()) return false
        val prevIdx = 1 - fIdx
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fFbo[fIdx])
        GLES30.glViewport(0, 0, srcW, srcH)
        curProg = progF
        GLES30.glUseProgram(progF)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fTex[prevIdx])
        GLES30.glUniform1i(loc("uPrev"), 2)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, tm, 0)
        GLES30.glUniform1i(loc("uRot"), rotQuarter(p, 0))

        val eisOn = p.eis && p.eisFocal > 1f
        GLES30.glUniform1i(loc("uEis"), b(eisOn))
        if (eisOn) {
            // единичная матрица, пока у гироскопа нет данных: кроп-запас применяется всегда, чтобы кадр не «прыгал»
            for (i in 0..8) eisR[i] = if (i % 4 == 0) 1f else 0f
            if (stab != null) {
                stab.onFrameArrival(ts, SystemClock.elapsedRealtimeNanos())
                stab.rotationAt(ts, eisR)
            }
            val f = p.eisFocal
            val cr = max(p.eisCrop, 1f)
            GLES30.glUniformMatrix3fv(loc("uEisR"), 1, false, eisR, 0)
            if (p.eisFrame > 0) publishFrame(p, if (p.eisFrame == 2) eisR else null)
            GLES30.glUniform2f(loc("uEisA"), (srcW / 2f) / (f * cr), (srcH / 2f) / (f * cr))
            GLES30.glUniform2f(loc("uEisB"), f / (srcW / 2f), f / (srcH / 2f))
        }
        GLES30.glUniform1i(loc("uNr"), p.nr)
        GLES30.glUniform1i(loc("uHavePrev"), if (p.nr > 0 && havePrev) 1 else 0)
        GLES30.glUniform2f(loc("uStep"), 1f / srcW, 1f / srcH)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        return true
    }

    private fun scope(p: GlParams) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glViewport(0, 0, SW, SH)
        draw(p, 2)
        px.clear()
        GLES30.glReadPixels(0, 0, SW, SH, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, px)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        val bins = IntArray(64)
        px.rewind()
        for (i in 0 until SW * SH) {
            val r = px.get().toInt() and 255
            val g = px.get().toInt() and 255
            val bl = px.get().toInt() and 255
            px.get()
            val y = 0.2126 * r + 0.7152 * g + 0.0722 * bl
            bins[(y / 4.0).toInt().coerceIn(0, 63)]++
        }
        onHistogram(bins)
    }
}
