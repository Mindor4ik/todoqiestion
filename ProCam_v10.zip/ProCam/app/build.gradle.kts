plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.procam"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.procam"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "0.10"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Зависимостей нет намеренно: только платформенные API (Camera2, MediaCodec, EGL/GLES).
