plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.procam"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.procam"
        minSdk = 26
        targetSdk = 34
        versionCode = 26
        versionName = "0.26"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    testOptions {
        unitTests.isReturnDefaultValues = true   // заглушки android.* не бросают исключение в юнит-тестах
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// В приложении зависимостей нет намеренно: только платформенные API (Camera2, MediaCodec, EGL/GLES).
dependencies {
    testImplementation("junit:junit:4.13.2")   // только юнит-тесты (app/src/test), в APK не попадает
}

