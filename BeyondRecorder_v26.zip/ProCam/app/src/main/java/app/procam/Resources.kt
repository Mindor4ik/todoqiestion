package app.procam

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import java.io.File

/** Снимок нагрузки. null означает «телефон не отдаёт этот показатель» (в диагностике пишется «недоступно»). */
data class ResourceSnapshot(
    /** Загрузка процесса приложения в % ОДНОГО ядра по реальному CPU-времени процесса. */
    val cpuProcessPercentOfCore: Float?,
    /** Загрузка всех ядер системой по /proc/stat (Android 8+ часто закрывает этот файл от приложений). */
    val cpuSystemPercent: Float?,
    val cpuCores: Int,
    val ramAvailMb: Long, val ramTotalMb: Long, val lowMemory: Boolean, val appPssMb: Int?,
    val thermalStatus: Int?, val thermalHeadroom: Float?, val batteryTempC: Float?, val batteryPercent: Int?,
    /** Публичного API загрузки GPU в Android нет. */
    val gpuLoad: Float? = null
) {
    val thermalLabel: String get() = thermalName(thermalStatus)
}

fun thermalName(s: Int?): String = when (s) {
    null -> "недоступно"
    0 -> "норма"
    1 -> "лёгкий нагрев"
    2 -> "умеренный нагрев"
    3 -> "сильный нагрев"
    4 -> "критический"
    5 -> "аварийный"
    6 -> "выключение"
    else -> "статус $s"
}

class ResourceMonitor(private val ctx: Context) {
    private var lastCpuMs = Process.getElapsedCpuTime()
    private var lastWall = SystemClock.elapsedRealtime()
    private var lastSys: Pair<Long, Long>? = null

    fun sample(): ResourceSnapshot {
        val now = SystemClock.elapsedRealtime()
        val cpuMs = Process.getElapsedCpuTime()
        val dw = now - lastWall
        val cpu = if (dw >= 200) ((cpuMs - lastCpuMs) * 100f / dw).also { lastCpuMs = cpuMs; lastWall = now } else null
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val pss = try { Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024 } catch (e: Exception) { null }
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val th = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else null
        val head = if (Build.VERSION.SDK_INT >= 30) try { pm.getThermalHeadroom(10).takeIf { !it.isNaN() } } catch (e: Exception) { null } else null
        val bat: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)?.takeIf { it != Int.MIN_VALUE }?.let { it / 10f }
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)?.takeIf { it >= 0 }
        return ResourceSnapshot(
            cpuProcessPercentOfCore = cpu, cpuSystemPercent = systemCpu(), cpuCores = Runtime.getRuntime().availableProcessors(),
            ramAvailMb = mi.availMem / (1024 * 1024), ramTotalMb = mi.totalMem / (1024 * 1024), lowMemory = mi.lowMemory, appPssMb = pss,
            thermalStatus = th, thermalHeadroom = head, batteryTempC = temp, batteryPercent = lvl
        )
    }

    private fun systemCpu(): Float? = try {
        val l = File("/proc/stat").bufferedReader().use { it.readLine() }
        if (l == null) null else {
        val p = l.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
        val idle = p[3] + p.getOrElse(4) { 0 }
        val total = p.sum()
        val prev = lastSys
        lastSys = idle to total
        if (prev == null || total == prev.second) null else (1f - (idle - prev.first).toFloat() / (total - prev.second)) * 100f
        }
    } catch (e: Exception) { null }
}

// ---------------------------------------------------------------- режимы оптимизации (только предложения)

enum class PerfMode(val label: String, val hint: String) {
    Performance("Performance", "максимальная плавность и минимум нагрева"),
    Balanced("Balanced", "баланс нагрузки и качества"),
    Quality("Quality", "максимум качества изображения")
}

/** Совет: [changes] — изменения в терминах ключей настроек. Применяются ТОЛЬКО после явного согласия пользователя. */
data class Suggestion(val title: String, val why: String, val changes: Map<String, Any> = emptyMap())

data class AdvisorInput(
    val width: Int, val height: Int, val fps: Int, val bitrateKbps: Int, val bppIdx: Int,
    val nrSoft: Int, val eis: Int, val codecHevc: Boolean,
    val thermalStatus: Int?, val lowMemory: Boolean, val droppedVideo: Long, val captureFailed: Long
)

object OptimizationAdvisor {
    fun suggest(mode: PerfMode, i: AdvisorInput): List<Suggestion> {
        val out = ArrayList<Suggestion>()
        val hot = (i.thermalStatus ?: 0) >= 2
        when (mode) {
            PerfMode.Performance -> {
                if (i.fps > 30) out.add(Suggestion("Частота кадров ${i.fps} → 30", "вдвое меньше кадров для обработки и кодирования", mapOf("fps" to 30)))
                if (i.nrSoft > 0) out.add(Suggestion("Выключить программное шумоподавление", "NR v3 нагружает GPU на каждом кадре", mapOf("nr_soft" to 0)))
                if (i.eis > 0) out.add(Suggestion("Выключить электронную стабилизацию (EIS)", "EIS — построчная обработка кадра на GPU", mapOf("eis" to 0)))
                if (i.bppIdx > 2) out.add(Suggestion("Качество → «Высокое»", "меньше битрейт — легче кодеку и накопителю", mapOf("bpp_idx" to 2)))
                if (i.height > 2160) out.add(Suggestion("Разрешение → 4K", "кадр вчетверо меньше 8K", mapOf("rec_w" to 3840, "rec_h" to 2160)))
            }
            PerfMode.Balanced -> {
                if (i.fps > 60) out.add(Suggestion("Частота кадров ${i.fps} → 60", "заметно снижает нагрузку, сохраняя плавность", mapOf("fps" to 60)))
                if (i.nrSoft > 2) out.add(Suggestion("Шумоподавление → средняя сила", "сильный NR заметно греет телефон", mapOf("nr_soft" to 2)))
                if (i.eis > 2) out.add(Suggestion("Стабилизация → средняя", "сильная стабилизация сильнее кропит кадр и грузит GPU", mapOf("eis" to 2)))
                if (hot && i.fps > 30) out.add(Suggestion("Частота кадров ${i.fps} → 30", "телефон уже греется", mapOf("fps" to 30)))
            }
            PerfMode.Quality -> {
                if (i.bppIdx < 3) out.add(Suggestion("Качество → «Максимальное»", "выше битрейт — меньше артефактов в движении и градиентах", mapOf("bpp_idx" to 3)))
                if (!i.codecHevc) out.add(Suggestion("Кодек → HEVC", "при том же битрейте HEVC даёт более чистую картинку, чем H.264", mapOf("codec" to "HEVC")))
                if (i.bitrateKbps in 1 until 50_000) out.add(Suggestion("Битрейт → Авто", "ручной потолок ${i.bitrateKbps / 1000} Мбит/с ограничивает качество", mapOf("q_kbps" to 0)))
            }
        }
        // Предупреждения (без изменений настроек): решение остаётся за пользователем.
        if ((i.thermalStatus ?: 0) >= 3) out.add(Suggestion("⚠ Сильный нагрев телефона", "возможны пропуски кадров и принудительное снижение частот системой; ничего не отключено автоматически"))
        if (i.lowMemory) out.add(Suggestion("⚠ Мало свободной памяти", "система может закрыть приложение; закройте другие программы"))
        if (i.droppedVideo > 0 || i.captureFailed > 0)
            out.add(Suggestion("⚠ Есть пропущенные кадры", "видео: ${i.droppedVideo} (по разрывам времени), камера: ${i.captureFailed} (потерянные кадры Camera2)"))
        return out
    }
}
