package app.procam

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max

/** Параметры шейдера. out: 0 = без обработки, 1 = LOG, 2 = HLG (только для кодера). */
data class GlParams(
    val out: Int = 0,
    val previewTurn180: Boolean = false,   // ручная поправка: превью повернуть на 180°
    val curve: Int = 1,
    val inLog: Boolean = false,      // камера уже отдаёт LOG (аппаратная кривая)
    val inHlg: Boolean = false,      // превью-выход камеры в HLG10
    val viewLog: Boolean = false,    // монитор показывает плоскую LOG-картинку
    val zebra: Boolean = false,
    val zebraLevel: Float = 0.95f,
    val peaking: Boolean = false,
    val falseColor: Boolean = false,
    val hist: Boolean = true,
    val sensorRot: Int = 90,         // SENSOR_ORIENTATION камеры
    val dispRot: Int = 90,           // поворот дисплея (0/90/180/270)
    val lutView: Boolean = false,    // применять LUT в превью (проход 1 и скоуп)
    val lutRec: Boolean = false,     // запекать LUT в запись (проход 0, только GL-маршрут)
    val lutInLog: Boolean = true,    // вход LUT: выбранная LOG-кривая (true) или Rec.709 gamma (false)
    val lutMix: Float = 1f,
    val logGain: Float = 1f,         // 2^EV: предусиление перед LOG-кривой (яркость LOG)
    val eis: Boolean = false,        // электронная стабилизация по гироскопу (проход «до всего»)
    val eisCrop: Float = 1f,         // кроп-запас (1.15 = 15 %)
    val eisFocal: Float = 0f,        // фокусное расстояние, пиксели кадра
    val nr: Int = 0,                 // программное шумоподавление: 0 выкл, 1..3 сила
    val dzoom: Float = 1f,           // цифровой зум сверх аппаратного (кроп центра кадра), 1 = нет
    val cu: ColorUniforms? = null,   // цветовая цепочка v0.26 (null — нейтральная, как v0.25)
    val scopeW: Int = 128, val scopeH: Int = 72, val scopeMs: Long = 160L, val dither: Float = 0f,
    val eisFrame: Int = 0            // рамка активной области: 0 выкл, 1 статичная, 2 живая (превью показывает весь кадр)
)

/**
 * Камера -> SurfaceTexture (OES) -> шейдер -> [окно превью] и (опционально) [входная поверхность кодека].
 * Здесь же эмуляция LOG/HLG для телефонов без нативной поддержки и все мониторные ассисты.
 */
class GlPipeline(private val onHistogram: (IntArray) -> Unit) {
    /** Сырые RGBA-пиксели кадра скоупа (w,h) — для волны/парада/вектороскопа (Scopes.kt). */
    @Volatile var onScopePixels: ((ByteArray, Int, Int) -> Unit)? = null
    companion object {
        private const val TAG = "ProCamGL"
        const val SW = 128
        const val SH = 72
        const val MESH_COLS = 8

        private const val VS = """#version 300 es
uniform mat4 uTexMat;
uniform int uRot;   // поворот картинки по часовой стрелке, четверти оборота (0..3)
out vec2 vUv;
void main() {
  vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
  vec2 q = p;
  if (uRot == 1) q = vec2(p.y, -p.x);
  else if (uRot == 2) q = -p;
  else if (uRot == 3) q = vec2(-p.y, p.x);
  gl_Position = vec4(q, 0.0, 1.0);
  vUv = (uTexMat * vec4(p * 0.5 + 0.5, 0.0, 1.0)).xy;
}
"""

        private const val FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp sampler3D;   // в GLSL ES 3.00 у sampler3D НЕТ точности по умолчанию — без этой строки шейдер не соберётся
uniform samplerExternalOES uTex;
uniform sampler3D uLut;
uniform int uLutEnabled;     // LUT включён в текущем проходе
uniform int uLutInLog;       // 1: вход LUT — LOG-кривая uCurve, 0: Rec.709 gamma
uniform float uLutMix;
uniform float uLogGain;      // предусиление сцены перед LOG-кривой
uniform float uLutSize;
uniform vec3 uLutMin;        // DOMAIN_MIN
uniform vec3 uLutScale;      // 1 / (DOMAIN_MAX - DOMAIN_MIN)
uniform int uPass;      // 0 = запись, 1 = превью, 2 = скоуп (гистограмма)
uniform int uOut;       // 0 sdr, 1 log, 2 hlg
uniform int uCurve;     // 0 flat, 1 slog3, 2 vlog, 3 logc
uniform int uInLog;
uniform int uInHlg;
uniform int uViewLog;
uniform int uZebra;
uniform float uZebraLevel;
uniform int uPeak;
uniform int uFalse;
uniform vec2 uTexel;
in vec2 vUv;
out vec4 oColor;

const float L10 = 0.30103;      // log10(2)
const float HLG_WHITE = 0.265;  // сцена-линейный уровень SDR-белого (~203 нит) в HLG
const mat3 TO2020 = mat3(0.6274039, 0.0690973, 0.0163914,
                         0.3292830, 0.9195404, 0.0880133,
                         0.0433131, 0.0113623, 0.8955953);
const mat3 TO709 = mat3(1.6604910, -0.1245505, -0.0181508,
                        -0.5876411, 1.1328999, -0.1005789,
                        -0.0728499, -0.0083494, 1.1187297);

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 srgbDec(vec3 v) { return mix(v / 12.92, pow((v + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), v)); }
vec3 srgbEnc(vec3 l) { l = clamp(l, 0.0, 1.0); return mix(l * 12.92, 1.055 * pow(l, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), l)); }

float logEncC(int c, float x) {
  x = max(x, 0.0);
  if (c == 1) return x >= 0.01125 ? (420.0 + log2((x + 0.01) / 0.19) * L10 * 261.5) / 1023.0
                                  : (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0;
  if (c == 2) return x < 0.01 ? 5.6 * x + 0.125 : 0.241514 * log2(x + 0.00873) * L10 + 0.598206;
  if (c == 3) return x > 0.010591 ? 0.247190 * log2(5.555556 * x + 0.052272) * L10 + 0.385537
                                  : 5.367655 * x + 0.092809;
  return log2(1.0 + 31.0 * x) / 5.0;
}
float logDecC(int c, float y) {
  y = clamp(y, 0.0, 1.0);
  if (c == 1) { float v = y * 1023.0; return v >= 171.2102946929 ? pow(10.0, (v - 420.0) / 261.5) * 0.19 - 0.01
                                                                 : (v - 95.0) * 0.01125 / (171.2102946929 - 95.0); }
  if (c == 2) return y < 0.181 ? (y - 0.125) / 5.6 : pow(10.0, (y - 0.598206) / 0.241514) - 0.00873;
  if (c == 3) return y > 0.149658 ? (pow(10.0, (y - 0.385537) / 0.247190) - 0.052272) / 5.555556
                                  : (y - 0.092809) / 5.367655;
  return (exp2(5.0 * y) - 1.0) / 31.0;
}
// logEnc0 — «чистая» кривая (так её ждут технические LUT); logEnc/logDec — с яркостью LOG (то, что пишется в файл и камеру).
vec3 logEnc0(vec3 l) { return vec3(logEncC(uCurve, l.r), logEncC(uCurve, l.g), logEncC(uCurve, l.b)); }
vec3 logEnc(vec3 l) { return logEnc0(l * uLogGain); }
vec3 logDec(vec3 v) { return vec3(logDecC(uCurve, v.r), logDecC(uCurve, v.g), logDecC(uCurve, v.b)) / uLogGain; }

float hlgOetf(float e) {
  e = clamp(e, 0.0, 1.0);
  return e <= 1.0 / 12.0 ? sqrt(3.0 * e) : 0.17883277 * log(max(12.0 * e - 0.28466892, 1e-6)) + 0.55991073;
}
float hlgInv(float v) {
  v = clamp(v, 0.0, 1.0);
  return v <= 0.5 ? v * v / 3.0 : (exp((v - 0.55991073) / 0.17883277) + 0.28466892) / 12.0;
}

vec3 falseColor(float y) {
  if (y < 0.03) return vec3(0.4, 0.0, 0.6);
  if (y < 0.10) return vec3(0.0, 0.25, 0.95);
  if (y > 0.97) return vec3(1.0, 0.0, 0.0);
  if (y > 0.90) return vec3(1.0, 0.9, 0.0);
  if (y > 0.55 && y < 0.62) return vec3(1.0, 0.55, 0.7);
  if (y > 0.38 && y < 0.48) return vec3(0.0, 0.75, 0.2);
  return vec3(y);
}

vec3 applyLut(vec3 c) {
  vec3 n = clamp((c - uLutMin) * uLutScale, 0.0, 1.0);
  vec3 uv = n * ((uLutSize - 1.0) / uLutSize) + vec3(0.5 / uLutSize);   // центры текселей
  return texture(uLut, uv).rgb;
}

void main() {
  vec3 src = clamp(texture(uTex, vUv).rgb, 0.0, 1.0);
  if (uPass == 0) {
    vec3 lin = srgbDec(src);
    vec3 c = src;
    if (uOut == 1) {
      c = logEnc(lin);
    } else if (uOut == 2) {
      vec3 e = TO2020 * lin * HLG_WHITE;
      c = vec3(hlgOetf(e.r), hlgOetf(e.g), hlgOetf(e.b));
    }
    if (uLutEnabled == 1) {
      vec3 li = (uLutInLog == 1) ? logEnc0(lin) : srgbEnc(lin);
      c = mix(c, applyLut(li), clamp(uLutMix, 0.0, 1.0));
    }
    oColor = vec4(c, 1.0);
    return;
  }
  vec3 lin;
  if (uInLog == 1) {
    lin = logDec(src);
  } else if (uInHlg == 1) {
    vec3 e = vec3(hlgInv(src.r), hlgInv(src.g), hlgInv(src.b)) / HLG_WHITE;
    lin = clamp(TO709 * e, 0.0, 1.0);
  } else {
    lin = srgbDec(src);
  }
  vec3 v = srgbEnc(lin);
  if (uViewLog == 1) v = (uInLog == 1) ? src : logEnc(lin);
  if (uLutEnabled == 1) {
    // Вход LUT один и тот же для превью и записи: LOG-кривая (или 709). Не зависит от режима VIEW.
    vec3 li = (uLutInLog == 1) ? logEnc0(lin) : srgbEnc(lin);
    v = mix(v, applyLut(li), clamp(uLutMix, 0.0, 1.0));
  }
  if (uPass == 1) {
    float y = lum(v);
    if (uFalse == 1) v = falseColor(y);
    if (uPeak == 1) {
      float gx = lum(texture(uTex, vUv + vec2(uTexel.x, 0.0)).rgb) - lum(texture(uTex, vUv - vec2(uTexel.x, 0.0)).rgb);
      float gy = lum(texture(uTex, vUv + vec2(0.0, uTexel.y)).rgb) - lum(texture(uTex, vUv - vec2(0.0, uTexel.y)).rgb);
      if (abs(gx) + abs(gy) > 0.18) v = vec3(1.0, 0.15, 0.15);
    }
    if (uZebra == 1 && y >= uZebraLevel) {
      if (fract((gl_FragCoord.x + gl_FragCoord.y) / 14.0) > 0.5) v = vec3(0.0);
    }
  }
  oColor = vec4(v, 1.0);
}
"""
    }

    private val VS_FRONT = """#version 300 es
uniform int uRot;
out vec2 vQ;
void main() {
  vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
  vec2 q = p;
  if (uRot == 1) q = vec2(p.y, -p.x);
  else if (uRot == 2) q = -p;
  else if (uRot == 3) q = vec2(-p.y, p.x);
  gl_Position = vec4(q, 0.0, 1.0);
  vQ = q;
}
"""

    /**
 * Вершинный шейдер EIS: сетка (BANDS строк × MESH_COLS столбцов).
 * Каждая строка получает свою матрицу поворота -> построчная коррекция rolling shutter.
 * Варп считается В ОСЯХ СЕНСОРА, поворот uRot применяется только при выборке (отмена texMat).
 * Это исправляет и латентную ошибку v1: там EIS применялась в повёрнутой системе, когда tmRot=true.
 */
    private val VS_MESH = """#version 300 es
precision highp float;
precision highp int;
uniform mat4 uTexMat;
uniform int uRot;
uniform int uEis;
uniform int uBands;
uniform mat3 uR[17];
uniform vec2 uA;
uniform vec2 uB;
uniform vec2 uT0;
uniform vec2 uT1;
uniform vec2 uT2;
vec2 tAt(float row) { return row < 0.5 ? mix(uT0, uT1, row * 2.0) : mix(uT1, uT2, (row - 0.5) * 2.0); }
out vec2 vUv;
out vec2 vQ;
vec2 rotInv(vec2 q) {
    if (uRot == 1) return vec2(-q.y, q.x);
    if (uRot == 2) return -q;
    if (uRot == 3) return vec2(q.y, -q.x);
    return q;
}
mat3 matAt(float row) {
    float x = clamp(row, 0.0, 1.0) * float(uBands);
    int i = int(x);
    if (i >= uBands) i = uBands - 1;
    float f = x - float(i);
    return uR[i] * (1.0 - f) + uR[i + 1] * f;
}
vec2 warp(vec2 p, float row) {
    vec3 d = vec3(p.x * uA.x, -p.y * uA.y, 1.0);
    vec3 s = matAt(row) * d;
    s.xy += tAt(clamp(row, 0.0, 1.0)) * s.z;
    float z = max(s.z, 0.05);
    return vec2(s.x / z * uB.x, -(s.y / z) * uB.y);
}
void main() {
    const int COLS = 8;
    int per = 2 * (COLS + 1);
    int r = gl_VertexID / per;
    int k = gl_VertexID - r * per;
    int c = k / 2;
    int rr = r + (k - c * 2);
    vec2 p = vec2(float(c) / float(COLS), float(rr) / float(uBands)) * 2.0 - 1.0;
    gl_Position = vec4(p, 0.0, 1.0);
    vQ = p;
    vec2 q = p;
    if (uEis == 1) {
        q = warp(p, (1.0 - p.y) * 0.5);
        // уточнение: номер строки ИСТОЧНИКА, а не выхода (важно при большом skew)
        q = warp(p, clamp((1.0 - q.y) * 0.5, 0.0, 1.0));
    }
    vUv = (uTexMat * vec4(rotInv(q) * 0.5 + 0.5, 0.0, 1.0)).xy;
}
"""

    /**
     * Проход «до всего»: камера (OES) -> сетка с EIS/RS-варпом -> шумоподавление v2 -> текстура кадра в ориентации сенсора.
     * NR v2: билинейные тапы ±0.5 текселя, пороги от ожидаемого шума uSigma (по ISO) и яркости, temporal по уже сглаженному кадру,
     * клиппинг истории по mean ± k·std, вес падает при пропуске кадров (uDt).
     */
    private val FS_FRONT = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp int;
precision highp sampler2D;
uniform samplerExternalOES uTex;
uniform sampler2D uPrev;
uniform int uNr;
uniform int uHavePrev;
uniform vec2 uStep;
uniform float uSigma;   // ожидаемое СКО шума в гамма-пространстве (оценка по ISO)
uniform float uDt;      // интервал до предыдущего обработанного кадра, в кадрах (1.0 = без пропусков)
in vec2 vUv;
in vec2 vQ;
out vec4 oColor;
void main() {
    vec2 uv = vUv;
    vec3 c = texture(uTex, uv).rgb;
    if (uNr > 0) {
        float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
        // шум в гамма-коде сильнее в тенях; множитель 0.8..2.5
        float sa = uSigma * clamp(pow(lum + 0.08, -0.35), 0.8, 2.5);
        float inv2 = 1.0 / (9.0 * sa * sa);

        vec2 o = uStep * 0.5;
        vec3 n1 = texture(uTex, uv + vec2( o.x,  o.y)).rgb;
        vec3 n2 = texture(uTex, uv + vec2(-o.x,  o.y)).rgb;
        vec3 n3 = texture(uTex, uv + vec2( o.x, -o.y)).rgb;
        vec3 n4 = texture(uTex, uv + vec2(-o.x, -o.y)).rgb;
        float w1 = exp(-dot(n1 - c, n1 - c) * inv2);
        float w2 = exp(-dot(n2 - c, n2 - c) * inv2);
        float w3 = exp(-dot(n3 - c, n3 - c) * inv2);
        float w4 = exp(-dot(n4 - c, n4 - c) * inv2);
        vec3 filt = (c + n1*w1 + n2*w2 + n3*w3 + n4*w4) / (1.0 + w1 + w2 + w3 + w4);

        // статистика соседей для клампинга истории
        vec3 mean = (c + n1 + n2 + n3 + n4) * 0.2;
        vec3 va = ((c-mean)*(c-mean) + (n1-mean)*(n1-mean) + (n2-mean)*(n2-mean)
                 + (n3-mean)*(n3-mean) + (n4-mean)*(n4-mean)) * 0.2;
        vec3 sd = sqrt(max(va, vec3(0.0)));
        float k = (uNr == 1) ? 1.6 : ((uNr == 2) ? 1.3 : 1.1);
        vec3 mn = mean - k * sd - sa;
        vec3 mx = mean + k * sd + sa;

        // сильный уровень: второй ярус à-trous (шаг 1.5 текселя) -> эффективное окно 5x5
        if (uNr == 3) {
            vec2 o2 = uStep * 1.5;
            float j2 = 1.0 / (16.0 * sa * sa);
            vec3 m1 = texture(uTex, uv + vec2( o2.x,  o2.y)).rgb;
            vec3 m2 = texture(uTex, uv + vec2(-o2.x,  o2.y)).rgb;
            vec3 m3 = texture(uTex, uv + vec2( o2.x, -o2.y)).rgb;
            vec3 m4 = texture(uTex, uv + vec2(-o2.x, -o2.y)).rgb;
            float v1 = exp(-dot(m1 - filt, m1 - filt) * j2);
            float v2 = exp(-dot(m2 - filt, m2 - filt) * j2);
            float v3 = exp(-dot(m3 - filt, m3 - filt) * j2);
            float v4 = exp(-dot(m4 - filt, m4 - filt) * j2);
            filt = (filt * 2.0 + m1*v1 + m2*v2 + m3*v3 + m4*v4) / (2.0 + v1 + v2 + v3 + v4);
        }

        if (uHavePrev == 1) {
            vec3 pv = clamp(texture(uPrev, vQ * 0.5 + 0.5).rgb, mn, mx);
            float d = length(filt - pv);
            float thr = sa * ((uNr == 1) ? 1.6 : ((uNr == 2) ? 2.2 : 3.0));
            float wmax = ((uNr == 1) ? 0.72 : ((uNr == 2) ? 0.85 : 0.92)) / max(uDt, 1.0);
            filt = mix(filt, pv, wmax / (1.0 + (d * d) / (thr * thr)));
        }
        c = filt;
    }
    oColor = vec4(c, 1.0);
}
"""

    /** Проба для автосинхронизации: яркость исходного (нестабилизированного) кадра в уменьшенном виде, ориентация сенсора. */
    private val FS_PROBE = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp int;
uniform samplerExternalOES uTex;
uniform mat4 uTexMat;
uniform int uRot;
uniform vec2 uPix;          // один пиксель проб-кадра в клип-координатах
in vec2 vQ;
out vec4 oColor;

vec2 rotInv(vec2 q) {
  if (uRot == 1) return vec2(-q.y, q.x);
  if (uRot == 2) return -q;
  if (uRot == 3) return vec2(q.y, -q.x);
  return q;
}
vec2 srcUv(vec2 q) { return (uTexMat * vec4(rotInv(q) * 0.5 + 0.5, 0.0, 1.0)).xy; }

void main() {
  float s = 0.0;
  for (int j = -2; j <= 2; j++) {
    for (int i = -2; i <= 2; i++) {
      vec3 c = texture(uTex, srcUv(vQ + vec2(float(i), float(j)) * 0.2 * uPix)).rgb;
      s += dot(c, vec3(0.299, 0.587, 0.114));
    }
  }
  s /= 25.0;
  oColor = vec4(s, s, s, 1.0);
}
"""

    /** Основной шейдер для чтения из обычной 2D-текстуры (результат прохода «до всего»); сам FS не меняется. */
    private val FS_2D: String = FS
        .replace("#extension GL_OES_EGL_image_external_essl3 : require\n", "")
        .replace("uniform samplerExternalOES uTex;", "uniform sampler2D uTex;")
        .replace("precision highp sampler3D;", "precision highp sampler3D;\nprecision highp sampler2D;")

    private val FS26_2D: String = ColorShader.FS
        .replace("#extension GL_OES_EGL_image_external_essl3 : require\n", "")
        .replace("uniform samplerExternalOES uTex;", "uniform sampler2D uTex;")

    private val thread = HandlerThread("procam-gl").also { it.start() }
    private val handler = Handler(thread.looper)
    @Volatile var params = GlParams()

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var prevSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var encSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var prevW = 1
    private var prevH = 1
    private var encW = 1
    private var encH = 1
    private var st: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private var tex = 0
    private var lutTex = 0
    private var lut1Tex = 0
    private var lutKind = 0                                   // 0: 3D, 1: 1D (только GL-поток)
    private var lut1Size = 0
    /** Результат сборки цветового шейдера v0.26: true — работает цепочка v0.26, false — откат на шейдер v0.25 (причина в [colorShaderError]). */
    @Volatile var colorShaderOk = false; private set
    @Volatile var colorShaderError = ""; private set
    private var lutSize = 0                                   // только GL-поток
    private var lutMin = floatArrayOf(0f, 0f, 0f)
    private var lutScale = floatArrayOf(1f, 1f, 1f)
    @Volatile private var lutSource: CubeLut? = null          // последний запрошенный LUT (мог прийти до создания GL)
    private var prog = 0
    private var scopeTex = 0
    private var fbo = 0
    private val tm = FloatArray(16)
    private val tmO = FloatArray(16)
    private val zm = FloatArray(16)
    private val locs = HashMap<String, Int>()
    private var texel = floatArrayOf(0f, 0f)
    private var lastScope = 0L
    private var encFails = 0

    /** Гироскопический стабилизатор (задаётся движком). */
    @Volatile var stabilizer: GyroStabilizer? = null
    /** Оценка СКО шума в гамма-пространстве; движок обновляет по ISO из CaptureResult. */
    @Volatile var nrSigma = 0.02f
    /** Ожидаемый интервал кадров, нс (из cfg.fps) — для детекта пропусков. */
    @Volatile var frameNs = 33_333_333L
    private var lastFrontTs = 0L

    /** Сообщение пользователю из GL-потока (например, программная обработка отключена). */
    var onNotice: ((String) -> Unit)? = null

    /** Углы рамки активной области в долях окна превью (x0,y0 … x3,y3); null — убрать рамку. Вызывается из GL-потока. */
    var onEisFrame: ((FloatArray?) -> Unit)? = null
    private var frameShown = false

    private var srcW = 1
    private var srcH = 1
    private var curProg = 0
    private var progF = 0
    private var prog2D = 0
    private val fTex = IntArray(2)
    private val fFbo = IntArray(2)
    private var fReady = false
    private var frontFailed = false
    private var fIdx = 0
    private var havePrev = false
    private var useFront = false

    // проба для автосинхронизации
    // ------------------------------------------------------------ NR v3: маска движения + пространственный фильтр + временной с клампом истории
    // Проход 1 (половинное разрешение, сетка с EIS-варпом): среднее 2x2 + min/max яркости. Проход 2 (¼): маска движения.
    // Проход 3 (½): пространственный фильтр только там, где есть движение. Проход 4 (полное): временной фильтр с клампом истории.
    private val VS_QUAD = """#version 300 es
precision highp float;
out highp vec2 vUv;
void main() {
    vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));
    vUv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

    private val FS_HALF = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision mediump float;
uniform highp samplerExternalOES uCur;
uniform highp vec2 uSrcTexel;
in highp vec2 vUv;
layout(location = 0) out mediump vec4 oAvg;
layout(location = 1) out mediump vec2 oMM;
float Y(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
void main() {
    highp vec2 d = uSrcTexel * 0.5;
    vec3 a = texture(uCur, vUv + vec2(-d.x, -d.y)).rgb;
    vec3 b = texture(uCur, vUv + vec2( d.x, -d.y)).rgb;
    vec3 c = texture(uCur, vUv + vec2(-d.x,  d.y)).rgb;
    vec3 e = texture(uCur, vUv + vec2( d.x,  d.y)).rgb;
    float ya = Y(a), yb = Y(b), yc = Y(c), ye = Y(e);
    oAvg = vec4((a + b + c + e) * 0.25, (ya + yb + yc + ye) * 0.25);
    oMM = vec2(min(min(ya, yb), min(yc, ye)), max(max(ya, yb), max(yc, ye)));
}
"""

    private val FS_MASK = """#version 300 es
precision mediump float;
uniform mediump sampler2D uAvg;
uniform mediump sampler2D uPrev;
uniform mediump sampler2D uSigma;
uniform highp vec2 uQTexel;
uniform float uK, uSigScale;
in highp vec2 vUv;
out mediump vec2 o;
void main() {
    float l = texture(uAvg, vUv).a;
    vec2 p0 = texture(uPrev, vUv).rg;
    float pm = p0.g;
    pm = max(pm, texture(uPrev, vUv + vec2(uQTexel.x, 0.0)).g);
    pm = max(pm, texture(uPrev, vUv - vec2(uQTexel.x, 0.0)).g);
    pm = max(pm, texture(uPrev, vUv + vec2(0.0, uQTexel.y)).g);
    pm = max(pm, texture(uPrev, vUv - vec2(0.0, uQTexel.y)).g);
    float sig = max(texture(uSigma, vec2(l, 0.5)).r * uSigScale * 0.25, 1e-4);
    float m = clamp(abs(l - p0.r) / (uK * sig) - 1.0, 0.0, 1.0);
    o = vec2(l, max(m, pm * 0.80));
}
"""

    private val FS_SPAT = """#version 300 es
precision mediump float;
uniform mediump sampler2D uAvg;
uniform mediump sampler2D uMask;
uniform mediump sampler2D uSigma;
uniform highp vec2 uHTexel;
uniform float uRangeK, uSigScale;
in highp vec2 vUv;
out mediump vec4 o;
void main() {
    vec4 c0 = texture(uAvg, vUv);
    float m = texture(uMask, vUv).g;
    if (m < 0.02) { o = c0; return; }
    float y0 = c0.a;
    float sr = max(uRangeK * texture(uSigma, vec2(y0, 0.5)).r * uSigScale * 0.5, 1e-4);
    float inv2r = 1.0 / (2.0 * sr * sr);
    vec3 acc = c0.rgb;
    float w = 1.0;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            if (i == 0 && j == 0) continue;
            vec4 s = texture(uAvg, vUv + vec2(float(i), float(j)) * uHTexel);
            float ws = (i != 0 && j != 0) ? 0.13534 : 0.60653;
            float dy = s.a - y0;
            float ww = ws * exp(-dy * dy * inv2r);
            acc += s.rgb * ww;
            w += ww;
        }
    }
    o = vec4(acc / w, y0);
}
"""

    private val FS_TEMP = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision mediump float;
uniform highp samplerExternalOES uCur;
uniform mediump sampler2D uHist;
uniform mediump sampler2D uMM;
uniform mediump sampler2D uMask;
uniform mediump sampler2D uSpat;
uniform mediump sampler2D uSigma;
uniform highp vec2 uHalfSize;
uniform float uAY, uAC, uK, uWSpat, uReset, uSigScale;
in highp vec2 vUv;
in highp vec2 vQ;
out mediump vec4 o;
float Y(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
void main() {
    highp vec2 vO = vQ * 0.5 + 0.5;
    vec3 c = texture(uCur, vUv).rgb;
    float yc = Y(c);
    vec3 h = texture(uHist, vO).rgb;
    float yh = Y(h);

    ivec2 b = ivec2(vO * uHalfSize);
    ivec2 lim = ivec2(uHalfSize) - ivec2(1);
    vec2 m0 = texelFetch(uMM, clamp(b,                  ivec2(0), lim), 0).rg;
    vec2 m1 = texelFetch(uMM, clamp(b + ivec2(-1,  0), ivec2(0), lim), 0).rg;
    vec2 m2 = texelFetch(uMM, clamp(b + ivec2( 0, -1), ivec2(0), lim), 0).rg;
    vec2 m3 = texelFetch(uMM, clamp(b + ivec2(-1, -1), ivec2(0), lim), 0).rg;
    float mn = min(min(m0.r, m1.r), min(m2.r, m3.r));
    float mx = max(max(m0.g, m1.g), max(m2.g, m3.g));

    float sig = max(texture(uSigma, vec2(yc, 0.5)).r * uSigScale, 1e-4);
    float pad = uK * sig;
    float yhc = clamp(yh, mn - pad, mx + pad);
    h *= clamp(yhc / max(yh, 1e-3), 0.25, 4.0);
    yh = yhc;

    float m = texture(uMask, vO).g;
    float ay = mix(mix(uAY, 1.0, m), 1.0, uReset);
    float ac = mix(mix(uAC, 1.0, m), 1.0, uReset);

    float yt = yh + ay * (yc - yh);
    vec3 ch = h - yh;
    vec3 t = vec3(yt) + ch + ac * ((c - yc) - ch);

    if (m > 0.02) t = mix(t, texture(uSpat, vO).rgb, m * uWSpat);
    o = vec4(t, 1.0);
}
"""

    // ресурсы NR v3 (создаются при первом включении шумоподавления)
    private var nrReady = false
    private var nrFailed = false
    private var progHalf = 0; private var progMask = 0; private var progSpat = 0; private var progTemp = 0
    private var nrAvg = 0; private var nrMM = 0; private var nrSpat = 0; private var nrSigmaTex = 0
    private val nrMaskTex = IntArray(2)
    private var nrHalfFbo = 0; private var nrSpatFbo = 0
    private val nrMaskFbo = IntArray(2)
    private var nrHW = 0; private var nrHH = 0; private var nrQW = 0; private var nrQH = 0
    private var nrMaskIdx = 0

    private var progP = 0
    private val FS_PROBE2 = """#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uTex;
uniform vec2 uPix;
in vec2 vQ;
out vec4 oColor;
void main() {
    float s = 0.0;
    for (int j = -2; j <= 2; j++) for (int i = 0; i <= 4; i++) {
        s += dot(texture(uTex, vQ * 0.5 + 0.5 + vec2(float(i - 2), float(j)) * 0.2 * uPix).rgb, vec3(0.299, 0.587, 0.114));
    }
    oColor = vec4(vec3(s / 25.0), 1.0);
}
"""
    private var progP2 = 0
    private var lockLuma: FloatArray? = null
    private var lockTs = 0L
    private val lockT = FloatArray(6)
    private var pFbo = 0
    private var pTex = 0
    private val pW = 128
    private var pH = 72
    private var probeBuf: java.nio.ByteBuffer? = null
    private var prevLuma: FloatArray? = null
    private var prevLumaTs = 0L
    private var probeSkip = 0
    private var probeCount = 0
    private var probeFailed = false
    private val ident4 = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    @Volatile private var contentAspect = 16f / 9f   // соотношение сторон кадра (в Open Gate 4:3): превью вписывается без растяжения

    /** Вызывается из GL-потока, если поверхность кодека перестала принимать кадры во время записи. */
    var onEncoderError: (() -> Unit)? = null
    private var px = ByteBuffer.allocateDirect(SW * SH * 4)
    private var scW = SW
    private var scH = SH
    private var lastScopeNs = 0L

    /** Запускается в GL-потоке. ready(поверхность для камеры, активен ли 10-bit, ошибка). */
    fun start(preview: Surface, camW: Int, camH: Int, wantTenBit: Boolean, ready: (Surface?, Boolean, String?) -> Unit) {
        lastFrontTs = 0L
        handler.post {
            try {
                var ten = false
                var created = false
                for (t in if (wantTenBit) listOf(true, false) else listOf(false)) {
                    try {
                        initEgl(t)
                        prevSurf = EGL14.eglCreateWindowSurface(dpy, cfg, preview, intArrayOf(EGL14.EGL_NONE), 0)
                        if (prevSurf == EGL14.EGL_NO_SURFACE) throw RuntimeException("eglCreateWindowSurface")
                        if (!EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)) throw RuntimeException("eglMakeCurrent")
                        ten = t
                        created = true
                        break
                    } catch (e: Exception) {
                        Log.w(TAG, "EGL init (10-bit=$t) failed: ${e.message}")
                        releaseEgl()
                    }
                }
                if (!created) throw RuntimeException("не удалось создать EGL")
                EGL14.eglSwapInterval(dpy, 0)
                val sz = IntArray(1)
                EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_WIDTH, sz, 0); prevW = sz[0]
                EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_HEIGHT, sz, 0); prevH = sz[0]
                initGl()
                try { uploadLut(lutSource) } catch (e: Exception) { Log.w(TAG, "LUT upload: ${e.message}") }
                contentAspect = camW.toFloat() / camH
                srcW = camW
                srcH = camH
                val k = max(1f, camW / 1280f)
                texel = floatArrayOf(k / camW, k / camH)
                val s = SurfaceTexture(tex)
                s.setDefaultBufferSize(camW, camH)
                s.setOnFrameAvailableListener({ drawFrame() }, handler)
                st = s
                camSurface = Surface(s)
                ready(camSurface, ten, null)
            } catch (e: Throwable) {
                Log.e(TAG, "start failed", e)
                ready(null, false, e.message)
            }
        }
    }

    fun startEncoding(surface: Surface, w: Int, h: Int) {
        handler.post {
            try {
                encSurf = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
                encW = w
                encH = h
                encFails = 0
                if (encSurf != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)
                    EGL14.eglSwapInterval(dpy, 0)
                    EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                }
            } catch (e: Exception) {
                Log.e(TAG, "startEncoding", e)
                encSurf = EGL14.EGL_NO_SURFACE
            }
        }
    }

    fun stopEncoding(done: () -> Unit) {
        handler.post {
            if (encSurf != EGL14.EGL_NO_SURFACE && dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                EGL14.eglDestroySurface(dpy, encSurf)
            }
            encSurf = EGL14.EGL_NO_SURFACE
            done()
        }
    }

    fun stop() {
        handler.post {
            try {
                st?.setOnFrameAvailableListener(null)
                st?.release(); st = null
                camSurface?.release(); camSurface = null
                releaseEgl()
            } catch (e: Exception) {
                Log.w(TAG, "stop", e)
            }
            thread.quitSafely()
        }
    }

    // ---------------------------------------------------------------- EGL / GL

    private fun initEgl(tenBit: Boolean) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw RuntimeException("eglInitialize")
        cfg = chooseConfig(tenBit)
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        if (ctx == EGL14.EGL_NO_CONTEXT) throw RuntimeException("eglCreateContext (нужен GLES 3.0)")
    }

    private fun chooseConfig(tenBit: Boolean): EGLConfig {
        val bits = if (tenBit) 10 else 8
        val alpha = if (tenBit) 2 else 8
        for (recordable in listOf(true, false)) {
            val a = ArrayList<Int>()
            a.addAll(listOf(EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR))
            a.addAll(listOf(EGL14.EGL_RED_SIZE, bits, EGL14.EGL_GREEN_SIZE, bits, EGL14.EGL_BLUE_SIZE, bits, EGL14.EGL_ALPHA_SIZE, alpha))
            if (recordable) a.addAll(listOf(0x3142, 1)) // EGL_RECORDABLE_ANDROID
            a.add(EGL14.EGL_NONE)
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (EGL14.eglChooseConfig(dpy, a.toIntArray(), 0, cfgs, 0, 1, n, 0) && n[0] > 0 && cfgs[0] != null) return cfgs[0]!!
        }
        throw RuntimeException("нет подходящего EGLConfig (10-bit=$tenBit)")
    }

    private fun releaseEgl() {
        if (dpy != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (encSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, encSurf)
            if (prevSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, prevSurf)
            if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(dpy)
        }
        dpy = EGL14.EGL_NO_DISPLAY; ctx = EGL14.EGL_NO_CONTEXT
        prevSurf = EGL14.EGL_NO_SURFACE; encSurf = EGL14.EGL_NO_SURFACE
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            throw RuntimeException("шейдер: $log")
        }
        return s
    }

    private fun initGl() {
        val vs = compile(GLES30.GL_VERTEX_SHADER, VS)
        prog = try {
            val p = linkProgram(vs, compile(GLES30.GL_FRAGMENT_SHADER, ColorShader.FS))
            colorShaderOk = true; colorShaderError = ""
            p
        } catch (e: Exception) {
            // Новая цепочка не собралась на этом GPU/драйвере: работаем на проверенном шейдере v0.25 и честно сообщаем.
            colorShaderOk = false; colorShaderError = (e.message ?: "?").take(400)
            Log.w(TAG, "color shader v0.26 failed, fallback to v0.25: $colorShaderError")
            linkProgram(vs, compile(GLES30.GL_FRAGMENT_SHADER, FS))
        }
        locs.clear()

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        tex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, tex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glGenTextures(1, t, 0)
        scopeTex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, scopeTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SW, SH, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, scopeTex, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    /**
     * Загрузка .cube в 3D-текстуру (порядок данных как в файле: R быстрее всего).
     * Можно вызывать из любого потока и в любой момент: если GL ещё не создан, LUT подхватит start().
     */
    fun setLut(lut: CubeLut?, done: (String?) -> Unit = {}) {
        lutSource = lut
        handler.post {
            if (dpy == EGL14.EGL_NO_DISPLAY) { done(null); return@post }   // start() загрузит lutSource сам
            try {
                uploadLut(lut)
                done(null)
            } catch (e: Exception) {
                Log.w(TAG, "setLut", e)
                done(e.message ?: "LUT upload error")
            }
        }
    }

    /** Только в GL-потоке с текущим контекстом. При ошибке LUT отключается, а не остаётся «наполовину». */
    private fun uploadLut(lut: CubeLut?) {
        if (lutTex != 0) { GLES30.glDeleteTextures(1, intArrayOf(lutTex), 0); lutTex = 0 }
        if (lut1Tex != 0) { GLES30.glDeleteTextures(1, intArrayOf(lut1Tex), 0); lut1Tex = 0 }
        lutSize = 0; lut1Size = 0; lutKind = 0
        if (lut == null) return
        val lim = IntArray(1)
        val one = lut.oneD
        if (one != null) {
            GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_SIZE, lim, 0)
            require(one.size <= lim[0]) { "1D LUT на ${one.size} точек не поддерживается GPU (предел текстуры ${lim[0]})" }
            val fb1 = ByteBuffer.allocateDirect(one.data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            fb1.put(one.data); fb1.position(0)
            val id1 = IntArray(1); GLES30.glGenTextures(1, id1, 0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id1[0])
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
            var g1 = 0
            while (GLES30.glGetError() != GLES30.GL_NO_ERROR && ++g1 < 16) { }
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGB16F, one.size, 1, 0, GLES30.GL_RGB, GLES30.GL_FLOAT, fb1)
            val e1 = GLES30.glGetError()
            if (e1 != GLES30.GL_NO_ERROR) { GLES30.glDeleteTextures(1, id1, 0); throw RuntimeException("glTexImage2D(1D LUT): 0x" + Integer.toHexString(e1)) }
            lut1Tex = id1[0]; lut1Size = one.size; lutKind = 1
            lutMin = one.domainMin.copyOf()
            lutScale = FloatArray(3) { 1f / (one.domainMax[it] - one.domainMin[it]) }
            return
        }
        val n = lut.size
        require(n in 2..CubeLutReader.MAX_SIZE && lut.data.size == n * n * n * 3) { "неверные размеры LUT" }
        GLES30.glGetIntegerv(GLES30.GL_MAX_3D_TEXTURE_SIZE, lim, 0)
        require(lim[0] <= 0 || n <= lim[0]) { "LUT $n³ больше предела 3D-текстуры этого GPU (${lim[0]}³)" }

        val fb = ByteBuffer.allocateDirect(lut.data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(lut.data)
        fb.position(0)

        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        val id = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, id)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
        var guard = 0
        while (GLES30.glGetError() != GLES30.GL_NO_ERROR && ++guard < 16) { /* сбросить старые ошибки */ }
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_RGB16F, n, n, n, 0, GLES30.GL_RGB, GLES30.GL_FLOAT, fb)
        val err = GLES30.glGetError()
        if (err != GLES30.GL_NO_ERROR) {
            GLES30.glDeleteTextures(1, ids, 0)
            throw RuntimeException("glTexImage3D: 0x" + Integer.toHexString(err) + (if (err == GLES30.GL_OUT_OF_MEMORY) " (не хватило видеопамяти для LUT $n³)" else ""))
        }
        lutTex = id
        lutSize = n
        lutMin = lut.domainMin.copyOf()
        lutScale = FloatArray(3) { 1f / (lut.domainMax[it] - lut.domainMin[it]) }
    }

    private fun loc(name: String) = locs.getOrPut("$curProg/$name") { GLES30.glGetUniformLocation(curProg, name) }

    private fun b(v: Boolean) = if (v) 1 else 0

    /** Матрица SurfaceTexture уже содержит поворот на 90/270 (камера отдаёт кадр, довёрнутый на ориентацию сенсора). */
    private var tmRot = false
    @Volatile var dbg = ""
    private var dbgCount = 0

    /**
     * Поворот по часовой (в четвертях) для прохода.
     * Превью: кадр «сырого» сенсора нужно повернуть на (S - D); если матрица уже довернула его на S, остаётся -D.
     * Кодер: ему нужен сырой кадр сенсора (метка поворота в MP4 = S - D), поэтому поворот матрицы отменяем.
     */
    private fun rotQuarter(p: GlParams, pass: Int, tmr: Boolean = tmRot): Int {
        val s = p.sensorRot
        val cw = when (pass) {
            0 -> if (tmr) 360 - s else 0
            1 -> s - p.dispRot - (if (tmr) s else 0)
            else -> 0
        }
        return (((cw % 360) + 360) % 360) / 90
    }

    private fun draw(p: GlParams, pass: Int) {
        val use2d = useFront && prog2D != 0 && fReady && !(pass == 1 && p.eis && p.eisFrame > 0)
        curProg = if (use2d) prog2D else prog
        GLES30.glUseProgram(curProg)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        if (use2d) GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fTex[fIdx])
        else GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, lutTex)
        GLES30.glUniform1i(loc("uLut"), 1)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, lut1Tex)
        GLES30.glUniform1i(loc("uLut1"), 2)
        val cuNow = p.cu ?: neutralCu
        val lutLoaded = (lutTex != 0 && lutSize > 0) || (lut1Tex != 0 && lut1Size > 0)
        val lutOn = lutLoaded && (if (pass == 0) p.lutRec else p.lutView && !(cuNow.bypassView))
        GLES30.glUniform1i(loc("uLutEnabled"), if (lutOn) 1 else 0)
        GLES30.glUniform1i(loc("uLutInLog"), b(p.lutInLog))
        GLES30.glUniform1f(loc("uLutSize"), max(1, lutSize).toFloat())
        GLES30.glUniform1f(loc("uLutMix"), p.lutMix)
        GLES30.glUniform1f(loc("uLogGain"), p.logGain)
        GLES30.glUniform3f(loc("uLutMin"), lutMin[0], lutMin[1], lutMin[2])
        GLES30.glUniform3f(loc("uLutScale"), lutScale[0], lutScale[1], lutScale[2])
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, if (use2d) ident4 else tm, 0)
        GLES30.glUniform1i(loc("uRot"), (rotQuarter(p, pass, tmRot && !use2d) + if (pass == 1 && p.previewTurn180) 2 else 0) % 4)
        GLES30.glUniform1i(loc("uPass"), pass)
        GLES30.glUniform1i(loc("uOut"), p.out)
        GLES30.glUniform1i(loc("uCurve"), if (colorShaderOk && cuNow.customLog != null) 4 else p.curve)
        GLES30.glUniform1i(loc("uInLog"), b(p.inLog))
        GLES30.glUniform1i(loc("uInHlg"), b(p.inHlg))
        GLES30.glUniform1i(loc("uViewLog"), b(p.viewLog))
        GLES30.glUniform1i(loc("uZebra"), b(p.zebra))
        GLES30.glUniform1f(loc("uZebraLevel"), p.zebraLevel)
        GLES30.glUniform1i(loc("uPeak"), b(p.peaking))
        GLES30.glUniform1i(loc("uFalse"), b(p.falseColor))
        GLES30.glUniform2f(loc("uTexel"), texel[0], texel[1])
        if (colorShaderOk) setColorUniforms(p, cuNow, pass, lutOn)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private val neutralCu: ColorUniforms by lazy { ColorUniforms.build(ColorSettings(MemStore()), 0, 0, 0, false, false, 0.95f) }

    private fun m3(name: String, m: FloatArray) = GLES30.glUniformMatrix3fv(loc(name), 1, true, m, 0)   // m — по строкам

    /** Цветовая цепочка v0.26: одни и те же формулы для записи (pass 0), превью (1) и скоупа (2); различаются только выходные матрицы и функция. */
    private fun setColorUniforms(p: GlParams, c: ColorUniforms, pass: Int, lutOn: Boolean) {
        val mon = pass != 0
        val byp = mon && c.bypassView
        val kind = if (mon) c.inKind else 0
        GLES30.glUniform1i(loc("uInKind"), kind)
        GLES30.glUniform1i(loc("uInTf"), c.inTf)
        GLES30.glUniform1f(loc("uHlgWhite"), c.hlgWhite)
        m3("uToWork", if (mon) c.toWork else c.toWorkRec)
        m3("uWb", c.wb)
        val toOut = if (mon) c.workToView else c.workToRec
        m3("uWorkToOut", toOut)
        GLES30.glUniform3fv(loc("uLumaW"), 1, c.lumaW, 0)
        GLES30.glUniform3fv(loc("uLumaOut"), 1, if (mon) c.lumaView else c.lumaRec, 0)
        GLES30.glUniform1i(loc("uBypass"), if (byp) 1 else 0)
        GLES30.glUniform1i(loc("uGradeOn"), if (c.gradeOn) 1 else 0)
        GLES30.glUniform1f(loc("uEx"), c.ex); GLES30.glUniform1f(loc("uContrast"), c.contrast)
        GLES30.glUniform1f(loc("uHi"), c.hi); GLES30.glUniform1f(loc("uSh"), c.sh); GLES30.glUniform1f(loc("uWh"), c.wh); GLES30.glUniform1f(loc("uBl"), c.bl)
        GLES30.glUniform1f(loc("uSat"), c.sat); GLES30.glUniform1f(loc("uVib"), c.vib); GLES30.glUniform1f(loc("uHueRot"), c.hueRot)
        GLES30.glUniform3fv(loc("uLift"), 1, c.lift, 0); GLES30.glUniform3fv(loc("uGammaV"), 1, c.gamma, 0); GLES30.glUniform3fv(loc("uGain"), 1, c.gain, 0)
        GLES30.glUniform1fv(loc("uCurves[0]"), 20, c.curves, 0)
        GLES30.glUniform3fv(loc("uHue[0]"), 6, c.hue, 0)
        GLES30.glUniform1i(loc("uBands"), if (c.bands) 1 else 0)
        GLES30.glUniform1i(loc("uSplitOn"), if (c.splitOn) 1 else 0)
        GLES30.glUniform3fv(loc("uSplitSh"), 1, c.splitSh, 0); GLES30.glUniform3fv(loc("uSplitHi"), 1, c.splitHi, 0); GLES30.glUniform1f(loc("uSplitBal"), c.splitBal)
        GLES30.glUniform1i(loc("uTone"), if (byp) 0 else c.tone); GLES30.glUniform1f(loc("uToneWhite"), c.toneWhite)
        GLES30.glUniform1i(loc("uGamut"), c.gamut); GLES30.glUniform1i(loc("uSdrTf"), c.sdrTf)
        c.customLog?.let { GLES30.glUniform4f(loc("uCl"), it[0], it[1], it[2], it[3]) }
        // LUT
        GLES30.glUniform1i(loc("uLutKind"), lutKind); GLES30.glUniform1i(loc("uLutInterp"), c.lutInterp)
        GLES30.glUniform1f(loc("uLut1Size"), max(1, lut1Size).toFloat())
        GLES30.glUniform1i(loc("uLutInTf"), c.lutInTf); GLES30.glUniform1i(loc("uLutOutTf"), c.lutOutTf); GLES30.glUniform1i(loc("uLutOutRaw"), if (c.lutOutRaw) 1 else 0)
        m3("uLutInMat", if (mon) c.lutInView else c.lutInRec); m3("uLutOutMat", if (mon) c.lutOutView else c.lutOutRec)
        GLES30.glUniform1f(loc("uLutMix"), c.lutMix)
        // ассистенты
        GLES30.glUniform1i(loc("uFcN"), c.fcN)
        GLES30.glUniform1fv(loc("uFcLo[0]"), 8, c.fcLo, 0); GLES30.glUniform1fv(loc("uFcHi[0]"), 8, c.fcHi, 0); GLES30.glUniform3fv(loc("uFcCol[0]"), 8, c.fcCol, 0)
        GLES30.glUniform1i(loc("uZebraHi"), if (pass == 1 && c.zHiOn) 1 else 0); GLES30.glUniform1f(loc("uZebraHiLv"), c.zHiLv)
        GLES30.glUniform1i(loc("uZebraLo"), if (pass == 1 && c.zLoOn) 1 else 0); GLES30.glUniform1f(loc("uZebraLoLv"), c.zLoLv); GLES30.glUniform1f(loc("uZebraAlpha"), c.zAlpha)
        GLES30.glUniform1f(loc("uDither"), if (pass == 2) 0f else p.dither)
        // запись без каких-либо преобразований — пиксель как есть (быстрый путь, ровно как в v0.25)
        val identIn = (if (mon) c.toWork else c.toWorkRec).contentEquals(ColorUniforms.IDENT) && toOut.contentEquals(ColorUniforms.IDENT)
        val pass0Plain = pass == 0 && !lutOn && p.dither == 0f && (c.inKind == 2 ||
            (p.out == 0 && !c.gradeOn && c.tone == 0 && c.inTf == c.sdrTf && identIn))
        GLES30.glUniform1i(loc("uPassthru"), if (pass0Plain) 1 else 0)
    }

    /** Диагностика (реальные измерения): кадров обработано, кадров отправлено в кодек, ошибок отправки, среднее CPU-время подачи кадра (мс; время на GPU API не отдаёт). */
    @Volatile var framesDrawn = 0L; private set
    @Volatile var framesToEncoder = 0L; private set
    @Volatile var encoderSwapFailures = 0L; private set
    @Volatile var drawMsAvg = 0f; private set

    private fun drawFrame() {
        val s = st ?: return
        if (dpy == EGL14.EGL_NO_DISPLAY) return
        val t0 = System.nanoTime()
        try {
            s.updateTexImage()
            s.getTransformMatrix(tm)
            tmRot = Math.abs(tm[1]) > Math.abs(tm[0])
            // Цифровой зум: сужаем выборку из кадра к центру. При EIS кроп уже учтён в eisCrop (иначе поправки гироскопа недокомпенсировались бы).
            val dzp = params
            val dz = dzp.dzoom
            if (dz > 1.001f && !(dzp.eis && stabilizer != null && dzp.eisFocal > 1f && !frontFailed)) {
                Matrix.setIdentityM(zm, 0)
                Matrix.translateM(zm, 0, 0.5f, 0.5f, 0f)
                Matrix.scaleM(zm, 0, 1f / dz, 1f / dz, 1f)
                Matrix.translateM(zm, 0, -0.5f, -0.5f, 0f)
                System.arraycopy(tm, 0, tmO, 0, 16)
                Matrix.multiplyMM(tm, 0, tmO, 0, zm, 0)
            }
            if (dbgCount++ % 30 == 0) dbg = "матрица: tmRot=$tmRot [%.1f %.1f / %.1f %.1f]; сенсор=${params.sensorRot}°, дисплей=${params.dispRot}°; путь=${if (useFront) "через обработку (NR/EIS)" else "прямой"}; NR=${params.nr}, EIS=${params.eis}".format(tm[0], tm[1], tm[4], tm[5])
            val ts = s.timestamp
            val p = params

            // Проход «до всего» (EIS / шумоподавление). Если ничего не включено или он сломался — всё работает как раньше.
            var front = false
            if (!frontFailed && ((p.eis && stabilizer != null) || p.nr > 0)) {
                front = try {
                    frontPass(p, ts, stabilizer)
                } catch (e: Exception) {
                    Log.e(TAG, "frontPass", e)
                    frontFailed = true
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                    onNotice?.invoke("Шумоподавление/стабилизация отключены: ${e.message}")
                    false
                }
            }
            useFront = front
            val lockStab = stabilizer
            if (front && lockStab != null && lockStab.lockEnable && p.eis) {
                try { runLockProbe(lockStab) } catch (e: Exception) { Log.w(TAG, "lockProbe: ${e.message}") }
            } else lockLuma = null
            if (!front || p.nr == 0) havePrev = false

            // Автосинхронизация гироскопа с видео: пока идёт калибровка, на каждом втором кадре снимаем уменьшенную яркость.
            val cal = stabilizer
            if (cal != null && cal.calibrating && p.eis && !probeFailed) {
                if (SystemClock.elapsedRealtime() - cal.calStartMs > 25_000L) {
                    prevLuma = null
                    cal.failCalibration()
                } else if (++probeSkip >= 2) {
                    probeSkip = 0
                    try {
                        runProbe(p, ts, cal)
                    } catch (e: Exception) {
                        Log.w(TAG, "probe: ${e.message}")
                        probeFailed = true
                        onNotice?.invoke("Автосинхронизация гироскопа недоступна: ${e.message}")
                        cal.failCalibration()
                    }
                }
            } else {
                prevLuma = null
            }
            if (frameShown && !(front && p.eis && p.eisFrame > 0)) {
                frameShown = false
                onEisFrame?.invoke(null)
            }

            if (encSurf != EGL14.EGL_NO_SURFACE) {
                EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)
                GLES30.glViewport(0, 0, encW, encH)
                draw(p, 0)
                EGLExt.eglPresentationTimeANDROID(dpy, encSurf, ts)
                if (!EGL14.eglSwapBuffers(dpy, encSurf)) {
                    // Раньше эта ошибка глоталась: превью живое, а видео в файле обрывалось.
                    encoderSwapFailures++
                    if (++encFails == 20) onEncoderError?.invoke()
                } else {
                    encFails = 0
                    framesToEncoder++
                }
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
            }

            // Буфер превью фиксирован (16:9). Кадр другого формата вписываем по центру, поля — чёрные (не растягиваем).
            GLES30.glViewport(0, 0, prevW, prevH)
            GLES30.glClearColor(0f, 0f, 0f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
            var vw = prevW
            var vh = prevH
            if (prevW.toFloat() / prevH > contentAspect) vw = (prevH * contentAspect).toInt().coerceAtLeast(1)
            else vh = (prevW / contentAspect).toInt().coerceAtLeast(1)
            GLES30.glViewport((prevW - vw) / 2, (prevH - vh) / 2, vw, vh)
            draw(p, 1)
            EGL14.eglSwapBuffers(dpy, prevSurf)

            if (p.hist || onScopePixels != null) {
                val now = SystemClock.uptimeMillis()
                // Скоуп читает пиксели с GPU синхронно — во время записи делаем это реже, чтобы не рвать кадры кодера.
                val every = if (encSurf != EGL14.EGL_NO_SURFACE) maxOf(500L, p.scopeMs) else 0L
                if (now - lastScope > every) {
                    lastScope = now
                    scope(p)
                }
            }
            if (front) {
                fIdx = 1 - fIdx           // следующий кадр пишем в другую текстуру, эта станет «предыдущим»
                havePrev = p.nr > 0
            }
            framesDrawn++
            val ms = (System.nanoTime() - t0) / 1e6f
            drawMsAvg = if (drawMsAvg == 0f) ms else drawMsAvg * 0.95f + ms * 0.05f
        } catch (e: Exception) {
            Log.w(TAG, "drawFrame: ${e.message}")
        }
    }

    private fun linkProgram(vs: Int, fs: Int): Int {
        val pr = GLES30.glCreateProgram()
        GLES30.glAttachShader(pr, vs)
        GLES30.glAttachShader(pr, fs)
        GLES30.glLinkProgram(pr)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(pr, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: ${GLES30.glGetProgramInfoLog(pr)}")
        return pr
    }

    /** Две текстуры кадра (ping-pong) в ориентации сенсора: RGBA16F, если устройство умеет рендерить в неё, иначе RGBA8. */
    /** Две текстуры кадра (ping-pong). RGB10_A2: 4 байта/пиксель вместо 8 у RGBA16F; RGBA8 — страховка. */
    private fun makeFrontTargets(): Boolean {
        for (fmt in listOf(GLES30.GL_RGB10_A2, GLES30.GL_RGBA8)) {
            var guard = 0
            while (GLES30.glGetError() != GLES30.GL_NO_ERROR && ++guard < 16) { }
            GLES30.glGenTextures(2, fTex, 0)
            GLES30.glGenFramebuffers(2, fFbo, 0)
            var ok = true
            val type = if (fmt == GLES30.GL_RGB10_A2) GLES30.GL_UNSIGNED_INT_2_10_10_10_REV else GLES30.GL_UNSIGNED_BYTE
            for (i in 0..1) {
                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fTex[i])
                GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, fmt, srcW, srcH, 0, GLES30.GL_RGBA, type, null)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fFbo[i])
                GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, fTex[i], 0)
                if (GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) != GLES30.GL_FRAMEBUFFER_COMPLETE) ok = false
            }
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            if (ok && GLES30.glGetError() == GLES30.GL_NO_ERROR) return true
            GLES30.glDeleteFramebuffers(2, fFbo, 0)
            GLES30.glDeleteTextures(2, fTex, 0)
        }
        return false
    }

    private fun ensureFront(): Boolean {
        if (fReady) return true
        if (frontFailed) return false
        try {
            if (srcW.toLong() * srcH > 16_000_000L) throw RuntimeException("кадр ${srcW}×$srcH слишком велик для программной обработки")
            progF = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_MESH), compile(GLES30.GL_FRAGMENT_SHADER, FS_FRONT))
            prog2D = if (colorShaderOk) try {
                linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS26_2D))
            } catch (e: Exception) {
                colorShaderOk = false; colorShaderError = "2D-вариант: " + (e.message ?: "?").take(400)
                Log.w(TAG, "color shader 2D failed: $colorShaderError")
                prog = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS))    // оба пути должны быть одной версии
                linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS_2D))
            } else linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS_2D))
            if (!makeFrontTargets()) throw RuntimeException("не удалось создать буферы кадра")
            fReady = true
            return true
        } catch (e: Exception) {
            frontFailed = true
            Log.e(TAG, "front init failed", e)
            onNotice?.invoke("Шумоподавление/стабилизация отключены: ${e.message}")
            return false
        }
    }

    /** Границы записываемого кадра внутри полного кадра (центральная полоса), с учётом вписывания превью (Open Gate). */
    private fun publishFrame(p: GlParams, mats: FloatArray?) {
        val cb = onEisFrame ?: return
        val f = p.eisFocal
        val cr = max(p.eisCrop, 1f)
        val ax = (srcW / 2f) / (f * cr); val ay = (srcH / 2f) / (f * cr)
        val bx = f / (srcW / 2f); val by = f / (srcH / 2f)
        val rot = rotQuarter(p, 1, false)
        val o = (GyroStabilizer.BANDS / 2) * 9
        val cx = floatArrayOf(-1f, 1f, 1f, -1f)
        val cy = floatArrayOf(-1f, -1f, 1f, 1f)
        // рамка живёт в координатах всего окна превью, а GL рисует кадр вписанным по центру
        var vw = prevW.toFloat(); var vh = prevH.toFloat()
        if (prevW.toFloat() / prevH > contentAspect) vw = prevH * contentAspect else vh = prevW / contentAspect
        val ox = (prevW - vw) / 2f; val oy = (prevH - vh) / 2f
        val out = FloatArray(8)
        for (k in 0..3) {
            var dx = cx[k] * ax; var dy = -cy[k] * ay; var dz = 1f
            if (mats != null) {
                val sx = mats[o + 0] * dx + mats[o + 3] * dy + mats[o + 6] * dz
                val sy = mats[o + 1] * dx + mats[o + 4] * dy + mats[o + 7] * dz
                val sz = mats[o + 2] * dx + mats[o + 5] * dy + mats[o + 8] * dz
                dx = sx; dy = sy; dz = sz
            }
            if (dz < 0.05f) dz = 0.05f
            val qx = dx / dz * bx; val qy = -(dy / dz) * by
            var ex = qx; var ey = qy
            when (rot) {
                1 -> { ex = qy; ey = -qx }
                2 -> { ex = -qx; ey = -qy }
                3 -> { ex = -qy; ey = qx }
            }
            out[k * 2] = (ox + (ex + 1f) * 0.5f * vw) / prevW
            out[k * 2 + 1] = (oy + (1f - ey) * 0.5f * vh) / prevH
        }
        cb(out)
        frameShown = true
    }

    private fun ensureProbe(): Boolean {
        if (progP != 0) return true
        pH = Math.round(pW.toDouble() * srcH / srcW).toInt().coerceIn(16, 128)
        val pr = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_FRONT), compile(GLES30.GL_FRAGMENT_SHADER, FS_PROBE))
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        pTex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, pTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, pW, pH, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        pFbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, pFbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, pTex, 0)
        val ok = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        if (!ok) throw RuntimeException("буфер пробы не создан")
        probeBuf = java.nio.ByteBuffer.allocateDirect(pW * pH * 4)
        progP = pr
        return true
    }

    /** Проба по уже стабилизированному кадру: остаточный сдвиг относительно предыдущего (замкнутый контур Frame Lock). */
    private fun runLockProbe(stab: GyroStabilizer) {
        if (!ensureProbe()) return
        if (progP2 == 0) progP2 = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_FRONT), compile(GLES30.GL_FRAGMENT_SHADER, FS_PROBE2))
        val buf = probeBuf ?: return
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, pFbo)
        GLES30.glViewport(0, 0, pW, pH)
        curProg = progP2
        GLES30.glUseProgram(progP2)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fTex[fIdx])
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glUniform2f(loc("uPix"), 2f / pW, 2f / pH)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        buf.clear()
        GLES30.glReadPixels(0, 0, pW, pH, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        val luma = FloatArray(pW * pH)
        for (y in 0 until pH) {
            val row = (pH - 1 - y) * pW * 4
            for (x in 0 until pW) luma[y * pW + x] = (buf.get(row + x * 4).toInt() and 255) / 255f
        }
        val now = SystemClock.elapsedRealtimeNanos()
        val prev = lockLuma
        if (prev != null) {
            val r = MotionProbe.bands(prev, luma, pW, pH)
            if (r != null) stab.addResidual(now, r[0], r[1], r, r[2], pW, pH)
        }
        lockLuma = luma
        lockTs = now
    }

    private fun runProbe(p: GlParams, ts: Long, stab: GyroStabilizer) {
        ensureProbe()
        val buf = probeBuf ?: return
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, pFbo)
        GLES30.glViewport(0, 0, pW, pH)
        curProg = progP
        GLES30.glUseProgram(progP)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, tm, 0)
        GLES30.glUniform1i(loc("uRot"), rotQuarter(p, 0))
        GLES30.glUniform2f(loc("uPix"), 2f / pW, 2f / pH)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        buf.clear()
        GLES30.glReadPixels(0, 0, pW, pH, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)

        // glReadPixels отдаёт строки снизу вверх; для оценки сдвига нужно y вниз (как в модели камеры)
        val luma = FloatArray(pW * pH)
        for (y in 0 until pH) {
            val row = (pH - 1 - y) * pW * 4
            for (x in 0 until pW) luma[y * pW + x] = (buf.get(row + x * 4).toInt() and 255) / 255f
        }
        val prev = prevLuma
        if (prev != null) {
            val r = MotionProbe.shift(prev, luma, pW, pH)
            if (r != null && r[2] > 0.3) stab.addMotion(prevLumaTs, ts, r[0], r[1])
        }
        prevLuma = luma
        prevLumaTs = ts
        if (++probeCount % 20 == 0) stab.requestCalibrate(p.eisFocal.toDouble() * pW / srcW)
    }

    private val eisMats = FloatArray((GyroStabilizer.BANDS + 1) * 9)
    private var eisOk = false
    
    private fun nrTex(w: Int, h: Int, internal: Int, filter: Int): Int {
        val a = IntArray(1); GLES30.glGenTextures(1, a, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, a[0])
        GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, 1, internal, w, h)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, filter)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, filter)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        return a[0]
    }

    private fun nrFbo(vararg tex: Int): Int {
        val a = IntArray(1); GLES30.glGenFramebuffers(1, a, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, a[0])
        val att = IntArray(tex.size) { GLES30.GL_COLOR_ATTACHMENT0 + it }
        tex.forEachIndexed { i, t -> GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, att[i], GLES30.GL_TEXTURE_2D, t, 0) }
        GLES30.glDrawBuffers(tex.size, att, 0)
        check(GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE) { "FBO шумоподавления неполный" }
        GLES30.glClearColor(0f, 0f, 0f, 0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        return a[0]
    }

    /** NR v3 нужен только при включённом шумоподавлении; при неудаче остаётся прежний однопроходный фильтр. */
    private fun ensureNr(): Boolean {
        if (nrReady) return true
        if (nrFailed) return false
        try {
            nrHW = (srcW + 1) / 2; nrHH = (srcH + 1) / 2
            nrQW = (srcW + 3) / 4; nrQH = (srcH + 3) / 4
            progHalf = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_MESH), compile(GLES30.GL_FRAGMENT_SHADER, FS_HALF))
            progMask = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_QUAD), compile(GLES30.GL_FRAGMENT_SHADER, FS_MASK))
            progSpat = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_QUAD), compile(GLES30.GL_FRAGMENT_SHADER, FS_SPAT))
            progTemp = linkProgram(compile(GLES30.GL_VERTEX_SHADER, VS_MESH), compile(GLES30.GL_FRAGMENT_SHADER, FS_TEMP))
            nrAvg = nrTex(nrHW, nrHH, GLES30.GL_RGBA8, GLES30.GL_LINEAR)
            nrMM = nrTex(nrHW, nrHH, GLES30.GL_RG8, GLES30.GL_NEAREST)
            nrSpat = nrTex(nrHW, nrHH, GLES30.GL_RGBA8, GLES30.GL_LINEAR)
            for (i in 0..1) nrMaskTex[i] = nrTex(nrQW, nrQH, GLES30.GL_RG8, GLES30.GL_LINEAR)
            nrSigmaTex = nrTex(64, 1, GLES30.GL_R16F, GLES30.GL_LINEAR)
            val lut = FloatArray(64) { Math.sqrt(1.5e-4 * (it / 63.0) + 4e-6).toFloat() }
            val fb = java.nio.ByteBuffer.allocateDirect(256).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
            fb.put(lut).position(0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, nrSigmaTex)
            GLES30.glTexSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, 64, 1, GLES30.GL_RED, GLES30.GL_FLOAT, fb)
            nrHalfFbo = nrFbo(nrAvg, nrMM)
            nrSpatFbo = nrFbo(nrSpat)
            for (i in 0..1) nrMaskFbo[i] = nrFbo(nrMaskTex[i])
            nrReady = true
            return true
        } catch (e: Exception) {
            nrFailed = true
            Log.e(TAG, "NR v3 init failed", e)
            onNotice?.invoke("Шумоподавление v3 недоступно, используется упрощённое: ${e.message}")
            return false
        }
    }

    private fun setMeshUniforms(p: GlParams, eisOn: Boolean) {
        GLES30.glUniformMatrix4fv(loc("uTexMat"), 1, false, tm, 0)
        GLES30.glUniform1i(loc("uRot"), rotQuarter(p, 0))
        GLES30.glUniform1i(loc("uEis"), b(eisOn))
        GLES30.glUniform1i(loc("uBands"), GyroStabilizer.BANDS)
        GLES30.glUniform2f(loc("uT0"), lockT[0], lockT[1])
        GLES30.glUniform2f(loc("uT1"), lockT[2], lockT[3])
        GLES30.glUniform2f(loc("uT2"), lockT[4], lockT[5])
        if (eisOn) {
            val f = p.eisFocal
            val cr = max(p.eisCrop, 1f)
            GLES30.glUniformMatrix3fv(loc("uR[0]"), GyroStabilizer.BANDS + 1, false, eisMats, 0)
            GLES30.glUniform2f(loc("uA"), (srcW / 2f) / (f * cr), (srcH / 2f) / (f * cr))
            GLES30.glUniform2f(loc("uB"), f / (srcW / 2f), f / (srcH / 2f))
        }
    }

    private fun drawMesh() {
        val per = 2 * (MESH_COLS + 1)
        for (r in 0 until GyroStabilizer.BANDS) GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, r * per, per)
    }

    private fun bindTex(unit: Int, id: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id)
    }

    private fun frontPass(p: GlParams, ts: Long, stab: GyroStabilizer?): Boolean {
        if (!ensureFront()) return false
        val useV3 = p.nr > 0 && ensureNr()
        val eisOn = p.eis && p.eisFocal > 1f
        if (stab != null && stab.lockEnable) stab.lockT(lockT) else java.util.Arrays.fill(lockT, 0f)
        if (eisOn) {
            stab?.onFrameArrival(ts, SystemClock.elapsedRealtimeNanos())
            eisOk = stab?.warpAt(ts, eisMats) ?: false
            if (!eisOk) {
                for (m in 0..GyroStabilizer.BANDS) {
                    val o = m * 9
                    for (k in 0..8) eisMats[o + k] = if (k == 0 || k == 4 || k == 8) 1f else 0f
                }
            }
            if (p.eisFrame > 0) publishFrame(p, if (p.eisFrame == 2 && eisOk) eisMats else null)
        }
        val dt = if (lastFrontTs > 0L && ts > lastFrontTs) ((ts - lastFrontTs).toDouble() / frameNs).toFloat().coerceIn(1f, 8f) else 1f
        lastFrontTs = ts
        if (useV3) nrChain(p, eisOn) else singlePass(p, eisOn, dt)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        return true
    }

    /** Без шумоподавления (или запасной вариант): один проход — варп камеры в текстуру кадра. */
    private fun singlePass(p: GlParams, eisOn: Boolean, dt: Float) {
        val prevIdx = 1 - fIdx
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fFbo[fIdx])
        GLES30.glViewport(0, 0, srcW, srcH)
        curProg = progF
        GLES30.glUseProgram(progF)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniform1i(loc("uTex"), 0)
        bindTex(2, fTex[prevIdx])
        GLES30.glUniform1i(loc("uPrev"), 2)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        setMeshUniforms(p, eisOn)
        GLES30.glUniform1i(loc("uNr"), p.nr)
        GLES30.glUniform1f(loc("uSigma"), (nrSigma * (if (p.nr >= 3) 1.9f else if (p.nr == 2) 1.4f else 1f)).coerceIn(0.008f, 0.25f))
        GLES30.glUniform1f(loc("uDt"), dt)
        GLES30.glUniform1i(loc("uHavePrev"), if (p.nr > 0 && havePrev) 1 else 0)
        GLES30.glUniform2f(loc("uStep"), 1f / srcW, 1f / srcH)
        drawMesh()
    }

    /** NR v3: ½-проход (среднее и min/max), маска движения (¼), пространственный фильтр (½), временной с клампом истории. */
    private fun nrChain(p: GlParams, eisOn: Boolean) {
        val ext = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        val (aY, aC, k, wSpat, rangeK) = when (p.nr) {
            1 -> floatArrayOf(0.30f, 0.15f, 2.5f, 0.6f, 2.0f)
            2 -> floatArrayOf(0.15f, 0.07f, 2.5f, 0.8f, 2.0f)
            else -> floatArrayOf(0.08f, 0.04f, 2.5f, 1.0f, 2.5f)
        }
        val sigScale = (nrSigma / 0.012f).coerceIn(0.5f, 8f)
        val mr = nrMaskIdx; val mw = 1 - nrMaskIdx

        // 1: ½-разрешение
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, nrHalfFbo)
        GLES30.glViewport(0, 0, nrHW, nrHH)
        curProg = progHalf; GLES30.glUseProgram(progHalf)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(ext, tex)
        GLES30.glUniform1i(loc("uCur"), 0)
        GLES30.glUniform2f(loc("uSrcTexel"), 1f / srcW, 1f / srcH)
        setMeshUniforms(p, eisOn)
        drawMesh()

        // 2: маска движения (¼)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, nrMaskFbo[mw])
        GLES30.glViewport(0, 0, nrQW, nrQH)
        curProg = progMask; GLES30.glUseProgram(progMask)
        bindTex(0, nrAvg); bindTex(1, nrMaskTex[mr]); bindTex(2, nrSigmaTex)
        GLES30.glUniform1i(loc("uAvg"), 0); GLES30.glUniform1i(loc("uPrev"), 1); GLES30.glUniform1i(loc("uSigma"), 2)
        GLES30.glUniform2f(loc("uQTexel"), 1f / nrQW, 1f / nrQH)
        GLES30.glUniform1f(loc("uK"), k); GLES30.glUniform1f(loc("uSigScale"), sigScale)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

        // 3: пространственный фильтр только в зонах движения (½)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, nrSpatFbo)
        GLES30.glViewport(0, 0, nrHW, nrHH)
        curProg = progSpat; GLES30.glUseProgram(progSpat)
        bindTex(0, nrAvg); bindTex(1, nrMaskTex[mw]); bindTex(2, nrSigmaTex)
        GLES30.glUniform1i(loc("uAvg"), 0); GLES30.glUniform1i(loc("uMask"), 1); GLES30.glUniform1i(loc("uSigma"), 2)
        GLES30.glUniform2f(loc("uHTexel"), 1f / nrHW, 1f / nrHH)
        GLES30.glUniform1f(loc("uRangeK"), rangeK); GLES30.glUniform1f(loc("uSigScale"), sigScale)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

        // 4: временной фильтр (полное разрешение), история — предыдущая текстура кадра
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fFbo[fIdx])
        GLES30.glViewport(0, 0, srcW, srcH)
        curProg = progTemp; GLES30.glUseProgram(progTemp)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(ext, tex)
        bindTex(1, fTex[1 - fIdx]); bindTex(2, nrMM); bindTex(3, nrMaskTex[mw]); bindTex(4, nrSpat); bindTex(5, nrSigmaTex)
        GLES30.glUniform1i(loc("uCur"), 0); GLES30.glUniform1i(loc("uHist"), 1); GLES30.glUniform1i(loc("uMM"), 2)
        GLES30.glUniform1i(loc("uMask"), 3); GLES30.glUniform1i(loc("uSpat"), 4); GLES30.glUniform1i(loc("uSigma"), 5)
        GLES30.glUniform2f(loc("uHalfSize"), nrHW.toFloat(), nrHH.toFloat())
        GLES30.glUniform1f(loc("uAY"), aY); GLES30.glUniform1f(loc("uAC"), aC)
        GLES30.glUniform1f(loc("uK"), k); GLES30.glUniform1f(loc("uWSpat"), wSpat)
        GLES30.glUniform1f(loc("uReset"), if (havePrev) 0f else 1f)
        GLES30.glUniform1f(loc("uSigScale"), sigScale)
        setMeshUniforms(p, eisOn)
        drawMesh()
        nrMaskIdx = mw
    }

    private fun scope(p: GlParams) {
        val w = p.scopeW.coerceIn(32, 1024); val h = p.scopeH.coerceIn(18, 576)
        val now = System.nanoTime()
        if (now - lastScopeNs < p.scopeMs * 1_000_000L) return
        lastScopeNs = now
        if (w != scW || h != scH) {
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, scopeTex)
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, w, h, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
            px = ByteBuffer.allocateDirect(w * h * 4); scW = w; scH = h
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glViewport(0, 0, w, h)
        draw(p, 2)
        px.clear()
        GLES30.glReadPixels(0, 0, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, px)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        val bins = IntArray(64)
        px.rewind()
        val cb = onScopePixels
        if (cb != null) { val arr = ByteArray(w * h * 4); px.get(arr); cb(arr, w, h); px.rewind() }
        for (i in 0 until w * h) {
            val r = px.get().toInt() and 255
            val g = px.get().toInt() and 255
            val bl = px.get().toInt() and 255
            px.get()
            val y = 0.2126 * r + 0.7152 * g + 0.0722 * bl
            bins[(y / 4.0).toInt().coerceIn(0, 63)]++
        }
        onHistogram(bins)
    }
}
