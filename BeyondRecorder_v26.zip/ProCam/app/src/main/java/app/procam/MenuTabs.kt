package app.procam

import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Вкладки меню «Камера», «Видео», «Цвет», «LUT», «Монитор», «Стабилизация»: вынесены из MainActivity. */
internal class MenuTabs(private val a: MainActivity) {
    private val MATCH get() = a.MATCH
    private val WRAP get() = a.WRAP
    private fun dp(v: Int) = a.dp(v)

    fun buildVideoTab() {
        val cfg = a.engine.cfg
        val sizes = a.engine.sizeOptions()
        a.toggle("Плавный старт записи",
            "В режиме «прямая запись» при старте камера на мгновение пересоздаёт сессию — картинка подвисает. Эта опция ведёт запись через GL (как LUT/EIS/NR): старт без подфриза, но чуть выше нагрев и расход батареи. Действует в SDR и LOG; нативный HLG10 остаётся прямым (там камера сама пишет 10-бит в кодек).",
            { cfg.smoothRec }) { cfg.smoothRec = it; a.prefs.edit().putBoolean("smooth_rec", it).apply(); a.idle { a.engine.restart() } }
        a.toggle("Open Gate (весь сенсор)",
            "Запись всего кадра сенсора без обрезки до 16:9 (обычно 4:3): шире угол обзора и больше пикселей по вертикали. " +
                "Снимайте «с запасом» и кадрируйте при монтаже в 16:9, 2.39:1 или вертикальное видео — рамки для этого на вкладке «Монитор». " +
                "Файлы крупнее, поддерживает не каждый телефон.",
            { cfg.openGate }, {
                if (a.engine.caps == null) ""
                else if (!a.engine.gateAvailable()) "Эта камера не отдаёт для видео кадр шире 16:9 — Open Gate недоступен (попробуйте другой объектив)"
                else if (cfg.openGate) "Пишется весь сенсор: ${sizeLabel(cfg.size)} (${aspectLabel(cfg.size)})"
                else ""
            }) { a.setOpenGate(it) }
        a.card("Важно", "Список значений не зависит от возможностей телефона: любое выбранное разрешение, частота кадров или битрейт НЕ гарантирует производительность и качество. " +
            "Высокие значения могут нагревать телефон, пропускать кадры, не стартовать или давать более слабое качество, чем ожидается. Значения со значком ⚠ телефон для текущего размера не заявляет.")
        a.drop("Разрешение", "Размер кадра записи. «4K» — стандартный UHD 3840×2160, остальные размеры подписаны цифрами. " +
            "В списке все размеры, которые отдаёт камера. ⚠ — кодек телефона такой размер не заявляет (не скрыт, но работа не гарантирована).",
            sizes.map { sizeLabel(it) + if (a.engine.sizeSupported(it)) "" else "  ⚠" }, { sizes.indexOf(cfg.size).coerceAtLeast(0) },
            { "${cfg.size.width}×${cfg.size.height} · ${aspectLabel(cfg.size)}" + if (a.engine.sizeSupported(cfg.size)) "" else "\n⚠ Кодек телефона не заявляет этот размер: запись может не стартовать или потерять кадры" }) { i ->
            a.idle { cfg.size = sizes[i]; a.engine.restart() }
        }
        val fpsList = a.engine.fpsOptions()
        a.drop("Частота кадров", "24/25 — «киношный» вид, 30 — универсальный вариант, 50/60 — плавное движение, 90–240 — для замедления при монтаже. " +
            "60, 50 и остальные стандартные значения доступны всегда, но это не гарантия: телефон может не потянуть их на выбранном размере.",
            fpsList.map { if (a.engine.fpsSupported(it)) "$it кадр/с" else "$it кадр/с  ⚠" }, { fpsList.indexOf(cfg.fps).coerceAtLeast(0) },
            { if (a.engine.fpsSupported(cfg.fps)) "" else "⚠ Телефон не заявляет ${cfg.fps} к/с для ${cfg.size.width}×${cfg.size.height}: запись может не стартовать, терять кадры или греться" }) { i ->
            a.idle { cfg.fps = fpsList[i]; a.engine.restart() }
        }
        a.drop("Кодек", "HEVC (H.265) — примерно вдвое экономнее H.264 при том же качестве и нужен для 10-bit. H.264 — максимальная совместимость с любыми плеерами и редакторами.",
            listOf("HEVC (H.265)", "H.264 (AVC)"), { cfg.codec.ordinal }) { i ->
            a.idle { cfg.codec = Codec.values()[i]; a.engine.restart() }
        }
        val qLabels = listOf("Минимальное", "Низкое", "Среднее", "Высокое", "Максимальное")
        val qIdx = listOf(4, 0, 1, 2, 3)
        a.drop("Качество (битрейт)", "Чем выше качество, тем чище картинка и больше файл. Для цветокоррекции и LOG берите «Высокое» и выше. Это не гарантирует результат: итог зависит от кодека телефона.",
            qLabels, { qIdx.indexOf(cfg.bppIdx).coerceAtLeast(0) }, { "≈ ${a.estMbps()} Мбит/с для текущих настроек" }) { i -> cfg.bppIdx = qIdx[i]; a.saveQuality() }
        a.drop("Пресет качества", "Быстрый набор: Эконом — VBR низкий битрейт; Стандарт — сбалансированно; Кино — CQ + короткий GOP + B-кадры для монтажа; Максимум — CBR высокий битрейт.",
            listOf("Эконом", "Стандарт", "Кино", "Максимум"), { cfg.qualityPreset }) { i -> a.applyQualityPreset(i) }
        a.drop("Режим битрейта", "VBR — переменный (эффективно), CBR — постоянный (предсказуемый размер/стрим), CQ — постоянное качество (лучше для монтажа, размер плавает). Если кодек телефона режим не поддерживает, пишется VBR.",
            listOf("VBR — переменный", "CBR — постоянный", "CQ — постоянное качество"), { cfg.bitrateMode }) { i -> cfg.bitrateMode = i; a.saveQuality() }
        val mbps = listOf(5, 8, 10, 12, 15, 20, 25, 30, 40, 50, 60, 70, 80, 100, 120, 150, 200, 250, 300)
        a.drop("Битрейт", "Авто — формула от разрешения и частоты кадров. Ручной — фиксированный потолок (Мбит/с); выше = чище градиенты и меньше артефактов в движении. Очень высокие значения телефон может не принять или ограничить сам.",
            listOf("Авто") + mbps.map { "$it Мбит/с" },
            { if (cfg.bitrateKbps == 0) 0 else mbps.indices.minByOrNull { abs(mbps[it] * 1000 - cfg.bitrateKbps) }!! + 1 }) { i ->
            cfg.bitrateKbps = if (i == 0) 0 else mbps[i - 1] * 1000; a.saveQuality()
        }
        val gops = floatArrayOf(0.25f, 0.5f, 1f, 1.5f, 2f, 3f, 4f)
        a.drop("GOP (ключевой кадр)", "Короткий GOP — легче монтаж и перемотка, больше размер; длинный — эффективнее сжатие.",
            gops.map { "${if (it == it.toInt().toFloat()) it.toInt().toString() else it.toString()} с" },
            { gops.indices.minByOrNull { abs(gops[it] - cfg.gopSec) }!! }) { i -> cfg.gopSec = gops[i]; a.saveQuality() }
        a.toggle("B-кадры", "Двустороннее предсказание: лучше сжатие при том же битрейте. Не все кодеки принимают; при отказе пишется без них.", { cfg.bFrames }) { cfg.bFrames = it; a.saveQuality() }
        val aud = listOf(64, 96, 128, 160, 192, 256, 320)
        a.drop("Битрейт звука", "Выше = чище речь и атмосфера (кбит/с, AAC).", aud.map { "$it кбит/с" },
            { aud.indices.minByOrNull { abs(aud[it] - cfg.audioKbps) }!! }) { i -> cfg.audioKbps = aud[i]; a.saveQuality() }
        a.toggle("Звук", "Запись со встроенного микрофона (AAC 192 кбит/с, стерео — если телефон отдаёт).", { cfg.audio }) { cfg.audio = it; a.updateMeter() }
    }

    fun buildColorTab() {
        val cfg = a.engine.cfg
        a.seg("Режим записи", "SDR — обычная картинка Rec.709, готова к просмотру. LOG — плоская картинка с запасом по теням и светам для цветокоррекции. HLG — HDR-запись (BT.2020 + HLG), выглядит правильно на HDR-экранах.",
            listOf("SDR", "LOG", "HLG"), { cfg.mode.ordinal }) { i ->
            a.idle { cfg.mode = Mode.values()[i]; a.engine.restart() }
        }
        a.seg("LOG-кривая", "Какую логарифмическую кривую писать. Выбирайте ту, под которую сделан ваш LUT: S-Log3, V-Log или LogC. Flat — простая универсальная плоская кривая. Работает в режиме LOG.",
            Curve.values().map { it.label }, { cfg.curve.ordinal }) { i -> cfg.curve = Curve.values()[i]; a.engine.update() }
        a.seg("Яркость LOG", "Эмулируемый LOG кладёт SDR-картинку в нижние ~60% диапазона, поэтому ролик выглядит тёмным и вялым — так устроены S-Log3, V-Log и LogC. " +
            "«+1»/«+2» поднимают картинку перед кривой (данные не обрезаются). LUT при этом получает «чистую» кривую, его look не меняется. " +
            "0 — точная стандартная кривая. Действует и в режиме «Камера (HW)».",
            listOf("0", "+1 EV", "+2 EV", "+3 EV"), { a.engine.cfg.logEv },
            { if (cfg.mode != Mode.LOG) "Применяется в режиме LOG" else "" }) { i -> a.setLogEv(i) }
        a.seg("Источник LOG", "Шейдер — кривая считается в приложении, работает на любом телефоне, но новых деталей в светах и тенях не добавляет. Камера — телефон сам применяет tone-кривую: картинка реально плоская и деталей больше, но запись идёт напрямую, поэтому LUT в файл запечь нельзя (только превью).",
            listOf("Шейдер (SW)", "Камера (HW)"), { if (cfg.hwLog && a.engine.caps?.hwLog == true) 1 else 0 },
            { if (a.engine.caps?.hwLog == true) "" else "Этот телефон не принимает аппаратную tone-кривую — работает шейдер" }) { i ->
            a.idle {
                if (i == 1 && a.engine.caps?.hwLog != true) a.toast("Аппаратная tone-кривая недоступна")
                else { cfg.hwLog = i == 1; a.engine.restart() }
            }
        }
        a.seg("Источник HLG", "Нативный — настоящий 10-bit HLG10 от камеры (Android 13+ и поддержка в телефоне). Эмуляция — HLG считается шейдером из обычной SDR-картинки: файл помечен как HLG, но динамического диапазона больше не становится.",
            listOf("Нативный", "Эмуляция"), { if (cfg.emuHlg || a.engine.caps?.hlg10Native != true) 1 else 0 },
            { if (a.engine.caps?.hlg10Native == true) "" else "Нативный HLG10 на этом телефоне недоступен — используется эмуляция" }) { i ->
            a.idle {
                if (i == 0 && a.engine.caps?.hlg10Native != true) a.toast("Нативный HLG10 не поддерживается")
                else { cfg.emuHlg = i == 1; a.engine.restart() }
            }
        }
        a.toggle("10-bit для эмуляции", "Экспериментально: запись эмулируемых LOG/HLG в 10-bit (только HEVC). Меньше бандинга в градиентах. Если телефон не примет 10-bit, будет 8-bit.", { cfg.tenBitEmu }) { v ->
            a.idle { cfg.tenBitEmu = v; a.engine.restart() }
        }
    }

    fun buildLutTab() {
        val cfg = a.engine.cfg
        a.toggle("Применять LUT к видео",
            "Вкл — LUT «запекается» в файл: ролик записывается сразу с look-ом LUT, убрать его потом нельзя. " +
                "Выкл — файл пишется без LUT (чистый SDR/LOG), а LUT виден только на экране; наложить его можно при монтаже.",
            { cfg.lutMode == 2 }, { a.lutBakeNote() }) { a.setLutBake(it) }

        val box = a.card("Список LUT",
            "Файлы .cube (3D, размер 2…65). Нажмите на LUT, чтобы выбрать его, ✕ — убрать из списка (сам файл не удаляется). " +
                "Быстро переключать LUT по кругу можно кнопкой «LUT» в нижней полосе.")
        a.lutRow(box, "Без LUT", "", a.lutLib.activeUri == null, null)
        for (e in a.lutLib.items) a.lutRow(box, e.name, if (e.size > 0) "${e.size}³" else "", e.uri == a.lutLib.activeUri, e)
        val add = a.flatButton("+  Добавить файлы .cube", 13f)
        a.segStyle(add, false)
        add.setOnClickListener { a.pickLutFiles() }
        box.addView(add, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })

        a.toggle("Показывать LUT на экране",
            "Включает LUT в превью, чтобы видеть итоговую картинку. На записанный файл это не влияет — за файл отвечает переключатель «Применять LUT к видео».",
            { cfg.lutMode != 0 }, { if (a.lutLib.activeUri != null && cfg.lutMode == 0) "LUT выбран, но на экране выключен" else "" }) { a.setLutPreview(it) }
        a.seg("Вход LUT", "LOG — LUT получает сигнал в выбранной LOG-кривой (для технических LUT вроде «S-Log3 → Rec.709»). Rec.709 — для обычных творческих LUT, рассчитанных на Rec.709.",
            listOf("LOG", "Rec.709"), { if (cfg.lutInLog) 0 else 1 }) { i ->
            a.idle {
                cfg.lutInLog = i == 0
                a.saveLutPrefs()
                a.engine.lutConfigChanged()
            }
        }
        buildLutAdvanced()
    }

    /** LUT Engine 2.0: интерполяция, пространства входа/выхода, интенсивность, раздельные режимы монитор/запись. */
    fun buildLutAdvanced() {
        val cs = a.colorSettings
        val cfg = a.engine.cfg
        fun put(k: String, v: Any) { cs.set(k, v); a.engine.update() }
        val act = a.lutLib.active()
        a.card("Выбранный LUT", if (act == null) "LUT не выбран" else "«${act.name}» · размер ${act.size}${if (act.size > 0) "" else " (1D/3D определяется при загрузке)"} · поддерживаются 1D и 3D .cube любого размера в пределах памяти и лимита GPU-текстуры")
        a.seg("Куда применять LUT", "Монитор — только экран. Запись — только файл (на экране LUT нет). Оба — и там, и там. Запись возможна только на GL-маршруте.",
            listOf("Выкл", "Монитор", "Монитор + запись", "Только запись"), { cfg.lutMode }) { i ->
            a.idle { cfg.lutMode = i; a.saveLutPrefs(); a.engine.lutConfigChanged() }
        }
        a.seg("Интерполяция", "Трилинейная — аппаратная, быстрая. Тетраэдральная — точнее на нейтральной оси и диагоналях (читает 4 узла, дороже). 1D LUT всегда линейная.",
            listOf("Трилинейная", "Тетраэдральная"), { cs.i("c26_lut_interp") }) { put("c26_lut_interp", it) }
        a.seg("Пространства LUT (вход → выход)", "Если LUT сделан под другую кривую, выберите пару. Первый вариант — как в v0.25: LUT получает LOG съёмки, его выход пишется как есть.",
            LutIo.presets.map { it.first }, { cs.i("c26_lut_io") }) { put("c26_lut_io", it) }
        val b = a.card("Интенсивность LUT", "0 — без LUT, 1 — полностью.")
        val row = android.widget.SeekBar(a); row.max = 100; row.progress = (cs.f("c26_lut_mix") * 100).toInt()
        val lab = android.widget.TextView(a); lab.setTextColor(Ui.text); lab.textSize = 12f; lab.text = "${row.progress}%"
        row.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: android.widget.SeekBar?, p: Int, user: Boolean) { if (user) { lab.text = "$p%"; put("c26_lut_mix", p / 100f) } }
            override fun onStartTrackingTouch(s: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(s: android.widget.SeekBar?) {}
        })
        b.addView(lab); b.addView(row)
    }

    fun buildMonitorTab() {
        val cfg = a.engine.cfg
        a.seg("Сетка", "Направляющие поверх превью (в видео не попадают). Помогают с композицией и ровным горизонтом.",
            Grid.values().map { it.label }, { a.gridIdx }, { Grid.values()[a.gridIdx].desc }) { i -> a.setGrid(i) }
        a.seg("Рамка кадрирования", "Показывает, какая часть кадра останется после обрезки до выбранного формата (за рамкой экран затемнён). В видео не попадает. Лучше всего вместе с Open Gate.",
            Guide.values().map { it.label }, { a.guideIdx }, { Guide.values()[a.guideIdx].desc }) { i -> a.setGuide(i) }
        a.toggle("Уровень (горизонт)", "Линия горизонта по датчикам телефона: зелёная — кадр ровный (±1°). Для альбомной съёмки.",
            { a.levelView.active }, { if (a.levelView.available) "" else "В этом телефоне нет акселерометра" }) { a.toggleLevel(it) }
        a.seg("Зебра", "Штрихует кадр там, где яркость выше порога. Нужна, чтобы не «сжечь» света: 95–100% — уже почти пересвет.",
            listOf("Выкл", "90%", "95%", "100%"), { a.zebraIdx() }) { i -> a.setZebra(i) }
        a.toggle("Focus peaking", "Красным подсвечивает резкие края — помогает точно навести ручной фокус.", { cfg.peaking }) { cfg.peaking = it; a.engine.update() }
        a.toggle("False color", "Раскрашивает кадр по яркости: синий и фиолетовый — тёмные тени, зелёный — средние тона (кожа), жёлтый и красный — света и пересвет.", { cfg.falseColor }) { cfg.falseColor = it; a.engine.update() }
        a.toggle("Шкалы звука (L / R)", "Две вертикальные шкалы слева на превью — уровень левого и правого канала микрофона в дБ (0 — потолок, выше начинаются искажения; верхний сегмент загорается при перегрузке). Видны, когда включён звук. Без записи микрофон слушается отдельно, во время записи шкалы показывают то, что реально пишется в файл.",
            { a.prefs.getBoolean("audio_meter", true) }, { if (cfg.audio) "" else "Звук выключен на вкладке «Запись»" }) { a.prefs.edit().putBoolean("audio_meter", it).apply(); a.updateMeter() }
        a.toggle("Гистограмма", "Распределение яркости в кадре: пик у правого края — пересвет, у левого — провалы в тенях.", { cfg.hist }) { cfg.hist = it; a.engine.update() }
        a.seg("Просмотр", "709 — картинка, как она будет выглядеть после коррекции или LUT. LOG — плоская картинка, как она записывается в файл (удобно оценивать экспозицию).",
            listOf("709", "LOG"), { if (cfg.viewLog) 1 else 0 }) { i -> cfg.viewLog = i == 1; a.engine.update() }
    }

    fun buildStabTab() {
        val cfg = a.engine.cfg
        a.toggle("Frame Lock (доводка по изображению)",
            "Замкнутый контур: приложение сравнивает предыдущий и текущий стабилизированный кадр и сдвигает окно кадра, удерживая картинку. Гасит остаточную тряску, ошибку синхронизации и межполосное «желе». Намеренные панорамы не трогает (высокочастотный контур).",
            { cfg.eisLock }, { if (cfg.eis == 0) "Включите стабилизацию по гироскопу" else "" }) {
            cfg.eisLock = it; a.prefs.edit().putBoolean("eis_lock", it).apply(); a.engine.update()
        }
        val isp = listOf("Авто" to 0, "Выкл" to 1, "Быстрое" to 2, "Высокое" to 3, "Мин." to 4).filter { a.engine.nrIspAvailable(it.second) }
        a.seg("Шумоподавление камеры (ISP)",
            "Штатное шумоподавление процессора камеры — работает при любой записи, нагрузки на GPU нет. «Авто» — как решит телефон; «Высокое» чище, но может смазывать мелкие детали; «Выкл» — максимум деталей и зерна (удобно, если шум чистится потом в монтаже). В списке только то, что умеет выбранный объектив.",
            isp.map { it.first }, { isp.indexOfFirst { it.second == cfg.nrIsp } }) { i -> a.setNrIsp(isp[i].second) }
        a.seg("Шумоподавление программное",
            "Фильтр в приложении: сглаживает шум внутри кадра, не трогая края, и усредняет его между кадрами там, где ничего не движется. Помогает в темноте и на высоком ISO. Сильное даёт «восковой» вид и лёгкий шлейф за быстрыми объектами. Запись идёт через GL — нагрузка на GPU выше. Лучше всего работает вместе с OIS (вкладка «Камера»).",
            listOf("Выкл", "Слабое", "Среднее", "Сильное"), { cfg.nrSoft },
            { if (cfg.nrSoft > 0 && cfg.mode == Mode.HLG) "Для программной обработки HLG записывается в режиме эмуляции" else "" }) { i -> a.setNrSoft(i) }
        a.seg("Стабилизация по гироскопу",
            "Электронная стабилизация по данным гироскопа (как в Gyroflow, но сразу при съёмке): кадр сдвигается и поворачивается так, чтобы убрать тряску рук. Платите кропом: слабая ≈ 7 %, средняя ≈ 15 %, сильная ≈ 25 %, максимальная ≈ 30 % картинки по краям; чем выше уровень, тем плавнее, но тем медленнее камера «догоняет» ваши намеренные движения. Встроенная стабилизация и OIS камеры на это время выключаются. Rolling shutter и искажения объектива не компенсируются.",
            listOf("Выкл", "Слабая", "Средняя", "Сильная", "Максимум"), { cfg.eis },
            {
                if (!a.engine.gyroAvailable()) "В телефоне нет гироскопа"
                else if (cfg.eis > 0 && a.engine.caps?.timestampRealtime == false) "Камера не отдаёт метки времени в общей шкале с гироскопом — синхронизация приблизительная, подстройте её ниже"
                else if (cfg.eis > 0 && cfg.mode == Mode.HLG) "Для программной обработки HLG записывается в режиме эмуляции"
                else ""
            }) { i -> a.setEis(i) }
        a.seg("Вид стабилизации",
            "Сглаживание — убирает тряску, но наклон кадра сохраняется (камера может «завалиться» вместе с рукой). Блокировка горизонта — кроме тряски выравнивает крен: горизонт остаётся ровным даже при наклоне телефона. Нужен больший кроп (+10 %), иначе в кадр попадут края: поэтому наклон компенсируется только в пределах запаса.",
            listOf("Сглаживание", "Блокировка горизонта"), { if (cfg.eisHorizon) 1 else 0 },
            {
                if (cfg.eisHorizon && !a.engine.horizonAvailable()) "В телефоне нет акселерометра — горизонт определить нечем"
                else if (cfg.eisHorizon && cfg.eis > 0) "Наклон компенсируется до ≈ " + listOf("", "5°", "7°", "10°", "12°")[cfg.eis.coerceIn(0, 4)] + " (кроп увеличен на 10 %)"
                else if (cfg.eisHorizon) "Включите уровень стабилизации выше"
                else ""
            }) { i -> a.setEisHorizon(i == 1) }
        a.seg("Рамка активной области",
            "Когда стабилизация включена, превью показывает весь кадр с камеры, а рамка обозначает часть, которая попадёт в видео (вне рамки затемнено). Статичная — просто показывает величину кропа. Живая — рамка двигается и поворачивается вместе со стабилизацией, так видно, как она работает и когда упирается в край. Выкл — превью показывает итоговую (обрезанную) картинку.",
            listOf("Выкл", "Статичная", "Живая"), { cfg.eisFrame }) { i -> a.setEisFrame(i) }
        val calBox = a.card("Автосинхронизация гироскопа",
            "Стабилизация работает только если время кадра и время гироскопа совпадают с точностью нескольких миллисекунд, а оси гироскопа правильно сопоставлены с осями камеры. " +
                "Приложение подбирает это само: сравнивает поворот по гироскопу с реальным сдвигом изображения в кадре. Запускается при включении стабилизации; для надёжного результата подвигайте телефон " +
                "(как при съёмке на ходу), камера должна смотреть на что-то с текстурой — не на гладкую стену и не в темноту.")
        if (a.syncStatus.isNotEmpty()) {
            val st = TextView(a)
            st.text = a.syncStatus
            st.textSize = 11f
            st.setTextColor(a.amber)
            calBox.addView(st)
        }
        val calBtn = a.flatButton("Откалибровать заново", 13f)
        a.segStyle(calBtn, false)
        calBtn.setOnClickListener { a.engine.recalibrate() }
        calBox.addView(calBtn, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
        a.seg("Синхронизация гироскопа, мс",
            "Ручная подстройка поверх автосинхронизации: сдвиг времени, по которому берутся данные гироскопа для кадра. Нужна, только если после калибровки кадр «дышит» или тряска не уходит. Положительные значения — более поздние данные гироскопа.",
            a.eisSyncChoices.map { if (it > 0) "+$it" else "$it" }, { a.eisSyncChoices.indexOf(cfg.eisSyncMs) }) { i -> a.setEisSync(a.eisSyncChoices[i]) }
        a.card("Что важно знать",
            "Лучше всего работает при выдержке не длиннее 1/60 с и достаточном свете: размытие от движения электронная стабилизация не убирает. " +
                "Стабилизация и программное шумоподавление работают в режимах SDR, LOG и эмулируемого HLG; нативный 10-bit HLG10 при их включении не используется. " +
                "Включение и выключение перезапускает камеру, поэтому во время записи недоступно.")
    }

    fun buildCameraTab() {
        val cfg = a.engine.cfg
        a.toggle("Фонарик", "Постоянный свет вспышки — для тёмных помещений и заброшек. Тот же переключатель — кнопка «ФОНАРИК» в правой панели.", { cfg.torch }) { cfg.torch = it; a.engine.update() }
        if (a.lenses.size > 1) {
            a.drop("Объективы", "Камеры телефона определяются автоматически: фронтальная, сверхширокая, основная, теле. Выбор объектива подставляется под зум: кнопки показывают кратности объективов (0.6×, 1×, 3× …), " +
                "а если вести ползунок, объектив меняется сам — например, основной кропит до 2.9×, а с 3× включается телевик. Смена работает и во время записи (в записи через GL): на 0.5–1 с остаётся последний кадр, звук не прерывается.",
                a.lenses.map { it.label }, { a.lenses.indexOfFirst { it.id == cfg.cameraId }.coerceAtLeast(0) }) { i ->
                val l = a.lenses[i]
                a.engine.switchLens(l.id, l.zLo.coerceAtLeast(1f).coerceAtMost(l.zHi))
            }
        }
        val curName = a.lenses.firstOrNull { it.id == cfg.cameraId }?.label ?: "камера ${cfg.cameraId}"
        a.toggle("Перевернуть модуль на 180°",
            "Настройка текущего модуля: $curName. На некоторых телефонах (например, Vivo) картинка отдельных объективов может идти вверх ногами. Включите — и она развернётся в превью и в записанном видео (метка поворота файла). " +
                "Настройка запоминается отдельно для каждого модуля. Зеркальное отражение пока не поддерживается.",
            { cfg.flipped() }) { on ->
            cfg.lensFlip[cfg.cameraId] = on
            a.prefs.edit().putBoolean("lens_flip_${cfg.cameraId}", on).apply()
            a.engine.update()
        }
        val zoomOpts = listOf(10, 20, 30, 50, 100)
        a.seg("Максимальный зум",
            "Верхний предел зума для ползунка, кнопок и щипка. По умолчанию 10×, можно поднять до 100×. Всё, что выше аппаратного зума камеры, включается цифровым кропом центра кадра — картинка мягче и шумнее — и помечено жёлтым «!». " +
                "Цифровой зум работает через GL (как LUT, EIS и шумоподавление): при выходе за аппаратный предел камера перезапускается на один-два кадра паузы. " +
                "Если запись уже идёт в прямом режиме, выйти за аппаратный предел нельзя — остановите запись или включите «Плавный старт записи». На большом зуме нужен штатив.",
            zoomOpts.map { "$it×" }, { zoomOpts.indexOf(a.prefs.getInt("zoom_max", 10)).coerceAtLeast(0) },
            {
                val c = a.engine.caps
                if (c != null && a.zoomCap() > c.zoomRange.upper + 0.01f) "Аппаратный зум этой камеры — до ${a.fmtZoom(c.zoomRange.upper)}×, выше — цифровой кроп («!»)" else ""
            }) { i ->
            a.prefs.edit().putInt("zoom_max", zoomOpts[i]).apply()
            a.refreshControls()
        }
        a.seg("Стабилизация камеры",
            "Выкл — со штатива. OIS — оптическая стабилизация линзой: не кропит кадр, не мылит детали и помогает программному шумоподавлению (статичная сцена стоит на месте, усреднение между кадрами работает сильнее). " +
                "OIS + EIS — дополнительно электронная стабилизация процессора: плавнее, но с кропом и лёгким «желе». " +
                "При включённой стабилизации по гироскопу обе выключаются: OIS убирает часть поворота, и гироскопический EIS вычел бы лишнее.",
            listOf("Выкл", "OIS", "OIS + EIS"), { cfg.stabMode },
            { if (cfg.eis > 0) "Сейчас не работает: включена стабилизация по гироскопу" else "" }) { i -> cfg.stabMode = i; a.engine.update() }
        val manual = a.card("Ручные настройки", "ISO, выдержка, экспозиция (EV), ручной фокус и баланс белого. Полоса появляется вверху превью; любой ползунок сам переключает параметр в ручной режим. Кнопка «РУЧН.» справа открывает её сразу.")
        val open = a.flatButton("Показать полосу", 13f)
        a.segStyle(open, false)
        open.setOnClickListener { a.closeMenu(); a.lutRibbon.close(); a.setPanel(true) }
        manual.addView(open, LinearLayout.LayoutParams(MATCH, dp(44)).apply { setMargins(dp(2), dp(8), dp(2), dp(2)) })
    }
}
