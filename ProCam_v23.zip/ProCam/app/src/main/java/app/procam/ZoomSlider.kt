package app.procam

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Зум одним контролом без фона. По умолчанию — столбик стеклянных кнопок-пресетов (0.5× 1× 2× …).
 * Если повести пальцем по кнопкам, кнопки плавно уступают место ползунку (логарифмическая шкала);
 * после отпускания ползунок через ~1,6 с снова превращается в кнопки. Долгий тап по ползунку — сброс к 1×.
 */
class ZoomSlider(ctx: Context) : View(ctx) {
    var onChange: ((Float) -> Unit)? = null   // во время тяги (можно дросселировать)
    var onCommit: (() -> Unit)? = null        // палец отпущен
    var onPreset: ((Float) -> Unit)? = null   // тап по кнопке-пресету

    private var lower = 1f
    private var upper = 10f
    private var hwMax = Float.MAX_VALUE          // предел, который реально отдаёт камера; выше — жёлтый «!»
    private val warn = 0xFFFFC107.toInt()
    private fun over(z: Float) = z > hwMax + 0.01f
    private var value = 1f
    private var btnPresets: List<Float> = emptyList()   // сверху вниз: от дальнего к широкому
    private val px = resources.displayMetrics.density
    private fun dp(v: Float) = v * px
    private val slop = dp(8f)

    private val white = 0xFFFFFFFF.toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(dp(3f), 0f, dp(1f), 0x99000000.toInt())
    }
    private val rect = RectF()
    private var dragging = false
    private var pressIdx = -1
    private var downY = 0f
    private var sliding = false          // активен режим ползунка
    private var mix = 0f                 // 0 = кнопки, 1 = ползунок
    private var mixAnim: ValueAnimator? = null
    private var dropPos = -1f            // индекс активной кнопки (дробный, для «капли»)
    private var dropAnim: ValueAnimator? = null
    private var dropTarget = -1
    private val backToButtons = Runnable { setSliding(false) }

    private val gesture = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onLongPress(e: MotionEvent) {
            if (!sliding) return
            val target = 1f.coerceIn(lower, upper)
            value = target
            onChange?.invoke(value)
            onCommit?.invoke()
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            invalidate()
        }
    })

    /** Аппаратный максимум зума камеры: значения выше него помечаются жёлтым восклицательным знаком. */
    fun setHwLimit(v: Float) { hwMax = v; invalidate() }

    fun setRange(l: Float, u: Float) {
        lower = l.coerceAtLeast(0.1f)
        upper = u.coerceAtLeast(lower + 0.01f)
        value = value.coerceIn(lower, upper)
        dropAnim?.cancel()
        if (btnPresets.isNotEmpty()) dropPos = nearIdx().toFloat()
        invalidate()
    }

    /** Кнопки-пресеты; порядок на экране — по убыванию, как шкала. */
    fun setPresets(p: List<Float>) {
        btnPresets = p.sortedDescending()
        dropAnim?.cancel()
        dropPos = nearIdx().toFloat()
        invalidate()
    }

    fun setValue(v: Float) {
        val nv = v.coerceIn(lower, upper)
        // идёт плавный переезд к этому же значению — не обрываем его повторным вызовом извне
        if (anim?.isRunning == true && abs(zoomToT(nv) - zoomToT(animTarget)) < 0.002f) return
        anim?.cancel()
        squash = 0f
        value = nv
        moveDrop(nearIdx())
        invalidate()
    }

    private var anim: ValueAnimator? = null
    private var animTarget = 1f
    private var squash = 0f

    /** Плавный переезд ползунка (тап по пресету): бегунок тянется, как капля, и оседает с перелётом. */
    fun setValueAnimated(v: Float) {
        val target = v.coerceIn(lower, upper)
        anim?.cancel()
        val t0 = zoomToT(value)
        val t1 = zoomToT(target)
        animTarget = target
        if (dragging || abs(t1 - t0) < 0.002f || !animationsEnabled()) { value = target; squash = 0f; moveDrop(nearIdxFor(target)); invalidate(); return }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 520
        a.interpolator = Spring(7f, 10f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            value = tToZoom(t0 + (t1 - t0) * f)
            squash = sin(Math.PI * it.animatedFraction.coerceIn(0f, 1f)).toFloat() * abs(t1 - t0).coerceAtMost(0.5f) * 2f
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) { squash = 0f; invalidate() }
        })
        anim = a
        a.start()
        // капля едет к кнопке по ЦЕЛЕВОМУ значению (value на старте ещё старое)
        moveDrop(nearIdxFor(target))
    }

    private fun animationsEnabled(): Boolean = try {
        android.provider.Settings.Global.getFloat(context.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
    } catch (e: Exception) { true }

    private fun nearIdxFor(v: Float): Int =
        if (btnPresets.isEmpty()) -1 else btnPresets.indices.minByOrNull { abs(ln(btnPresets[it] / v)) } ?: -1
    private fun nearIdx(): Int = nearIdxFor(value)

    /** «Капля» активной кнопки переезжает к кнопке n; в конце всегда садится ровно на неё. */
    private fun moveDrop(n: Int) {
        if (n < 0) return
        if (dropPos < 0f || !animationsEnabled() || sliding || mix > 0.5f) {
            dropAnim?.cancel(); dropPos = n.toFloat(); dropTarget = n; invalidate(); return
        }
        // уже плывём к этой же кнопке (плавный зум вызывает setValue на каждом кадре) — не перезапускаем
        if (n == dropTarget && dropAnim?.isRunning == true) return
        if (abs(dropPos - n) < 0.01f && dropAnim?.isRunning != true) { dropPos = n.toFloat(); dropTarget = n; return }
        dropTarget = n
        val from = dropPos
        dropAnim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 480
        a.interpolator = Spring(7f, 10f)
        a.addUpdateListener { dropPos = from + (n - from) * (it.animatedValue as Float); invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) { if (!cancelled) { dropPos = n.toFloat(); invalidate() } }
        })
        dropAnim = a
        a.start()
    }

    private fun setSliding(on: Boolean) {
        removeCallbacks(backToButtons)
        sliding = on
        mixAnim?.cancel()
        dropAnim?.cancel()
        // кнопки при возврате появляются уже с каплей на нужном месте (а не «доезжают» после)
        if (!on) dropPos = nearIdx().toFloat()
        val to = if (on) 1f else 0f
        if (!animationsEnabled()) { mix = to; if (!on) dropPos = nearIdx().toFloat(); invalidate(); return }
        val from = mix
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = 260
        a.addUpdateListener { mix = it.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) { if (!on) dropPos = nearIdx().toFloat() }
        })
        mixAnim = a
        a.start()
    }

    private fun presets(): List<Float> {
        val base = if (btnPresets.isNotEmpty()) btnPresets else listOf(0.5f, 1f, 2f, 3f, 5f, 10f)
        val out = ArrayList<Float>()
        out.add(lower)
        for (p in base.sortedBy { it }) if (p > lower + 0.02f && p < upper - 0.02f) out.add(p)
        out.add(upper)
        return out
    }

    private fun fmtN(z: Float): String =
        if (z >= 10f || abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)
    private fun fmt(z: Float): String = fmtN(z) + "×"

    // ---------- геометрия ----------
    /** Шаг кнопок: 48 dp, а если колонка из пяти кнопок не помещается по высоте — чуть меньше, чтобы ничего не обрезалось. */
    private fun step() = if (btnPresets.isEmpty()) dp(48f) else minOf(dp(48f), (height - dp(4f)) / btnPresets.size)
    private fun blockH() = btnPresets.size * step()
    private fun blockTop() = (height - blockH()) / 2f
    private fun btnCy(i: Float) = blockTop() + (i + 0.5f) * step()
    private fun btnCx() = width / 2f
    private fun idxAt(y: Float): Int {
        if (btnPresets.isEmpty()) return -1
        val i = ((y - blockTop()) / step()).toInt()
        return if (y >= blockTop() && i in btnPresets.indices) i else -1
    }

    private fun topPad() = dp(26f)
    private fun botPad() = dp(14f)
    private fun trackX() = width - dp(18f)
    private fun usable() = (height - topPad() - botPad()).coerceAtLeast(dp(40f))
    private fun zoomToT(z: Float) = (ln((z / lower).toDouble()) / ln((upper / lower).toDouble())).toFloat().coerceIn(0f, 1f)
    private fun tToZoom(t: Float) = lower * (upper / lower).pow(t.coerceIn(0f, 1f))
    private fun yFor(z: Float) = topPad() + (1f - zoomToT(z)) * usable()

    /** Жёлтый кружок с «!» — значение выше аппаратного зума камеры. */
    private fun badge(cv: Canvas, x: Float, y: Float, r: Float, f: Float) {
        paint.style = Paint.Style.FILL
        paint.color = al(0xFF000000.toInt(), f * 0.35f); cv.drawCircle(x, y + dp(0.8f), r + dp(0.5f), paint)
        paint.color = al(warn, f); cv.drawCircle(x, y, r, paint)
        txt.textSize = r * 1.55f; txt.color = al(0xFF000000.toInt(), f)
        txt.clearShadowLayer()
        cv.drawText("!", x, y + r * 0.55f, txt)
    }

    private fun al(c: Int, f: Float): Int = ((c ushr 24) * f.coerceIn(0f, 1f)).toInt() shl 24 or (c and 0xFFFFFF)

    override fun onDraw(cv: Canvas) {
        if (mix < 0.995f) drawButtons(cv, 1f - mix)
        if (mix > 0.005f) drawSlider(cv, mix)
    }

    /** Стеклянные кнопки без общей подложки; активная — белая «капля» с текущим значением. */
    private fun drawButtons(cv: Canvas, f: Float) {
        if (btnPresets.size < 2) return
        val cx = btnCx()
        val r = minOf(dp(21f), step() * 0.44f)
        paint.style = Paint.Style.FILL
        for (i in btnPresets.indices) {
            val cy = btnCy(i.toFloat())
            paint.color = al(0x66000000, f); cv.drawCircle(cx, cy, r, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1f)
            paint.color = al(0x40FFFFFF, f); cv.drawCircle(cx, cy, r - dp(0.5f), paint)
            paint.style = Paint.Style.FILL
        }
        // активная капля; если анимации стоят, а капля не на «своей» кнопке — ставим её на место
        if (dropAnim?.isRunning != true && anim?.isRunning != true && nearIdx() >= 0 && abs(dropPos - nearIdx()) > 0.01f) dropPos = nearIdx().toFloat()
        val dp0 = if (dropPos < 0f) nearIdx().toFloat() else dropPos
        val cy = btnCy(dp0)
        val st = abs(dp0 - dp0.roundToInt()) * 0.5f
        rect.set(cx - r * (1f - 0.14f * st), cy - r * (1f + 0.35f * st), cx + r * (1f - 0.14f * st), cy + r * (1f + 0.35f * st))
        paint.color = al(white, f); cv.drawOval(rect, paint)
        val near = dp0.roundToInt().coerceIn(0, btnPresets.size - 1)
        for (i in btnPresets.indices) {
            val on = i == near
            txt.textSize = dp(13f)
            txt.color = al(if (on) 0xFF000000.toInt() else white, f)
            txt.clearShadowLayer(); if (!on) txt.setShadowLayer(dp(3f), 0f, dp(1f), al(0x99000000.toInt(), f))
            val s = if (on) fmt(value) else fmt(btnPresets[i])
            cv.drawText(s, cx, btnCy(i.toFloat()) + dp(4.5f), txt)
        }
        // «!» у кнопок и у капли, если значение камера аппаратно не отдаёт
        val br = dp(7.5f)
        for (i in btnPresets.indices) {
            if (i != near && over(btnPresets[i])) badge(cv, cx + r * 0.74f, btnCy(i.toFloat()) - r * 0.74f, br, f)
        }
        if (over(value)) badge(cv, cx + r * 0.74f, cy - r * 0.74f, br, f)
    }

    /** Ползунок без фона: тонкая линия, засечки, белый бегунок. */
    private fun drawSlider(cv: Canvas, f: Float) {
        val x = trackX()
        val tw = dp(4f)
        val y0 = topPad(); val y1 = height - botPad()
        paint.style = Paint.Style.FILL
        rect.set(x - tw / 2, y0, x + tw / 2, y1)
        paint.color = al(0x59FFFFFF, f); cv.drawRoundRect(rect, tw / 2, tw / 2, paint)
        val ty = yFor(value)
        val yH = if (hwMax < upper - 0.01f) yFor(hwMax) else y0
        val hasOver = hwMax < upper - 0.01f
        if (hasOver) { rect.set(x - tw / 2, y0, x + tw / 2, yH); paint.color = al(0x66FFC107, f); cv.drawRect(rect, paint) }
        rect.set(x - tw / 2, ty, x + tw / 2, y1)
        paint.color = al(white, f); cv.drawRoundRect(rect, tw / 2, tw / 2, paint)
        if (hasOver && over(value)) { rect.set(x - tw / 2, ty, x + tw / 2, yH); paint.color = al(warn, f); cv.drawRect(rect, paint) }
        for (p in presets()) {
            val y = yFor(p)
            val ov = over(p)
            paint.color = al(if (ov) warn else 0xCCFFFFFF.toInt(), f); paint.strokeWidth = dp(1.2f)
            cv.drawLine(x - dp(10f), y, x - dp(5f), y, paint)
            txt.textSize = dp(11f); txt.textAlign = Paint.Align.RIGHT
            txt.color = al(if (ov) warn else 0xE6FFFFFF.toInt(), f); txt.isFakeBoldText = false
            txt.setShadowLayer(dp(3f), 0f, dp(1f), al(0x99000000.toInt(), f))
            cv.drawText(fmt(p), x - dp(13f), y + dp(3.5f), txt)
        }
        txt.textAlign = Paint.Align.CENTER; txt.isFakeBoldText = true
        // бегунок-капля: при движении вытягивается по вертикали и сужается по горизонтали
        val rx = dp(10f) * (1f - 0.2f * squash)
        val ry = dp(10f) * (1f + 0.55f * squash)
        rect.set(x - rx, ty - ry, x + rx, ty + ry)
        paint.color = al(0x55000000, f); rect.offset(0f, dp(1.5f)); cv.drawOval(rect, paint); rect.offset(0f, -dp(1.5f))
        paint.color = al(white, f); cv.drawOval(rect, paint)
        txt.textSize = dp(13f); txt.color = al(white, f)
        txt.setShadowLayer(dp(3f), 0f, dp(1f), al(0x99000000.toInt(), f))
        cv.drawText(fmt(value), width / 2f, dp(16f), txt)
        if (over(value)) {
            val tw2 = txt.measureText(fmt(value))
            badge(cv, width / 2f + tw2 / 2f + dp(11f), dp(11.5f), dp(8f), f)
            badge(cv, x + rx + dp(9f), ty - ry * 0.6f, dp(7f), f)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (upper - lower < 0.02f) return false
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            // вне кнопок/полосы касание отдаём превью (фокус по тапу)
            pressIdx = if (sliding) -1 else idxAt(e.y)
            if (!sliding && pressIdx < 0) return false
            if (!sliding && abs(e.x - btnCx()) > dp(30f)) return false
            downY = e.y
            dragging = false
            removeCallbacks(backToButtons)
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        gesture.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> if (sliding) { dragging = true; applyY(e.y, false) }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.y - downY) > slop) {
                    dragging = true
                    if (!sliding) { setSliding(true); performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
                }
                if (dragging) applyY(e.y, false)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    applyY(e.y, true)
                    dragging = false
                    onCommit?.invoke()
                    performClick()
                    postDelayed(backToButtons, 1600)
                } else if (e.actionMasked == MotionEvent.ACTION_UP && pressIdx >= 0 && pressIdx < btnPresets.size) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onPreset?.invoke(btnPresets[pressIdx])
                }
                pressIdx = -1
            }
        }
        return true
    }

    private fun applyY(y: Float, snap: Boolean) {
        var t = 1f - (y - topPad()) / usable()
        t = t.coerceIn(0f, 1f)
        var z = tToZoom(t)
        if (snap) {
            val tp = zoomToT(z)
            val near = presets().minByOrNull { abs(zoomToT(it) - tp) }
            if (near != null && abs(zoomToT(near) - tp) < 0.045f) {
                z = near
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
        }
        z = z.coerceIn(lower, upper)
        if (abs(z - value) > 0.0005f) {
            value = z
            onChange?.invoke(z)
            invalidate()
        }
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
