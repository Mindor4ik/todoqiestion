package app.procam

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Электронная стабилизация по гироскопу (в духе Gyroflow, но в реальном времени).
 *
 * Гироскоп интегрируется в ориентацию реальной камеры q_a. «Виртуальная» камера q_v — это q_a, пропущенная
 * через сглаживание (два каскада экспоненциального фильтра на кватернионах). Для кадра с временем t шейдер
 * получает поворот R = R_a(t)^T · R_v(t) (из виртуальной камеры в реальную) и строит по нему гомографию.
 * Отклонение виртуальной камеры от реальной ограничено запасом кропа по каждой оси, чтобы в кадр не попадали
 * края матрицы. Эталон математики и синтетический тест — tools/eis_ref.py, проверка формул шейдера — tools/shader_chain.py.
 *
 * Ограничения: rolling shutter не компенсируется, искажения объектива не учитываются, оптическая
 * стабилизация (OIS) на время работы выключается (иначе она «двоит» коррекцию).
 */
class GyroStabilizer(ctx: Context) : SensorEventListener {
    companion object {
        private const val TAG = "ProCamGyro"
        private const val CAP = 4096                       // ~10 с истории при 400 Гц
        private const val ASSUMED_LATENCY_NS = 35_000_000L // типичная задержка кадра до GL, если часы камеры не общие с гироскопом

        fun horizonAvailable(ctx: Context): Boolean = try {
            (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager).getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        } catch (e: Exception) {
            false
        }

        fun available(ctx: Context): Boolean = try {
            (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager).getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        } catch (e: Exception) {
            false
        }
    }

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelerometer: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var thread: HandlerThread? = null
    private val lock = Any()

    // кольцевой буфер: время, ориентация реальной (qa) и виртуальной (qv) камеры
    private val ts = LongArray(CAP)
    private val qa = DoubleArray(CAP * 4)
    private val qv = DoubleArray(CAP * 4)
    private var head = 0
    private var count = 0

    // состояние интегратора (под lock)
    private var qA = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var q1 = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var q2 = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var tPrev = -1L
    private var wPrev = doubleArrayOf(0.0, 0.0, 0.0)
    private var sensorRot = 90

    @Volatile private var tau = 0.2
    @Volatile private var limX = 0.05   // тангаж (вокруг оси x камеры)
    @Volatile private var limY = 0.08   // рыскание (вокруг y)
    @Volatile private var limZ = 0.07   // крен (вокруг z)
    @Volatile private var exposureNs = 0L
    @Volatile private var skewNs = 0L
    @Volatile private var useArrival = false

    /** Блокировка горизонта: крен виртуальной камеры выравнивается по гравитации (в пределах кроп-запаса). */
    @Volatile var horizonLock = false

    // оценка направления «вверх» в мировой системе интегратора (по акселерометру, медленный фильтр)
    private var upW = doubleArrayOf(0.0, 0.0, 0.0)
    private var haveUp = false
    private var tAcc = 0L

    /** Ручная подстройка синхронизации гироскопа и кадра, нс (положительное — берём более поздние данные гироскопа). */
    @Volatile var manualOffsetNs = 0L

    // оценка сдвига часов камеры относительно гироскопа (только если камера не отдаёт REALTIME-метки). Только GL-поток.
    private var minDelta = Long.MAX_VALUE
    private var winCount = 0
    private var clockOffset = 0L
    private var haveClock = false

    fun start(sensorOrientation: Int, arrivalSync: Boolean): Boolean {
        val g = gyro ?: return false
        sensorRot = sensorOrientation
        useArrival = arrivalSync
        synchronized(lock) {
            head = 0; count = 0; tPrev = -1L; haveUp = false
            qA = doubleArrayOf(1.0, 0.0, 0.0, 0.0); q1 = qA.copyOf(); q2 = qA.copyOf()
        }
        val t = HandlerThread("procam-gyro")
        t.start()
        thread = t
        val h = Handler(t.looper)
        var ok = false
        try {
            ok = sm.registerListener(this, g, 2500, h)          // 400 Гц; выше 200 Гц нужно разрешение HIGH_SAMPLING_RATE_SENSORS
        } catch (e: Exception) {
            Log.w(TAG, "400 Hz refused: ${e.message}")
        }
        if (!ok) {
            try { ok = sm.registerListener(this, g, 5000, h) } catch (e: Exception) { Log.w(TAG, "200 Hz refused: ${e.message}") }
        }
        if (ok) accelerometer?.let { a ->
            try { sm.registerListener(this, a, 10000, h) } catch (e: Exception) { Log.w(TAG, "accelerometer refused: ${e.message}") }
        }
        if (!ok) stop()
        return ok
    }

    fun stop() {
        try { sm.unregisterListener(this) } catch (e: Exception) { }
        thread?.quitSafely()
        thread = null
    }

    /** Настройки сглаживания и допустимого отклонения (зависят от кропа, размера кадра и фокусного расстояния в пикселях). */
    fun configure(tauSec: Double, focalPx: Double, w: Int, h: Int, crop: Double) {
        tau = tauSec.coerceIn(0.02, 2.0)
        val f = max(focalPx, 100.0)
        val c = max(crop, 1.01)
        val sx = (w / 2.0) * (1.0 - 1.0 / c)
        val sy = (h / 2.0) * (1.0 - 1.0 / c)
        limY = 0.85 * atan(sx / f)
        limX = 0.85 * atan(sy / f)
        // наибольший крен, при котором повёрнутый кадр с кропом ещё целиком внутри исходного
        val ratio = max(w, h).toDouble() / min(w, h)
        var a = 0.0
        while (a < 0.6 && ratio * sin(a + 0.002) + cos(a + 0.002) <= c) a += 0.002
        limZ = 0.85 * a
    }

    /** Время экспозиции и «перекос» rolling shutter последнего кадра: середина кадра по времени = старт + (экспозиция + перекос) / 2. */
    fun setFrameTiming(exposure: Long, skew: Long) {
        exposureNs = exposure
        skewNs = skew
    }

    /** Для камер без REALTIME-меток: по минимальной задержке «метка → приход кадра» оцениваем сдвиг часов. Вызывать из GL-потока. */
    fun onFrameArrival(frameTs: Long, arrivalNs: Long) {
        if (!useArrival) return
        val d = arrivalNs - frameTs
        if (d < minDelta) minDelta = d
        if (++winCount >= 60) {
            clockOffset = minDelta
            haveClock = true
            minDelta = Long.MAX_VALUE
            winCount = 0
        }
    }

    // ---------------------------------------------------------------- сенсор

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val v = e.values
        val c = toCam(v[0].toDouble(), v[1].toDouble(), v[2].toDouble())
        when (e.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> synchronized(lock) { integrate(e.timestamp, c) }
            Sensor.TYPE_ACCELEROMETER -> synchronized(lock) { accel(e.timestamp, c) }
        }
    }

    /** Акселерометр (в осях камеры) -> направление «вверх» в мировой системе интегратора; сильные ускорения отбрасываются. */
    private fun accel(t: Long, a: DoubleArray) {
        val n = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
        if (n < 8.3 || n > 11.3) return
        val m = toMat(qA)
        val ux = a[0] / n
        val uy = a[1] / n
        val uz = a[2] / n
        val wx = m[0] * ux + m[1] * uy + m[2] * uz
        val wy = m[3] * ux + m[4] * uy + m[5] * uz
        val wz = m[6] * ux + m[7] * uy + m[8] * uz
        if (!haveUp) {
            upW = doubleArrayOf(wx, wy, wz)
            haveUp = true
            tAcc = t
            return
        }
        val dt = max((t - tAcc) * 1e-9, 0.0)
        tAcc = t
        val k = 1.0 - exp(-dt / 1.0)
        val nx = upW[0] + k * (wx - upW[0])
        val ny = upW[1] + k * (wy - upW[1])
        val nz = upW[2] + k * (wz - upW[2])
        val nn = sqrt(nx * nx + ny * ny + nz * nz)
        if (nn > 1e-9) upW = doubleArrayOf(nx / nn, ny / nn, nz / nn)
    }

    /** Довернуть виртуальную камеру вокруг оптической оси так, чтобы горизонт в кадре был ровным. */
    private fun level(qs: DoubleArray): DoubleArray {
        val m = toMat(qs)
        val ux = m[0] * upW[0] + m[3] * upW[1] + m[6] * upW[2]     // «вверх» в координатах виртуальной камеры (Mᵀ·up)
        val uy = m[1] * upW[0] + m[4] * upW[1] + m[7] * upW[2]
        val phi = atan2(ux, -uy)
        return qNorm(qMul(qs, fromRotVec(doubleArrayOf(0.0, 0.0, phi))))
    }

    private fun clampRel(q: DoubleArray): DoubleArray {
        val r = toRotVec(qMul(qConj(qA), q))
        val lx = limX; val ly = limY; val lz = limZ
        val cx = r[0].coerceIn(-lx, lx)
        val cy = r[1].coerceIn(-ly, ly)
        val cz = r[2].coerceIn(-lz, lz)
        return if (cx != r[0] || cy != r[1] || cz != r[2]) qNorm(qMul(qA, fromRotVec(doubleArrayOf(cx, cy, cz)))) else q
    }

    /** Оси устройства (x вправо, y вверх, z из экрана) -> оси камеры (x вправо в кадре, y вниз, z вперёд) по SENSOR_ORIENTATION. */
    private fun toCam(x: Double, y: Double, z: Double): DoubleArray = when (sensorRot) {
        90 -> doubleArrayOf(-y, -x, -z)
        270 -> doubleArrayOf(y, x, -z)
        180 -> doubleArrayOf(-x, y, -z)
        else -> doubleArrayOf(x, -y, -z)
    }

    private fun integrate(t: Long, w: DoubleArray) {
        if (tPrev < 0) {
            tPrev = t; wPrev = w; push(t, q2)
            return
        }
        val dt = (t - tPrev) * 1e-9
        if (dt <= 0.0 || dt > 0.1) {      // пропуск данных — не интегрируем «дыру»
            tPrev = t; wPrev = w
            return
        }
        qA = qNorm(qMul(qA, fromRotVec(doubleArrayOf(
            (w[0] + wPrev[0]) * 0.5 * dt, (w[1] + wPrev[1]) * 0.5 * dt, (w[2] + wPrev[2]) * 0.5 * dt))))
        // два каскада по tau/2: общая задержка ≈ tau, подавление высоких частот сильнее, чем у одного фильтра
        val al = 1.0 - exp(-dt / max(tau * 0.5, 1e-3))
        q1 = qNorm(qMul(q1, fromRotVec(scale(toRotVec(qMul(qConj(q1), qA)), al))))
        q2 = qNorm(qMul(q2, fromRotVec(scale(toRotVec(qMul(qConj(q2), q1)), al))))
        // ограничение отклонения виртуальной камеры от реальной по осям (запас кропа)
        val r = toRotVec(qMul(qConj(qA), q2))
        val lx = limX; val ly = limY; val lz = limZ
        val cx = r[0].coerceIn(-lx, lx)
        val cy = r[1].coerceIn(-ly, ly)
        val cz = r[2].coerceIn(-lz, lz)
        if (cx != r[0] || cy != r[1] || cz != r[2]) q2 = qNorm(qMul(qA, fromRotVec(doubleArrayOf(cx, cy, cz))))
        tPrev = t; wPrev = w
        // Блокировка горизонта работает поверх сглаживания и не попадает в его состояние (иначе обратная связь)
        push(t, if (horizonLock && haveUp) clampRel(level(q2)) else q2)
    }

    private fun push(t: Long, qOut: DoubleArray) {
        ts[head] = t
        for (k in 0..3) { qa[head * 4 + k] = qA[k]; qv[head * 4 + k] = qOut[k] }
        head = (head + 1) % CAP
        if (count < CAP) count++
    }

    private fun idx(i: Int) = (head - count + i + CAP) % CAP

    /**
     * Поворот R (из виртуальной камеры в реальную) для кадра с меткой frameTs, 3×3 в порядке «по столбцам» (как ждёт GLSL mat3).
     * false — данных нет (оставляйте единичную матрицу).
     */
    fun rotationAt(frameTs: Long, out: FloatArray): Boolean {
        if (useArrival && !haveClock) return false
        var t = frameTs + (exposureNs + skewNs) / 2 + manualOffsetNs
        if (useArrival) t += clockOffset - ASSUMED_LATENCY_NS
        return synchronized(lock) {
            if (count < 2) return@synchronized false
            if (t - ts[idx(count - 1)] > 300_000_000L) return@synchronized false     // гироскоп давно молчит
            var i0: Int
            var a: Double
            if (t <= ts[idx(0)]) {
                i0 = 0; a = 0.0
            } else if (t >= ts[idx(count - 1)]) {
                i0 = count - 2; a = 1.0
            } else {
                var lo = 0
                var hi = count - 1
                while (hi - lo > 1) {
                    val mid = (lo + hi) ushr 1
                    if (ts[idx(mid)] <= t) lo = mid else hi = mid
                }
                i0 = lo
                val t0 = ts[idx(lo)]
                val t1 = ts[idx(lo + 1)]
                a = if (t1 > t0) (t - t0).toDouble() / (t1 - t0) else 0.0
            }
            val p0 = idx(i0)
            val p1 = idx(i0 + 1)
            val qaT = nlerp(qa, p0, p1, a)
            val qvT = nlerp(qv, p0, p1, a)
            val m = toMat(qMul(qConj(qaT), qvT))
            for (c in 0..2) for (r in 0..2) out[c * 3 + r] = m[r * 3 + c].toFloat()
            true
        }
    }

    private fun nlerp(arr: DoubleArray, i0: Int, i1: Int, a: Double): DoubleArray {
        val dot = arr[i0 * 4] * arr[i1 * 4] + arr[i0 * 4 + 1] * arr[i1 * 4 + 1] +
            arr[i0 * 4 + 2] * arr[i1 * 4 + 2] + arr[i0 * 4 + 3] * arr[i1 * 4 + 3]
        val s = if (dot >= 0) 1.0 else -1.0
        return qNorm(DoubleArray(4) { k -> (1 - a) * arr[i0 * 4 + k] + a * s * arr[i1 * 4 + k] })
    }
}

// ---------------------------------------------------------------- кватернионы (w, x, y, z)

private fun qMul(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
    a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
    a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
    a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
    a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
)

private fun qConj(q: DoubleArray) = doubleArrayOf(q[0], -q[1], -q[2], -q[3])

private fun qNorm(q: DoubleArray): DoubleArray {
    val n = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    return if (n < 1e-12) doubleArrayOf(1.0, 0.0, 0.0, 0.0) else doubleArrayOf(q[0] / n, q[1] / n, q[2] / n, q[3] / n)
}

private fun scale(v: DoubleArray, k: Double) = doubleArrayOf(v[0] * k, v[1] * k, v[2] * k)

private fun fromRotVec(r: DoubleArray): DoubleArray {
    val a = sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2])
    if (a < 1e-12) return qNorm(doubleArrayOf(1.0, r[0] / 2, r[1] / 2, r[2] / 2))
    val s = sin(a / 2) / a
    return doubleArrayOf(cos(a / 2), r[0] * s, r[1] * s, r[2] * s)
}

private fun toRotVec(q0: DoubleArray): DoubleArray {
    val q = if (q0[0] < 0) doubleArrayOf(-q0[0], -q0[1], -q0[2], -q0[3]) else q0
    val n = sqrt(q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    if (n < 1e-12) return doubleArrayOf(2 * q[1], 2 * q[2], 2 * q[3])
    val k = 2 * atan2(n, q[0]) / n
    return doubleArrayOf(q[1] * k, q[2] * k, q[3] * k)
}

/** Матрица 3×3 по строкам. */
private fun toMat(q: DoubleArray): DoubleArray {
    val w = q[0]; val x = q[1]; val y = q[2]; val z = q[3]
    return doubleArrayOf(
        1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w),
        2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
        2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)
    )
}
